import React, { useEffect, useRef, useState } from "react";
import { CallClient, CallEvents } from "./CallClient";

type Props = {
  pbxWssUrl: string;        // wss://pbx.domain.com:8089/ws
  sipDomain: string;        // yourdomain.com
  extension: string;        // 1001
  password: string;         // extension password
  turn?: { urls: string; username?: string; credential?: string };
};

export const Dialer: React.FC<Props> = ({ pbxWssUrl, sipDomain, extension, password, turn }) => {
  const [target, setTarget] = useState("");
  const [status, setStatus] = useState<"idle"|"ringing"|"in-call">("idle");
  const clientRef = useRef<CallClient>();

  useEffect(() => {
    const client = new CallClient({
      serverWss: pbxWssUrl,
      aor: `sip:${extension}@${sipDomain}`,
      authorizationUsername: extension,
      authorizationPassword: password,
      turn,
      events: {
        onIncoming: (inv, from) => {
          if (confirm(`Incoming call from ${from}. Answer?`)) {
            client.answer(inv);
            setStatus("in-call");
          } else {
            inv.reject();
          }
        }
      }
    });
    client.start();
    clientRef.current = client;
    return () => { client.stop(); };
  }, [pbxWssUrl, sipDomain, extension, password]);

  const placeCall = async () => {
    if (!clientRef.current || !target) return;
    const events: CallEvents = {
      onRinging: () => setStatus("ringing"),
      onAnswered: () => setStatus("in-call"),
      onEnded: () => setStatus("idle"),
      onError: () => setStatus("idle")
    };
    await clientRef.current.call(target, events);
  };

  const hangup = async () => {
    await clientRef.current?.hangup();
    setStatus("idle");
  };

  return (
    <div style={{ border: "1px solid #ddd", padding: 12, borderRadius: 8 }}>
      <h3>Dialer</h3>
      <input
        placeholder="Enter number or extension"
        value={target}
        onChange={(e) => setTarget(e.target.value)}
        style={{ width: "100%", padding: 8, marginBottom: 8 }}
      />
      <div style={{ display: "flex", gap: 8 }}>
        <button onClick={placeCall} disabled={!target || status!=="idle"}>Call</button>
        <button onClick={hangup} disabled={status==="idle"}>Hang up</button>
      </div>
      <div style={{ marginTop: 8 }}>Status: <b>{status}</b></div>
    </div>
  );
};
