import React, { useEffect, useState } from "react";
import io from "socket.io-client";

type Props = {
  apiBase: string; // http://localhost:4000
  defaultTo?: string;
};

export const SMSPanel: React.FC<Props> = ({ apiBase, defaultTo }) => {
  const [to, setTo] = useState(defaultTo || "");
  const [body, setBody] = useState("");
  const [feed, setFeed] = useState<{from?:string,to?:string,body:string}[]>([]);

  useEffect(() => {
    const socket = io(apiBase, { transports: ['websocket'] });
    socket.on("sms.inbound", (msg) => setFeed((f) => [msg, ...f]));
    return () => { socket.disconnect(); }
  }, [apiBase]);

  const send = async () => {
    const res = await fetch(`${apiBase}/sms/send`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ to, body })
    });
    if (res.ok) {
      setFeed((f) => [{ to, body }, ...f]);
      setBody("");
    } else {
      alert("SMS send failed");
    }
  };

  return (
    <div style={{ border: "1px solid #ddd", padding: 12, borderRadius: 8 }}>
      <h3>SMS</h3>
      <input placeholder="Destination number" value={to} onChange={e=>setTo(e.target.value)} style={{ width: "100%", padding: 8, marginBottom: 8 }}/>
      <textarea placeholder="Message" value={body} onChange={e=>setBody(e.target.value)} rows={3} style={{ width: "100%", padding: 8 }} />
      <div style={{ marginTop: 8 }}>
        <button onClick={send} disabled={!to || !body}>Send</button>
      </div>

      <div style={{ marginTop: 16 }}>
        <h4>Thread</h4>
        <div>
          {feed.map((m, i) => (
            <div key={i} style={{ padding: 8, background: "#f9f9f9", marginBottom: 8, borderRadius: 6 }}>
              <div style={{ fontSize: 12, color: "#666" }}>{m.from ? `From ${m.from}` : `To ${m.to}`}</div>
              <div>{m.body}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
