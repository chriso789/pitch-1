import React, { useEffect, useState } from "react";
import io from "socket.io-client";

type Props = {
  apiBase: string; // http://localhost:4000
  defaultTo?: string;
};

export const EmailPanel: React.FC<Props> = ({ apiBase, defaultTo }) => {
  const [to, setTo] = useState(defaultTo || "");
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [inbox, setInbox] = useState<{from:string,subject:string,html?:string,text?:string}[]>([]);

  useEffect(() => {
    const socket = io(apiBase, { transports: ['websocket'] });
    socket.on("email.inbound", (msg) => setInbox((f) => [msg, ...f]));
    return () => { socket.disconnect(); }
  }, [apiBase]);

  const send = async () => {
    const res = await fetch(`${apiBase}/email/send`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ to, subject, text: body })
    });
    if (!res.ok) {
      alert("Email send failed");
    } else {
      setSubject("");
      setBody("");
      alert("Sent!");
    }
  };

  return (
    <div style={{ border: "1px solid #ddd", padding: 12, borderRadius: 8 }}>
      <h3>Email</h3>
      <input placeholder="To" value={to} onChange={e=>setTo(e.target.value)} style={{ width: "100%", padding: 8, marginBottom: 8 }} />
      <input placeholder="Subject" value={subject} onChange={e=>setSubject(e.target.value)} style={{ width: "100%", padding: 8, marginBottom: 8 }} />
      <textarea placeholder="Body (text)" value={body} onChange={e=>setBody(e.target.value)} rows={4} style={{ width: "100%", padding: 8 }} />
      <div style={{ marginTop: 8 }}>
        <button onClick={send} disabled={!to}>Send</button>
      </div>

      <div style={{ marginTop: 16 }}>
        <h4>Inbox (live)</h4>
        {inbox.map((m, i) => (
          <div key={i} style={{ padding: 8, background: "#f9f9f9", marginBottom: 8, borderRadius: 6 }}>
            <div style={{ fontWeight: 600 }}>{m.subject || "(no subject)"}</div>
            <div style={{ fontSize: 12, color: "#666" }}>{m.from}</div>
            <div dangerouslySetInnerHTML={{ __html: m.html || "" }} />
            {!m.html && <div>{m.text}</div>}
          </div>
        ))}
      </div>
    </div>
  );
};
