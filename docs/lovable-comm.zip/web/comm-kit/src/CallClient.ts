import { Inviter, Invitation, Registerer, SessionState, UserAgent, Web } from "sip.js";

export type CallEvents = {
  onRinging?: (remoteNumber: string) => void;
  onAnswered?: () => void;
  onEnded?: () => void;
  onError?: (err: Error) => void;
  onIncoming?: (invitation: Invitation, from: string) => void;
};

export class CallClient {
  private ua: UserAgent;
  private registerer?: Registerer;
  private inviter?: Inviter;
  private remoteAudio: HTMLAudioElement;
  private localStream?: MediaStream;

  constructor(opts: {
    serverWss: string;           // e.g. wss://pbx.yourdomain.com:8089/ws
    aor: string;                 // e.g. sip:1001@yourdomain.com
    authorizationUsername: string;
    authorizationPassword: string;
    turn?: { urls: string; username?: string; credential?: string };
    events?: CallEvents;
  }) {
    const transportOptions = { server: opts.serverWss };
    const uri = UserAgent.makeURI(opts.aor)!;

    this.ua = new UserAgent({
      uri,
      transportOptions,
      authorizationUsername: opts.authorizationUsername,
      authorizationPassword: opts.authorizationPassword,
      sessionDescriptionHandlerFactoryOptions: {
        peerConnectionConfiguration: {
          iceServers: opts.turn ? [opts.turn] : []
        }
      }
    });

    this.remoteAudio = new Audio();
    this.remoteAudio.autoplay = true;

    if (opts.events?.onIncoming) {
      this.ua.delegate = {
        onInvite: (invitation: Invitation) => {
          const from = invitation.remoteIdentity.uri.normal.user || "unknown";
          opts.events?.onIncoming?.(invitation, from);
        }
      }
    }
  }

  async start() {
    await this.ua.start();
    this.registerer = new Registerer(this.ua);
    await this.registerer.register();
  }

  async stop() {
    await this.registerer?.unregister();
    await this.ua.stop();
  }

  async call(target: string, events?: CallEvents) {
    // target: E.164 or extension like "14155551212"
    this.localStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const targetURI = UserAgent.makeURI(`sip:${target}`)!;
    this.inviter = new Inviter(this.ua, targetURI, {
      sessionDescriptionHandlerOptions: { streams: [this.localStream] }
    });

    const session = this.inviter;
    session.stateChange.addListener((state) => {
      switch (state) {
        case SessionState.Establishing:
          events?.onRinging?.(target);
          break;
        case SessionState.Established:
          const sdh: any = session.sessionDescriptionHandler;
          const remoteStream = new MediaStream();
          sdh.peerConnection.getReceivers().forEach((r: RTCRtpReceiver) => {
            if (r.track) remoteStream.addTrack(r.track);
          });
          this.remoteAudio.srcObject = remoteStream;
          events?.onAnswered?.();
          break;
        case SessionState.Terminated:
          events?.onEnded?.();
          break;
      }
    });

    await session.invite();
  }

  async answer(invitation: Invitation) {
    this.localStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    await invitation.accept({ sessionDescriptionHandlerOptions: { streams: [this.localStream] } });
    const sdh: any = invitation.sessionDescriptionHandler;
    const remoteStream = new MediaStream();
    sdh.peerConnection.getReceivers().forEach((r: RTCRtpReceiver) => {
      if (r.track) remoteStream.addTrack(r.track);
    });
    this.remoteAudio.srcObject = remoteStream;
  }

  async hangup() {
    if (this.inviter) {
      await this.inviter.cancel();
    }
  }
}
