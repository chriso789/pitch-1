-- Users/agents mapped to SIP/WebRTC extensions
CREATE TABLE IF NOT EXISTS agents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT UNIQUE NOT NULL,
  display_name TEXT NOT NULL,
  sip_extension TEXT UNIQUE NOT NULL,
  sip_password TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Calls
CREATE TYPE call_direction AS ENUM ('inbound', 'outbound');
CREATE TYPE call_status AS ENUM ('ringing','answered','completed','failed','missed');

CREATE TABLE IF NOT EXISTS calls (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  direction call_direction NOT NULL,
  from_number TEXT NOT NULL,
  to_number TEXT NOT NULL,
  agent_id UUID REFERENCES agents(id),
  started_at TIMESTAMPTZ DEFAULT now(),
  answered_at TIMESTAMPTZ,
  ended_at TIMESTAMPTZ,
  status call_status DEFAULT 'ringing',
  recording_url TEXT,
  metadata JSONB DEFAULT '{}'::jsonb
);

-- SMS
CREATE TYPE msg_direction AS ENUM ('inbound','outbound');
CREATE TYPE msg_status AS ENUM ('queued','sent','delivered','failed');

CREATE TABLE IF NOT EXISTS sms_threads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  contact_number TEXT NOT NULL,
  agent_id UUID REFERENCES agents(id),
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(contact_number, agent_id)
);

CREATE TABLE IF NOT EXISTS sms_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_id UUID REFERENCES sms_threads(id) ON DELETE CASCADE,
  direction msg_direction NOT NULL,
  from_number TEXT NOT NULL,
  to_number TEXT NOT NULL,
  body TEXT NOT NULL,
  status msg_status DEFAULT 'queued',
  provider_message_id TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Email
CREATE TABLE IF NOT EXISTS email_threads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  subject TEXT,
  contact_address TEXT NOT NULL,
  agent_id UUID REFERENCES agents(id),
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS email_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_id UUID REFERENCES email_threads(id) ON DELETE CASCADE,
  direction msg_direction NOT NULL,
  from_address TEXT NOT NULL,
  to_address TEXT NOT NULL,
  subject TEXT,
  text TEXT,
  html TEXT,
  message_id TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);
