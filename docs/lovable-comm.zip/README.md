# Lovable Communications Kit (Self‑Hosted Dialer, SMS, & Email)

This is a **drop-in starter kit** for embedding a fully self-hosted communications stack (voice, SMS, and email) inside your CRM.

> **Reality check (important):** To reach the public phone network (PSTN) and mobile carriers for SMS, you must interconnect with a carrier:
> - **Voice**: a SIP trunk (DIDs + outbound) from any carrier you choose.
> - **SMS**: an SMPP connection (or a GSM/SIM modem) from a carrier/aggregator.
> Email can be fully self-hosted, but you must configure DNS (MX, SPF, DKIM, DMARC) for reliable delivery.
> This kit **does not use any third‑party SaaS** at runtime—everything here is self‑hosted. You bring your own carrier interconnects.

## What’s inside

- **Asterisk 20 PBX** (WebRTC softphone, SIP trunk, ARI control) — `services/asterisk`
- **Coturn** (TURN/STUN for WebRTC across NAT) — `services/coturn`
- **Comms API (TypeScript/Node)** — `services/comms-api`
  - Outbound/inbound calls via **ARI** (Asterisk REST Interface)
  - **SMPP** client for SMS (send/receive)
  - **SMTP inbound** (via Node `smtp-server`) and **SMTP outbound** (via relay or your MTA)
  - WebSocket events to your CRM
- **Frontend React components** (drop-in) — `web/comm-kit`
  - `<Dialer />` (WebRTC) using `sip.js`
  - `<SMSPanel />`
  - `<EmailPanel />`
- **Postgres schema** for calls/messages/emails — `db/init.sql`
- **Docker Compose** to run all services together — `docker-compose.yml`

## Quick start

1. **Prereqs**
   - Docker & Docker Compose
   - Public IP / domain for PBX (Asterisk) and TURN
   - TLS certs for `wss` (WebRTC). Place PEM files in `services/asterisk/keys/` and `services/coturn/certs/`.
   - A **SIP trunk** for PSTN (set env in `.env`).
   - (Optional) An **SMPP** account for SMS (set env in `.env`).

2. **Configure .env**
   Copy `.env.example` to `.env` and fill in values (DID numbers, trunk creds, ARI password, TURN creds, etc.).

3. **Start**:
   ```bash
   docker compose up --build
   ```

4. **Embed in your CRM (frontend)**:
   - Copy `web/comm-kit/src` components into your app, or publish this as a private package.
   - Initialize the dialer with your SIP extension/user and PBX WSS URL.

5. **Map inbound**:
   - Point your **DID** to this PBX (SIP trunk → Asterisk).
   - Point **MX** to your SMTP inbound (or use relay to your internal SMTP if you have one).
   - Configure your **SMPP** provider to allow transceiver bind (send/receive).

## Notes

- Production hardening (firewalls, fail2ban, rtpengine if you prefer, QoS, multi‑AZ) is recommended.
- For email deliverability you’ll need DNS: SPF, DKIM, DMARC; set via your DNS provider.
- If you prefer FreeSWITCH/Kamailio, the app is carrier-agnostic. Swap PBX and keep the comms API + frontend.
