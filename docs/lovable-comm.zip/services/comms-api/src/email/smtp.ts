import { SMTPServer } from 'smtp-server';
import nodemailer from 'nodemailer';
import { simpleParser } from 'mailparser';
import type { Server as IOServer } from 'socket.io';
import type { Logger } from 'winston';

export async function initSmtpInbound(io: IOServer, logger: Logger) {
  const port = Number(process.env.SMTP_INBOUND_PORT || 2525);

  const server = new SMTPServer({
    disabledCommands: ['AUTH'], // run behind firewall/VPN or add auth if exposing public
    onData(stream, session, callback) {
      simpleParser(stream)
        .then((mail) => {
          const from = mail.from?.text || '';
          const to = mail.to?.text || '';
          const subject = mail.subject || '';
          const text = mail.text || '';
          const html = mail.html || '';
          io.emit('email.inbound', { from, to, subject, text, html });
          callback();
        })
        .catch((e) => {
          logger.error('SMTP parse error', { error: e.message });
          callback(e);
        });
    },
    onRcptTo(address, session, callback) {
      // Allow any recipient in your domain (validate here if you prefer)
      return callback();
    }
  });

  await new Promise<void>((resolve) => server.listen(port, resolve));
  logger.info(`SMTP inbound listening on :${port}`);
}

export async function sendEmail({ to, subject, text, html, from } : { to: string, subject?: string, text?: string, html?: string, from?: string }) {
  const relayHost = process.env.SMTP_RELAY_HOST || 'smtp-relay';
  const relayPort = Number(process.env.SMTP_RELAY_PORT || 25);
  const fromDomain = process.env.SMTP_FROM_DOMAIN || 'local.lovable';

  const transporter = nodemailer.createTransport({
    host: relayHost,
    port: relayPort,
    secure: false
  });

  const info = await transporter.sendMail({
    from: from || `noreply@${fromDomain}`,
    to,
    subject: subject || '(no subject)',
    text,
    html
  });

  return info;
}
