import ari from 'ari-client';
import type { Server as IOServer } from 'socket.io';
import type { Logger } from 'winston';

let client: any;

export async function initAri(io: IOServer, logger: Logger) {
  const url = process.env.ARI_URL || 'http://asterisk:8088/ari';
  const username = process.env.ARI_USERNAME || 'crm';
  const password = process.env.ARI_PASSWORD || 'supersecure';

  return new Promise<void>((resolve, reject) => {
    ari.connect(url, username, password, (err: any, _client: any) => {
      if (err) {
        logger.error('ARI connect failed', { error: err.message });
        return reject(err);
      }
      client = _client;
      const appName = 'crm-ari';

      client.on('StasisStart', (event: any, channel: any) => {
        logger.info('StasisStart', { channel: channel.id });
        // Auto-bridge to agent or play ringback / IVR as needed
        // For now just answer and play a beep
        channel.answer()
          .then(() => channel.play({ media: 'sound:beep' }))
          .catch((e: any) => logger.error('answer/play failed', { err: e.message }));

        io.emit('call.inbound', { channelId: channel.id, from: channel.caller.number });
      });

      client.on('ChannelHangupRequest', (event: any, channel: any) => {
        io.emit('call.ended', { channelId: channel.id });
      });

      client.start(appName);
      logger.info('ARI connected & app started', { appName });
      resolve();
    });
  });
}

export async function originateCall(to: string, callerId?: string) {
  if (!client) throw new Error('ARI not connected');
  const app = 'crm-ari';
  const endpoint = `PJSIP/${to}@trunk-out`;
  const res = await client.channels.originate({
    endpoint,
    app,
    callerId: callerId || process.env.TRUNK_DID || 'Unknown',
    timeout: 60
  });
  return res.id;
}
