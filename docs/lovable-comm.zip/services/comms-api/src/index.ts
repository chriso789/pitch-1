import 'dotenv/config';
import express from 'express';
import http from 'http';
import cors from 'cors';
import bodyParser from 'body-parser';
import { Server as IOServer } from 'socket.io';
import { createLogger, format, transports } from 'winston';
import { initDb } from './lib/db.js';
import { initAri, originateCall } from './telephony/ari.js';
import { initSmpp, sendSms } from './sms/smpp.js';
import { initSmtpInbound, sendEmail } from './email/smtp.js';

const app = express();
const server = http.createServer(app);
const io = new IOServer(server, { cors: { origin: '*'} });

const logger = createLogger({
  level: 'info',
  format: format.combine(format.timestamp(), format.json()),
  transports: [new transports.Console()]
});

app.use(cors());
app.use(bodyParser.json({ limit: '2mb' }));

// Health
app.get('/health', (_req, res) => res.json({ ok: true }));

// Outbound call
app.post('/calls/outbound', async (req, res) => {
  try {
    const { to, callerId } = req.body;
    if (!to) return res.status(400).json({ error: 'Missing "to"' });
    const callId = await originateCall(to, callerId);
    return res.json({ callId });
  } catch (e:any) {
    logger.error('outbound error', { error: e.message });
    return res.status(500).json({ error: e.message });
  }
});

// SMS send
app.post('/sms/send', async (req, res) => {
  try {
    const { to, body } = req.body;
    if (!to || !body) return res.status(400).json({ error: 'Missing to/body' });
    const result = await sendSms(to, body);
    return res.json({ ok: true, result });
  } catch (e:any) {
    logger.error('sms send error', { error: e.message });
    return res.status(500).json({ error: e.message });
  }
});

// Email send
app.post('/email/send', async (req, res) => {
  try {
    const { to, subject, text, html, from } = req.body;
    if (!to) return res.status(400).json({ error: 'Missing "to"' });
    const info = await sendEmail({ to, subject, text, html, from });
    return res.json({ ok: true, messageId: info.messageId });
  } catch (e:any) {
    return res.status(500).json({ error: e.message });
  }
});

// Socket.io for real-time events (calls, sms, email)
io.on('connection', (socket) => {
  logger.info('socket connected', { id: socket.id });
});

// Bootstrap
async function main() {
  await initDb(logger);
  await initAri(io, logger);
  await initSmpp(io, logger);
  await initSmtpInbound(io, logger);

  const port = process.env.PORT || 4000;
  server.listen(port, () => {
    logger.info(`Comms API listening on :${port}`);
  });
}

main().catch((e) => {
  logger.error('startup failed', { error: e.stack });
  process.exit(1);
});
