import smpp from 'smpp';
import type { Server as IOServer } from 'socket.io';
import type { Logger } from 'winston';

let session: any;

export async function initSmpp(io: IOServer, logger: Logger) {
  const url = process.env.SMPP_URL;
  const system_id = process.env.SMPP_SYSTEM_ID;
  const password = process.env.SMPP_PASSWORD;

  if (!url || !system_id || !password) {
    logger.warn('SMPP not configured; SMS features disabled');
    return;
  }

  session = smpp.connect(url);
  session.on('error', (e: any) => logger.error('SMPP error', { error: e.message }));

  session.bind_transceiver({ system_id, password }, (pdu: any) => {
    if (pdu.command_status === 0) {
      logger.info('SMPP bound as transceiver');
    } else {
      logger.error('SMPP bind failed', { status: pdu.command_status });
    }
  });

  // inbound delivery
  session.on('deliver_sm', (pdu: any) => {
    try {
      const from = pdu.source_addr?.toString();
      const to = pdu.destination_addr?.toString();
      const text = pdu.short_message?.message || pdu.short_message?.toString() || '';
      io.emit('sms.inbound', { from, to, body: text });
      session.deliver_sm_resp(pdu.sequence_number);
    } catch (e:any) {
      logger.error('deliver_sm handler failed', { error: e.message });
    }
  });
}

export async function sendSms(to: string, body: string) {
  if (!session) throw new Error('SMPP not initialized');
  const src = process.env.SMPP_SOURCE_NUMBER || 'Lovable';
  return new Promise((resolve, reject) => {
    session.submit_sm({
      source_addr: src,
      destination_addr: to,
      short_message: body,
      registered_delivery: 1
    }, (pdu: any) => {
      if (pdu.command_status === 0) {
        resolve({ message_id: pdu.message_id });
      } else {
        reject(new Error(`SMPP submit failed: ${pdu.command_status}`));
      }
    });
  });
}
