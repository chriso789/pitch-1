import { Pool } from 'pg';
import type { Logger } from 'winston';

let pool: Pool;

export function getDb() {
  if (!pool) throw new Error('DB not initialized');
  return pool;
}

export async function initDb(logger: Logger) {
  const user = process.env.POSTGRES_USER || 'lovable';
  const password = process.env.POSTGRES_PASSWORD || 'lovablepass';
  const db = process.env.POSTGRES_DB || 'lovable_comm';
  const host = process.env.POSTGRES_HOST || 'postgres';
  const port = Number(process.env.POSTGRES_PORT || 5432);

  pool = new Pool({ user, password, database: db, host, port });
  const client = await pool.connect();
  try {
    await client.query('SELECT 1');
    logger.info('DB connected');
  } finally {
    client.release();
  }
}
