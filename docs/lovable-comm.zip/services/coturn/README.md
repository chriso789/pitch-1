# Coturn

We pass all config via command-line in docker-compose. Place your TLS certs in this folder as:
- fullchain.pem
- privkey.pem
