#!/bin/bash

# Environment Verification Runner
# Alternative to npm script for CI/CD usage

echo "🔍 Running environment verification..."
node scripts/verify-env.js

exit_code=$?
if [ $exit_code -eq 0 ]; then
    echo "✅ Environment verification completed successfully"
else
    echo "❌ Environment verification failed with exit code $exit_code"
fi

exit $exit_code