#!/bin/bash

# CI/CD Environment Verification Script
# Used to verify environment variables in CI/CD pipelines
# Exits with non-zero code if required variables are missing

echo "🔍 CI/CD Environment Verification for Canvass-IQ"
echo "================================================"

# Set strict error handling
set -e

# Run the Node.js verification script
echo "Running environment verification..."
node scripts/verify-env.js

# Capture exit code
VERIFY_EXIT_CODE=$?

if [ $VERIFY_EXIT_CODE -eq 0 ]; then
    echo ""
    echo "✅ CI/CD Environment verification PASSED"
    echo "All required environment variables are present"
    exit 0
else
    echo ""
    echo "❌ CI/CD Environment verification FAILED"
    echo "Missing required environment variables"
    echo "Build will be aborted"
    exit 1
fi