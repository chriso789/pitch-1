#!/usr/bin/env node

/**
 * Environment Verification Script for Canvass-IQ
 * Validates that all required environment variables are present
 * Used in CI/CD to fail builds when configuration is incomplete
 */

const requiredVars = [
  'VITE_SUPABASE_URL',
  'VITE_SUPABASE_ANON_KEY', 
  'VITE_GOOGLE_MAPS_API_KEY',
  'VITE_SKIPTRACE_BASE_URL',
  'VITE_SKIPTRACE_API_KEY',
  'VITE_APP_ENV'
];

const optionalVars = [
  'VITE_SENTRY_DSN'
];

function checkEnvironment() {
  console.log('🔍 Verifying environment configuration...\n');
  
  let hasErrors = false;
  const missing = [];
  const present = [];
  
  // Check required variables
  requiredVars.forEach(varName => {
    if (process.env[varName]) {
      present.push(varName);
      console.log(`✅ ${varName}: Present`);
    } else {
      missing.push(varName);
      console.error(`❌ ${varName}: MISSING (Required)`);
      hasErrors = true;
    }
  });
  
  // Check optional variables
  optionalVars.forEach(varName => {
    if (process.env[varName]) {
      present.push(varName);
      console.log(`✅ ${varName}: Present (Optional)`);
    } else {
      console.log(`⚠️  ${varName}: Not set (Optional)`);
    }
  });
  
  console.log('\n📊 Summary:');
  console.log(`✅ Present: ${present.length}`);
  console.log(`❌ Missing: ${missing.length}`);
  
  if (hasErrors) {
    console.error('\n🚨 Environment verification failed!');
    console.error('Missing required environment variables:');
    missing.forEach(varName => {
      console.error(`  - ${varName}`);
    });
    console.error('\nPlease check your .env.local file or environment configuration.');
    console.error('See .env.local.example for reference.');
    process.exit(1);
  } else {
    console.log('\n✅ Environment verification passed!');
    console.log('All required environment variables are present.');
    process.exit(0);
  }
}

// Handle different environments
const env = process.env.NODE_ENV || process.env.VITE_APP_ENV || 'development';
console.log(`Environment: ${env}\n`);

checkEnvironment();