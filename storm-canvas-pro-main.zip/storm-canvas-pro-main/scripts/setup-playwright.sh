#!/bin/bash

# Install Playwright browsers for CI
echo "Installing Playwright browsers..."

if [ "$CI" = "true" ]; then
  # In CI, install only Chromium for faster setup
  npx playwright install chromium
else
  # In local development, install all browsers
  npx playwright install
fi

echo "Playwright setup complete!"