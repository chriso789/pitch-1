import { test, expect } from '@playwright/test';
import { promises as fs } from 'fs';
import path from 'path';

// Gate 2: Validation tests
test.describe('Form Validation', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
    // Assume user is authenticated for these tests
    await authenticateUser(page);
  });

  test('should show Zod validation errors for required fields', async ({ page }) => {
    await page.goto('/properties/new');
    
    // Try to submit form without required fields
    await page.click('button[type="submit"]');
    
    // Should show validation errors
    await expect(page.locator('.error-message')).toContainText('Address is required');
    
    // Fill in invalid latitude/longitude
    await page.fill('input[name="address"]', '123 Main St');
    await page.fill('input[name="latitude"]', 'invalid_lat');
    await page.fill('input[name="longitude"]', 'invalid_lng');
    
    await page.click('button[type="submit"]');
    
    // Should show validation errors for invalid coordinates
    await expect(page.locator('.error-message')).toContainText('Invalid latitude');
    await expect(page.locator('.error-message')).toContainText('Invalid longitude');
    
    // Fix the validation errors
    await page.fill('input[name="latitude"]', '40.7128');
    await page.fill('input[name="longitude"]', '-74.0060');
    
    // Form should now submit successfully
    await Promise.all([
      page.waitForNavigation(),
      page.click('button[type="submit"]')
    ]);
    
    await expect(page).not.toHaveURL('/properties/new');
  });

  test('should handle CSV import with validation errors and provide downloadable error file', async ({ page, context }) => {
    await page.goto('/properties/import');
    
    // Create test CSV with invalid data
    const invalidCsvContent = `address,latitude,longitude,notes
123 Main St,40.7128,-74.0060,Valid row
,invalid_lat,invalid_lng,Invalid row - missing address and bad coords
456 Oak Ave,91.0000,-181.0000,Invalid row - coords out of range
789 Pine St,40.7589,-73.9851,Another valid row`;

    // Create a temporary CSV file
    const csvBlob = new Blob([invalidCsvContent], { type: 'text/csv' });
    const csvFile = new File([csvBlob], 'test-properties.csv', { type: 'text/csv' });
    
    // Upload the CSV file
    const fileInput = page.locator('input[type="file"]');
    await fileInput.setInputFiles([{
      name: 'test-properties.csv',
      mimeType: 'text/csv',
      buffer: Buffer.from(invalidCsvContent)
    }]);
    
    // Start import process
    await page.click('button:has-text("Import CSV")');
    
    // Should show import progress
    await expect(page.locator('.import-progress')).toBeVisible();
    
    // Wait for import to complete
    await expect(page.locator('.import-complete')).toBeVisible();
    
    // Should show validation errors summary
    await expect(page.locator('.import-errors')).toContainText('2 rows failed validation');
    
    // Should have download link for error file
    const downloadPromise = page.waitForEvent('download');
    await page.click('button:has-text("Download Error Report")');
    const download = await downloadPromise;
    
    // Verify error file was downloaded
    expect(download.suggestedFilename()).toMatch(/error.*\.csv$/);
    
    // Save and verify error file content
    const errorFilePath = path.join(__dirname, 'temp', download.suggestedFilename());
    await download.saveAs(errorFilePath);
    
    const errorContent = await fs.readFile(errorFilePath, 'utf-8');
    expect(errorContent).toContain('Invalid row - missing address');
    expect(errorContent).toContain('coords out of range');
    
    // Clean up
    await fs.unlink(errorFilePath).catch(() => {});
  });

  test('should validate form fields in real-time', async ({ page }) => {
    await page.goto('/properties/new');
    
    // Test real-time email validation
    const emailInput = page.locator('input[name="contact_email"]');
    await emailInput.fill('invalid-email');
    
    // Should show validation error immediately
    await expect(page.locator('.field-error')).toContainText('Invalid email format');
    
    // Fix email format
    await emailInput.fill('valid@example.com');
    
    // Error should disappear
    await expect(page.locator('.field-error')).not.toBeVisible();
    
    // Test phone number validation
    const phoneInput = page.locator('input[name="contact_phone"]');
    await phoneInput.fill('123');
    
    await expect(page.locator('.field-error')).toContainText('Phone number must be at least 10 digits');
    
    await phoneInput.fill('(555) 123-4567');
    await expect(page.locator('.field-error')).not.toBeVisible();
  });
});

async function authenticateUser(page: any) {
  // Mock authentication or perform actual login
  await page.evaluate(() => {
    localStorage.setItem('supabase.auth.token', 'mock-auth-token');
  });
}