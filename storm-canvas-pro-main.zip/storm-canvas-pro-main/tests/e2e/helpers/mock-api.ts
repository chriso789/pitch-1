import { Page } from '@playwright/test';
import { mockEnrichmentData, mockDispositions, mockHealthCheckResponse } from './test-data';

export class MockApiHelper {
  constructor(private page: Page) {}

  async mockHealthCheck(status: 'healthy' | 'partial' | 'error' = 'healthy') {
    await this.page.route('**/api/health*', route => {
      route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify(mockHealthCheckResponse(status))
      });
    });
  }

  async mockEnrichmentApi(shouldSucceed: boolean = true, cacheHit: boolean = false) {
    await this.page.route('**/api/enrich*', route => {
      if (!shouldSucceed) {
        route.fulfill({
          status: 500,
          contentType: 'application/json',
          body: JSON.stringify({ error: 'Enrichment failed' })
        });
        return;
      }

      route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          cache_hit: cacheHit,
          enrichment_data: mockEnrichmentData
        })
      });
    });
  }

  async mockRateLimitedApi(failCount: number = 3) {
    let requestCount = 0;
    
    await this.page.route('**/api/enrich*', route => {
      requestCount++;
      
      if (requestCount <= failCount) {
        route.fulfill({
          status: 429,
          contentType: 'application/json',
          body: JSON.stringify({
            error: 'Rate limit exceeded',
            retry_after: 2
          })
        });
      } else {
        route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({
            enrichment_data: mockEnrichmentData
          })
        });
      }
    });
  }

  async mockValidationApi(isValid: boolean = true) {
    await this.page.route('**/api/validate/**', route => {
      if (isValid) {
        route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({ valid: true })
        });
      } else {
        route.fulfill({
          status: 400,
          contentType: 'application/json',
          body: JSON.stringify({ error: 'Invalid configuration' })
        });
      }
    });
  }

  async mockDispositionsApi() {
    await this.page.route('**/api/dispositions*', route => {
      route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify(mockDispositions)
      });
    });
  }

  async mockProvidersHealthApi() {
    await this.page.route('**/api/health/providers*', route => {
      route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          skiptrace: {
            name: 'Skiptrace Provider',
            ok: true,
            latency_ms: 245,
            quota: '8,500 / 10,000 requests',
            last_check: new Date().toISOString()
          },
          mapbox: {
            name: 'Mapbox Geocoding',
            ok: true,
            latency_ms: 120,
            quota: '90,000 / 100,000 requests',
            last_check: new Date().toISOString()
          }
        })
      });
    });
  }

  async mockSupabaseApi() {
    // Mock common Supabase API endpoints
    await this.page.route('**/rest/v1/**', route => {
      const url = route.request().url();
      
      if (url.includes('properties')) {
        route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify([])
        });
      } else if (url.includes('dispositions')) {
        route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify(mockDispositions)
        });
      } else {
        route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({ data: [] })
        });
      }
    });
  }
}