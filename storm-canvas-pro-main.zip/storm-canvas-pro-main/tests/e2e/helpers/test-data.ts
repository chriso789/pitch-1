export const mockPropertyData = {
  id: 'test-property-123',
  address: {
    line1: '123 Test Street',
    city: 'Test City',
    state: 'CA',
    postal_code: '90210'
  },
  address_hash: 'test-hash-123',
  geom: null,
  flags: { test: true },
  created_at: '2023-12-01T10:00:00Z',
  created_by: 'test-user-id'
};

export const mockEnrichmentData = {
  owner: {
    name: 'John Doe',
    age: 45,
    gender: 'M'
  },
  phones: [
    { number: '+1-555-123-4567', type: 'mobile', score: 0.95 },
    { number: '+1-555-987-6543', type: 'landline', score: 0.80 }
  ],
  emails: [
    { email: 'john.doe@example.com', score: 0.90 }
  ],
  financial: {
    credit_score: 750,
    mortgage_balance: 250000,
    equity: 150000,
    last_sale_price: 400000
  },
  sources: ['mock_provider'],
  enriched_at: '2023-12-01T12:00:00Z'
};

export const mockDispositions = [
  { id: '1', name: 'Interested', color: '#22c55e', description: 'Homeowner showed interest' },
  { id: '2', name: 'Not Home', color: '#f59e0b', description: 'No one answered' },
  { id: '3', name: 'Not Interested', color: '#ef4444', description: 'Homeowner declined' },
  { id: '4', name: 'Call Back', color: '#3b82f6', description: 'Requested callback' }
];

export const generateTestUser = (role: 'user' | 'admin' = 'user') => ({
  id: `test-${role}-${Date.now()}`,
  email: `${role}@test.com`,
  full_name: `Test ${role.charAt(0).toUpperCase() + role.slice(1)}`,
  role,
  created_at: new Date().toISOString()
});

export const generateTestProperty = (override: Partial<typeof mockPropertyData> = {}) => ({
  ...mockPropertyData,
  id: `test-prop-${Date.now()}`,
  ...override
});

export const mockHealthCheckResponse = (status: 'healthy' | 'partial' | 'error' = 'healthy') => ({
  status,
  checks: {
    supabase: { ok: status !== 'error', error: status === 'error' ? 'Connection failed' : null },
    mapbox: { ok: status === 'healthy', error: status !== 'healthy' ? 'Invalid token' : null },
    skiptrace: { ok: status !== 'error', error: status === 'error' ? 'API unavailable' : null }
  },
  providers: {
    supabase: { ok: status !== 'error', validated: status === 'healthy' },
    mapbox: { ok: status === 'healthy', validated: status === 'healthy' },
    skiptrace: { ok: status !== 'error', validated: status === 'healthy' }
  }
});