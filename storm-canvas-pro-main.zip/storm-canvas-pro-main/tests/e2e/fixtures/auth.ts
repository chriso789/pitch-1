import { test as base, expect } from '@playwright/test';

export interface AuthFixtures {
  authenticatedPage: any;
  adminPage: any;
}

export const test = base.extend<AuthFixtures>({
  authenticatedPage: async ({ page }, use) => {
    // Set up authenticated state
    await page.goto('/');
    await page.evaluate(() => {
      localStorage.setItem('supabase.auth.token', JSON.stringify({
        access_token: 'mock-access-token',
        refresh_token: 'mock-refresh-token',
        user: {
          id: 'test-user-id',
          email: 'test@example.com',
          role: 'user'
        }
      }));
    });
    
    await use(page);
  },

  adminPage: async ({ page }, use) => {
    // Set up admin authenticated state
    await page.goto('/');
    await page.evaluate(() => {
      localStorage.setItem('supabase.auth.token', JSON.stringify({
        access_token: 'mock-admin-token',
        refresh_token: 'mock-refresh-token',
        user: {
          id: 'admin-user-id',
          email: 'admin@example.com',
          role: 'admin'
        }
      }));
    });
    
    await use(page);
  }
});

export { expect };