import { test, expect } from '@playwright/test';

// Gates 1 & 5: Authentication tests
test.describe('Authentication', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
  });

  test('should redirect unauthenticated users from /canvassing to /signin', async ({ page }) => {
    // Try to access protected route
    await page.goto('/canvassing');
    
    // Should redirect to signin
    await expect(page).toHaveURL('/signin');
    
    // Should show sign in form
    await expect(page.locator('form')).toBeVisible();
    await expect(page.locator('input[type="email"]')).toBeVisible();
    await expect(page.locator('input[type="password"]')).toBeVisible();
  });

  test('should create user and verify session persists after reload', async ({ page }) => {
    // Navigate to sign up
    await page.goto('/signup');
    
    // Fill out registration form
    const testEmail = `test+${Date.now()}@example.com`;
    const testPassword = 'TestPassword123!';
    
    await page.fill('input[type="email"]', testEmail);
    await page.fill('input[type="password"]', testPassword);
    await page.fill('input[name="full_name"]', 'Test User');
    
    // Submit form
    await Promise.all([
      page.waitForNavigation(),
      page.click('button[type="submit"]')
    ]);
    
    // Should be redirected to dashboard or main app
    await expect(page).not.toHaveURL('/signup');
    
    // Verify user is authenticated (navigation should show user menu)
    await expect(page.locator('[data-testid="user-menu"]')).toBeVisible();
    
    // Reload page
    await page.reload();
    
    // Session should persist - user menu should still be visible
    await expect(page.locator('[data-testid="user-menu"]')).toBeVisible();
    
    // Should still be able to access protected routes
    await page.goto('/canvassing');
    await expect(page).toHaveURL('/canvassing');
  });

  test('should show different navigation for admin vs non-admin users', async ({ page }) => {
    // This test assumes there's a way to set user roles for testing
    
    // Test with regular user
    await signInAsUser(page, 'user');
    
    // Admin-only navigation items should not be visible
    await expect(page.locator('[data-testid="admin-menu"]')).not.toBeVisible();
    await expect(page.locator('text=Admin Dashboard')).not.toBeVisible();
    
    // Sign out and sign in as admin
    await signOut(page);
    await signInAsUser(page, 'admin');
    
    // Admin navigation should be visible
    await expect(page.locator('[data-testid="admin-menu"]')).toBeVisible();
    await expect(page.locator('text=Admin Dashboard')).toBeVisible();
  });
});

async function signInAsUser(page: any, role: 'user' | 'admin') {
  await page.goto('/signin');
  
  // Use test credentials based on role
  const email = role === 'admin' ? 'admin@test.com' : 'user@test.com';
  const password = 'TestPassword123!';
  
  await page.fill('input[type="email"]', email);
  await page.fill('input[type="password"]', password);
  
  await Promise.all([
    page.waitForNavigation(),
    page.click('button[type="submit"]')
  ]);
}

async function signOut(page: any) {
  await page.click('[data-testid="user-menu"]');
  await page.click('text=Sign Out');
  await expect(page).toHaveURL('/signin');
}