import { test, expect } from '@playwright/test';

// Gate 5: Navigation and feature flags tests
test.describe('Navigation & Feature Flags', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
    await authenticateUser(page);
  });

  test('should show setup badge until all providers are validated', async ({ page }) => {
    // Mock partial provider configuration
    await page.route('**/api/health*', route => {
      route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          status: 'partial',
          providers: {
            supabase: { ok: true, validated: true },
            mapbox: { ok: false, validated: false, error: 'Invalid token' },
            skiptrace: { ok: true, validated: true }
          }
        })
      });
    });

    await page.reload();
    
    // Setup badge should be visible when providers are not fully validated
    await expect(page.locator('[data-testid="setup-badge"]')).toBeVisible();
    await expect(page.locator('[data-testid="setup-badge"]')).toContainText('Setup Required');
    
    // Badge should be clickable and navigate to setup
    await page.click('[data-testid="setup-badge"]');
    await expect(page).toHaveURL('/setup');
  });

  test('should hide setup badge when all providers are validated', async ({ page }) => {
    // Mock fully validated configuration
    await page.route('**/api/health*', route => {
      route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          status: 'healthy',
          providers: {
            supabase: { ok: true, validated: true },
            mapbox: { ok: true, validated: true },
            skiptrace: { ok: true, validated: true }
          }
        })
      });
    });

    await page.reload();
    
    // Setup badge should not be visible when everything is validated
    await expect(page.locator('[data-testid="setup-badge"]')).not.toBeVisible();
    
    // Main navigation should be fully accessible
    await expect(page.locator('nav')).toBeVisible();
    await expect(page.locator('a[href="/properties"]')).toBeVisible();
    await expect(page.locator('a[href="/canvassing"]')).toBeVisible();
  });

  test('should toggle Mock Skiptrace feature flag', async ({ page }) => {
    await page.goto('/admin/settings');
    
    // Should show feature flags section
    await expect(page.locator('h2:has-text("Feature Flags")')).toBeVisible();
    
    // Mock Skiptrace toggle should be present
    const mockSkiptraceToggle = page.locator('[data-testid="mock-skiptrace-toggle"]');
    await expect(mockSkiptraceToggle).toBeVisible();
    
    // Get initial state
    const initialState = await mockSkiptraceToggle.isChecked();
    
    // Toggle the feature flag
    await mockSkiptraceToggle.click();
    
    // State should change
    await expect(mockSkiptraceToggle).toBeChecked(!initialState);
    
    // Should save setting
    await page.click('button:has-text("Save Settings")');
    await expect(page.locator('.success-message')).toBeVisible();
    
    // Navigate to enrichment page to verify flag effect
    await page.goto('/properties');
    
    if (!initialState) {
      // If we enabled mock mode, should see mock provider indicator
      await expect(page.locator('.mock-provider-indicator')).toBeVisible();
    }
  });

  test('should toggle Demo Data feature flag', async ({ page }) => {
    await page.goto('/admin/settings');
    
    const demoDataToggle = page.locator('[data-testid="demo-data-toggle"]');
    await expect(demoDataToggle).toBeVisible();
    
    // Enable demo data
    if (!await demoDataToggle.isChecked()) {
      await demoDataToggle.click();
      await page.click('button:has-text("Save Settings")');
    }
    
    // Navigate to properties page
    await page.goto('/properties');
    
    // Should show demo data banner or indicator
    await expect(page.locator('.demo-data-banner')).toBeVisible();
    
    // Should see sample properties
    await expect(page.locator('[data-testid="property-card"]')).toHaveCount.greaterThan(0);
    
    // Disable demo data
    await page.goto('/admin/settings');
    await demoDataToggle.click();
    await page.click('button:has-text("Save Settings")');
    
    // Go back to properties
    await page.goto('/properties');
    
    // Demo banner should be gone
    await expect(page.locator('.demo-data-banner')).not.toBeVisible();
  });

  test('should show automations and event architecture status when linked to Supabase', async ({ page }) => {
    await page.goto('/admin/automations');
    
    // Should show automations dashboard
    await expect(page.locator('h1:has-text("Automations")')).toBeVisible();
    
    // Should show Supabase connection status
    await expect(page.locator('.supabase-connection-status')).toBeVisible();
    await expect(page.locator('.connection-indicator.connected')).toBeVisible();
    
    // Should show event architecture components
    await expect(page.locator('.event-outbox-status')).toBeVisible();
    await expect(page.locator('.integration-endpoints')).toBeVisible();
    
    // Should show PITCH CRM integration status
    await expect(page.locator('.pitch-integration-card')).toBeVisible();
    
    // Should show recent events
    await expect(page.locator('.recent-events')).toBeVisible();
    
    // Test event triggering
    const testEventButton = page.locator('button:has-text("Test Event")');
    if (await testEventButton.isVisible()) {
      await testEventButton.click();
      await expect(page.locator('.event-triggered-success')).toBeVisible();
    }
  });

  test('should navigate between main sections correctly', async ({ page }) => {
    // Test navigation between main sections
    const navigationTests = [
      { link: 'a[href="/properties"]', expectedUrl: '/properties', title: 'Properties' },
      { link: 'a[href="/canvassing"]', expectedUrl: '/canvassing', title: 'Canvassing' },
      { link: 'a[href="/photos"]', expectedUrl: '/photos', title: 'Photos' },
      { link: 'a[href="/proposals"]', expectedUrl: '/proposals', title: 'Proposals' },
      { link: 'a[href="/team"]', expectedUrl: '/team', title: 'Team' }
    ];

    for (const nav of navigationTests) {
      await page.click(nav.link);
      await expect(page).toHaveURL(nav.expectedUrl);
      await expect(page.locator('h1')).toContainText(nav.title);
    }
  });

  test('should maintain responsive navigation on mobile viewports', async ({ page }) => {
    // Set mobile viewport
    await page.setViewportSize({ width: 375, height: 667 });
    
    // Mobile menu should be collapsed initially
    await expect(page.locator('.mobile-menu-button')).toBeVisible();
    await expect(page.locator('.mobile-nav-menu')).not.toBeVisible();
    
    // Click mobile menu button
    await page.click('.mobile-menu-button');
    
    // Menu should expand
    await expect(page.locator('.mobile-nav-menu')).toBeVisible();
    
    // Navigation links should be accessible
    await expect(page.locator('.mobile-nav-menu a[href="/properties"]')).toBeVisible();
    await expect(page.locator('.mobile-nav-menu a[href="/canvassing"]')).toBeVisible();
    
    // Clicking a link should navigate and close menu
    await page.click('.mobile-nav-menu a[href="/properties"]');
    await expect(page).toHaveURL('/properties');
    await expect(page.locator('.mobile-nav-menu')).not.toBeVisible();
  });
});

async function authenticateUser(page: any) {
  await page.evaluate(() => {
    localStorage.setItem('supabase.auth.token', 'mock-auth-token');
  });
}