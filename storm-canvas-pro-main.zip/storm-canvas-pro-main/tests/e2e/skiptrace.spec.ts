import { test, expect } from '@playwright/test';

// Gate 3: Skiptrace/enrichment tests
test.describe('Skiptrace Integration', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
    await authenticateUser(page);
  });

  test('should enrich single property with mock provider and store deterministic payload', async ({ page }) => {
    // Navigate to properties page
    await page.goto('/properties');
    
    // Add a new property
    await page.click('button:has-text("Add Property")');
    await page.fill('input[name="address"]', '123 Test Street');
    await page.fill('input[name="city"]', 'Test City');
    await page.fill('input[name="state"]', 'CA');
    await page.fill('input[name="zip"]', '90210');
    
    await Promise.all([
      page.waitForNavigation(),
      page.click('button[type="submit"]')
    ]);
    
    // Mock the enrichment API to return deterministic data
    await page.route('**/api/enrich*', route => {
      const deterministicPayload = {
        property_id: 'test-property-id',
        enrichment_data: {
          owner: {
            name: 'John Doe',
            age: 45,
            gender: 'M'
          },
          phones: [
            { number: '+1-555-123-4567', type: 'mobile', score: 0.95 },
            { number: '+1-555-987-6543', type: 'landline', score: 0.80 }
          ],
          emails: [
            { email: 'john.doe@example.com', score: 0.90 }
          ],
          financial: {
            credit_score: 750,
            mortgage_balance: 250000,
            equity: 150000,
            last_sale_price: 400000
          },
          sources: ['mock_provider'],
          enriched_at: '2023-12-01T12:00:00Z'
        }
      };
      
      route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify(deterministicPayload)
      });
    });
    
    // Trigger enrichment
    await page.click('button:has-text("Enrich Property")');
    
    // Should show loading state
    await expect(page.locator('.enrichment-loading')).toBeVisible();
    
    // Wait for enrichment to complete
    await expect(page.locator('.enrichment-complete')).toBeVisible();
    
    // Verify enrichment data is displayed
    await expect(page.locator('text=John Doe')).toBeVisible();
    await expect(page.locator('text=+1-555-123-4567')).toBeVisible();
    await expect(page.locator('text=john.doe@example.com')).toBeVisible();
    await expect(page.locator('text=Credit Score: 750')).toBeVisible();
    
    // Verify data was stored in database
    const enrichmentData = await page.evaluate(() => {
      return fetch('/api/properties/test-property-id/enrichment')
        .then(r => r.json());
    });
    
    expect(enrichmentData.owner.name).toBe('John Doe');
    expect(enrichmentData.phones).toHaveLength(2);
    expect(enrichmentData.emails).toHaveLength(1);
  });

  test('should hit cache on re-enrichment of same target', async ({ page }) => {
    // Set up property that's already been enriched
    await page.goto('/properties/test-property-123');
    
    // Mock API to track request count
    let requestCount = 0;
    await page.route('**/api/enrich*', route => {
      requestCount++;
      route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          cache_hit: true,
          enrichment_data: { /* cached data */ }
        })
      });
    });
    
    // First enrichment request
    await page.click('button:has-text("Enrich Property")');
    await expect(page.locator('.enrichment-complete')).toBeVisible();
    
    // Second enrichment request (should hit cache)
    await page.click('button:has-text("Enrich Property")');
    await expect(page.locator('.cache-hit-indicator')).toBeVisible();
    
    // Verify only one network request was made due to caching
    expect(requestCount).toBe(1);
  });

  test('should handle 429 rate limiting with exponential backoff without UI crash', async ({ page }) => {
    await page.goto('/properties');
    
    // Mock rate limiting scenario
    let requestCount = 0;
    await page.route('**/api/enrich*', route => {
      requestCount++;
      
      if (requestCount <= 3) {
        // Return 429 for first few requests
        route.fulfill({
          status: 429,
          contentType: 'application/json',
          body: JSON.stringify({
            error: 'Rate limit exceeded',
            retry_after: 2
          })
        });
      } else {
        // Success after retries
        route.fulfill({
          status: 200,
          contentType: 'application/json',
          body: JSON.stringify({
            enrichment_data: { success: true }
          })
        });
      }
    });
    
    // Start enrichment process
    await page.click('button:has-text("Bulk Enrich")');
    
    // Should show rate limit warning, not crash
    await expect(page.locator('.rate-limit-warning')).toBeVisible();
    await expect(page.locator('text=Rate limited, retrying...')).toBeVisible();
    
    // Should show exponential backoff progress
    await expect(page.locator('.retry-countdown')).toBeVisible();
    
    // Wait for eventual success
    await expect(page.locator('.enrichment-complete')).toBeVisible({ timeout: 10000 });
    
    // UI should remain responsive throughout
    await expect(page.locator('nav')).toBeVisible();
    await expect(page.locator('.main-content')).toBeVisible();
    
    // Verify multiple retry attempts were made
    expect(requestCount).toBeGreaterThan(1);
  });

  test('should display enrichment provider health status', async ({ page }) => {
    await page.goto('/admin/health');
    
    // Mock provider health check
    await page.route('**/api/health/providers*', route => {
      route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          skiptrace: {
            name: 'Skiptrace Provider',
            ok: true,
            latency_ms: 245,
            quota: '8,500 / 10,000 requests',
            last_check: new Date().toISOString()
          },
          mapbox: {
            name: 'Mapbox Geocoding',
            ok: true,
            latency_ms: 120,
            quota: '90,000 / 100,000 requests',
            last_check: new Date().toISOString()
          }
        })
      });
    });
    
    // Should display provider status
    await expect(page.locator('.provider-status')).toBeVisible();
    await expect(page.locator('text=Skiptrace Provider')).toBeVisible();
    await expect(page.locator('text=245ms')).toBeVisible();
    await expect(page.locator('text=8,500 / 10,000')).toBeVisible();
    
    // Status indicators should be green for healthy providers
    await expect(page.locator('.status-indicator.healthy')).toHaveCount(2);
  });
});

async function authenticateUser(page: any) {
  await page.evaluate(() => {
    localStorage.setItem('supabase.auth.token', 'mock-auth-token');
  });
}