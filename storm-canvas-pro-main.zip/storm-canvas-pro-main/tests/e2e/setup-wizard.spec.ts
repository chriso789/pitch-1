import { test, expect } from '@playwright/test';

// Gates 0 & 4: Setup wizard tests
test.describe('Setup Wizard', () => {
  test('should land on /setup when booting with missing environment variables', async ({ page }) => {
    // Mock missing environment variables scenario
    await page.route('**/api/health*', route => {
      route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          status: 'error',
          checks: {
            supabase: { ok: false, error: 'Missing SUPABASE_URL' },
            mapbox: { ok: false, error: 'Missing MAPBOX_TOKEN' },
            skiptrace: { ok: false, error: 'Missing SKIPTRACE_API_KEY' }
          }
        })
      });
    });

    await page.goto('/');
    
    // Should redirect to setup wizard
    await expect(page).toHaveURL('/setup');
    
    // Should show setup wizard UI
    await expect(page.locator('h1')).toContainText('Setup');
    await expect(page.locator('text=Environment Configuration')).toBeVisible();
  });

  test('should show inline error for invalid Mapbox token and prevent advancement', async ({ page }) => {
    await page.goto('/setup');
    
    // Fill in valid Supabase config
    await page.fill('input[name="supabase_url"]', 'https://test.supabase.co');
    await page.fill('input[name="supabase_anon_key"]', 'valid_anon_key');
    
    // Fill in invalid Mapbox token
    await page.fill('input[name="mapbox_token"]', 'invalid_token');
    
    // Mock Mapbox token validation to return error
    await page.route('**/api/validate/mapbox*', route => {
      route.fulfill({
        status: 400,
        contentType: 'application/json',
        body: JSON.stringify({
          error: 'Invalid Mapbox token'
        })
      });
    });
    
    // Try to advance to next step
    await page.click('button:has-text("Next")');
    
    // Should show inline error
    await expect(page.locator('.error-message')).toContainText('Invalid Mapbox token');
    
    // Should not advance to next step
    await expect(page.locator('text=Skiptrace Configuration')).not.toBeVisible();
    
    // Next button should remain disabled or show error state
    const nextButton = page.locator('button:has-text("Next")');
    await expect(nextButton).toBeDisabled();
  });

  test('should complete setup flow with all valid configuration and hide badge', async ({ page }) => {
    await page.goto('/setup');
    
    // Fill in valid configuration
    await page.fill('input[name="supabase_url"]', 'https://test.supabase.co');
    await page.fill('input[name="supabase_anon_key"]', 'valid_anon_key');
    await page.fill('input[name="mapbox_token"]', 'valid_mapbox_token');
    await page.fill('input[name="skiptrace_api_key"]', 'valid_skiptrace_key');
    
    // Mock all validations to pass
    await page.route('**/api/validate/**', route => {
      route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({ valid: true })
      });
    });
    
    // Complete setup wizard
    await page.click('button:has-text("Next")'); // Step 1
    await page.click('button:has-text("Next")'); // Step 2
    await page.click('button:has-text("Finish Setup")'); // Final step
    
    // Should redirect to main app
    await expect(page).not.toHaveURL('/setup');
    
    // Setup badge should not be visible
    await expect(page.locator('[data-testid="setup-badge"]')).not.toBeVisible();
    
    // Should be able to access main features
    await expect(page.locator('nav')).toBeVisible();
    await expect(page.locator('[data-testid="map-container"]')).toBeVisible();
  });

  test('should show setup badge until all providers are validated', async ({ page }) => {
    // Mock partial configuration (only some providers valid)
    await page.route('**/api/health*', route => {
      route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          status: 'partial',
          checks: {
            supabase: { ok: true },
            mapbox: { ok: false, error: 'Invalid token' },
            skiptrace: { ok: true }
          }
        })
      });
    });

    await page.goto('/');
    
    // Setup badge should be visible
    await expect(page.locator('[data-testid="setup-badge"]')).toBeVisible();
    
    // Clicking badge should navigate to setup
    await page.click('[data-testid="setup-badge"]');
    await expect(page).toHaveURL('/setup');
  });
});