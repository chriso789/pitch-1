# PITCH CRM Integration Guide

## Overview
The CanvassIQ app now includes full bi-directional integration with PITCH CRM, automatically syncing qualified leads and tracking project completion.

## Features

### 1. Automatic Lead Sync (CanvassIQ → PITCH)
When a canvasser sets specific dispositions, the lead is automatically synced to PITCH CRM with all collected information.

**Dispositions that sync to PITCH CRM:**
- ⭐ **Signed Contingency** - Agreement signed, ready for processing
- ⭐ **Signed Contract** - Full contract signed
- ⭐📅 **Go Back** - Follow-up appointment scheduled (includes date/time)

**Data synced includes:**
- First Name & Last Name (from skip trace or manual entry)
- Phone Number & Email
- Full Property Address
- Disposition Status
- Appointment Date/Time (if scheduled)
- Canvasser Notes
- Property Details (roof age, storm damage flags, etc.)
- Lead Score (calculated based on property characteristics)

### 2. Contact Collection Flow
Before setting any disposition, the app requires homeowner data:

1. **Automatic Skip Trace**: When clicking a property bubble, skip trace runs automatically
2. **Data Confirmation**: Canvasser reviews and can edit skip-traced data
3. **Manual Override**: Can enter all data manually if skip trace fails
4. **Required Fields**: First Name and Last Name are mandatory
5. **Disposition Selection**: Only after confirming contact data

### 3. Appointment Scheduling
For the "Go Back" disposition:
- Date picker with calendar view
- Time picker with 15-minute intervals (8 AM - 8 PM)
- Appointment date/time synced to PITCH CRM

### 4. Reverse Sync (PITCH → CanvassIQ)
When a project is completed in PITCH CRM:
- Webhook receives "project.completed" event
- Automatically updates property disposition to "Project Completed"
- Maintains audit trail with notes

## Setup Instructions

### Step 1: Configure PITCH CRM Integration

1. Go to the Admin page in CanvassIQ
2. Navigate to the PITCH Integration section
3. Enter your PITCH CRM Base URL (e.g., `https://api.pitchcrm.com`)
4. Enter your PITCH CRM API Key
5. Click "Save Configuration"
6. Click "Test Connection" to verify

### Step 2: Configure PITCH CRM Webhook (for reverse sync)

1. In PITCH CRM, go to **Settings → Webhooks**
2. Click **Add New Webhook**
3. Enter the webhook URL: `https://bevovurzumbupezcarql.supabase.co/functions/v1/pitch-webhook`
4. Select event type: **project.completed**
5. Save the webhook configuration

### Step 3: Map Your Reps (Optional)

If you want to assign leads to specific reps in PITCH:

```sql
-- Insert rep mapping in Supabase
INSERT INTO rep_integrations (user_id, pitch_rep_id, is_active)
VALUES 
  ('user-uuid-here', 'pitch-rep-id-here', true);
```

## Technical Architecture

### Database Schema

#### New Columns Added:
- `dispositions.sync_to_pitch` (boolean) - Flags which dispositions sync
- `dispositions.requires_appointment` (boolean) - Requires appointment scheduling
- `contacts.first_name` (text) - Separate first name field
- `contacts.last_name` (text) - Separate last name field
- `visits.appointment_date` (timestamp) - Scheduled appointment time

#### Workflow:
1. **Property Click** → Opens `HomeownerContactModal`
2. **Skip Trace** → Runs automatically, populates contact fields
3. **Contact Confirmation** → User confirms/edits data, saved to `contacts` table
4. **Disposition Selection** → User selects disposition
5. **Visit Creation** → Creates record in `visits` table with disposition
6. **Trigger Fires** → `handle_disposition_visit()` checks `sync_to_pitch` flag
7. **Outbox Queue** → If true, adds event to `outbox` table
8. **Worker Dispatch** → `worker-dispatch` function processes outbox
9. **PITCH Sync** → `sync-to-pitch` function sends data to PITCH CRM

### Edge Functions

#### `sync-to-pitch`
Sends qualified leads to PITCH CRM with full contact and property data.

**Input:**
```json
{
  "property_id": "uuid",
  "disposition_id": "uuid",
  "user_id": "uuid"
}
```

**Enrichment:**
- Fetches property data from `properties` table
- Fetches contact data from `contacts` table
- Fetches visit/appointment data from `visits` table
- Calculates lead score based on property characteristics
- Generates formatted notes

#### `pitch-webhook`
Receives webhook events from PITCH CRM.

**Supported Events:**
- `project.completed` - Updates property disposition when project completes

**Webhook Payload:**
```json
{
  "event": "project.completed",
  "data": {
    "projectId": "string",
    "completedDate": "ISO-8601",
    "customFields": {
      "propertyId": "uuid",
      "addressHash": "string"
    }
  }
}
```

#### `worker-dispatch`
Background worker that processes the outbox queue.

**Features:**
- Polls `outbox` table for queued events
- Calls appropriate handler (e.g., `sync-to-pitch`)
- Implements retry logic with exponential backoff
- Moves failed events to dead letter queue after 5 retries

## UI Updates

### New Components

#### `HomeownerContactModal`
Modal for collecting/confirming homeowner data before disposition.

**Features:**
- Automatic skip trace on open
- Loading state during skip trace
- Editable contact fields (first name, last name, phone, email)
- Date/time picker for appointments
- Cannot close during skip trace
- Validation (first/last name required)

#### `StatusQuickActions` (Updated)
Disposition selection component with visual indicators.

**New Features:**
- Grouped by category (Marketing, Qualified, Follow-up, Not Qualified, Completed)
- Visual indicators: ⭐ for PITCH sync, 📅 for appointment required
- Color-coded buttons matching disposition colors
- Legend at bottom explaining indicators

### Updated Pages

#### `Canvassing.tsx`
Main canvassing page with integrated contact flow.

**Changes:**
- Opens `HomeownerContactModal` on property pin click
- Manages contact confirmation flow
- Refreshes pins after disposition set to show new colors

## Color Scheme

All dispositions now have semantic colors:

| Disposition | Color | Hex | Meaning |
|-------------|-------|-----|---------|
| Old Roof Marketing | Blue | #3b82f6 | Marketing opportunity |
| Storm Damage | Orange | #f97316 | Urgent opportunity |
| New Roof | Green | #22c55e | Recently completed |
| Signed Contingency | Purple | #a855f7 | Qualified - contingent |
| Signed Contract | Deep Purple | #7c3aed | Qualified - contracted |
| Project Completed | Emerald | #10b981 | Successfully completed |
| Unqualified | Gray | #6b7280 | Not a good fit |
| Interested | Light Green | #86efac | Potential opportunity |
| Not Interested | Red | #ef4444 | Not interested |
| Already Solar | Amber | #f59e0b | Existing solar |
| Abandoned House | Slate | #475569 | Cannot contact |
| Go Back | Yellow | #eab308 | Follow-up needed |

## Testing the Integration

### Test the Contact Flow:
1. Open the Canvassing page
2. Click any property bubble on the map
3. Wait for skip trace to complete
4. Verify contact data displays correctly
5. Edit if needed, then click "Confirm & Continue"
6. Select a disposition

### Test PITCH Sync:
1. Follow the contact flow above
2. Select a disposition with ⭐ (e.g., "Signed Contingency")
3. Check the `outbox` table - should have a new queued event
4. Manually trigger `worker-dispatch` or wait for automatic processing
5. Check PITCH CRM - lead should appear with all contact data

### Test Appointment Scheduling:
1. Follow the contact flow
2. Select "Go Back" disposition (has 📅 indicator)
3. Calendar picker should appear
4. Select date and time
5. Click "Schedule & Save"
6. Verify appointment_date in `visits` table
7. Check PITCH CRM - lead should include appointment time

### Test Reverse Sync:
1. Create a test webhook in PITCH CRM
2. Mark a project as completed in PITCH
3. Webhook should fire to CanvassIQ
4. Check `visits` table - new visit with "Project Completed" disposition
5. Check map - property bubble should update to green

## Troubleshooting

### Skip trace not working
- Check edge function logs: `supabase functions logs skip-trace-free`
- Verify skip trace providers are configured
- Check network tab for errors

### Lead not syncing to PITCH
- Check `outbox` table status - should show "sent" after processing
- Check edge function logs: `supabase functions logs sync-to-pitch`
- Verify PITCH CRM credentials are correct
- Test connection in Admin settings

### Webhook not receiving
- Verify webhook URL is correct in PITCH CRM
- Check edge function logs: `supabase functions logs pitch-webhook`
- Verify webhook secret is configured (optional)

### Appointment not showing in PITCH
- Check `visits` table - appointment_date should be populated
- Verify the sync payload includes appointmentDate field
- Check PITCH CRM API documentation for field names

## Database Queries

### Check recent syncs:
```sql
SELECT * FROM outbox 
WHERE event_type = 'disposition.created' 
ORDER BY created_at DESC 
LIMIT 10;
```

### Check contacts for a property:
```sql
SELECT * FROM contacts 
WHERE property_id = 'property-uuid-here' 
AND is_active = true;
```

### Check visits with appointments:
```sql
SELECT v.*, d.name as disposition, p.address 
FROM visits v
JOIN dispositions d ON d.id = v.disposition_id
JOIN properties p ON p.id = v.property_id
WHERE v.appointment_date IS NOT NULL
ORDER BY v.appointment_date DESC;
```

### Check PITCH sync statistics:
```sql
SELECT 
  d.name,
  COUNT(*) as sync_count,
  d.sync_to_pitch
FROM visits v
JOIN dispositions d ON d.id = v.disposition_id
WHERE v.created_at > NOW() - INTERVAL '7 days'
GROUP BY d.name, d.sync_to_pitch
ORDER BY sync_count DESC;
```

## Security Considerations

1. **API Keys**: Never expose PITCH CRM API keys in client code
2. **Webhook Signature**: Enable webhook signature verification for production
3. **RLS Policies**: All tables have Row Level Security enabled
4. **Service Role**: Background workers use service role key for database access
5. **Contact Data**: PII stored securely with proper access controls

## Future Enhancements

Potential improvements for future releases:

1. **Bulk Operations**: Sync multiple leads at once
2. **Custom Field Mapping**: Configure which fields map to PITCH
3. **Rep Dashboard**: View sync status and stats per rep
4. **Retry Management**: UI for managing failed syncs
5. **Two-way Disposition Sync**: Update CanvassIQ when status changes in PITCH
6. **Activity Timeline**: Show full sync history for each property
