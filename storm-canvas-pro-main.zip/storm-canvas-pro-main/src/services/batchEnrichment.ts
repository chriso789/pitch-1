// Batch enrichment service for Gate 3 compliance
import { SkiptraceService } from './skiptraceApi';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { createSkiptraceRateLimiter, ExponentialBackoffRetry, DEFAULT_RETRY_OPTIONS } from '@/lib/rateLimit';

export interface BatchEnrichmentOptions {
  concurrency?: number;
  progressCallback?: (progress: BatchProgress) => void;
  rateLimiter?: any;
}

export interface BatchProgress {
  total: number;
  completed: number;
  failed: number;
  inProgress: number;
  percentage: number;
  errors: BatchError[];
}

export interface BatchError {
  propertyId: string;
  address: string;
  error: string;
  timestamp: Date;
}

export interface BatchResult {
  success: boolean;
  enriched: number;
  failed: number;
  skipped: number;
  errors: BatchError[];
  duration: number;
}

export class BatchEnrichmentService {
  private rateLimiter = createSkiptraceRateLimiter();
  private retry = new ExponentialBackoffRetry(DEFAULT_RETRY_OPTIONS);

  async enrichPropertiesBatch(
    propertyIds: string[],
    options: BatchEnrichmentOptions = {}
  ): Promise<BatchResult> {
    const startTime = Date.now();
    const { concurrency = 3, progressCallback } = options;
    
    console.log(`Starting batch enrichment for ${propertyIds.length} properties with concurrency ${concurrency}`);
    
    const progress: BatchProgress = {
      total: propertyIds.length,
      completed: 0,
      failed: 0,
      inProgress: 0,
      percentage: 0,
      errors: []
    };

    const results = {
      success: true,
      enriched: 0,
      failed: 0,
      skipped: 0,
      errors: [] as BatchError[],
      duration: 0
    };

    // Fetch properties that need enrichment
    const { data: properties, error } = await supabase
      .from('properties')
      .select('id, address, latitude, longitude, enriched_at')
      .in('id', propertyIds);

    if (error) {
      toast.error('Failed to fetch properties for enrichment');
      throw new Error(error.message);
    }

    if (!properties || properties.length === 0) {
      toast.warning('No properties found for enrichment');
      return { ...results, duration: Date.now() - startTime };
    }

    // Filter properties that haven't been enriched recently
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const propertiesToEnrich = properties.filter(p => 
      !p.enriched_at || new Date(p.enriched_at) < thirtyDaysAgo
    );

    results.skipped = properties.length - propertiesToEnrich.length;
    progress.total = propertiesToEnrich.length;

    if (propertiesToEnrich.length === 0) {
      toast.info('All properties are already enriched within the last 30 days');
      return { ...results, duration: Date.now() - startTime };
    }

    toast.info(`Enriching ${propertiesToEnrich.length} properties (${results.skipped} skipped as recently enriched)`);

    // Process in batches with concurrency control
    const promises: Promise<void>[] = [];
    const semaphore = new Semaphore(concurrency);

    for (const property of propertiesToEnrich) {
      const promise = semaphore.acquire().then(async () => {
        try {
          progress.inProgress++;
          progressCallback?.(progress);

          await this.enrichSingleProperty(property);
          
          progress.completed++;
          results.enriched++;
          
        } catch (error) {
          const batchError: BatchError = {
            propertyId: property.id,
            address: property.address || 'Unknown address',
            error: error instanceof Error ? error.message : String(error),
            timestamp: new Date()
          };
          
          progress.errors.push(batchError);
          results.errors.push(batchError);
          progress.failed++;
          results.failed++;
          
        } finally {
          progress.inProgress--;
          progress.percentage = Math.round((progress.completed + progress.failed) / progress.total * 100);
          progressCallback?.(progress);
          semaphore.release();
        }
      });

      promises.push(promise);
    }

    // Wait for all enrichments to complete
    await Promise.all(promises);

    results.duration = Date.now() - startTime;
    results.success = results.failed < results.enriched; // Success if more succeeded than failed

    const successRate = Math.round(results.enriched / (results.enriched + results.failed) * 100);
    
    if (results.success) {
      toast.success(`Batch enrichment completed: ${results.enriched} enriched, ${results.failed} failed (${successRate}% success rate)`);
    } else {
      toast.error(`Batch enrichment completed with issues: ${results.enriched} enriched, ${results.failed} failed (${successRate}% success rate)`);
    }

    return results;
  }

  private async enrichSingleProperty(property: any): Promise<void> {
    // Wait for rate limiter
    while (!(await this.rateLimiter.canProceed())) {
      await this.delay(100); // Wait 100ms before checking again
    }

    // Record last enrichment attempt
    await supabase
      .from('properties')
      .update({ last_enrichment_attempt: new Date().toISOString() })
      .eq('id', property.id);

    // Perform enrichment with retry logic
    const enrichmentResult = await this.retry.execute(
      () => SkiptraceService.enrichProperty(property.address, property.latitude, property.longitude),
      `Property ${property.id} enrichment`
    );

    if (!enrichmentResult.success) {
      throw new Error(enrichmentResult.error || 'Enrichment failed');
    }

    // Update property with enriched data
    const updateData = {
      ...enrichmentResult.data,
      enriched_at: new Date().toISOString(),
      enrichment_source: 'batch_skiptrace'
    };

    const { error: updateError } = await supabase
      .from('properties')
      .update(updateData)
      .eq('id', property.id);

    if (updateError) {
      throw new Error(`Failed to update property: ${updateError.message}`);
    }

    console.log(`Successfully enriched property ${property.id}`);
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  getRateLimiterStatus(): { tokensRemaining: number } {
    return {
      tokensRemaining: this.rateLimiter.getTokensRemaining()
    };
  }
}

// Semaphore for controlling concurrency
class Semaphore {
  private permits: number;
  private waiting: (() => void)[] = [];

  constructor(permits: number) {
    this.permits = permits;
  }

  async acquire(): Promise<void> {
    if (this.permits > 0) {
      this.permits--;
      return Promise.resolve();
    }

    return new Promise<void>((resolve) => {
      this.waiting.push(resolve);
    });
  }

  release(): void {
    this.permits++;
    if (this.waiting.length > 0) {
      const resolve = this.waiting.shift()!;
      resolve();
    }
  }
}

// Export singleton instance
export const batchEnrichmentService = new BatchEnrichmentService();