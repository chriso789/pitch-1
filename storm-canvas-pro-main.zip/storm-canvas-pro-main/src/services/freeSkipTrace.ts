import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface SkipTraceContact {
  name?: string;
  phone?: string;
  email?: string;
  confidence?: number;
  provider: string;
  type?: 'owner' | 'resident' | 'related';
}

interface SkipTraceResult {
  parcel?: {
    apn?: string;
    ownerNames?: string[];
    situsAddress?: string;
    mailingAddress?: string;
    propertyValue?: number;
    yearBuilt?: number;
    squareFootage?: number;
    propertyType?: string;
    qualityGrade?: string;
    condition?: string;
  };
  contacts: SkipTraceContact[];
  source?: string;
  processedAt?: Date;
  confidence?: number;
  ownerType?: 'individual' | 'business' | 'trust' | 'llc' | 'unknown';
  isOwnerOccupied?: boolean;
  propertyInsights?: {
    marketValue?: number;
    assessedValue?: number;
    valuationConfidence?: number;
    recentSale?: boolean;
    saleHistory?: Array<{ date: string; price: number }>;
  };
}

interface FreeSkipTraceResponse {
  success: boolean;
  data?: SkipTraceResult;
  error?: string;
  provider?: string;
  timestamp?: string;
}

class FreeSkipTraceService {
  
  /**
   * Perform skip trace lookup using free public data sources
   */
  static async lookup(params: {
    address?: string;
    lat?: number;
    lng?: number;
    apn?: string;
    propertyId?: string;
    leadId?: string;
  }): Promise<FreeSkipTraceResponse> {
    try {
      console.log('Free skip trace lookup:', params);

      const { data, error } = await supabase.functions.invoke('skip-trace-free', {
        body: {
          address: params.address,
          lat: params.lat,
          lng: params.lng,
          apn: params.apn,
          property_id: params.propertyId,
          lead_id: params.leadId
        }
      });

      if (error) {
        console.error('Skip trace function error:', error);
        throw new Error(error.message || 'Skip trace request failed');
      }

      if (!data.success) {
        throw new Error(data.error || 'Skip trace lookup failed');
      }

      console.log('Skip trace result:', data);
      return data;

    } catch (error) {
      console.error('Free skip trace service error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error occurred',
        provider: 'free-public-records'
      };
    }
  }

  /**
   * Get health status of the free skip trace service
   */
  static async health(): Promise<{ ok: boolean; latency_ms: number; error?: string }> {
    const startTime = Date.now();
    
    try {
      // Test with a simple address lookup
      const result = await this.lookup({
        address: '123 Main St, New York, NY 10001'
      });

      return {
        ok: result.success,
        latency_ms: Date.now() - startTime,
        error: result.success ? undefined : result.error
      };

    } catch (error) {
      return {
        ok: false,
        latency_ms: Date.now() - startTime,
        error: error instanceof Error ? error.message : 'Health check failed'
      };
    }
  }

  /**
   * Get recent skip trace jobs for a user
   */
  static async getRecentJobs(limit: number = 10) {
    try {
      const { data, error } = await supabase
        .from('skip_trace_jobs')
        .select(`
          *,
          properties:property_id(address, geom),
          leads:lead_id(address, city, state)
        `)
        .order('created_at', { ascending: false })
        .limit(limit);

      if (error) throw error;

      return { success: true, data };
    } catch (error) {
      console.error('Failed to fetch skip trace jobs:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to fetch jobs'
      };
    }
  }

  /**
   * Get contacts for a property or lead
   */
  static async getContacts(params: { propertyId?: string; leadId?: string }) {
    try {
      let query = supabase.from('contacts').select('*');

      if (params.propertyId) {
        query = query.eq('property_id', params.propertyId);
      } else if (params.leadId) {
        query = query.eq('lead_id', params.leadId);
      } else {
        throw new Error('Either propertyId or leadId is required');
      }

      const { data, error } = await query.order('confidence', { ascending: false });

      if (error) throw error;

      return { success: true, data };
    } catch (error) {
      console.error('Failed to fetch contacts:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Failed to fetch contacts'
      };
    }
  }

  /**
   * Test the service with UI feedback
   */
  static async testService() {
    toast.info('Testing free skip trace service...');
    
    const result = await this.health();
    
    if (result.ok) {
      toast.success(`Free skip trace service is working! (${result.latency_ms}ms)`);
    } else {
      toast.error(`Service test failed: ${result.error}`);
    }
    
    return result;
  }
}

export { FreeSkipTraceService };
export type { SkipTraceResult, SkipTraceContact, FreeSkipTraceResponse };