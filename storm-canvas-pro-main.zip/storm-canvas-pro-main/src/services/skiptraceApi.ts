// Enhanced Property Enrichment Service with Provider Interface and Rate Limiting
import { toast } from 'sonner';
import { getEnrichmentService } from '@/lib/enrichment';
import { AddressSchema, type Address, type Enrichment, type Provider, type Health } from '@/lib/enrichment/types';
import { config } from '@/lib/config';
import { createSkiptraceRateLimiter, ExponentialBackoffRetry, DEFAULT_RETRY_OPTIONS } from '@/lib/rateLimit';

interface PropertyEnrichmentData {
  homeowner_name?: string;
  phone?: string;
  email?: string;
  credit_score?: number;
  age?: number;
  gender?: string;
  property_value?: number;
  mortgage_balance?: number;
  equity?: number;
  home_purchase_date?: string;
  last_sale_price?: number;
  place_id?: string;
  lat?: number;
  lng?: number;
  apn?: string;
  year_built?: number;
  square_footage?: number;
}

interface SkiptraceResponse {
  success: boolean;
  data?: PropertyEnrichmentData;
  error?: string;
}

class SkiptraceService {
  private static readonly API_BASE = 'https://api.skiptracing-provider.com/v1';
  private static apiKey: string | null = null;
  private static rateLimiter = createSkiptraceRateLimiter();
  private static retry = new ExponentialBackoffRetry(DEFAULT_RETRY_OPTIONS);

  static setApiKey(key: string) {
    this.apiKey = key;
    localStorage.setItem('skiptrace_api_key', key);
  }

  static getApiKey(): string | null {
    if (!this.apiKey) {
      this.apiKey = localStorage.getItem('skiptrace_api_key');
    }
    return this.apiKey;
  }

  /**
   * Enhanced property enrichment with rate limiting and retry logic
   */
  static async enrichProperty(address: string, latitude?: number, longitude?: number): Promise<SkiptraceResponse> {
    // Wait for rate limiter
    while (!(await this.rateLimiter.canProceed())) {
      toast.info('Rate limit reached, waiting...', { duration: 2000 });
      await this.delay(1000);
    }

    try {
      console.log('Enriching property with rate limiting:', { address, latitude, longitude });
      
      return await this.retry.execute(
        () => this.performEnrichment(address, latitude, longitude),
        `Property enrichment for ${address}`
      );

    } catch (error) {
      console.error('Property enrichment error:', error);
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }

  /**
   * Internal enrichment logic
   */
  private static async performEnrichment(address: string, latitude?: number, longitude?: number): Promise<SkiptraceResponse> {
    try {
      // Parse address string into components
      const addressParts = this.parseAddressString(address);
      
      // Validate address using Zod
      const addressResult = AddressSchema.safeParse(addressParts);
      if (!addressResult.success) {
        return {
          success: false,
          error: `Invalid address format: ${addressResult.error.message}`
        };
      }

      // Use the new enrichment service
      const enrichmentService = getEnrichmentService();
      const enrichment = await enrichmentService.enrich(addressResult.data, {
        staleDays: 30
      });

      // Convert enrichment result to legacy format
      const data = this.mapEnrichmentToLegacyFormat(enrichment);

      return {
        success: true,
        data
      };

    } catch (error) {
      console.error('Property enrichment error:', error);
      throw error; // Re-throw for retry logic
    }
  }

  /**
   * Parse a full address string into components
   */
  private static parseAddressString(address: string): Partial<Address> {
    // Basic address parsing - in production, use a proper address parser
    const parts = address.split(',').map(p => p.trim());
    
    if (parts.length < 3) {
      // If we don't have enough parts, make assumptions
      return {
        line1: address,
        city: 'Unknown',
        state: 'FL', // Default to Florida for canvassing app
        postal_code: '00000'
      };
    }

    const [line1, city, stateZip] = parts;
    const stateZipMatch = stateZip.match(/([A-Z]{2})\s*(\d{5}(?:-\d{4})?)?/);
    
    return {
      line1,
      city,
      state: stateZipMatch?.[1] || 'FL',
      postal_code: stateZipMatch?.[2]?.replace('-', '').substring(0, 5) || '00000'
    };
  }

  /**
   * Convert enrichment result to legacy format for backward compatibility
   */
  private static mapEnrichmentToLegacyFormat(enrichment: Enrichment): PropertyEnrichmentData {
    const phone = enrichment.phones?.[0]?.number;
    const email = enrichment.emails?.[0]?.email;
    
    return {
      homeowner_name: enrichment.owner?.name,
      phone: phone,
      email: email,
      credit_score: undefined, // Not available in simplified schema
      age: undefined, // Not available in simplified schema
      gender: undefined, // Not available in simplified schema
      property_value: undefined, // Not available in simplified schema
      mortgage_balance: undefined, // Not available in simplified schema
      equity: undefined, // Not available in simplified schema
      last_sale_price: undefined, // Not available in simplified schema
      place_id: enrichment.place_id,
      lat: enrichment.location?.lat,
      lng: enrichment.location?.lng,
      apn: enrichment.parcel?.apn,
      year_built: undefined, // Not available in simplified schema
      square_footage: undefined, // Not available in simplified schema
    };
  }

  private static generateMockName(): string {
    const firstNames = ['John', 'Sarah', 'Michael', 'Emily', 'David', 'Jessica', 'Robert', 'Ashley', 'James', 'Amanda'];
    const lastNames = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Rodriguez', 'Martinez'];
    
    const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
    const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
    
    return `${firstName} ${lastName}`;
  }

  private static generateMockPhone(): string {
    const areaCode = Math.floor(Math.random() * 800) + 200;
    const exchange = Math.floor(Math.random() * 800) + 200;
    const number = Math.floor(Math.random() * 9000) + 1000;
    
    return `(${areaCode}) ${exchange}-${number}`;
  }

  private static generateMockEmail(): string {
    const domains = ['gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com', 'aol.com'];
    const domain = domains[Math.floor(Math.random() * domains.length)];
    const username = Math.random().toString(36).substring(2, 10);
    
    return `${username}@${domain}`;
  }

  static async testConnection(): Promise<boolean> {
    const apiKey = this.getApiKey();
    if (!apiKey) return false;

    try {
      // Test with rate limiting
      while (!(await this.rateLimiter.canProceed())) {
        await this.delay(100);
      }
      
      // Mock test - replace with actual API health check
      await new Promise(resolve => setTimeout(resolve, 1000));
      return true;
    } catch {
      return false;
    }
  }

  static getRateLimiterStatus(): { tokensRemaining: number } {
    return {
      tokensRemaining: this.rateLimiter.getTokensRemaining()
    };
  }

  private static delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// Provider adapter for enrichment service  
export function createSkiptraceProvider(): Provider {
  return {
    name: 'skiptrace',
    
    async health(): Promise<Health> {
      try {
        const startTime = Date.now();
        const isConnected = await SkiptraceService.testConnection();
        return {
          name: 'skiptrace',
          ok: isConnected,
          latency_ms: Date.now() - startTime
        };
      } catch (error) {
        return {
          name: 'skiptrace',
          ok: false,
          error: error instanceof Error ? error.message : 'Configuration error'
        };
      }
    },

    async normalize(addr: Address): Promise<{ address: Address }> {
      // For now, return the address as-is
      // In a real implementation, this could normalize via USPS or similar
      return { address: addr };
    },

    async geocode(addr: Address): Promise<{ place_id: string; lat: number; lng: number }> {
      const addressString = `${addr.line1}, ${addr.city}, ${addr.state} ${addr.postal_code}`;
      const result = await SkiptraceService.enrichProperty(addressString);
      
      if (!result.success || !result.data?.lat || !result.data?.lng) {
        throw new Error('No location data returned from Skiptrace');
      }

      return {
        place_id: result.data.place_id || `skiptrace:${addr.line1}:${addr.postal_code}`,
        lat: result.data.lat,
        lng: result.data.lng,
      };
    },

    async property(addr: Address | { place_id: string }): Promise<{
      apn?: string;
      wkt?: string;
      owner?: string;
      value?: number;
      year_built?: number;
      square_footage?: number;
    }> {
      if ('place_id' in addr) {
        // Can't enrich from place_id alone with current API
        throw new Error('Skiptrace requires full address for property data');
      }

      const addressString = `${addr.line1}, ${addr.city}, ${addr.state} ${addr.postal_code}`;
      const result = await SkiptraceService.enrichProperty(addressString);
      
      if (!result.success) {
        throw new Error(result.error || 'Failed to get property data');
      }
      
      return {
        owner: result.data?.homeowner_name,
        value: result.data?.property_value,
        year_built: result.data?.year_built,
        square_footage: result.data?.square_footage,
        apn: result.data?.apn,
      };
    },

    async people(input: { name?: string; address: Address }): Promise<{
      phones?: string[];
      emails?: string[];
      age?: number;
      gender?: string;
      credit_score?: number;
    }> {
      const addressString = `${input.address.line1}, ${input.address.city}, ${input.address.state} ${input.address.postal_code}`;
      const result = await SkiptraceService.enrichProperty(addressString);
      
      if (!result.success) {
        throw new Error(result.error || 'Failed to get people data');
      }
      
      return {
        phones: result.data?.phone ? [result.data.phone] : undefined,
        emails: result.data?.email ? [result.data.email] : undefined,
        age: result.data?.age,
        gender: result.data?.gender,
        credit_score: result.data?.credit_score,
      };
    },

    async phoneVerify(numbers: string[]): Promise<Array<{
      number: string;
      type?: string;
      score?: number;
      carrier?: string;
    }>> {
      // For now, we don't have a separate phone verification endpoint
      // Return the numbers with basic formatting and scores
      return numbers.map(number => ({
        number,
        type: 'unknown',
        score: 0.5,
      }));
    },
  };
}

export { SkiptraceService };
export type { PropertyEnrichmentData, SkiptraceResponse };