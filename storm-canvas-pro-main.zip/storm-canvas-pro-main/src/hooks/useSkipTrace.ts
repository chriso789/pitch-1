// React hook for skip-trace functionality
import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import type { SkipTraceResult, SkipTraceJob } from '@/lib/skiptrace/types';

export function useSkipTrace() {
  const [loading, setLoading] = useState(false);
  const [jobs, setJobs] = useState<SkipTraceJob[]>([]);

  const runSkipTrace = useCallback(async (input: {
    leadId?: string;
    propertyId?: string;
    address?: string;
    lat?: number;
    lng?: number;
  }) => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('skip-trace', {
        body: input
      });

      if (error) throw error;

      if (data?.success) {
        toast.success('Skip-trace completed successfully');
        return data.result as SkipTraceResult;
      } else {
        throw new Error(data?.error || 'Skip-trace failed');
      }
    } catch (error) {
      console.error('Skip-trace error:', error);
      toast.error('Failed to run skip-trace');
      throw error;
    } finally {
      setLoading(false);
    }
  }, []);

  const getSkipTraceJobs = useCallback(async (leadId?: string, propertyId?: string) => {
    try {
      let query = supabase
        .from('skip_trace_jobs')
        .select('*')
        .order('created_at', { ascending: false });

      if (leadId) {
        query = query.eq('lead_id', leadId);
      }
      if (propertyId) {
        query = query.eq('property_id', propertyId);
      }

      const { data, error } = await query;
      
      if (error) throw error;
      
      setJobs(data || []);
      return data || [];
    } catch (error) {
      console.error('Error fetching skip-trace jobs:', error);
      toast.error('Failed to load skip-trace jobs');
      return [];
    }
  }, []);

  const getContacts = useCallback(async (leadId?: string, propertyId?: string) => {
    try {
      let query = supabase
        .from('contacts')
        .select('*')
        .eq('is_active', true)
        .order('confidence', { ascending: false });

      if (leadId) {
        query = query.eq('lead_id', leadId);
      }
      if (propertyId) {
        query = query.eq('property_id', propertyId);
      }

      const { data, error } = await query;
      
      if (error) throw error;
      
      return data || [];
    } catch (error) {
      console.error('Error fetching contacts:', error);
      toast.error('Failed to load contacts');
      return [];
    }
  }, []);

  const getProviderHealth = useCallback(async () => {
    // Mock health check for now - in production this would call a real endpoint
    return [
      { name: 'mock', ok: true, latency_ms: 50 },
      { name: 'estated', ok: false, latency_ms: 0 },
      { name: 'pdl', ok: false, latency_ms: 0 }
    ];
  }, []);

  return {
    loading,
    jobs,
    runSkipTrace,
    getSkipTraceJobs,
    getContacts,
    getProviderHealth
  };
}