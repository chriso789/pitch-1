import { useState, useEffect, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { PropertyFilters } from '@/components/PropertyFilters';

const defaultFilters: PropertyFilters = {
  dispositions: [],
  dateRange: {
    from: undefined,
    to: undefined,
  },
  creditScoreRange: {
    min: undefined,
    max: undefined,
  },
  propertyValueRange: {
    min: undefined,
    max: undefined,
  },
  yearBuiltRange: {
    min: undefined,
    max: undefined,
  },
  hasHomeowner: null,
  isEnriched: null,
  hasVisits: null,
};

export function usePropertyFilters() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [filters, setFilters] = useState<PropertyFilters>(defaultFilters);

  // Load filters from URL on mount
  useEffect(() => {
    const urlFilters: PropertyFilters = { ...defaultFilters };

    // Parse dispositions
    const dispositionsParam = searchParams.get('dispositions');
    if (dispositionsParam) {
      urlFilters.dispositions = dispositionsParam.split(',');
    }

    // Parse date range
    const dateFromParam = searchParams.get('dateFrom');
    const dateToParam = searchParams.get('dateTo');
    if (dateFromParam) {
      urlFilters.dateRange.from = new Date(dateFromParam);
    }
    if (dateToParam) {
      urlFilters.dateRange.to = new Date(dateToParam);
    }

    // Parse credit score range
    const creditMinParam = searchParams.get('creditMin');
    const creditMaxParam = searchParams.get('creditMax');
    if (creditMinParam) {
      urlFilters.creditScoreRange.min = parseInt(creditMinParam);
    }
    if (creditMaxParam) {
      urlFilters.creditScoreRange.max = parseInt(creditMaxParam);
    }

    // Parse property value range
    const valueMinParam = searchParams.get('valueMin');
    const valueMaxParam = searchParams.get('valueMax');
    if (valueMinParam) {
      urlFilters.propertyValueRange.min = parseInt(valueMinParam);
    }
    if (valueMaxParam) {
      urlFilters.propertyValueRange.max = parseInt(valueMaxParam);
    }

    // Parse year built range
    const yearMinParam = searchParams.get('yearMin');
    const yearMaxParam = searchParams.get('yearMax');
    if (yearMinParam) {
      urlFilters.yearBuiltRange.min = parseInt(yearMinParam);
    }
    if (yearMaxParam) {
      urlFilters.yearBuiltRange.max = parseInt(yearMaxParam);
    }

    // Parse boolean filters
    const hasHomeownerParam = searchParams.get('hasHomeowner');
    if (hasHomeownerParam !== null) {
      urlFilters.hasHomeowner = hasHomeownerParam === 'true';
    }

    const isEnrichedParam = searchParams.get('isEnriched');
    if (isEnrichedParam !== null) {
      urlFilters.isEnriched = isEnrichedParam === 'true';
    }

    const hasVisitsParam = searchParams.get('hasVisits');
    if (hasVisitsParam !== null) {
      urlFilters.hasVisits = hasVisitsParam === 'true';
    }

    setFilters(urlFilters);
  }, [searchParams]);

  // Update URL when filters change
  const updateFilters = (newFilters: PropertyFilters) => {
    setFilters(newFilters);

    const newSearchParams = new URLSearchParams();

    // Add dispositions to URL
    if (newFilters.dispositions.length > 0) {
      newSearchParams.set('dispositions', newFilters.dispositions.join(','));
    }

    // Add date range to URL
    if (newFilters.dateRange.from) {
      newSearchParams.set('dateFrom', newFilters.dateRange.from.toISOString());
    }
    if (newFilters.dateRange.to) {
      newSearchParams.set('dateTo', newFilters.dateRange.to.toISOString());
    }

    // Add credit score range to URL
    if (newFilters.creditScoreRange.min) {
      newSearchParams.set('creditMin', newFilters.creditScoreRange.min.toString());
    }
    if (newFilters.creditScoreRange.max) {
      newSearchParams.set('creditMax', newFilters.creditScoreRange.max.toString());
    }

    // Add property value range to URL
    if (newFilters.propertyValueRange.min) {
      newSearchParams.set('valueMin', newFilters.propertyValueRange.min.toString());
    }
    if (newFilters.propertyValueRange.max) {
      newSearchParams.set('valueMax', newFilters.propertyValueRange.max.toString());
    }

    // Add year built range to URL
    if (newFilters.yearBuiltRange.min) {
      newSearchParams.set('yearMin', newFilters.yearBuiltRange.min.toString());
    }
    if (newFilters.yearBuiltRange.max) {
      newSearchParams.set('yearMax', newFilters.yearBuiltRange.max.toString());
    }

    // Add boolean filters to URL
    if (newFilters.hasHomeowner !== null) {
      newSearchParams.set('hasHomeowner', newFilters.hasHomeowner.toString());
    }
    if (newFilters.isEnriched !== null) {
      newSearchParams.set('isEnriched', newFilters.isEnriched.toString());
    }
    if (newFilters.hasVisits !== null) {
      newSearchParams.set('hasVisits', newFilters.hasVisits.toString());
    }

    setSearchParams(newSearchParams);
  };

  const clearFilters = () => {
    updateFilters(defaultFilters);
  };

  // Check if filters are active
  const hasActiveFilters = useMemo(() => {
    return (
      filters.dispositions.length > 0 ||
      filters.dateRange.from ||
      filters.dateRange.to ||
      filters.creditScoreRange.min ||
      filters.creditScoreRange.max ||
      filters.propertyValueRange.min ||
      filters.propertyValueRange.max ||
      filters.yearBuiltRange.min ||
      filters.yearBuiltRange.max ||
      filters.hasHomeowner !== null ||
      filters.isEnriched !== null ||
      filters.hasVisits !== null
    );
  }, [filters]);

  return {
    filters,
    updateFilters,
    clearFilters,
    hasActiveFilters,
  };
}