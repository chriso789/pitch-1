import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface ForceAddParams {
  place_id?: string;
  formatted_address?: string;
  lat?: number;
  lng?: number;
}

export function useForceAddProperty() {
  const [isAdding, setIsAdding] = useState(false);

  const forceAddProperty = async (params: ForceAddParams) => {
    setIsAdding(true);
    try {
      const { data, error } = await supabase.functions.invoke('force-add-property', {
        body: params
      });

      if (error) throw error;

      if (!data.ok) {
        throw new Error(data.error || 'Failed to add property');
      }

      toast.success(`Property added: ${data.address}`);
      return { ok: true, property_id: data.property_id };
    } catch (error: any) {
      console.error('Force add property error:', error);
      toast.error(`Failed to add property: ${error.message}`);
      return { ok: false, error: error.message };
    } finally {
      setIsAdding(false);
    }
  };

  return {
    forceAddProperty,
    isAdding,
  };
}
