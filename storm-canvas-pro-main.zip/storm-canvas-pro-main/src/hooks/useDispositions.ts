import { useSupabaseQuery } from './useSupabaseQuery';
import { supabase } from '@/integrations/supabase/client';
import { z } from 'zod';

export function useDispositions() {
  return useSupabaseQuery(
    ['dispositions'],
    async () => {
      return supabase
        .from('dispositions')
        .select('*')
        .order('name');
    },
    z.any(),
    { staleTime: 10 * 60 * 1000 }
  );
}