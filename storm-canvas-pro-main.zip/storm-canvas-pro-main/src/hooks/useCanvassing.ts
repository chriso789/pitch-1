import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface Property {
  id: string;
  address: string;
  latitude: number;
  longitude: number;
  homeowner_name?: string;
  phone?: string;
  email?: string;
  credit_score?: number;
  age?: number;
  gender?: string;
  disposition?: string;
  disposition_color?: string;
  created_at?: string;
  updated_at?: string;
  created_by?: string;
  team_id?: string;
}

export interface Disposition {
  id: string;
  name: string;
  color: string;
  description: string;
  sync_to_pitch?: boolean;
  requires_appointment?: boolean;
}

export interface PropertyVisit {
  id: string;
  property_id: string;
  user_id: string;
  disposition_id: string;
  notes?: string;
  visited_at: string;
  latitude?: number;
  longitude?: number;
}

export function useCanvassing() {
  const [properties, setProperties] = useState<Property[]>([]);
  const [dispositions, setDispositions] = useState<Disposition[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Load properties from database with their latest disposition
  const loadProperties = async () => {
    try {
      setLoading(true);
    const { data, error } = await supabase
      .from('properties')
      .select(`
        *,
        visits:visits(
          disposition_id,
          notes,
          visit_date,
          dispositions:dispositions!fk_visits_disposition(name, color)
        )
      `)
      .order('created_at', { ascending: false });

      if (error) throw error;
      
      // Transform data to include lat/lng from geom and latest disposition
      const transformedData = (data || []).map(prop => {
        // Extract coordinates from geom using ST_X and ST_Y
        const lat = prop.geom?.coordinates?.[1] || (prop as any).lat;
        const lng = prop.geom?.coordinates?.[0] || (prop as any).lng;
        
        // Get the most recent visit
        const visits = Array.isArray(prop.visits) ? prop.visits : [];
        const latestVisit = visits.sort((a: any, b: any) => 
          new Date(b.visit_date).getTime() - new Date(a.visit_date).getTime()
        )[0];
        
        return {
          ...prop,
          latitude: lat,
          longitude: lng,
          disposition: latestVisit?.dispositions?.name,
          disposition_color: latestVisit?.dispositions?.color,
        };
      });
      
      setProperties(transformedData as Property[]);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to load properties';
      setError(message);
      toast.error(message);
    } finally {
      setLoading(false);
    }
  };

  // Load dispositions from database
  const loadDispositions = async () => {
    try {
      const { data, error } = await supabase
        .from('dispositions')
        .select('*')
        .order('name');

      if (error) throw error;
      setDispositions(data || []);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to load dispositions';
      setError(message);
      toast.error(message);
    }
  };

  // Update property in database
  const updateProperty = async (propertyId: string, updates: Partial<Property>) => {
    try {
      const { data, error } = await supabase
        .from('properties')
        .update(updates)
        .eq('id', propertyId)
        .select()
        .single();

      if (error) throw error;

      // Update local state
      setProperties(prev => 
        prev.map(p => p.id === propertyId ? { ...p, ...data } : p)
      );

      return data;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to update property';
      setError(message);
      toast.error(message);
      throw err;
    }
  };

  // Set property disposition
  const setPropertyDisposition = async (propertyId: string, dispositionId: string) => {
    try {
      const disposition = dispositions.find(d => d.id === dispositionId);
      if (!disposition) throw new Error('Disposition not found');

      // Update property with disposition
      const updatedProperty = await updateProperty(propertyId, {
        disposition: disposition.name,
        disposition_color: disposition.color
      });

      // Record the visit
      const { data: user } = await supabase.auth.getUser();
      if (user.user) {
        await supabase
          .from('property_visits')
          .insert({
            property_id: propertyId,
            user_id: user.user.id,
            disposition_id: dispositionId
          });
      }

      toast.success(`Disposition set to: ${disposition.name}`);
      return updatedProperty;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to set disposition';
      setError(message);
      toast.error(message);
      throw err;
    }
  };

  // Add new property
  const addProperty = async (property: Omit<Property, 'id' | 'created_at' | 'updated_at' | 'created_by'>) => {
    try {
      const { data: user } = await supabase.auth.getUser();
      
      const { data, error } = await supabase
        .from('properties')
        .insert({
          ...property,
          created_by: user.user?.id
        })
        .select()
        .single();

      if (error) throw error;

      setProperties(prev => [data, ...prev]);
      toast.success('Property added successfully');
      return data;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to add property';
      setError(message);
      toast.error(message);
      throw err;
    }
  };

  // Subscribe to real-time updates
  useEffect(() => {
    const subscription = supabase
      .channel('properties_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'properties'
        },
        (payload) => {
          if (payload.eventType === 'INSERT') {
            setProperties(prev => [payload.new as Property, ...prev]);
          } else if (payload.eventType === 'UPDATE') {
            setProperties(prev => 
              prev.map(p => p.id === payload.new.id ? payload.new as Property : p)
            );
          } else if (payload.eventType === 'DELETE') {
            setProperties(prev => prev.filter(p => p.id !== payload.old.id));
          }
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  // Initial load
  useEffect(() => {
    loadProperties();
    loadDispositions();
  }, []);

  return {
    properties,
    dispositions,
    loading,
    error,
    updateProperty,
    setPropertyDisposition,
    addProperty,
    loadProperties
  };
}