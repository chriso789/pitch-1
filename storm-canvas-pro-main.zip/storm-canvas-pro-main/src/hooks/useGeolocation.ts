import { useState, useEffect } from 'react';
import { toast } from 'sonner';

interface GeolocationState {
  position: GeolocationPosition | null;
  error: GeolocationPositionError | null;
  loading: boolean;
}

interface GeolocationOptions {
  enableHighAccuracy?: boolean;
  timeout?: number;
  maximumAge?: number;
}

export function useGeolocation(options?: GeolocationOptions) {
  const [state, setState] = useState<GeolocationState>({
    position: null,
    error: null,
    loading: false,
  });

  const getCurrentPosition = () => {
    if (!navigator.geolocation) {
      setState(prev => ({
        ...prev,
        error: {
          code: 2,
          message: 'Geolocation is not supported by this browser',
        } as GeolocationPositionError,
        loading: false,
      }));
      toast.error('Location services not supported');
      return;
    }

    setState(prev => ({ ...prev, loading: true, error: null }));

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setState({
          position,
          error: null,
          loading: false,
        });
      },
      (error) => {
        setState({
          position: null,
          error,
          loading: false,
        });
        
        let message = 'Failed to get location';
        switch (error.code) {
          case error.PERMISSION_DENIED:
            message = 'Location access denied. Please enable location services.';
            break;
          case error.POSITION_UNAVAILABLE:
            message = 'Location information unavailable.';
            break;
          case error.TIMEOUT:
            message = 'Location request timed out.';
            break;
        }
        toast.error(message);
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 60000,
        ...options,
      }
    );
  };

  // Convert position to simple lat/lng object
  const coordinates = state.position ? {
    lat: state.position.coords.latitude,
    lng: state.position.coords.longitude,
    accuracy: state.position.coords.accuracy,
  } : null;

  return {
    ...state,
    coordinates,
    getCurrentPosition,
    isSupported: !!navigator.geolocation,
  };
}