import { useState } from 'react';
import { FreeSkipTraceService } from '@/services/freeSkipTrace';
import type { SkipTraceResult, FreeSkipTraceResponse } from '@/services/freeSkipTrace';
import { toast } from 'sonner';

interface UseSkipTraceOptions {
  onSuccess?: (result: SkipTraceResult) => void;
  onError?: (error: string) => void;
  showToasts?: boolean;
}

export function useFreeSkipTrace(options: UseSkipTraceOptions = {}) {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<SkipTraceResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const lookup = async (params: {
    address?: string;
    lat?: number;
    lng?: number;
    apn?: string;
    propertyId?: string;
    leadId?: string;
  }) => {
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      if (options.showToasts !== false) {
        toast.info('Running skip trace lookup...');
      }

      const response: FreeSkipTraceResponse = await FreeSkipTraceService.lookup(params);

      if (!response.success) {
        throw new Error(response.error || 'Skip trace lookup failed');
      }

      const data = response.data!;
      setResult(data);

      if (options.showToasts !== false) {
        const contactCount = data.contacts?.length || 0;
        const confidencePercent = Math.round((data.confidence || 0) * 100);
        toast.success(
          `Skip trace completed! Found ${contactCount} contact${contactCount !== 1 ? 's' : ''} (${confidencePercent}% confidence)`
        );
      }

      options.onSuccess?.(data);
      return data;

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Skip trace lookup failed';
      setError(errorMessage);

      if (options.showToasts !== false) {
        toast.error(`Skip trace failed: ${errorMessage}`);
      }

      options.onError?.(errorMessage);
      throw err;

    } finally {
      setLoading(false);
    }
  };

  const testService = async () => {
    setLoading(true);
    setError(null);

    try {
      const result = await FreeSkipTraceService.testService();
      return result;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Service test failed';
      setError(errorMessage);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const getContacts = async (params: { propertyId?: string; leadId?: string }) => {
    setLoading(true);
    setError(null);

    try {
      const response = await FreeSkipTraceService.getContacts(params);
      
      if (!response.success) {
        throw new Error(response.error || 'Failed to fetch contacts');
      }

      return response.data;

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch contacts';
      setError(errorMessage);
      toast.error(errorMessage);
      throw err;

    } finally {
      setLoading(false);
    }
  };

  const getRecentJobs = async (limit?: number) => {
    setLoading(true);
    setError(null);

    try {
      const response = await FreeSkipTraceService.getRecentJobs(limit);
      
      if (!response.success) {
        throw new Error(response.error || 'Failed to fetch recent jobs');
      }

      return response.data;

    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch recent jobs';
      setError(errorMessage);
      throw err;

    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    setResult(null);
    setError(null);
    setLoading(false);
  };

  return {
    // State
    loading,
    result,
    error,
    
    // Actions
    lookup,
    testService,
    getContacts,
    getRecentJobs,
    reset,
    
    // Computed values
    hasResult: !!result,
    contactCount: result?.contacts?.length || 0,
    confidence: result?.confidence || 0,
    confidencePercent: Math.round((result?.confidence || 0) * 100),
    
    // Quick access to result data
    contacts: result?.contacts || [],
    parcel: result?.parcel,
    ownerType: result?.ownerType,
    isOwnerOccupied: result?.isOwnerOccupied,
    propertyInsights: result?.propertyInsights
  };
}

export default useFreeSkipTrace;