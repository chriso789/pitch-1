import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { type Property } from './useCanvassing';

interface NearestLocationParams {
  lat: number;
  lng: number;
  radiusKm?: number;
}

export function useNearestLocations() {
  const [pins, setPins] = useState<Property[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchNearestLocations = useCallback(async ({ lat, lng, radiusKm = 3.22 }: NearestLocationParams) => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('maps-getNearestLocations', {
        body: { lat, lng, radiusKm }
      });

      if (error) throw error;

      if (data?.ok && data?.features) {
        const properties: Property[] = data.features.map((feature: any) => {
          const addr = feature.properties.address || {};
          const homeowner = feature.properties.homeowner || {};
          
          return {
            id: feature.properties.id,
            latitude: feature.geometry.coordinates[1],
            longitude: feature.geometry.coordinates[0],
            address: addr.line1 || `${feature.geometry.coordinates[1]}, ${feature.geometry.coordinates[0]}`,
            homeowner_name: homeowner.name || '',
            phone: homeowner.phone || '',
            email: homeowner.email || '',
            disposition: feature.properties.disposition,
            disposition_color: feature.properties.dispositionColor,
            created_at: feature.properties.createdAt
          };
        });
        setPins(properties);
      } else {
        throw new Error(data?.error || 'Failed to fetch locations');
      }
    } catch (error) {
      console.error('Error fetching nearest locations:', error);
      toast.error('Failed to load nearby properties');
      setPins([]);
    } finally {
      setLoading(false);
    }
  }, []);

  const addProperty = useCallback(async (
    address: any, 
    lat: number, 
    lng: number, 
    flags?: any, 
    consumerId?: string
  ) => {
    try {
      const { data: userData } = await supabase.auth.getUser();
      
      const { data, error } = await supabase.rpc('add_property_pin', {
        addr: address,
        lat: lat,
        lng: lng,
        property_flags: flags,
        consumer_id_val: consumerId,
        created_by_val: userData.user?.id
      });

      if (error) throw error;

      // Add to local state as Property
      const newProperty: Property = {
        id: data,
        latitude: lat,
        longitude: lng,
        address: address.line1 || `${lat}, ${lng}`,
        homeowner_name: '',
        phone: '',
        email: '',
        created_at: new Date().toISOString()
      };

      setPins(prev => [...prev, newProperty]);
      toast.success('Property added successfully');
      return data;
    } catch (error) {
      console.error('Error adding property:', error);
      toast.error('Failed to add property');
      throw error;
    }
  }, []);

  return {
    pins,
    loading,
    fetchNearestLocations,
    addProperty
  };
}

// Helper function to generate address hash
async function generateAddressHash(address: any): Promise<string> {
  const { data, error } = await supabase.rpc('generate_address_hash', {
    addr: address
  });

  if (error) {
    // Fallback: generate hash client-side
    const addressString = JSON.stringify(address);
    const encoder = new TextEncoder();
    const data = encoder.encode(addressString);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }

  return data;
}