import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import type { ManualMeasureInput } from '@/lib/measure/types';

export function useMeasurements(propertyId: string | null) {
  const queryClient = useQueryClient();

  // Get latest measurement for a property
  const { data: latestMeasurement, isLoading } = useQuery({
    queryKey: ['measurement', propertyId],
    queryFn: async () => {
      if (!propertyId) return null;

      const { data, error } = await supabase.functions.invoke(
        `measure/${propertyId}/latest`,
        { method: 'GET' }
      );

      if (error) throw error;
      return data?.data || null;
    },
    enabled: !!propertyId,
    staleTime: 5 * 60 * 1000,
  });

  // Save manual measurement
  const saveManual = useMutation({
    mutationFn: async (input: ManualMeasureInput) => {
      const { data, error } = await supabase.functions.invoke('measure/manual', {
        body: input,
      });

      if (error) throw error;
      return data;
    },
    onSuccess: (data, variables) => {
      toast.success('Measurement saved successfully');
      queryClient.invalidateQueries({ queryKey: ['measurement', variables.propertyId] });
    },
    onError: (error: Error) => {
      console.error('Error saving measurement:', error);
      toast.error(error.message || 'Failed to save measurement');
    },
  });

  // Auto measure (provider-based)
  const autoMeasure = useMutation({
    mutationFn: async (input: {
      propertyId: string;
      address?: any;
      lat?: number;
      lng?: number;
      waste_pct?: number;
    }) => {
      const { data, error } = await supabase.functions.invoke('measure/auto', {
        body: input,
      });

      if (error) throw error;
      return data;
    },
    onSuccess: (data, variables) => {
      toast.success(`Auto-measurement complete (${data.data?.source})`);
      queryClient.invalidateQueries({ queryKey: ['measurement', variables.propertyId] });
    },
    onError: (error: Error) => {
      console.error('Auto-measure error:', error);
      toast.error(error.message || 'Auto-measure failed. Try Manual-Measure instead.');
    },
  });

  return {
    latestMeasurement,
    isLoading,
    saveManual,
    autoMeasure,
  };
}
