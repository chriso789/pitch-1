// src/hooks/usePhotoUpload.ts
import { useState } from "react";
import { toast } from "sonner";

export interface PhotoUploadOptions {
  propertyId: string;
  file: File;
  exif?: any;
  lat?: number;
  lng?: number;
  createdBy?: string;
}

export function usePhotoUpload(apiEndpoint: "express" | "supabase" = "supabase") {
  const [uploading, setUploading] = useState(false);

  const uploadPhoto = async (options: PhotoUploadOptions): Promise<string> => {
    const { propertyId, file, exif = {}, lat, lng, createdBy } = options;
    
    setUploading(true);
    
    try {
      // Generate unique key for the photo
      const key = `properties/${propertyId}/${crypto.randomUUID()}.jpg`;
      
      if (apiEndpoint === "express") {
        // 1. Get presigned URL
        const presignResponse = await fetch("/api/photos/presign", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ 
            key, 
            contentType: file.type || "image/jpeg" 
          })
        });
        
        const presignResult = await presignResponse.json();
        
        if (!presignResult.ok) {
          throw new Error(presignResult.error || 'Failed to get upload URL');
        }
        
        // 2. Upload file
        if (presignResult.provider === "s3") {
          await fetch(presignResult.url, {
            method: "PUT",
            headers: { "content-type": file.type || "image/jpeg" },
            body: file
          });
        } else if (presignResult.provider === "supabase") {
          await fetch(presignResult.signedUrl, {
            method: "PUT",
            headers: { 
              "content-type": file.type || "image/jpeg",
              "authorization": `Bearer ${presignResult.token}`
            },
            body: file
          });
        }
        
        // 3. Attach photo record to database
        const attachResponse = await fetch("/api/photos/attach", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({
            propertyId,
            key,
            exif,
            lat,
            lng,
            created_by: createdBy
          })
        });
        
        const attachResult = await attachResponse.json();
        
        if (!attachResult.ok) {
          throw new Error(attachResult.error || 'Failed to attach photo');
        }
        
        toast.success('Photo uploaded successfully');
        return key;
      } else {
        // Use Supabase client directly
        const { supabase } = await import('@/integrations/supabase/client');
        
        // 1. Upload to Supabase Storage
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('photos')
          .upload(key, file, {
            contentType: file.type || 'image/jpeg',
            upsert: false
          });
        
        if (uploadError) throw uploadError;
        
        // 2. Create database record
        const { error: insertError } = await supabase
          .from('photos')
          .insert({
            property_id: propertyId,
            key: uploadData.path,
            exif,
            lat,
            lng,
            created_by: createdBy
          });
        
        if (insertError) throw insertError;
        
        toast.success('Photo uploaded successfully');
        return uploadData.path;
      }
    } catch (error) {
      console.error('Error uploading photo:', error);
      toast.error('Failed to upload photo');
      throw error;
    } finally {
      setUploading(false);
    }
  };

  const getPhotoFeed = async (
    propertyId?: string,
    filter = "all",
    page = 1,
    limit = 12
  ) => {
    try {
      if (apiEndpoint === "express") {
        const response = await fetch("/api/photos/getFeed", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ propertyId, filter, page, limit })
        });
        
        const result = await response.json();
        
        if (!result.ok) {
          throw new Error(result.error || 'Failed to get photo feed');
        }
        
        return {
          data: result.data,
          total: result.total
        };
      } else {
        // Use Supabase client directly
        const { supabase } = await import('@/integrations/supabase/client');
        
        const from = Math.max(0, (page - 1) * limit);
        const to = from + limit - 1;
        
        let query = supabase
          .from('photos')
          .select('*', { count: 'exact' });
        
        if (propertyId) {
          query = query.eq('property_id', propertyId);
        }
        
        const { data, error, count } = await query
          .order('created_at', { ascending: false })
          .range(from, to);
        
        if (error) throw error;
        
        return {
          data: data || [],
          total: count || 0
        };
      }
    } catch (error) {
      console.error('Error getting photo feed:', error);
      toast.error('Failed to load photos');
      throw error;
    }
  };

  return {
    uploadPhoto,
    getPhotoFeed,
    uploading
  };
}