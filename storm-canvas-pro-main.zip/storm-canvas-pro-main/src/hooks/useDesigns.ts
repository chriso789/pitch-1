import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { pathToWkt, naiveAreaSqft } from '@/lib/wkt';

export interface Design {
  id: string;
  property_id: string;
  type: 'FAST_ESTIMATES' | 'CUSTOM';
  geom: string; // WKT polygon
  area_sqft?: number;
  pitch_est?: number;
  created_by?: string;
  created_at: string;
}

export interface CreateDesignParams {
  propertyId: string;
  type: 'FAST_ESTIMATES' | 'CUSTOM';
  polygon: google.maps.LatLng[] | { lat: number; lng: number }[];
  areaSqft?: number;
  pitchEst?: number;
}

export function useDesigns(apiEndpoint: "express" | "supabase" = "supabase") {
  const [designs, setDesigns] = useState<Design[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchDesigns = useCallback(async (propertyId?: string) => {
    setLoading(true);
    try {
      let query = supabase
        .from('designs')
        .select('*')
        .order('created_at', { ascending: false });

      if (propertyId) {
        query = query.eq('property_id', propertyId);
      }

      const { data, error } = await query;

      if (error) throw error;

      setDesigns(data || []);
    } catch (error) {
      console.error('Error fetching designs:', error);
      toast.error('Failed to load designs');
    } finally {
      setLoading(false);
    }
  }, []);

  const createDesign = useCallback(async (params: CreateDesignParams) => {
    try {
      // Convert polygon to WKT format
      const polygonPath = params.polygon.map(point => ({
        lat: typeof point.lat === 'function' ? point.lat() : point.lat,
        lng: typeof point.lng === 'function' ? point.lng() : point.lng
      }));
      
      const wktPolygon = pathToWkt(polygonPath);
      
      // Calculate area if not provided
      let areaSqft = params.areaSqft;
      if (!areaSqft) {
        areaSqft = window.google?.maps ? calculatePolygonArea(params.polygon) : naiveAreaSqft(polygonPath);
      }

      if (apiEndpoint === "express") {
        const response = await fetch("/api/designs/save", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({
            property_id: params.propertyId,
            type: params.type,
            geom_wkt: wktPolygon,
            area_sqft: areaSqft,
            pitch_est: params.pitchEst,
            created_by: (await supabase.auth.getUser()).data.user?.id
          })
        });
        
        const result = await response.json();
        
        if (!result.ok) {
          throw new Error(result.error || 'Failed to save design');
        }
        
        // Refresh designs after creation
        await fetchDesigns(params.propertyId);
        
        toast.success(`${params.type === 'FAST_ESTIMATES' ? 'Fast estimate' : 'Custom design'} created successfully`);
        return result;
      } else {
        const { data, error } = await supabase
          .from('designs')
          .insert({
            property_id: params.propertyId,
            type: params.type,
            geom: wktPolygon,
            area_sqft: areaSqft,
            pitch_est: params.pitchEst,
            created_by: (await supabase.auth.getUser()).data.user?.id
          })
          .select()
          .single();

        if (error) throw error;

        setDesigns(prev => [data, ...prev]);
        toast.success(`${params.type === 'FAST_ESTIMATES' ? 'Fast estimate' : 'Custom design'} created successfully`);
        return data;
      }
    } catch (error) {
      console.error('Error creating design:', error);
      toast.error('Failed to create design');
      throw error;
    }
  }, [apiEndpoint, fetchDesigns]);

  const updateDesign = useCallback(async (designId: string, updates: Partial<Design>) => {
    try {
      const { data, error } = await supabase
        .from('designs')
        .update(updates)
        .eq('id', designId)
        .select()
        .single();

      if (error) throw error;

      setDesigns(prev => prev.map(design => 
        design.id === designId ? { ...design, ...data } : design
      ));

      toast.success('Design updated successfully');
      return data;
    } catch (error) {
      console.error('Error updating design:', error);
      toast.error('Failed to update design');
      throw error;
    }
  }, []);

  const deleteDesign = useCallback(async (designId: string) => {
    try {
      const { error } = await supabase
        .from('designs')
        .delete()
        .eq('id', designId);

      if (error) throw error;

      setDesigns(prev => prev.filter(design => design.id !== designId));
      toast.success('Design deleted successfully');
    } catch (error) {
      console.error('Error deleting design:', error);
      toast.error('Failed to delete design');
    }
  }, []);

  return {
    designs,
    loading,
    fetchDesigns,
    createDesign,
    updateDesign,
    deleteDesign
  };
}

// Helper functions
function polygonToWKT(polygon: google.maps.LatLng[] | { lat: number; lng: number }[]): string {
  const coords = polygon.map(point => {
    const lat = typeof point.lat === 'function' ? point.lat() : point.lat;
    const lng = typeof point.lng === 'function' ? point.lng() : point.lng;
    return `${lng} ${lat}`;
  });
  
  // Close the polygon by adding the first point at the end
  if (coords.length > 0) {
    coords.push(coords[0]);
  }
  
  return `POLYGON((${coords.join(', ')}))`;
}

function calculatePolygonArea(polygon: google.maps.LatLng[] | { lat: number; lng: number }[]): number {
  if (!window.google?.maps) return 0;

  // Convert to google.maps.LatLng if needed
  const latLngs = polygon.map(point => {
    if (typeof point.lat === 'function') {
      return point as google.maps.LatLng;
    }
    return new google.maps.LatLng(point.lat, point.lng);
  });

  // Calculate area in square meters using spherical geometry
  const areaMeters = google.maps.geometry.spherical.computeArea(latLngs);
  
  // Convert to square feet (1 square meter = 10.764 square feet)
  return Math.round(areaMeters * 10.764);
}