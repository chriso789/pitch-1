import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface Photo {
  id: string;
  property_id?: string;
  key: string; // storage key path
  exif?: any;
  lat?: number;
  lng?: number;
  created_by?: string;
  created_at: string;
  public_url?: string;
  // Compatibility fields for existing UI
  caption?: string;
  original_filename?: string;
  storage_path?: string;
  latitude?: number;
  longitude?: number;
  file_size?: number;
}

export interface PhotoFeedParams {
  propertyId?: string;
  page?: number;
  limit?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

// Enhanced photo management for new schema
export function usePhotos() {
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchPhotos = useCallback(async (propertyId?: string) => {
    setLoading(true);
    try {
      let query = supabase
        .from('photos')
        .select('*')
        .order('created_at', { ascending: false });

      if (propertyId) {
        query = query.eq('property_id', propertyId);
      }

      const { data, error } = await query;

      if (error) throw error;

      // Add public URLs
      const photosWithUrls = (data || []).map(photo => ({
        ...photo,
        public_url: supabase.storage.from('photos').getPublicUrl(photo.key).data.publicUrl
      }));

      setPhotos(photosWithUrls);
      return photosWithUrls;
    } catch (error) {
      console.error('Error fetching photos:', error);
      toast.error('Failed to load photos');
      return [];
    } finally {
      setLoading(false);
    }
  }, []);

  const uploadPhoto = useCallback(async (
    file: File, 
    propertyId: string, 
    exifData?: any,
    lat?: number,
    lng?: number
  ) => {
    try {
      // Generate storage key
      const timestamp = Date.now();
      const randomId = crypto.randomUUID();
      const fileExtension = file.name.split('.').pop() || 'jpg';
      const storageKey = `${propertyId}/${timestamp}_${randomId}.${fileExtension}`;

      // Upload to storage
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('photos')
        .upload(storageKey, file);

      if (uploadError) throw uploadError;

      // Create database record
      const { data: photoRecord, error: dbError } = await supabase
        .from('photos')
        .insert({
          property_id: propertyId,
          key: storageKey,
          exif: exifData,
          lat,
          lng,
          created_by: (await supabase.auth.getUser()).data.user?.id
        })
        .select()
        .single();

      if (dbError) throw dbError;

      const photoWithUrl = {
        ...photoRecord,
        public_url: supabase.storage.from('photos').getPublicUrl(storageKey).data.publicUrl
      };

      setPhotos(prev => [photoWithUrl, ...prev]);
      toast.success('Photo uploaded successfully');
      return photoWithUrl;
    } catch (error) {
      console.error('Upload error:', error);
      toast.error('Failed to upload photo');
      throw error;
    }
  }, []);

  const deletePhoto = useCallback(async (photoId: string) => {
    try {
      // Get photo to find storage key
      const { data: photo } = await supabase
        .from('photos')
        .select('key')
        .eq('id', photoId)
        .single();

      if (photo?.key) {
        // Delete from storage
        await supabase.storage
          .from('photos')
          .remove([photo.key]);
      }

      // Delete database record
      const { error } = await supabase
        .from('photos')
        .delete()
        .eq('id', photoId);

      if (error) throw error;

      setPhotos(prev => prev.filter(p => p.id !== photoId));
      toast.success('Photo deleted successfully');
    } catch (error) {
      console.error('Delete error:', error);
      toast.error('Failed to delete photo');
    }
  }, []);

  return {
    photos,
    loading,
    data: photos, // For compatibility with existing usage
    isLoading: loading, // For compatibility
    fetchPhotos,
    uploadPhoto,
    deletePhoto
  };
}