import { useGoogleMapsContext } from '@/components/GoogleMapsProvider';

export function useGoogleMaps() {
  return useGoogleMapsContext();
}
