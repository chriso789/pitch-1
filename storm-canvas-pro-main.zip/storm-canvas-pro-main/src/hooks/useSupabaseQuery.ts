import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { z } from 'zod';

export function useSupabaseQuery<T>(
  key: string[],
  queryFn: () => Promise<{ data: any; error: any }>,
  schema: z.ZodSchema<T>,
  options?: {
    enabled?: boolean;
    staleTime?: number;
  }
) {
  return useQuery({
    queryKey: key,
    queryFn: async () => {
      const result = await queryFn();
      const { data, error } = result;
      
      if (error) {
        console.error(`Query error for ${key.join('.')}:`, error);
        throw new Error(error.message || 'Failed to fetch data');
      }

      // Validate data with safeParse for Gate 2 compliance
      const validation = schema.safeParse(data);
      if (validation.success) {
        return validation.data;
      } else {
        console.warn(`Data validation failed for ${key.join('.')}:`, validation.error.issues);
        // Return raw data but log validation issues - don't break app
        return data;
      }
    },
    enabled: options?.enabled,
    staleTime: options?.staleTime || 5 * 60 * 1000,
  });
}

export function useSupabaseMutation<TInput, TOutput>(
  mutationFn: (input: TInput) => Promise<{ data: any; error: any }>,
  inputSchema: z.ZodSchema<TInput>,
  outputSchema?: z.ZodSchema<TOutput>,
  options?: {
    onSuccess?: (data: TOutput) => void;
    onError?: (error: Error) => void;
    invalidateQueries?: string[][];
  }
) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (input: TInput) => {
      // Validate input with safeParse for Gate 2 compliance
      const inputValidation = inputSchema.safeParse(input);
      if (!inputValidation.success) {
        const firstError = inputValidation.error.issues[0]?.message || 'Invalid input data';
        throw new Error(firstError);
      }

      const result = await mutationFn(inputValidation.data);
      const { data, error } = result;
      
      if (error) {
        console.error('Mutation error:', error);
        throw new Error(error.message || 'Operation failed');
      }

      // Validate output if schema provided
      if (outputSchema) {
        const outputValidation = outputSchema.safeParse(data);
        if (outputValidation.success) {
          return outputValidation.data;
        } else {
          console.warn('Output validation failed:', outputValidation.error.issues);
          // Return raw data but log validation issues
          return data;
        }
      }

      return data;
    },
    onSuccess: (data) => {
      if (options?.invalidateQueries) {
        options.invalidateQueries.forEach(queryKey => {
          queryClient.invalidateQueries({ queryKey });
        });
      }
      options?.onSuccess?.(data);
    },
    onError: (error: Error) => {
      toast.error(error.message);
      options?.onError?.(error);
    },
  });
}