import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface Template {
  id: string;
  name: string;
  currency: string;
  labor: {
    rate_per_square: number;
    complexity: Record<string, number>;
  };
  overhead: {
    type: 'percent' | 'fixed' | 'both';
    percent?: number;
    fixed?: number;
  };
  items?: TemplateItem[];
}

export interface TemplateItem {
  id: string;
  item_name: string;
  unit: string;
  waste_pct: number;
  unit_cost: number;
  qty_formula: string;
  sort_order: number;
  active: boolean;
}

export function useTemplates() {
  const [templates, setTemplates] = useState<Template[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchTemplates = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('templates')
        .select('*')
        .order('name');

      if (error) throw error;
      setTemplates(data || []);
    } catch (error) {
      console.error('Error fetching templates:', error);
      toast.error('Failed to load templates');
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchTemplateWithItems = useCallback(async (templateId: string): Promise<Template | null> => {
    try {
      const { data, error } = await supabase.rpc('api_template_get_full', { 
        p_template_id: templateId 
      });

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error fetching template:', error);
      toast.error('Failed to load template');
      return null;
    }
  }, []);

  const createTemplate = useCallback(async (template: Omit<Template, 'id'>) => {
    try {
      const { data, error } = await supabase
        .from('templates')
        .insert({
          name: template.name,
          currency: template.currency,
          labor: template.labor,
          overhead: template.overhead,
          tenant_id: (await supabase.auth.getUser()).data.user?.id
        })
        .select()
        .single();

      if (error) throw error;
      toast.success('Template created successfully');
      await fetchTemplates();
      return data;
    } catch (error) {
      console.error('Error creating template:', error);
      toast.error('Failed to create template');
      throw error;
    }
  }, [fetchTemplates]);

  return {
    templates,
    loading,
    fetchTemplates,
    fetchTemplateWithItems,
    createTemplate
  };
}