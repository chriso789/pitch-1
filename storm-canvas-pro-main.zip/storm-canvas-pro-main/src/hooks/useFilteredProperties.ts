import { useMemo } from 'react';
import { useProperties } from './useProperties';
import { PropertyFilters } from '@/components/PropertyFilters';

export function useFilteredProperties(filters: PropertyFilters, searchTerm?: string) {
  const { data: allProperties = [], ...queryProps } = useProperties();

  const filteredProperties = useMemo(() => {
    let filtered = allProperties;

    // Apply search term filter (client-side for now)
    if (searchTerm && searchTerm.trim()) {
      const term = searchTerm.toLowerCase().trim();
      filtered = filtered.filter(property => 
        property.address?.toLowerCase().includes(term) ||
        property.homeowner_name?.toLowerCase().includes(term) ||
        property.email?.toLowerCase().includes(term) ||
        property.phone?.toLowerCase().includes(term)
      );
    }

    // Apply server-side filters (already handled in useProperties hook)
    // This function provides client-side filtering for complex filters not easily done server-side

    return filtered;
  }, [allProperties, searchTerm]);

  return {
    ...queryProps,
    data: filteredProperties,
    totalCount: allProperties.length,
    filteredCount: filteredProperties.length,
  };
}