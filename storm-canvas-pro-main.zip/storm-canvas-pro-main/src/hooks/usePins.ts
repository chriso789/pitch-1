// src/hooks/usePins.ts
import { useEffect, useRef, useState } from "react";

export type Pin = { 
  id: string; 
  addressHash: string; 
  lat: number; 
  lng: number; 
  flags?: any; 
  consumer_id?: string;
  disposition?: string;
  disposition_color?: string;
  address?: any;
  homeowner?: any;
  place_id?: string;
};

export function usePins(apiEndpoint: "express" | "supabase" = "supabase") {
  const [pins, setPins] = useState<Pin[]>([]);
  const [loading, setLoading] = useState(false);
  const inflight = useRef<AbortController | null>(null);

  const fetchPins = async (lat: number, lng: number, radiusKm = 2) => {
    // Abort any existing request
    inflight.current?.abort();
    const ac = new AbortController();
    inflight.current = ac;
    
    setLoading(true);
    
    try {
      let response;
      
      if (apiEndpoint === "express") {
        response = await fetch("/api/maps/getNearestLocations", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ lat, lng, radiusKm }),
          signal: ac.signal
        });
      } else {
        // Use Supabase Edge Functions (existing implementation)
        const { supabase } = await import('@/integrations/supabase/client');
        const { data, error } = await supabase.functions.invoke('maps-getNearestLocations', {
          body: { lat, lng, radiusKm }
        });
        
        if (error) throw error;
        response = { json: async () => data };
      }
      
      const result = await response.json();
      
      if (result.ok && result.features) {
        const pins = result.features.map((feature: any) => ({
          id: feature.properties.addressHash,
          addressHash: feature.properties.addressHash,
          lat: feature.geometry.coordinates[1],
          lng: feature.geometry.coordinates[0],
          flags: feature.properties.flags,
          consumerId: feature.properties.consumerId
        }));
        setPins(pins);
      } else {
        throw new Error(result.error || 'Failed to fetch pins');
      }
    } catch (error) {
      if (!ac.signal.aborted) {
        console.error('Error fetching pins:', error);
        setPins([]);
      }
    } finally {
      setLoading(false);
    }
  };

  const fetchPinsBbox = async (minLng: number, minLat: number, maxLng: number, maxLat: number) => {
    inflight.current?.abort();
    const ac = new AbortController();
    inflight.current = ac;
    
    setLoading(true);
    
    try {
      const { supabase } = await import('@/integrations/supabase/client');
      const { data, error } = await supabase.functions.invoke('maps-getPropertiesInBbox', {
        body: { minLng, minLat, maxLng, maxLat }
      });
      
      if (error) throw error;
      
      console.log('🗺️ Bbox response:', data);
      
      if (data.ok && data.features) {
        const pins = data.features.map((feature: any) => ({
          id: feature.properties.id || feature.properties.addressHash,
          addressHash: feature.properties.addressHash,
          lat: feature.geometry.coordinates[1],
          lng: feature.geometry.coordinates[0],
          flags: feature.properties.flags,
          consumer_id: feature.properties.consumer_id,
          disposition: feature.properties.disposition,
          disposition_color: feature.properties.disposition_color,
          address: feature.properties.address,
          homeowner: feature.properties.homeowner,
          place_id: feature.properties.place_id
        }));
        console.log('🗺️ Mapped pins:', pins.length, pins[0]);
        setPins(pins);
      } else {
        throw new Error(data.error || 'Failed to fetch pins');
      }
    } catch (error) {
      if (!ac.signal.aborted) {
        console.error('Error fetching pins:', error);
        setPins([]);
      }
    } finally {
      setLoading(false);
    }
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      inflight.current?.abort();
    };
  }, []);

  return { pins, loading, fetchPins, fetchPinsBbox };
}