import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useAddressAudit } from './useAddressAudit';
import { useForceAddProperty } from './useForceAddProperty';

export function useAutoPopulate() {
  const [isPopulating, setIsPopulating] = useState(false);
  const { auditArea, isAuditing, auditResult } = useAddressAudit();
  const { forceAddProperty, isAdding } = useForceAddProperty();

  const autoDetectProperties = async (lat: number, lng: number, radiusMeters: number = 500) => {
    setIsPopulating(true);
    
    try {
      console.log('🔍 Auto-detecting real properties near location:', { lat, lng, radiusMeters });
      
      const { data, error } = await supabase.functions.invoke('auto-detect-properties', {
        body: { lat, lng, radiusMeters }
      });

      if (error) throw error;

      if (data.ok) {
        const { inserted, skipped, errors } = data;
        
        if (inserted > 0) {
          toast.success(
            `Found ${inserted} real properties!`,
            {
              description: skipped > 0 ? `${skipped} already in database` : undefined
            }
          );
        }
        // Only show error notification if there were actually errors
        // Don't show warning for skipped properties as those are already in database

        return { success: true, inserted, skipped, errors };
      } else {
        throw new Error(data.error || 'Failed to detect properties');
      }
    } catch (error) {
      console.error('Error auto-detecting properties:', error);
      toast.error('Failed to detect properties', {
        description: error instanceof Error ? error.message : 'Unknown error'
      });
      return { success: false, inserted: 0, skipped: 0, errors: 0 };
    } finally {
      setIsPopulating(false);
    }
  };

  const populateArea = async (bounds: { minLng: number; minLat: number; maxLng: number; maxLat: number }) => {
    setIsPopulating(true);
    
    try {
      console.log('🏘️ Starting auto-populate for bounds:', bounds);
      
      const { data, error } = await supabase.functions.invoke('populate-properties', {
        body: bounds
      });

      if (error) throw error;

      if (data.ok) {
        const { inserted, skipped, errors } = data;
        
        if (inserted > 0) {
          toast.success(
            `Loaded ${inserted} new properties!`,
            {
              description: skipped > 0 ? `${skipped} already existed in the database` : undefined
            }
          );
        } else if (skipped > 0) {
          toast.info(`All ${skipped} properties already in database`);
        } else {
          toast.warning('No properties found in this area');
        }

        if (errors > 0) {
          toast.warning(`${errors} properties could not be loaded`);
        }

        return { success: true, inserted, skipped, errors };
      } else {
        throw new Error(data.error || 'Failed to populate properties');
      }
    } catch (error) {
      console.error('Error populating properties:', error);
      toast.error('Failed to load properties', {
        description: error instanceof Error ? error.message : 'Unknown error'
      });
      return { success: false, inserted: 0, skipped: 0, errors: 0 };
    } finally {
      setIsPopulating(false);
    }
  };

  return {
    populateArea,
    autoDetectProperties,
    auditArea,
    forceAddProperty,
    isPopulating: isPopulating || isAuditing || isAdding,
    auditResult,
  };
}
