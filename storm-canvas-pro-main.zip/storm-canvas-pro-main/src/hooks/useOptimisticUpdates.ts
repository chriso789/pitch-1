import { useCallback } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';

export interface OptimisticUpdate<T = any> {
  queryKey: string[];
  updateFn: (oldData: T) => T;
  rollbackFn?: (oldData: T) => T;
  successMessage?: string;
  errorMessage?: string;
}

export function useOptimisticUpdates() {
  const queryClient = useQueryClient();

  const applyOptimisticUpdate = useCallback(async <T>(
    update: OptimisticUpdate<T>,
    mutationPromise: Promise<any>
  ): Promise<T> => {
    const { queryKey, updateFn, rollbackFn, successMessage, errorMessage } = update;

    // Store previous data for rollback
    const previousData = queryClient.getQueryData<T>(queryKey);
    
    // Apply optimistic update
    queryClient.setQueryData<T>(queryKey, (oldData) => {
      if (!oldData) return oldData;
      return updateFn(oldData);
    });

    try {
      // Execute the actual mutation
      const result = await mutationPromise;
      
      // Show success message
      if (successMessage) {
        toast.success(successMessage);
      }
      
      // Invalidate queries to ensure fresh data
      queryClient.invalidateQueries({ queryKey });
      
      return result;
    } catch (error) {
      console.error('Optimistic update failed:', error);
      
      // Rollback on error
      if (previousData) {
        queryClient.setQueryData<T>(queryKey, rollbackFn ? rollbackFn(previousData) : previousData);
      }
      
      // Show error message
      const message = errorMessage || 'Update failed - changes have been reverted';
      toast.error(message);
      
      throw error;
    }
  }, [queryClient]);

  const createPropertyUpdate = useCallback((propertyId: string, updates: Partial<any>) => ({
    queryKey: ['properties'],
    updateFn: (oldData: any[]) => 
      oldData.map(property => 
        property.id === propertyId 
          ? { ...property, ...updates, updated_at: new Date().toISOString() }
          : property
      ),
    successMessage: 'Property updated successfully',
    errorMessage: 'Failed to update property'
  }), []);

  const createPropertyDelete = useCallback((propertyId: string) => ({
    queryKey: ['properties'],
    updateFn: (oldData: any[]) => oldData.filter(property => property.id !== propertyId),
    rollbackFn: (oldData: any[]) => oldData, // Full rollback to original data
    successMessage: 'Property deleted successfully',
    errorMessage: 'Failed to delete property'
  }), []);

  const createVisitAdd = useCallback((newVisit: any) => ({
    queryKey: ['visits'],
    updateFn: (oldData: any[]) => [newVisit, ...oldData],
    successMessage: 'Visit recorded successfully',
    errorMessage: 'Failed to record visit'
  }), []);

  const createPhotoAdd = useCallback((newPhoto: any) => ({
    queryKey: ['photos'],
    updateFn: (oldData: any[]) => [newPhoto, ...oldData],
    successMessage: 'Photo uploaded successfully',
    errorMessage: 'Failed to upload photo'
  }), []);

  const createProposalUpdate = useCallback((proposalId: string, updates: Partial<any>) => ({
    queryKey: ['proposals'],
    updateFn: (oldData: any[]) => 
      oldData.map(proposal => 
        proposal.id === proposalId 
          ? { ...proposal, ...updates, updated_at: new Date().toISOString() }
          : proposal
      ),
    successMessage: 'Proposal updated successfully',
    errorMessage: 'Failed to update proposal'
  }), []);

  return {
    applyOptimisticUpdate,
    createPropertyUpdate,
    createPropertyDelete,
    createVisitAdd,
    createPhotoAdd,
    createProposalUpdate,
  };
}