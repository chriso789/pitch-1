import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface Estimate {
  id: string;
  property_id: string;
  name?: string;
  status: string;
  tenant_id: string;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface EstimateStatus {
  estimate_id: string;
  template_bound: boolean;
  measurements_present: boolean;
  ready: boolean;
  slider_disabled: boolean;
  last_computed_at?: string;
  mode?: 'margin' | 'markup';
  margin_pct?: number;
  markup_pct?: number;
  next_required: string[];
  messages: string[];
}

export interface HyperlinkBarData {
  estimate_id: string;
  currency: string;
  ready: boolean;
  template_bound: boolean;
  measurements_present: boolean;
  squares?: number;
  materials: number;
  labor: number;
  overhead: number;
  cost_pre_profit: number;
  mode: 'margin' | 'markup';
  margin_pct?: number;
  markup_pct?: number;
  sale_price: number;
  profit: number;
  sections: Array<{
    key: string;
    label: string;
    amount?: number;
    pending: boolean;
    extra?: Record<string, any>;
  }>;
}

export function useEstimates() {
  const [estimates, setEstimates] = useState<Estimate[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchEstimates = useCallback(async (propertyId?: string) => {
    setLoading(true);
    try {
      let query = supabase
        .from('estimates')
        .select('*')
        .order('created_at', { ascending: false });

      if (propertyId) {
        query = query.eq('property_id', propertyId);
      }

      const { data, error } = await query;
      if (error) throw error;

      setEstimates(data || []);
    } catch (error) {
      console.error('Error fetching estimates:', error);
      toast.error('Failed to load estimates');
    } finally {
      setLoading(false);
    }
  }, []);

  const createEstimate = useCallback(async (propertyId: string, name?: string) => {
    try {
      const user = await supabase.auth.getUser();
      const { data, error } = await supabase
        .from('estimates')
        .insert({
          property_id: propertyId,
          name,
          tenant_id: user.data.user?.id,
          created_by: user.data.user?.id
        })
        .select()
        .single();

      if (error) throw error;
      toast.success('Estimate created successfully');
      await fetchEstimates(propertyId);
      return data;
    } catch (error) {
      console.error('Error creating estimate:', error);
      toast.error('Failed to create estimate');
      throw error;
    }
  }, [fetchEstimates]);

  const getEstimateStatus = useCallback(async (estimateId: string): Promise<EstimateStatus | null> => {
    try {
      const { data, error } = await supabase.rpc('api_estimate_status_get', { 
        p_estimate_id: estimateId 
      });

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error fetching estimate status:', error);
      toast.error('Failed to load estimate status');
      return null;
    }
  }, []);

  const getHyperlinkBarData = useCallback(async (estimateId: string): Promise<HyperlinkBarData | null> => {
    try {
      const { data, error } = await supabase.rpc('api_estimate_hyperlink_bar', { 
        p_estimate_id: estimateId 
      });

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error fetching hyperlink bar data:', error);
      toast.error('Failed to load pricing data');
      return null;
    }
  }, []);

  const bindTemplate = useCallback(async (estimateId: string, templateId: string) => {
    try {
      const { error } = await supabase
        .from('estimate_bindings')
        .upsert({
          estimate_id: estimateId,
          template_id: templateId
        });

      if (error) throw error;
      toast.success('Template bound to estimate');
    } catch (error) {
      console.error('Error binding template:', error);
      toast.error('Failed to bind template');
      throw error;
    }
  }, []);

  const addMeasurements = useCallback(async (estimateId: string, squares: number, complexityFactor: number = 1.0) => {
    try {
      const { error } = await supabase
        .from('estimate_measurements')
        .upsert({
          estimate_id: estimateId,
          squares,
          complexity_factor: complexityFactor
        });

      if (error) throw error;
      toast.success('Measurements added to estimate');
    } catch (error) {
      console.error('Error adding measurements:', error);
      toast.error('Failed to add measurements');
      throw error;
    }
  }, []);

  return {
    estimates,
    loading,
    fetchEstimates,
    createEstimate,
    getEstimateStatus,
    getHyperlinkBarData,
    bindTemplate,
    addMeasurements
  };
}