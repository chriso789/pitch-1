import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface AddressAuditResult {
  area: {
    center: { lat: number; lng: number };
    radius: number;
    bbox: { minLng: number; minLat: number; maxLng: number; maxLat: number };
  };
  google_places: {
    total_addresses_found: number;
    addresses_with_pins: number;
    addresses_without_pins: number;
    sample_missing: Array<{
      formatted_address: string;
      place_id: string;
      lat: number;
      lng: number;
      has_pin: boolean;
    }>;
  };
  database: {
    total_properties: number;
    properties_with_place_id: number;
    properties_without_place_id: number;
  };
  distance_analysis: {
    min_distance_meters: number;
    avg_distance_meters: number;
    max_distance_meters: number;
    sample_count: number;
  };
  gap_analysis: {
    gap_percentage: number;
    estimated_missing_pins: number;
  };
}

export function useAddressAudit() {
  const [isAuditing, setIsAuditing] = useState(false);
  const [auditResult, setAuditResult] = useState<AddressAuditResult | null>(null);

  const auditArea = async (minLng: number, minLat: number, maxLng: number, maxLat: number) => {
    setIsAuditing(true);
    try {
      const { data, error } = await supabase.functions.invoke('address-audit', {
        body: { minLng, minLat, maxLng, maxLat }
      });

      if (error) throw error;

      if (!data.ok) {
        throw new Error(data.error || 'Audit failed');
      }

      setAuditResult(data as AddressAuditResult);
      
      toast.success(
        `Audit complete: ${data.google_places.total_addresses_found} addresses found, ` +
        `${data.database.total_properties} pins in database (${data.gap_analysis.gap_percentage}% gap)`
      );

      return data as AddressAuditResult;
    } catch (error: any) {
      console.error('Address audit error:', error);
      toast.error(`Audit failed: ${error.message}`);
      return null;
    } finally {
      setIsAuditing(false);
    }
  };

  return {
    auditArea,
    isAuditing,
    auditResult,
  };
}
