import { useEffect, useRef, useCallback } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useAuth } from '@/components/AuthProvider';

interface RealtimeSyncConfig {
  enablePropertySync?: boolean;
  enableVisitSync?: boolean;
  enablePhotoSync?: boolean;
  enableProposalSync?: boolean;
  enableDispositionSync?: boolean;
  enableDesignSync?: boolean;
  onUpdate?: (table: string, event: string, payload: any) => void;
}

export function useRealtimeSync(config: RealtimeSyncConfig = {}) {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const subscriptionsRef = useRef<Array<{ channel: any; table: string }>>([]);

  const {
    enablePropertySync = true,
    enableVisitSync = true,
    enablePhotoSync = true,
    enableProposalSync = true,
    enableDispositionSync = true,
    enableDesignSync = true,
    onUpdate
  } = config;

  const showNotification = useCallback((table: string, event: string, data: any) => {
    const tableNames: Record<string, string> = {
      properties: 'Property',
      visits: 'Visit',
      photos: 'Photo',
      proposals: 'Proposal',
      dispositions: 'Disposition',
      designs: 'Design'
    };

    const tableName = tableNames[table] || table;
    
    switch (event) {
      case 'INSERT':
        toast.success(`New ${tableName.toLowerCase()} added`, {
          description: `A teammate added a new ${tableName.toLowerCase()}`,
          duration: 3000,
        });
        break;
      case 'UPDATE':
        toast.info(`${tableName} updated`, {
          description: `A teammate updated a ${tableName.toLowerCase()}`,
          duration: 2000,
        });
        break;
      case 'DELETE':
        toast.error(`${tableName} deleted`, {
          description: `A teammate deleted a ${tableName.toLowerCase()}`,
          duration: 2000,
        });
        break;
    }
  }, []);

  const createSubscription = useCallback((table: string, hasUserFilter: boolean = true) => {
    console.log(`Creating real-time subscription for ${table}`);
    
    const channelName = `${table}_realtime_${Date.now()}`;
    const channel = supabase.channel(channelName);

    const subscriptionConfig = {
      event: '*' as const,
      schema: 'public',
      table,
      ...(hasUserFilter && user ? { filter: `created_by=eq.${user.id}` } : {})
    };

    channel.on('postgres_changes', subscriptionConfig, (payload) => {
      console.log(`Real-time update for ${table}:`, payload);
      
      const { eventType, new: newRecord, old: oldRecord } = payload;
      
      // Call custom callback if provided
      onUpdate?.(table, eventType, payload);
      
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: [table] });
      
      // Show notification if it's not from the current user  
      const newRecordCreatedBy = (newRecord as any)?.created_by;
      const oldRecordCreatedBy = (oldRecord as any)?.created_by;
      const isOwnUpdate = (newRecordCreatedBy === user?.id) || (oldRecordCreatedBy === user?.id);
      if (!isOwnUpdate) {
        showNotification(table, eventType, newRecord || oldRecord);
      }
      
      // Optimistic updates for immediate UI feedback
      if (eventType === 'INSERT' && newRecord) {
        queryClient.setQueryData([table], (oldData: any) => {
          if (Array.isArray(oldData)) {
            return [newRecord, ...oldData];
          }
          return oldData;
        });
      } else if (eventType === 'UPDATE' && newRecord) {
        queryClient.setQueryData([table], (oldData: any) => {
          if (Array.isArray(oldData)) {
            return oldData.map((item: any) => 
              item.id === newRecord.id ? { ...item, ...newRecord } : item
            );
          }
          return oldData;
        });
      } else if (eventType === 'DELETE' && oldRecord) {
        queryClient.setQueryData([table], (oldData: any) => {
          if (Array.isArray(oldData)) {
            return oldData.filter((item: any) => item.id !== oldRecord.id);
          }
          return oldData;
        });
      }
    });

    channel.subscribe((status) => {
      console.log(`Subscription status for ${table}:`, status);
      if (status === 'SUBSCRIBED') {
        console.log(`✅ Successfully subscribed to ${table} updates`);
      } else if (status === 'CLOSED') {
        console.log(`❌ Subscription closed for ${table}`);
      } else if (status === 'CHANNEL_ERROR') {
        console.error(`💥 Subscription error for ${table}`);
        toast.error(`Real-time sync error for ${table}`);
      }
    });

    return { channel, table };
  }, [user, queryClient, onUpdate, showNotification]);

  useEffect(() => {
    if (!user) {
      console.log('No authenticated user - skipping real-time subscriptions');
      return;
    }

    console.log('Setting up real-time subscriptions...');

    // Clean up existing subscriptions
    subscriptionsRef.current.forEach(({ channel }) => {
      channel.unsubscribe();
    });
    subscriptionsRef.current = [];

    const subscriptions: Array<{ channel: any; table: string }> = [];

    // Create subscriptions based on config
    if (enablePropertySync) {
      subscriptions.push(createSubscription('properties'));
    }
    
    if (enableVisitSync) {
      subscriptions.push(createSubscription('visits'));
    }
    
    if (enablePhotoSync) {
      subscriptions.push(createSubscription('photos'));
    }
    
    if (enableProposalSync) {
      subscriptions.push(createSubscription('proposals'));
    }
    
    if (enableDispositionSync) {
      subscriptions.push(createSubscription('dispositions', false)); // Global dispositions
    }
    
    if (enableDesignSync) {
      subscriptions.push(createSubscription('designs'));
    }

    subscriptionsRef.current = subscriptions;

    // Cleanup function
    return () => {
      console.log('Cleaning up real-time subscriptions...');
      subscriptions.forEach(({ channel, table }) => {
        console.log(`Unsubscribing from ${table}`);
        channel.unsubscribe();
      });
      subscriptionsRef.current = [];
    };
  }, [
    user,
    enablePropertySync,
    enableVisitSync,
    enablePhotoSync,
    enableProposalSync,
    enableDispositionSync,
    enableDesignSync,
    createSubscription
  ]);

  // Return subscription status and control functions
  return {
    isConnected: subscriptionsRef.current.length > 0,
    activeSubscriptions: subscriptionsRef.current.map(s => s.table),
    cleanup: () => {
      subscriptionsRef.current.forEach(({ channel }) => {
        channel.unsubscribe();
      });
      subscriptionsRef.current = [];
    }
  };
}