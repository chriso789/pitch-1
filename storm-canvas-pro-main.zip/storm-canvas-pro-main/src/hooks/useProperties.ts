import { useSupabaseQuery, useSupabaseMutation } from './useSupabaseQuery';
import { useOptimisticUpdates } from './useOptimisticUpdates';
import { supabase } from '@/integrations/supabase/client';
import { z } from 'zod';
import { toast } from 'sonner';
import { PropertyFilters } from '@/components/PropertyFilters';
import { 
  PropertySchema,
  CreatePropertySchema,
  UpdatePropertySchema,
} from '@/lib/validation';
// Database response schemas (without branding for compatibility)
const DatabasePropertySchema = z.object({
  id: z.string().uuid(),
  user_id: z.string().uuid(),
  address: z.string(),
  latitude: z.number(),
  longitude: z.number(),
  place_id: z.string().nullable(),
  address_hash: z.string().optional(),
  homeowner_name: z.string().nullable(),
  phone: z.string().nullable(),
  email: z.string().email().nullable().or(z.literal('').transform(() => null)),
  credit_score: z.number().int().min(300).max(850).nullable(),
  age: z.number().int().min(0).max(120).nullable(),
  gender: z.enum(['Male', 'Female', 'Other', 'Prefer not to say']).nullable(),
  property_value: z.number().int().min(0).nullable(),
  year_built: z.number().int().min(1800).max(new Date().getFullYear()).nullable(),
  square_footage: z.number().int().min(0).nullable(),
  disposition_id: z.string().uuid().nullable(),
  disposition_notes: z.string().nullable(),
  enriched_at: z.string().datetime().nullable(),
  enrichment_source: z.string().nullable(),
  last_enrichment_attempt: z.string().datetime().nullable(),
  created_at: z.string().datetime(),
  updated_at: z.string().datetime(),
});

const DatabaseCreatePropertySchema = DatabasePropertySchema.omit({
  id: true,
  user_id: true,
  address_hash: true,
  created_at: true,
  updated_at: true,
});

export function useProperties(filters?: PropertyFilters, pagination?: { page: number; pageSize: number }) {
  return useSupabaseQuery(
    ['properties', JSON.stringify(filters), JSON.stringify(pagination)],
    async () => {
      let query = supabase
        .from('properties')
        .select(`
          *,
          disposition:dispositions(id, name, color, description)
        `);

      // Apply filters if provided
      if (filters) {
        // Disposition filter
        if (filters.dispositions.length > 0) {
          query = query.in('disposition_id', filters.dispositions);
        }

        // Date range filter
        if (filters.dateRange.from) {
          query = query.gte('created_at', filters.dateRange.from.toISOString());
        }
        if (filters.dateRange.to) {
          query = query.lte('created_at', filters.dateRange.to.toISOString());
        }

        // Credit score range filter
        if (filters.creditScoreRange.min) {
          query = query.gte('credit_score', filters.creditScoreRange.min);
        }
        if (filters.creditScoreRange.max) {
          query = query.lte('credit_score', filters.creditScoreRange.max);
        }

        // Property value range filter
        if (filters.propertyValueRange.min) {
          query = query.gte('property_value', filters.propertyValueRange.min);
        }
        if (filters.propertyValueRange.max) {
          query = query.lte('property_value', filters.propertyValueRange.max);
        }

        // Year built range filter
        if (filters.yearBuiltRange.min) {
          query = query.gte('year_built', filters.yearBuiltRange.min);
        }
        if (filters.yearBuiltRange.max) {
          query = query.lte('year_built', filters.yearBuiltRange.max);
        }

        // Boolean filters
        if (filters.hasHomeowner !== null) {
          if (filters.hasHomeowner) {
            query = query.not('homeowner_name', 'is', null);
          } else {
            query = query.is('homeowner_name', null);
          }
        }

        if (filters.isEnriched !== null) {
          if (filters.isEnriched) {
            query = query.not('enriched_at', 'is', null);
          } else {
            query = query.is('enriched_at', null);
          }
        }

        // For hasVisits, we need to use a different approach since visits are in a separate table
        // This would require a join or subquery - for now we'll skip this complex filter
      }

      // Apply pagination if provided
      if (pagination) {
        const offset = (pagination.page - 1) * pagination.pageSize;
        query = query.range(offset, offset + pagination.pageSize - 1);
      }

      // Default ordering
      query = query.order('created_at', { ascending: false });

      return query;
    },
    z.array(DatabasePropertySchema),
    { staleTime: 30000 }
  );
}

export function useProperty(id: string) {
  return useSupabaseQuery(
    ['properties', id],
    async () => {
      return supabase
        .from('properties')
        .select(`
          *,
          disposition:dispositions(id, name, color, description)
        `)
        .eq('id', id)
        .single();
    },
    DatabasePropertySchema,
    { enabled: !!id }
  );
}

export function useCreateProperty() {
  return useSupabaseMutation(
    async (property: any) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      return supabase
        .from('properties')
        .insert({
          ...property,
          user_id: user.id,
          email: property.email || null,
        })
        .select()
        .single();
    },
    DatabaseCreatePropertySchema,
    DatabasePropertySchema,
    {
      onSuccess: () => {
        toast.success('Property created successfully');
      },
      invalidateQueries: [['properties']],
    }
  );
}

export function useUpdateProperty() {
  return useSupabaseMutation(
    async ({ id, ...updates }: any) => {
      return supabase
        .from('properties')
        .update({
          ...updates,
          email: updates.email || null,
        })
        .eq('id', id)
        .select()
        .single();
    },
    z.any(),
    z.any(),
    {
      onSuccess: () => {
        toast.success('Property updated successfully');
      },
      invalidateQueries: [['properties']],
    }
  );
}

export function useSetPropertyDisposition() {
  return useSupabaseMutation(
    async ({ propertyId, dispositionId, notes }: { 
      propertyId: string; 
      dispositionId: string | null;
      notes?: string;
    }) => {
      return supabase
        .from('properties')
        .update({
          disposition_id: dispositionId,
          disposition_notes: notes || null,
        })
        .eq('id', propertyId)
        .select(`
          *,
          disposition:dispositions(id, name, color, description)
        `)
        .single();
    },
    z.any(),
    z.any(),
    {
      onSuccess: () => {
        toast.success('Disposition updated successfully');
      },
      invalidateQueries: [['properties']],
    }
  );
}