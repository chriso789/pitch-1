import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

export const useGoogleMapsKey = () => {
  const [apiKey, setApiKey] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchApiKey = async () => {
    setLoading(true);
    setError(null);
    
    try {
      // First try to get from Supabase secrets
      const { data, error: funcError } = await supabase.functions.invoke('get-google-maps-key');
      
      if (!funcError && data?.ok && data?.apiKey) {
        setApiKey(data.apiKey);
        return;
      }
      
      // Fallback to environment variable
      const envKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY;
      if (envKey) {
        setApiKey(envKey);
        return;
      }
      
      setApiKey(null);
    } catch (err) {
      console.error('Error fetching Google Maps API key:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch API key');
      
      // Try environment variable as fallback
      const envKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY;
      if (envKey) {
        setApiKey(envKey);
        setError(null);
      }
    } finally {
      setLoading(false);
    }
  };

  const saveApiKey = async (key: string): Promise<boolean> => {
    try {
      const { data, error } = await supabase.functions.invoke('save-google-maps-key', {
        body: { apiKey: key }
      });
      
      if (error || !data?.ok) {
        throw new Error(data?.error || 'Failed to save API key');
      }
      
      setApiKey(key);
      return true;
    } catch (err) {
      console.error('Error saving Google Maps API key:', err);
      setError(err instanceof Error ? err.message : 'Failed to save API key');
      return false;
    }
  };

  useEffect(() => {
    fetchApiKey();
  }, []);

  return {
    apiKey,
    loading,
    error,
    saveApiKey,
    refetch: fetchApiKey
  };
};