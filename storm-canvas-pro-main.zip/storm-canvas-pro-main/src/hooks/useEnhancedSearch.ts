import { useState, useCallback, useRef } from 'react';
import { config } from '@/lib/config';
import { toast } from 'sonner';

export interface SearchResult {
  place_id: string;
  formatted_address: string;
  geometry: {
    location: { lat: number; lng: number };
  };
  address_components: Array<{
    long_name: string;
    short_name: string;
    types: string[];
  }>;
  confidence: number;
  address_hash: string;
  partial_match: boolean;
  location_type?: string;
}

export interface UseEnhancedSearchOptions {
  debounceMs?: number;
  onDuplicateFound?: (existing: SearchResult, duplicate: SearchResult) => void;
  minQueryLength?: number;
}

export function useEnhancedSearch(options: UseEnhancedSearchOptions = {}) {
  const {
    debounceMs = 300,
    onDuplicateFound,
    minQueryLength = 3
  } = options;

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [retryCount, setRetryCount] = useState(0);
  const debounceRef = useRef<NodeJS.Timeout>();
  const seenAddresses = useRef<Set<string>>(new Set());

  const calculateConfidence = useCallback((result: any): number => {
    let confidence = 0.5; // Base confidence
    
    // Boost for exact matches
    if (result.geometry?.location_type === 'ROOFTOP') confidence += 0.4;
    else if (result.geometry?.location_type === 'RANGE_INTERPOLATED') confidence += 0.3;
    else if (result.geometry?.location_type === 'GEOMETRIC_CENTER') confidence += 0.2;
    
    // Penalty for partial matches
    if (result.partial_match) confidence -= 0.2;
    
    // Boost for specific address types
    const types = result.types || [];
    if (types.includes('street_address')) confidence += 0.2;
    else if (types.includes('premise')) confidence += 0.15;
    else if (types.includes('subpremise')) confidence += 0.1;
    
    // Boost for complete address components
    const components = result.address_components || [];
    const hasStreetNumber = components.some((c: any) => c.types.includes('street_number'));
    const hasRoute = components.some((c: any) => c.types.includes('route'));
    if (hasStreetNumber && hasRoute) confidence += 0.1;
    
    return Math.min(Math.max(confidence, 0.1), 1.0);
  }, []);

  const generateAddressHash = useCallback(async (address: string): Promise<string> => {
    // Normalize address for consistent hashing
    const normalized = address
      .toLowerCase()
      .replace(/[^\w\s]/g, '')
      .replace(/\s+/g, ' ')
      .trim();
    
    const encoder = new TextEncoder();
    const data = encoder.encode(normalized);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('').substring(0, 16);
  }, []);

  const searchAddresses = useCallback(async (query: string): Promise<SearchResult[]> => {
    if (!config?.googleMaps?.apiKey) {
      const errorMsg = 'Google Maps API key not configured. Please check your setup.';
      setError(errorMsg);
      throw new Error(errorMsg);
    }

    if (query.length < minQueryLength) {
      return [];
    }

    setLoading(true);
    setError(null);
    
    try {
      const response = await fetch(
        `https://maps.googleapis.com/maps/api/geocode/json?` +
        new URLSearchParams({
          key: config.googleMaps.apiKey,
          address: query,
          region: 'US',
          components: 'country:US',
        })
      );

      if (!response.ok) {
        throw new Error(`Geocoding request failed: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      
      if (data.status === 'REQUEST_DENIED') {
        throw new Error(`API access denied: ${data.error_message || 'Check your API key and billing'}`);
      }
      
      if (data.status === 'OVER_QUERY_LIMIT') {
        throw new Error('API quota exceeded. Please try again later.');
      }
      
      const formattedResults: SearchResult[] = await Promise.all(
        (data.results || []).map(async (result: any) => {
          const confidence = calculateConfidence(result);
          const address_hash = await generateAddressHash(result.formatted_address);
          
          return {
            place_id: result.place_id,
            formatted_address: result.formatted_address,
            geometry: {
              location: {
                lat: result.geometry.location.lat,
                lng: result.geometry.location.lng,
              },
            },
            address_components: result.address_components || [],
            confidence,
            address_hash,
            partial_match: result.partial_match || false,
            location_type: result.geometry?.location_type,
          };
        })
      );

      // Check for duplicates
      const uniqueResults = formattedResults.filter(result => {
        if (seenAddresses.current.has(result.address_hash)) {
          onDuplicateFound?.(result, result);
          return false;
        }
        seenAddresses.current.add(result.address_hash);
        return true;
      });

      // Sort by confidence (highest first)
      uniqueResults.sort((a, b) => b.confidence - a.confidence);

      setRetryCount(0);
      
      if (uniqueResults.length === 0 && data.results?.length > 0) {
        toast.info('All search results were duplicates of previously selected addresses');
      }
      
      return uniqueResults;
      
    } catch (error) {
      console.error('Enhanced search error:', error);
      const errorMessage = error instanceof Error ? error.message : 'Search failed';
      setError(errorMessage);
      
      if (errorMessage.includes('quota') || errorMessage.includes('denied')) {
        toast.error(errorMessage);
      }
      
      throw error;
    } finally {
      setLoading(false);
    }
  }, [config?.googleMaps?.apiKey, minQueryLength, calculateConfidence, generateAddressHash, onDuplicateFound]);

  const debouncedSearch = useCallback((query: string): Promise<SearchResult[]> => {
    return new Promise((resolve, reject) => {
      if (debounceRef.current) {
        clearTimeout(debounceRef.current);
      }

      debounceRef.current = setTimeout(async () => {
        try {
          const results = await searchAddresses(query);
          resolve(results);
        } catch (error) {
          reject(error);
        }
      }, debounceMs);
    });
  }, [searchAddresses, debounceMs]);

  const retry = useCallback(() => {
    setRetryCount(prev => prev + 1);
    setError(null);
  }, []);

  const clearCache = useCallback(() => {
    seenAddresses.current.clear();
  }, []);

  return {
    searchAddresses: debouncedSearch,
    loading,
    error,
    retryCount,
    retry,
    clearCache,
  };
}