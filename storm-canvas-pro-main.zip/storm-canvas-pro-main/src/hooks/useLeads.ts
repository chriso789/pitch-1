// React hooks for managing skip-trace leads
import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import type { LeadRecord } from '@/lib/skiptrace/types';

interface CreateLeadInput {
  address: string;
  city?: string;
  state?: string;
  zip?: string;
  lat: number;
  lng: number;
  statusTypeId?: number;
  statusTitle?: string;
  statusFrontColor?: string;
  statusBackColor?: string;
  source?: string;
  propertyId?: string;
}

export function useLeads() {
  const [loading, setLoading] = useState(false);
  const [leads, setLeads] = useState<LeadRecord[]>([]);

  const createLead = useCallback(async (input: CreateLeadInput) => {
    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      const { data, error } = await supabase
        .from('leads')
        .insert({
          address: input.address,
          city: input.city,
          state: input.state,
          zip: input.zip,
          lat: input.lat,
          lng: input.lng,
          status_type_id: input.statusTypeId,
          status_title: input.statusTitle,
          status_front_color: input.statusFrontColor || '#ffffff',
          status_back_color: input.statusBackColor || '#cc0000',
          source: input.source || 'manual',
          property_id: input.propertyId,
          created_by: user.id
        })
        .select()
        .single();

      if (error) throw error;

      toast.success('Lead created successfully');
      return data;
    } catch (error) {
      console.error('Error creating lead:', error);
      toast.error('Failed to create lead');
      throw error;
    } finally {
      setLoading(false);
    }
  }, []);

  const getLeadsInBounds = useCallback(async (bounds: {
    minLng: number;
    minLat: number;
    maxLng: number;
    maxLat: number;
    statusIds?: number[];
  }) => {
    try {
      const { data, error } = await supabase.rpc('get_leads_in_bbox', {
        min_lng: bounds.minLng,
        min_lat: bounds.minLat,
        max_lng: bounds.maxLng,
        max_lat: bounds.maxLat,
        status_ids: bounds.statusIds || null
      });

      if (error) throw error;
      
      setLeads(data || []);
      return data || [];
    } catch (error) {
      console.error('Error fetching leads:', error);
      toast.error('Failed to load leads');
      return [];
    }
  }, []);

  const updateLeadDisposition = useCallback(async (leadId: string, statusTypeId: number, statusTitle?: string) => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('leads')
        .update({
          status_type_id: statusTypeId,
          status_title: statusTitle
        })
        .eq('id', leadId)
        .select()
        .single();

      if (error) throw error;

      toast.success('Lead disposition updated');
      return data;
    } catch (error) {
      console.error('Error updating lead disposition:', error);
      toast.error('Failed to update disposition');
      throw error;
    } finally {
      setLoading(false);
    }
  }, []);

  const getLeadsGeoJSON = useCallback(async (statusIds?: number[]) => {
    try {
      const query = statusIds && statusIds.length > 0
        ? supabase.from('leads').select('*').in('status_type_id', statusIds)
        : supabase.from('leads').select('*');

      const { data, error } = await query;
      
      if (error) throw error;

      // Convert to GeoJSON format
      const features = (data || []).map(lead => ({
        type: 'Feature' as const,
        geometry: {
          type: 'Point' as const,
          coordinates: [lead.lng, lead.lat]
        },
        properties: {
          id: lead.id,
          address: lead.address,
          city: lead.city,
          state: lead.state,
          zip: lead.zip,
          status_type_id: lead.status_type_id,
          status_title: lead.status_title,
          front_color: lead.status_front_color,
          back_color: lead.status_back_color,
          source: lead.source
        }
      }));

      return {
        type: 'FeatureCollection' as const,
        features
      };
    } catch (error) {
      console.error('Error fetching leads GeoJSON:', error);
      return { type: 'FeatureCollection' as const, features: [] };
    }
  }, []);

  return {
    loading,
    leads,
    createLead,
    getLeadsInBounds,
    updateLeadDisposition,
    getLeadsGeoJSON
  };
}