import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface Proposal {
  id: string;
  property_id: string;
  type?: string;
  url?: string; // S3/signed URL
  created_by?: string;
  created_at: string;
}

export interface GenerateProposalParams {
  propertyId: string;
  proposalType?: string;
  customerName?: string;
  designId?: string;
  notes?: string;
}

export function useProposals(apiEndpoint: "express" | "supabase" = "supabase") {
  const [proposals, setProposals] = useState<Proposal[]>([]);
  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);

  const fetchProposals = useCallback(async (propertyId?: string) => {
    setLoading(true);
    try {
      let query = supabase
        .from('proposals')
        .select('*')
        .order('created_at', { ascending: false });

      if (propertyId) {
        query = query.eq('property_id', propertyId);
      }

      const { data, error } = await query;

      if (error) throw error;

      setProposals(data || []);
    } catch (error) {
      console.error('Error fetching proposals:', error);
      toast.error('Failed to load proposals');
    } finally {
      setLoading(false);
    }
  }, []);

  const generateProposal = useCallback(async (params: GenerateProposalParams) => {
    setGenerating(true);
    try {
      if (apiEndpoint === "express") {
        const response = await fetch("/api/proposals/generate", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({
            propertyId: params.propertyId,
            type: params.proposalType || 'hail',
            created_by: (await supabase.auth.getUser()).data.user?.id
          })
        });
        
        const result = await response.json();
        
        if (!result.ok) {
          throw new Error(result.error || 'Failed to generate proposal');
        }
        
        // Refresh proposals after generation
        await fetchProposals(params.propertyId);
        
        toast.success('Proposal generated successfully!');
        return result;
      } else {
        // Use Edge Function for PDF generation
        const { data: edgeResult, error: edgeError } = await supabase.functions.invoke('proposals-generate', {
          body: {
            propertyId: params.propertyId,
            type: params.proposalType || 'hail',
            created_by: (await supabase.auth.getUser()).data.user?.id
          }
        });
        
        if (edgeError) throw edgeError;
        
        if (!edgeResult.ok) {
          throw new Error(edgeResult.error || 'Failed to generate proposal');
        }
        
        // Refresh proposals after generation
        await fetchProposals(params.propertyId);
        
        toast.success('Proposal generated successfully!');
        return edgeResult;
      }
    } catch (error) {
      console.error('Generate proposal error:', error);
      toast.error('Failed to generate proposal');
      throw error;
    } finally {
      setGenerating(false);
    }
  }, [apiEndpoint, fetchProposals]);

  const updateProposal = useCallback(async (proposalId: string, updates: Partial<Proposal>) => {
    try {
      const { data, error } = await supabase
        .from('proposals')
        .update(updates)
        .eq('id', proposalId)
        .select()
        .single();

      if (error) throw error;

      setProposals(prev => prev.map(proposal => 
        proposal.id === proposalId ? { ...proposal, ...data } : proposal
      ));

      toast.success('Proposal updated successfully');
      return data;
    } catch (error) {
      console.error('Update proposal error:', error);
      toast.error('Failed to update proposal');
      throw error;
    }
  }, []);

  const deleteProposal = useCallback(async (proposalId: string) => {
    try {
      const { error } = await supabase
        .from('proposals')
        .delete()
        .eq('id', proposalId);

      if (error) throw error;

      setProposals(prev => prev.filter(proposal => proposal.id !== proposalId));
      toast.success('Proposal deleted successfully');
    } catch (error) {
      console.error('Delete proposal error:', error);
      toast.error('Failed to delete proposal');
    }
  }, []);

  return {
    proposals,
    loading,
    generating,
    fetchProposals,
    generateProposal,
    updateProposal,
    deleteProposal
  };
}