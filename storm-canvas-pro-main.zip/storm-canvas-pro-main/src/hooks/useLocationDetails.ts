import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface LocationDetails {
  addressHash: string;
  owner?: { 
    name?: string;
    type?: string;
    mailing_address?: string;
    is_out_of_state?: boolean;
  };
  parcel?: { apn?: string; wkt?: string };
  lastVisits: any[];
  dispositions: any[];
  photos: Array<{
    id: string;
    key: string;
    url: string;
    created_at: string;
  }>;
  cached?: boolean;
  cacheAgedays?: number;
}

export function useLocationDetails() {
  const [details, setDetails] = useState<LocationDetails | null>(null);
  const [loading, setLoading] = useState(false);

  const fetchLocationDetails = useCallback(async (addressHash: string) => {
    if (!addressHash) return;

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('locations-details', {
        body: { addressHash }
      });

      if (error) throw error;

      if (data?.ok && data?.data) {
        setDetails(data.data);
        
        // Notify user if using cached data
        if (data.data.cached) {
          const ageText = data.data.cacheAgedays === 1 
            ? '1 day ago' 
            : `${data.data.cacheAgedays} days ago`;
          toast.info(`Using cached homeowner data from ${ageText}`, {
            description: 'No new charges applied'
          });
        }
      } else {
        throw new Error(data?.error || 'Failed to fetch location details');
      }
    } catch (error) {
      console.error('Error fetching location details:', error);
      toast.error('Failed to load location details');
      setDetails(null);
    } finally {
      setLoading(false);
    }
  }, []);

  const clearDetails = useCallback(() => {
    setDetails(null);
  }, []);

  return {
    details,
    loading,
    fetchLocationDetails,
    clearDetails
  };
}