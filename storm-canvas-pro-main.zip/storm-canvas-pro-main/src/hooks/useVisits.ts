import { useSupabaseQuery, useSupabaseMutation } from './useSupabaseQuery';
import { supabase } from '@/integrations/supabase/client';
import { z } from 'zod';
import { toast } from 'sonner';
import { 
  CreateVisit, 
  UpdateVisit, 
  VisitSchema, 
  CreateVisitSchema, 
  UpdateVisitSchema, 
  UUIDSchema 
} from '@/lib/validation';

export function useVisits(propertyId?: string) {
  return useSupabaseQuery(
    propertyId ? ['visits', 'property', propertyId] : ['visits'],
    async () => {
      let query = supabase
        .from('visits')
        .select(`
          *,
          property:properties(id, address),
          disposition:dispositions(id, name, color, description)
        `)
        .order('visit_date', { ascending: false });

      if (propertyId) {
        query = query.eq('property_id', propertyId);
      }

      return query;
    },
    z.any(),
    { enabled: !propertyId || !!propertyId }
  );
}

export function useCreateVisit() {
  return useSupabaseMutation(
    async (visit: CreateVisit) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      return supabase
        .from('visits')
        .insert({
          ...visit,
          user_id: user.id,
        })
        .select(`
          *,
          property:properties(id, address),
          disposition:dispositions(id, name, color, description)
        `)
        .single();
    },
    CreateVisitSchema,
    VisitSchema,
    {
      onSuccess: () => {
        toast.success('Visit recorded successfully');
      },
      invalidateQueries: [['visits'], ['properties']],
    }
  );
}

export function useUpdateVisit() {
  return useSupabaseMutation(
    async ({ id, ...updates }: UpdateVisit & { id: string }) => {
      return supabase
        .from('visits')
        .update(updates)
        .eq('id', id)
        .select(`
          *,
          property:properties(id, address),
          disposition:dispositions(id, name, color, description)
        `)
        .single();
    },
    UpdateVisitSchema.extend({ id: UUIDSchema }),
    VisitSchema,
    {
      onSuccess: () => {
        toast.success('Visit updated successfully');
      },
      invalidateQueries: [['visits']],
    }
  );
}