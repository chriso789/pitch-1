// src/lib/wkt.ts

export type LatLng = { lat: number; lng: number };

/** Convert a closed polygon path to WKT Polygon string. Assumes path[0] !== path[last] and closes for you */
export function pathToWkt(path: LatLng[]): string {
  if (!path.length) throw new Error("empty path");
  
  const closed = [...path];
  const first = path[0];
  const last = path[path.length - 1];
  
  // Close the polygon if it's not already closed
  if (first.lat !== last.lat || first.lng !== last.lng) {
    closed.push({ lat: first.lat, lng: first.lng });
  }
  
  // WKT format is longitude first, then latitude
  const points = closed.map(p => `${p.lng} ${p.lat}`).join(",");
  return `POLYGON((${points}))`;
}

/** Compute polygon area in sqft given LatLng path (spherical approximation) */
export function naiveAreaSqft(path: LatLng[]): number {
  if (path.length < 3) return 0;
  
  // Shoelace formula adapted for spherical coordinates
  const R = 6378137; // Earth radius in meters
  const rad = (d: number) => (d * Math.PI) / 180;
  
  let area = 0;
  for (let i = 0, j = path.length - 1; i < path.length; j = i++) {
    const xi = rad(path[i].lng) * Math.cos(rad(path[i].lat));
    const yi = rad(path[i].lat);
    const xj = rad(path[j].lng) * Math.cos(rad(path[j].lat));
    const yj = rad(path[j].lat);
    area += xi * yj - xj * yi;
  }
  
  const m2 = Math.abs(area) * R * R;
  return m2 * 10.7639; // Convert square meters to square feet
}

/** Parse WKT Polygon string back to LatLng path */
export function wktToPath(wkt: string): LatLng[] {
  const match = wkt.match(/POLYGON\s*\(\s*\((.*?)\)\s*\)/i);
  if (!match) throw new Error("Invalid WKT Polygon format");
  
  const coordsStr = match[1];
  const coords = coordsStr.split(',').map(pair => {
    const [lng, lat] = pair.trim().split(/\s+/).map(Number);
    return { lat, lng };
  });
  
  // Remove the closing point if it duplicates the first
  if (coords.length > 1) {
    const first = coords[0];
    const last = coords[coords.length - 1];
    if (first.lat === last.lat && first.lng === last.lng) {
      coords.pop();
    }
  }
  
  return coords;
}