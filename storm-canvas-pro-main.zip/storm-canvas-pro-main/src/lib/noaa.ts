// src/lib/noaa.ts

/** NOAA NGS tile URL composer. Example eventId: '20241011b-rgb' */
export const NGS_TILE = (eventId: string, z: number, x: number, y: number) =>
  `https://stormscdn.ngs.noaa.gov/${eventId}/${z}/${x}/${y}`;

/** Common NOAA event IDs and their descriptions */
export const NOAA_EVENTS = {
  '20241011b-rgb': 'Hurricane Milton - October 2024',
  '20240926a-rgb': 'Hurricane Helene - September 2024',
  '20240808a-rgb': 'Hurricane Debby - August 2024',
  '20240701a-rgb': 'Hurricane Beryl - July 2024',
} as const;

export type NoaaEventId = keyof typeof NOAA_EVENTS;

/** Generate tile URLs for a given event and zoom level */
export function generateNoaaTiles(
  eventId: string,
  centerLat: number,
  centerLng: number,
  zoom: number,
  radius = 1
): Array<{ x: number; y: number; url: string }> {
  const tiles: Array<{ x: number; y: number; url: string }> = [];
  
  // Convert lat/lng to tile coordinates
  const n = Math.pow(2, zoom);
  const centerX = Math.floor((centerLng + 180) / 360 * n);
  const centerY = Math.floor((1 - Math.log(Math.tan(centerLat * Math.PI / 180) + 1 / Math.cos(centerLat * Math.PI / 180)) / Math.PI) / 2 * n);
  
  // Generate tiles in a grid around the center
  for (let dx = -radius; dx <= radius; dx++) {
    for (let dy = -radius; dy <= radius; dy++) {
      const x = centerX + dx;
      const y = centerY + dy;
      
      // Ensure tile coordinates are valid
      if (x >= 0 && x < n && y >= 0 && y < n) {
        tiles.push({
          x,
          y,
          url: NGS_TILE(eventId, zoom, x, y)
        });
      }
    }
  }
  
  return tiles;
}

/** Convert tile coordinates back to lat/lng bounds */
export function tileToBounds(x: number, y: number, z: number) {
  const n = Math.pow(2, z);
  const lonMin = (x / n) * 360 - 180;
  const lonMax = ((x + 1) / n) * 360 - 180;
  const latMin = Math.atan(Math.sinh(Math.PI * (1 - 2 * (y + 1) / n))) * 180 / Math.PI;
  const latMax = Math.atan(Math.sinh(Math.PI * (1 - 2 * y / n))) * 180 / Math.PI;
  
  return {
    north: latMax,
    south: latMin,
    east: lonMax,
    west: lonMin
  };
}