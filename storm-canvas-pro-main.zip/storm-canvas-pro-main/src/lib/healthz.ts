import { supabase } from '@/integrations/supabase/client';
import { SkiptraceService } from '@/services/skiptraceApi';

export interface HealthStatus {
  name: string;
  status: 'healthy' | 'unhealthy' | 'unknown';
  latency?: number;
  error?: string;
  details?: Record<string, any>;
}

export class HealthChecker {
  async checkSupabase(): Promise<HealthStatus> {
    const start = Date.now();
    try {
      const { data, error } = await supabase
        .from('dispositions')
        .select('count')
        .limit(1);
      
      const latency = Date.now() - start;
      
      if (error) {
        return {
          name: 'Supabase',
          status: 'unhealthy',
          latency,
          error: error.message
        };
      }
      
      return {
        name: 'Supabase',
        status: 'healthy',
        latency,
        details: { connectionTest: 'passed' }
      };
    } catch (error) {
      return {
        name: 'Supabase',
        status: 'unhealthy',
        latency: Date.now() - start,
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  }

  async checkGoogleMaps(apiKey?: string): Promise<HealthStatus> {
    const start = Date.now();
    
    if (!apiKey) {
      return {
        name: 'Google Maps',
        status: 'unhealthy',
        error: 'API key not configured'
      };
    }

    try {
      const response = await fetch(
        `https://maps.googleapis.com/maps/api/geocode/json?address=test&key=${apiKey}`
      );
      const data = await response.json();
      const latency = Date.now() - start;
      
      if (response.ok && (data.status === 'OK' || data.status === 'ZERO_RESULTS')) {
        return {
          name: 'Google Maps',
          status: 'healthy',
          latency,
          details: { quotaUsed: data.status }
        };
      }
      
      return {
        name: 'Google Maps',
        status: 'unhealthy',
        latency,
        error: data.error_message || `Status: ${data.status}`
      };
    } catch (error) {
      return {
        name: 'Google Maps',
        status: 'unhealthy',
        latency: Date.now() - start,
        error: error instanceof Error ? error.message : 'Network error'
      };
    }
  }

  async checkSkiptrace(): Promise<HealthStatus> {
    const start = Date.now();
    
    try {
      const isHealthy = await SkiptraceService.testConnection();
      const latency = Date.now() - start;
      
      return {
        name: 'Skiptrace',
        status: isHealthy ? 'healthy' : 'unhealthy',
        latency,
        details: { provider: 'mock' }
      };
    } catch (error) {
      return {
        name: 'Skiptrace',
        status: 'unhealthy',
        latency: Date.now() - start,
        error: error instanceof Error ? error.message : 'Connection failed'
      };
    }
  }

  async checkAll(googleMapsApiKey?: string): Promise<HealthStatus[]> {
    const checks = await Promise.allSettled([
      this.checkSupabase(),
      this.checkGoogleMaps(googleMapsApiKey),
      this.checkSkiptrace()
    ]);

    return checks.map((result, index) => {
      if (result.status === 'fulfilled') {
        return result.value;
      } else {
        const services = ['Supabase', 'Google Maps', 'Skiptrace'];
        return {
          name: services[index],
          status: 'unhealthy' as const,
          error: result.reason?.message || 'Health check failed'
        };
      }
    });
  }
}

export const healthChecker = new HealthChecker();