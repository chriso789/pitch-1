// Rate limiting and retry utilities for Gate 3 compliance

export interface RateLimiter {
  canProceed(): Promise<boolean>;
  recordRequest(): void;
  reset(): void;
}

export class TokenBucketRateLimiter implements RateLimiter {
  private tokens: number;
  private lastRefill: number;

  constructor(
    private maxTokens: number,
    private refillRate: number // tokens per second
  ) {
    this.tokens = maxTokens;
    this.lastRefill = Date.now();
  }

  async canProceed(): Promise<boolean> {
    this.refillTokens();
    if (this.tokens >= 1) {
      this.tokens--;
      return true;
    }
    return false;
  }

  recordRequest(): void {
    // Token already consumed in canProceed
  }

  reset(): void {
    this.tokens = this.maxTokens;
    this.lastRefill = Date.now();
  }

  private refillTokens(): void {
    const now = Date.now();
    const elapsed = (now - this.lastRefill) / 1000;
    const tokensToAdd = elapsed * this.refillRate;
    
    this.tokens = Math.min(this.maxTokens, this.tokens + tokensToAdd);
    this.lastRefill = now;
  }

  getTokensRemaining(): number {
    this.refillTokens();
    return Math.floor(this.tokens);
  }
}

export interface RetryOptions {
  maxRetries: number;
  baseDelayMs: number;
  maxDelayMs: number;
  backoffMultiplier: number;
  retryCondition?: (error: Error) => boolean;
}

export class ExponentialBackoffRetry {
  constructor(private options: RetryOptions) {}

  async execute<T>(
    operation: () => Promise<T>,
    context?: string
  ): Promise<T> {
    let lastError: Error | null = null;
    
    for (let attempt = 0; attempt <= this.options.maxRetries; attempt++) {
      try {
        const result = await operation();
        if (attempt > 0) {
          console.log(`${context || 'Operation'} succeeded on attempt ${attempt + 1}`);
        }
        return result;
      } catch (error) {
        lastError = error instanceof Error ? error : new Error(String(error));
        
        if (attempt === this.options.maxRetries) {
          console.error(`${context || 'Operation'} failed after ${attempt + 1} attempts:`, lastError);
          break;
        }

        // Check if we should retry this error
        if (this.options.retryCondition && !this.options.retryCondition(lastError)) {
          console.log(`${context || 'Operation'} not retrying due to error type:`, lastError.message);
          break;
        }

        const delay = Math.min(
          this.options.baseDelayMs * Math.pow(this.options.backoffMultiplier, attempt),
          this.options.maxDelayMs
        );

        console.warn(`${context || 'Operation'} attempt ${attempt + 1} failed, retrying in ${delay}ms:`, lastError.message);
        await this.delay(delay);
      }
    }

    throw lastError;
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// Default retry configuration for API calls
export const DEFAULT_RETRY_OPTIONS: RetryOptions = {
  maxRetries: 3,
  baseDelayMs: 1000,
  maxDelayMs: 10000,
  backoffMultiplier: 2,
  retryCondition: (error: Error) => {
    // Retry on rate limit errors and temporary failures
    const message = error.message.toLowerCase();
    return (
      message.includes('rate limit') ||
      message.includes('timeout') ||
      message.includes('network') ||
      message.includes('temporary') ||
      message.includes('502') ||
      message.includes('503') ||
      message.includes('504')
    );
  }
};

// Create rate limiter for different services
export const createSkiptraceRateLimiter = () => new TokenBucketRateLimiter(
  10, // 10 requests max
  1   // 1 request per second refill
);

export const createGoogleMapsRateLimiter = () => new TokenBucketRateLimiter(
  50, // 50 requests max  
  10  // 10 requests per second refill
);