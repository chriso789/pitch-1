// Roof measurement types and provider interface

export type EdgeType = 'ridge' | 'hip' | 'valley' | 'eave' | 'rake' | 'wall_flashing' | 'step_flashing' | 'other';

export type LinearFeature = {
  id: string;
  wkt: string;                        // LINESTRING WKT (lon lat)
  length_ft: number;
  type: EdgeType;
  label?: string;
};

export type RoofFace = {
  id: string;                         // e.g. 'A', 'B', 'C'
  wkt: string;                        // POLYGON WKT (lon lat)
  area_sqft: number;
  pitch?: string;                     // '6/12', etc
  linear_features?: LinearFeature[];  // Lines drawn on this face
};

export type MeasureResult = {
  faces: RoofFace[];
  linear_features?: LinearFeature[];  // Standalone linear features
  summary: {
    total_area_sqft: number;
    total_squares: number;            // area / 100
    waste_pct: number;
    pitch_method: 'vendor' | 'manual';
  };
  source: 'manual' | 'eagleview' | 'nearmap' | 'hover' | 'roofr' | 'regrid' | 'osm';
};

export interface MeasureProvider {
  name: MeasureResult['source'];
  supports(address: any): Promise<boolean>;
  run(input: {
    address?: any;
    lat?: number;
    lng?: number;
    propertyId: string;
  }): Promise<MeasureResult>;
}

export type MeasureInput = {
  propertyId: string;
  address?: {
    line1: string;
    city: string;
    state: string;
    postal_code: string;
  };
  lat?: number;
  lng?: number;
  waste_pct?: number;
};

export type ManualMeasureInput = {
  propertyId: string;
  faces: Array<{
    id: string;
    wkt: string;
    area_sqft: number;
    pitch?: string;
    linear_features?: LinearFeature[];
  }>;
  linear_features?: LinearFeature[];
  waste_pct?: number;
};
