// Measurement orchestration service
import type { MeasureProvider, MeasureResult, MeasureInput } from './types';

/**
 * Auto-measure: tries providers in ranked order until one succeeds
 * Order: EagleView → Nearmap → HOVER → Roofr → Regrid → OSM
 */
export async function autoMeasure(
  input: MeasureInput,
  providers: MeasureProvider[]
): Promise<MeasureResult> {
  const errors: Array<{ provider: string; error: string }> = [];
  
  for (const provider of providers) {
    try {
      const supported = await provider.supports(input.address);
      if (!supported) {
        continue;
      }
      
      const result = await provider.run(input);
      
      // Check if result has valid faces
      if (result.faces && result.faces.length > 0) {
        return result;
      }
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Unknown error';
      errors.push({ provider: provider.name, error: errorMsg });
      console.warn(`Provider ${provider.name} failed:`, errorMsg);
    }
  }
  
  // All providers failed or returned empty results
  throw new Error(
    `No provider available. Tried: ${errors.map(e => e.provider).join(', ')}. ` +
    `Use Manual-Measure instead.`
  );
}
