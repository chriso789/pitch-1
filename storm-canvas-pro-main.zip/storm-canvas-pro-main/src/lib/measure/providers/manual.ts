// Manual measurement provider (user-drawn polygons)
import type { MeasureProvider, MeasureResult } from '../types';
import { pitchFactor, sqftToSquares } from '../util';

export const manualProvider: MeasureProvider = {
  name: 'manual',
  
  async supports(): Promise<boolean> {
    return true; // Always available
  },
  
  async run(input): Promise<MeasureResult> {
    // Manual measurements are created directly via the UI
    // This provider is mainly for the type interface
    throw new Error('Manual measurements should be created via POST /measure/manual');
  }
};
