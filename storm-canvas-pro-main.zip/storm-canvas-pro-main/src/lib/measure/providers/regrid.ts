// Regrid provider stub - parcel + building footprints
import type { MeasureProvider, MeasureResult } from '../types';

export const regridProvider = (apiKey: string): MeasureProvider => ({
  name: 'regrid',
  
  async supports(): Promise<boolean> {
    return !!apiKey;
  },
  
  async run({ address, lat, lng, propertyId }): Promise<MeasureResult> {
    // TODO: Implement Regrid API integration
    // 1. Call Regrid parcel+buildings near lat/lng
    // 2. Choose building polygon(s) with max area (main roof)
    // 3. Compute area (planar) + apply pitch factor if provided
    
    throw new Error('Regrid provider not yet implemented');
  }
});
