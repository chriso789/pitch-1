// EagleView provider stub - property data + 3D measurements
import type { MeasureProvider, MeasureResult } from '../types';

export const eagleviewProvider = (apiKey: string): MeasureProvider => ({
  name: 'eagleview',
  
  async supports(): Promise<boolean> {
    return !!apiKey;
  },
  
  async run({ address, propertyId }): Promise<MeasureResult> {
    // TODO: Implement EagleView API integration
    // Call measurement/property-data endpoints
    // Map to faces/edges/pitch
    
    throw new Error('EagleView provider not yet implemented');
  }
});
