// HOVER provider stub - 3D model + measurements
import type { MeasureProvider, MeasureResult } from '../types';

export const hoverProvider = (apiKey: string): MeasureProvider => ({
  name: 'hover',
  
  async supports(): Promise<boolean> {
    return !!apiKey;
  },
  
  async run({ address }): Promise<MeasureResult> {
    // TODO: Implement HOVER API integration
    // Create job -> webhook or poll -> fetch measurements
    
    throw new Error('HOVER provider not yet implemented');
  }
});
