// Roofr provider stub - ordered/DIY instant reports
import type { MeasureProvider, MeasureResult } from '../types';

export const roofrProvider = (apiKey?: string): MeasureProvider => ({
  name: 'roofr',
  
  async supports(): Promise<boolean> {
    return true; // Can order without key if DIY flow available
  },
  
  async run({ address }): Promise<MeasureResult> {
    // TODO: Implement Roofr API integration
    // Order or DIY instant; parse response
    
    throw new Error('Roofr provider not yet implemented');
  }
});
