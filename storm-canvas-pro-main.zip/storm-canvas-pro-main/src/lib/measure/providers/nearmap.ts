// Nearmap provider stub - roof measurements API
import type { MeasureProvider, MeasureResult } from '../types';

export const nearmapProvider = (token: string): MeasureProvider => ({
  name: 'nearmap',
  
  async supports(): Promise<boolean> {
    return !!token;
  },
  
  async run({ address, lat, lng, propertyId }): Promise<MeasureResult> {
    // TODO: Implement Nearmap Roof Measurements API
    // Call API, parse JSON/XML to faces + pitch + edges
    
    throw new Error('Nearmap provider not yet implemented');
  }
});
