// Utility functions for roof measurements

/**
 * Calculate pitch factor to convert projected area to actual roof surface area
 * @param pitch - Pitch in format "rise/run" (e.g., "6/12")
 * @returns Multiplier for projected area
 */
export function pitchFactor(pitch: string | undefined): number {
  if (!pitch) return 1;
  
  const parts = pitch.split('/').map(Number);
  if (parts.length !== 2 || parts.some(isNaN)) return 1;
  
  const [rise, run] = parts;
  if (run === 0) return 1;
  
  // Roof slope = hypotenuse / run = sqrt(rise² + run²) / run
  const roofSlope = Math.sqrt(rise * rise + run * run) / run;
  return roofSlope;
}

/**
 * Standard pitch factors for common roof pitches
 */
export const PITCH_FACTORS = {
  'flat': 1.0,
  '3/12': 1.031,
  '4/12': 1.054,
  '5/12': 1.083,
  '6/12': 1.118,
  '7/12': 1.158,
  '8/12': 1.202,
  '9/12': 1.250,
  '10/12': 1.302,
  '12/12': 1.414,
} as const;

/**
 * Calculate squares from square feet
 */
export function sqftToSquares(sqft: number): number {
  return sqft / 100;
}

/**
 * Apply waste percentage to area
 */
export function applyWaste(sqft: number, wastePct: number): number {
  return sqft * (1 + wastePct / 100);
}

/**
 * Calculate edge lengths from a polygon path
 */
export function calculateEdgeLengths(
  path: google.maps.LatLng[]
): { [key: string]: number } {
  if (!path || path.length < 2) return {};
  
  let totalPerimeter = 0;
  for (let i = 0; i < path.length; i++) {
    const nextIndex = (i + 1) % path.length;
    const distance = google.maps.geometry.spherical.computeDistanceBetween(
      path[i],
      path[nextIndex]
    );
    // Convert meters to feet
    totalPerimeter += distance * 3.28084;
  }
  
  return { perimeter: totalPerimeter };
}
