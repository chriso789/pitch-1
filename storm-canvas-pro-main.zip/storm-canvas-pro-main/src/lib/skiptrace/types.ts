// Skip-trace provider types and interfaces
export interface Address {
  street?: string;
  city?: string;
  state?: string;
  zip?: string;
  country?: string;
}

// Enhanced Estated API data structures
export interface EstatedProperty {
  metadata?: {
    attom_id?: number;
    publishing_date?: string;
  };
  address?: {
    street_number?: string;
    street_name?: string;
    formatted_street_address?: string;
    city?: string;
    state?: string;
    zip_code?: string;
    latitude?: number;
    longitude?: number;
    geocoding_accuracy?: string;
  };
  parcel?: {
    apn_original?: string;
    apn_unformatted?: string;
    fips_code?: string;
    area_sq_ft?: number;
    area_acres?: number;
    county_name?: string;
    standardized_land_use_category?: string;
    standardized_land_use_type?: string;
    location_descriptions?: string[];
    zoning?: string;
    building_count?: number;
    legal_description?: string;
    subdivision?: string;
    municipality?: string;
  };
  structure?: {
    year_built?: number;
    effective_year_built?: number;
    stories?: string;
    rooms_count?: number;
    beds_count?: number;
    baths?: number;
    partial_baths_count?: number;
    units_count?: number;
    parking_type?: string;
    parking_spaces_count?: number;
    pool_type?: string;
    architecture_type?: string;
    construction_type?: string;
    exterior_wall_type?: string;
    foundation_type?: string;
    roof_material_type?: string;
    heating_type?: string;
    air_conditioning_type?: string;
    fireplaces?: string;
    basement_type?: string;
    quality?: string;
    condition?: string;
    total_area_sq_ft?: number;
    other_areas?: Array<{ type: string; sq_ft: string }>;
    other_features?: Array<{ type: string; sq_ft: string }>;
    other_improvements?: Array<{ type: string; sq_ft: string }>;
    other_rooms?: string[];
    amenities?: string[];
  };
  taxes?: Array<{
    year?: number;
    amount?: number;
    exemptions?: string[];
    rate_code_area?: string;
  }>;
  assessments?: Array<{
    year?: number;
    land_value?: number;
    improvement_value?: number;
    total_value?: number;
  }>;
  market_assessments?: Array<{
    year?: number;
    land_value?: number;
    improvement_value?: number;
    total_value?: number;
  }>;
  valuation?: {
    value?: number;
    high?: number;
    low?: number;
    forecast_standard_deviation?: number;
    date?: string;
  };
  owner?: {
    name?: string;
    formatted_street_address?: string;
    unit_type?: string;
    unit_number?: string;
    city?: string;
    state?: string;
    zip_code?: string;
    zip_plus_four_code?: string;
    owner_occupied?: string;
  };
  deeds?: Array<{
    document_type?: string;
    recording_date?: string;
    original_contract_date?: string;
    sale_price?: number;
    sale_price_description?: string;
    distressed_sale?: boolean;
    seller_first_name?: string;
    seller_last_name?: string;
    seller_address?: string;
    seller_city?: string;
    seller_state?: string;
    seller_zip_code?: string;
    buyer_first_name?: string;
    buyer_last_name?: string;
    buyer_address?: string;
    buyer_city?: string;
    buyer_state?: string;
    buyer_zip_code?: string;
    lender_name?: string;
    loan_amount?: number;
    loan_type?: string;
    loan_due_date?: string;
    loan_interest_rate?: number;
  }>;
  boundary?: {
    wkt?: string;
    geojson?: {
      type: string;
      coordinates: number[][][];
    };
  };
}

export interface ParcelInfo {
  apn?: string;
  ownerNames?: string[];
  situsAddress?: string;
  mailingAddress?: string;
  propertyValue?: number;
  yearBuilt?: number;
  squareFootage?: number;
  // Enhanced fields
  boundaryWkt?: string;
  ownerOccupied?: string;
  landUseType?: string;
  propertyType?: string;
  qualityGrade?: string;
  condition?: string;
  taxExemptions?: string[];
  deedHistory?: Array<{
    date?: string;
    type?: string;
    price?: number;
    buyer?: string;
    seller?: string;
  }>;
}

export interface Contact {
  name?: string;
  phone?: string;
  email?: string;
  confidence?: number;
  provider: string;
  type?: 'owner' | 'resident' | 'related';
}

export interface SkipTraceResult {
  parcel?: ParcelInfo;
  contacts: Contact[];
  source?: string;
  processedAt?: Date;
  // Enhanced fields
  estatedData?: EstatedProperty;
  confidence?: number;
  ownerType?: 'individual' | 'business' | 'trust' | 'llc' | 'unknown';
  isOwnerOccupied?: boolean;
  propertyInsights?: {
    marketValue?: number;
    assessedValue?: number;
    valuationConfidence?: number;
    recentSale?: boolean;
    saleHistory?: Array<{ date: string; price: number }>;
  };
}

export interface SkipTraceProvider {
  name: string;
  health(): Promise<{ name: string; ok: boolean; latency_ms: number }>;
  lookup(input: { 
    address?: string; 
    lat?: number; 
    lng?: number; 
    apn?: string;
  }): Promise<SkipTraceResult>;
}

export interface SkipTraceJob {
  id: string;
  leadId?: string;
  propertyId?: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  provider?: string;
  inputData?: any;
  resultData?: SkipTraceResult;
  errorMessage?: string;
  startedAt: Date;
  completedAt?: Date;
  createdBy: string;
}

export interface LeadRecord {
  id: string;
  address: string;
  city?: string;
  state?: string;
  zip?: string;
  lat: number;
  lng: number;
  statusTypeId?: number;
  statusTitle?: string;
  statusFrontColor?: string;
  statusBackColor?: string;
  source?: string;
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
}