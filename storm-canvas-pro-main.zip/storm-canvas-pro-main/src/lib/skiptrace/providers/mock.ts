// Mock skip-trace provider for development and testing
import type { SkipTraceProvider, SkipTraceResult, Contact, ParcelInfo } from '../types';

export class MockSkipTraceProvider implements SkipTraceProvider {
  name = 'mock';

  async health() {
    return { name: this.name, ok: true, latency_ms: 50 };
  }

  async lookup(input: { address?: string; lat?: number; lng?: number; apn?: string }): Promise<SkipTraceResult> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 100));

    // Generate mock data based on input
    const mockContacts: Contact[] = [
      {
        name: 'John Smith',
        phone: '(555) 123-4567',
        email: 'john.smith@email.com',
        confidence: 0.85,
        provider: this.name,
        type: 'owner'
      },
      {
        name: 'Jane Smith',
        phone: '(555) 987-6543',
        email: 'jane.smith@email.com',
        confidence: 0.75,
        provider: this.name,
        type: 'related'
      }
    ];

    const mockParcel: ParcelInfo = {
      apn: `${Math.random().toString(36).substr(2, 9)}`,
      ownerNames: ['Smith, John & Jane'],
      situsAddress: input.address || '123 Main St',
      mailingAddress: input.address || '123 Main St',
      propertyValue: Math.floor(Math.random() * 500000) + 200000,
      yearBuilt: Math.floor(Math.random() * 50) + 1970,
      squareFootage: Math.floor(Math.random() * 2000) + 1000
    };

    return {
      parcel: mockParcel,
      contacts: mockContacts,
      source: this.name,
      processedAt: new Date()
    };
  }
}