// SearchBug skip trace provider
import type { SkipTraceProvider, SkipTraceResult, Contact } from '../types';

export class SearchBugProvider implements SkipTraceProvider {
  name = 'searchbug';
  private username: string;
  private password: string;
  private baseUrl = 'https://www.searchbug.com/api';

  constructor(username: string, password: string) {
    this.username = username;
    this.password = password;
  }

  private getAuthHeader(): string {
    const credentials = btoa(`${this.username}:${this.password}`);
    return `Basic ${credentials}`;
  }

  async health() {
    const start = Date.now();
    try {
      const response = await fetch(`${this.baseUrl}/property/lookup`, {
        method: 'POST',
        headers: {
          'Authorization': this.getAuthHeader(),
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          address: 'test',
          output: 'json'
        })
      });
      const latency_ms = Date.now() - start;
      return { name: this.name, ok: response.status !== 401, latency_ms };
    } catch (error) {
      return { name: this.name, ok: false, latency_ms: Date.now() - start };
    }
  }

  async lookup(input: { address?: string; lat?: number; lng?: number }): Promise<SkipTraceResult> {
    if (!this.username || !this.password) {
      throw new Error('SearchBug credentials not configured');
    }

    if (!input.address) {
      return { contacts: [], source: this.name };
    }

    try {
      // Property lookup
      const propertyResponse = await fetch(`${this.baseUrl}/property/lookup`, {
        method: 'POST',
        headers: {
          'Authorization': this.getAuthHeader(),
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          address: input.address,
          output: 'json'
        })
      });

      if (!propertyResponse.ok) {
        throw new Error(`SearchBug API error: ${propertyResponse.status}`);
      }

      const propertyData = await propertyResponse.json();
      
      if (!propertyData || propertyData.error) {
        return { contacts: [], source: this.name };
      }

      const ownerName = propertyData.owner_name || propertyData.owner || propertyData.OwnerName || '';
      
      // Contact enrichment
      let contacts: Contact[] = [];
      if (ownerName) {
        try {
          const peopleResponse = await fetch(`${this.baseUrl}/people/search`, {
            method: 'POST',
            headers: {
              'Authorization': this.getAuthHeader(),
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              name: ownerName,
              address: input.address,
              output: 'json'
            })
          });

          if (peopleResponse.ok) {
            const peopleData = await peopleResponse.json();
            contacts = this.parseContacts(peopleData, ownerName);
          }
        } catch (error) {
          // Fallback to property data
          contacts = this.extractPropertyContacts(propertyData, ownerName);
        }
      }

      return {
        parcel: {
          apn: propertyData.apn || propertyData.APN,
          ownerNames: [ownerName],
          situsAddress: input.address,
          mailingAddress: propertyData.mailing_address || propertyData.MailingAddress || input.address,
          propertyValue: propertyData.assessed_value || propertyData.AssessedValue,
          yearBuilt: propertyData.year_built || propertyData.YearBuilt,
          squareFootage: propertyData.square_footage || propertyData.SquareFootage
        },
        contacts,
        source: this.name,
        processedAt: new Date()
      };
    } catch (error) {
      console.error('SearchBug lookup error:', error);
      throw error;
    }
  }

  private parseContacts(peopleResult: any, ownerName: string): Contact[] {
    const contacts: Contact[] = [];
    
    if (!peopleResult || !peopleResult.results || !Array.isArray(peopleResult.results)) {
      return contacts;
    }

    for (const person of peopleResult.results) {
      if (person.phones && Array.isArray(person.phones)) {
        for (const phone of person.phones) {
          contacts.push({
            name: person.name || ownerName,
            phone: phone.number || phone,
            email: person.email || null,
            confidence: person.confidence || 0.7,
            provider: this.name,
            type: 'owner' as const
          });
        }
      }
      
      if ((!person.phones || person.phones.length === 0) && person.email) {
        contacts.push({
          name: person.name || ownerName,
          phone: null,
          email: person.email,
          confidence: person.confidence || 0.6,
          provider: this.name,
          type: 'owner' as const
        });
      }
    }

    return contacts;
  }

  private extractPropertyContacts(propertyData: any, ownerName: string): Contact[] {
    const contacts: Contact[] = [];
    
    if (propertyData.phone || propertyData.Phone) {
      contacts.push({
        name: ownerName,
        phone: propertyData.phone || propertyData.Phone,
        email: propertyData.email || propertyData.Email || null,
        confidence: 0.6,
        provider: this.name,
        type: 'owner' as const
      });
    } else if (propertyData.email || propertyData.Email) {
      contacts.push({
        name: ownerName,
        phone: null,
        email: propertyData.email || propertyData.Email,
        confidence: 0.5,
        provider: this.name,
        type: 'owner' as const
      });
    }

    return contacts;
  }
}
