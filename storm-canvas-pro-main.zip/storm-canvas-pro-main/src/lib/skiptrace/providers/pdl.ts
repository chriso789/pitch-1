// People Data Labs contact enrichment provider
import type { SkipTraceProvider, SkipTraceResult, Contact } from '../types';

export class PeopleDataLabsProvider implements SkipTraceProvider {
  name = 'pdl';
  private apiKey: string;
  private baseUrl = 'https://api.peopledatalabs.com/v5';

  constructor(apiKey: string) {
    this.apiKey = apiKey;
  }

  async health() {
    const start = Date.now();
    try {
      const response = await fetch(`${this.baseUrl}/person/search`, {
        method: 'GET',
        headers: {
          'X-Api-Key': this.apiKey,
          'Content-Type': 'application/json'
        }
      });
      const latency_ms = Date.now() - start;
      return { name: this.name, ok: response.status !== 401, latency_ms };
    } catch (error) {
      return { name: this.name, ok: false, latency_ms: Date.now() - start };
    }
  }

  async lookup(input: { address?: string; lat?: number; lng?: number }): Promise<SkipTraceResult> {
    if (!this.apiKey) {
      throw new Error('PDL API key not configured');
    }

    if (!input.address) {
      return { contacts: [], source: this.name };
    }

    // Parse address for PDL search
    const addressParts = this.parseAddress(input.address);
    
    const searchParams = {
      street_address: addressParts.street,
      locality: addressParts.city,
      region: addressParts.state,
      postal_code: addressParts.zip,
      size: 10
    };

    const response = await fetch(`${this.baseUrl}/person/search`, {
      method: 'POST',
      headers: {
        'X-Api-Key': this.apiKey,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(searchParams)
    });

    if (!response.ok) {
      throw new Error(`PDL API error: ${response.status}`);
    }

    const data = await response.json();
    
    if (!data.data || data.data.length === 0) {
      return { contacts: [], source: this.name };
    }

    const contacts: Contact[] = data.data.map((person: any) => ({
      name: person.full_name,
      phone: person.phone_numbers?.[0],
      email: person.emails?.[0]?.address,
      confidence: person.likelihood || 0.5,
      provider: this.name,
      type: 'resident' as const
    })).filter((contact: Contact) => contact.name);

    return {
      contacts,
      source: this.name,
      processedAt: new Date()
    };
  }

  private parseAddress(address: string) {
    // Simple address parsing - in production, use a proper address parser
    const parts = address.split(',').map(p => p.trim());
    
    return {
      street: parts[0] || '',
      city: parts[1] || '',
      state: parts[2]?.split(' ')[0] || '',
      zip: parts[2]?.split(' ')[1] || ''
    };
  }
}