// Enhanced Estated property data provider with comprehensive data extraction
import type { SkipTraceProvider, SkipTraceResult, Contact, ParcelInfo, EstatedProperty } from '../types';

export class EstatedProvider implements SkipTraceProvider {
  name = 'estated';
  private apiKey: string;
  private baseUrl = 'https://apis.estated.com/v4';

  constructor(apiKey: string) {
    this.apiKey = apiKey;
  }

  async health() {
    const start = Date.now();
    try {
      // Simple health check using combined address format
      const response = await fetch(`${this.baseUrl}/property?token=${this.apiKey}&combined_address=123%20Main%20St,%20New%20York,%20NY`);
      const latency_ms = Date.now() - start;
      return { name: this.name, ok: response.ok, latency_ms };
    } catch (error) {
      return { name: this.name, ok: false, latency_ms: Date.now() - start };
    }
  }

  async lookup(input: { address?: string; lat?: number; lng?: number; apn?: string }): Promise<SkipTraceResult> {
    if (!this.apiKey) {
      throw new Error('Estated API key not configured');
    }

    const params = new URLSearchParams({
      token: this.apiKey
    });

    // Estated supports different lookup methods
    if (input.address) {
      params.append('combined_address', input.address);
    } else if (input.apn) {
      throw new Error('APN lookup requires FIPS code - not yet implemented');
    } else {
      throw new Error('Estated provider requires an address - coordinates not supported');
    }

    const response = await fetch(`${this.baseUrl}/property?${params}`);
    
    if (!response.ok) {
      throw new Error(`Estated API error: ${response.status}`);
    }

    const data = await response.json();
    
    if (!data.data || data.data.length === 0) {
      return { contacts: [], source: this.name };
    }

    const property = data.data[0];
    
    // Extract comprehensive Estated data
    const estatedData: EstatedProperty = this.extractEstatedData(property);
    
    // Enhanced parcel information with comprehensive data
    const parcel: ParcelInfo = {
      apn: property.parcel?.apn_original,
      ownerNames: property.owner?.name ? [property.owner.name] : [],
      situsAddress: property.address?.formatted_street_address,
      mailingAddress: this.buildMailingAddress(property.owner),
      propertyValue: property.valuation?.value || property.market_assessments?.[0]?.total_value,
      yearBuilt: property.structure?.year_built,
      squareFootage: property.structure?.total_area_sq_ft,
      
      // Enhanced fields
      boundaryWkt: property.boundary?.wkt,
      ownerOccupied: property.owner?.owner_occupied,
      landUseType: property.parcel?.standardized_land_use_type,
      propertyType: property.parcel?.standardized_land_use_category,
      qualityGrade: property.structure?.quality,
      condition: property.structure?.condition,
      taxExemptions: property.taxes?.[0]?.exemptions || [],
      deedHistory: this.extractDeedHistory(property.deeds)
    };

    // Enhanced contact extraction
    const contacts: Contact[] = this.extractContacts(property);
    
    // Advanced confidence scoring
    const confidence = this.calculateAdvancedConfidence(property);
    
    // Determine owner type
    const ownerType = this.classifyOwnerType(property.owner?.name);
    
    // Owner occupancy determination
    const isOwnerOccupied = this.determineOwnerOccupancy(property);
    
    // Property insights
    const propertyInsights = this.extractPropertyInsights(property);

    return {
      parcel,
      contacts,
      source: this.name,
      processedAt: new Date(),
      estatedData,
      confidence,
      ownerType,
      isOwnerOccupied,
      propertyInsights
    };
  }

  private extractEstatedData(property: any): EstatedProperty {
    return {
      metadata: {
        attom_id: property.metadata?.attom_id,
        publishing_date: property.metadata?.publishing_date
      },
      address: {
        street_number: property.address?.street_number,
        street_name: property.address?.street_name,
        formatted_street_address: property.address?.formatted_street_address,
        city: property.address?.city,
        state: property.address?.state,
        zip_code: property.address?.zip_code,
        latitude: property.address?.latitude,
        longitude: property.address?.longitude,
        geocoding_accuracy: property.address?.geocoding_accuracy
      },
      parcel: {
        apn_original: property.parcel?.apn_original,
        apn_unformatted: property.parcel?.apn_unformatted,
        fips_code: property.parcel?.fips_code,
        area_sq_ft: property.parcel?.area_sq_ft,
        area_acres: property.parcel?.area_acres,
        county_name: property.parcel?.county_name,
        standardized_land_use_category: property.parcel?.standardized_land_use_category,
        standardized_land_use_type: property.parcel?.standardized_land_use_type,
        location_descriptions: property.parcel?.location_descriptions,
        zoning: property.parcel?.zoning,
        building_count: property.parcel?.building_count,
        legal_description: property.parcel?.legal_description,
        subdivision: property.parcel?.subdivision,
        municipality: property.parcel?.municipality
      },
      structure: property.structure,
      taxes: property.taxes,
      assessments: property.assessments,
      market_assessments: property.market_assessments,
      valuation: property.valuation,
      owner: property.owner,
      deeds: property.deeds,
      boundary: property.boundary
    };
  }

  private buildMailingAddress(owner: any): string | undefined {
    if (!owner) return undefined;
    
    const parts = [
      owner.formatted_street_address,
      owner.unit_type && owner.unit_number ? `${owner.unit_type} ${owner.unit_number}` : null,
      owner.city,
      owner.state && owner.zip_code ? `${owner.state} ${owner.zip_code}` : null
    ].filter(Boolean);
    
    return parts.length > 0 ? parts.join(', ') : undefined;
  }

  private extractDeedHistory(deeds: any[]): Array<{ date?: string; type?: string; price?: number; buyer?: string; seller?: string }> {
    if (!deeds) return [];
    
    return deeds.slice(0, 5).map(deed => ({
      date: deed.recording_date,
      type: deed.document_type,
      price: deed.sale_price,
      buyer: this.buildPersonName(deed.buyer_first_name, deed.buyer_last_name),
      seller: this.buildPersonName(deed.seller_first_name, deed.seller_last_name)
    }));
  }

  private buildPersonName(firstName?: string, lastName?: string): string | undefined {
    if (!lastName) return undefined;
    return firstName ? `${firstName} ${lastName}` : lastName;
  }

  private extractContacts(property: any): Contact[] {
    const contacts: Contact[] = [];
    
    // Primary owner contact
    if (property.owner?.name) {
      contacts.push({
        name: property.owner.name,
        confidence: this.calculateOwnerConfidence(property),
        provider: this.name,
        type: 'owner'
      });
    }

    // Historical contacts from deed records
    if (property.deeds) {
      property.deeds.slice(0, 3).forEach((deed: any, index: number) => {
        const buyerName = this.buildPersonName(deed.buyer_first_name, deed.buyer_last_name);
        if (buyerName && buyerName !== property.owner?.name) {
          contacts.push({
            name: buyerName,
            confidence: Math.max(0.5, 0.8 - (index * 0.1)), // Decrease confidence for older records
            provider: this.name,
            type: index === 0 ? 'owner' : 'related'
          });
        }
      });
    }

    return contacts;
  }

  private calculateAdvancedConfidence(property: any): number {
    let confidence = 0.6; // Base confidence
    
    // Owner occupancy boost
    if (property.owner?.owner_occupied === 'YES') {
      confidence += 0.25;
    } else if (property.owner?.owner_occupied === 'PROBABLE') {
      confidence += 0.15;
    }
    
    // Recent deed activity
    const mostRecentDeed = property.deeds?.[0];
    if (mostRecentDeed?.recording_date) {
      const deedDate = new Date(mostRecentDeed.recording_date);
      const yearsOld = (Date.now() - deedDate.getTime()) / (1000 * 60 * 60 * 24 * 365);
      if (yearsOld < 2) confidence += 0.15;
      else if (yearsOld < 5) confidence += 0.1;
    }
    
    // Deed type quality
    if (mostRecentDeed?.document_type?.toLowerCase().includes('warranty')) {
      confidence += 0.1;
    } else if (mostRecentDeed?.document_type?.toLowerCase().includes('quitclaim')) {
      confidence -= 0.05;
    }
    
    // Tax exemptions (homestead = owner occupied)
    if (property.taxes?.[0]?.exemptions?.some((ex: string) => 
      ex.toLowerCase().includes('homestead') || ex.toLowerCase().includes('principal')
    )) {
      confidence += 0.1;
    }
    
    // Property data quality
    if (property.structure?.quality && ['A+', 'A', 'A-'].includes(property.structure.quality)) {
      confidence += 0.05;
    }
    
    // Valuation confidence
    if (property.valuation?.forecast_standard_deviation && property.valuation.forecast_standard_deviation < 20) {
      confidence += 0.05;
    }
    
    return Math.min(0.95, confidence);
  }

  private calculateOwnerConfidence(property: any): number {
    const baseConfidence = this.calculateAdvancedConfidence(property);
    
    // Additional owner-specific factors
    let ownerConfidence = baseConfidence;
    
    // Owner name quality
    if (property.owner?.name && !property.owner.name.toLowerCase().includes('trust')) {
      ownerConfidence += 0.05;
    }
    
    // Mailing address matches property address
    const propertyAddr = property.address?.formatted_street_address?.toLowerCase();
    const mailingAddr = property.owner?.formatted_street_address?.toLowerCase();
    if (propertyAddr && mailingAddr && propertyAddr === mailingAddr) {
      ownerConfidence += 0.1;
    }
    
    return Math.min(0.95, ownerConfidence);
  }

  private classifyOwnerType(ownerName?: string): 'individual' | 'business' | 'trust' | 'llc' | 'unknown' {
    if (!ownerName) return 'unknown';
    
    const name = ownerName.toLowerCase();
    if (name.includes('llc')) return 'llc';
    if (name.includes('inc') || name.includes('corp') || name.includes('company')) return 'business';
    if (name.includes('trust')) return 'trust';
    
    return 'individual';
  }

  private determineOwnerOccupancy(property: any): boolean {
    // Direct indicator
    if (property.owner?.owner_occupied === 'YES') return true;
    if (property.owner?.owner_occupied === 'PROBABLE') return true;
    
    // Tax exemption indicators
    const exemptions = property.taxes?.[0]?.exemptions || [];
    return exemptions.some((ex: string) => 
      ex.toLowerCase().includes('homestead') || 
      ex.toLowerCase().includes('principal') ||
      ex.toLowerCase().includes('residential')
    );
  }

  private extractPropertyInsights(property: any): any {
    const marketValue = property.valuation?.value || property.market_assessments?.[0]?.total_value;
    const assessedValue = property.assessments?.[0]?.total_value;
    
    // Valuation confidence based on range
    let valuationConfidence = 0.5;
    if (property.valuation?.high && property.valuation?.low && property.valuation?.value) {
      const range = property.valuation.high - property.valuation.low;
      const midpoint = (property.valuation.high + property.valuation.low) / 2;
      const variance = Math.abs(property.valuation.value - midpoint) / midpoint;
      valuationConfidence = Math.max(0.3, 1 - variance - (range / midpoint));
    }
    
    // Recent sale detection
    const recentSale = property.deeds?.[0] && 
      new Date(property.deeds[0].recording_date).getTime() > (Date.now() - 2 * 365 * 24 * 60 * 60 * 1000);
    
    // Sale history
    const saleHistory = property.deeds
      ?.filter((deed: any) => deed.sale_price && deed.recording_date)
      ?.slice(0, 5)
      ?.map((deed: any) => ({
        date: deed.recording_date,
        price: deed.sale_price
      })) || [];
    
    return {
      marketValue,
      assessedValue,
      valuationConfidence,
      recentSale,
      saleHistory
    };
  }
}