// Skip-trace aggregation and orchestration service
import type { SkipTraceProvider, SkipTraceResult, Contact } from './types';
import { MockSkipTraceProvider } from './providers/mock';
import { SearchBugProvider } from './providers/searchbug';
import { PeopleDataLabsProvider } from './providers/pdl';
import { FreeSkipTraceProvider } from './providers/free';

export class SkipTraceService {
  private providers: SkipTraceProvider[] = [];
  
  constructor(config: {
    mockOnly?: boolean;
    searchBugUsername?: string;
    searchBugPassword?: string;
    pdlApiKey?: string;
    restrictedProviders?: boolean;
    useFreeProvider?: boolean;
  } = {}) {
    // Always include free provider first (most reliable for demo)
    if (config.useFreeProvider !== false) {
      this.providers.push(new FreeSkipTraceProvider());
    }
    
    // Include mock provider for development
    this.providers.push(new MockSkipTraceProvider());

    // Add real providers if credentials are available and not in mock-only mode
    if (!config.mockOnly) {
      if (config.searchBugUsername && config.searchBugPassword) {
        this.providers.push(new SearchBugProvider(config.searchBugUsername, config.searchBugPassword));
      }
      
      if (config.pdlApiKey && config.restrictedProviders) {
        this.providers.push(new PeopleDataLabsProvider(config.pdlApiKey));
      }
    }
  }

  async getProviderHealth() {
    const healthChecks = await Promise.all(
      this.providers.map(provider => provider.health())
    );
    
    return healthChecks;
  }

  async runSkipTrace(input: { 
    address?: string; 
    lat?: number; 
    lng?: number; 
    apn?: string;
  }): Promise<SkipTraceResult> {
    if (!input.address && !(input.lat && input.lng) && !input.apn) {
      throw new Error('Either address, coordinates, or APN must be provided');
    }

    // Run all providers in parallel
    const results = await Promise.allSettled(
      this.providers.map(provider => provider.lookup(input))
    );

    // Merge results from all successful providers
    return this.mergeResults(results);
  }

  private mergeResults(results: PromiseSettledResult<SkipTraceResult>[]): SkipTraceResult {
    let mergedParcel = {};
    const contactMap = new Map<string, Contact>();
    const sources: string[] = [];

    for (const result of results) {
      if (result.status !== 'fulfilled') continue;
      
      const { parcel, contacts, source } = result.value;
      
      // Merge parcel data (first wins for most fields)
      if (parcel && Object.keys(mergedParcel).length === 0) {
        mergedParcel = parcel;
      }
      
      // Deduplicate and score contacts
      for (const contact of contacts) {
        const key = this.getContactKey(contact);
        const existing = contactMap.get(key);
        
        if (!existing || (contact.confidence || 0) > (existing.confidence || 0)) {
          contactMap.set(key, contact);
        }
      }
      
      if (source) {
        sources.push(source);
      }
    }

    // Sort contacts by confidence
    const sortedContacts = Array.from(contactMap.values())
      .sort((a, b) => (b.confidence || 0) - (a.confidence || 0));

    return {
      parcel: Object.keys(mergedParcel).length > 0 ? mergedParcel as any : undefined,
      contacts: sortedContacts,
      source: sources.join(', '),
      processedAt: new Date()
    };
  }

  private getContactKey(contact: Contact): string {
    // Create unique key for deduplication based on phone or email
    if (contact.phone) {
      return `phone:${contact.phone.replace(/\D/g, '')}`;
    }
    if (contact.email) {
      return `email:${contact.email.toLowerCase()}`;
    }
    return `name:${contact.name?.toLowerCase() || 'unknown'}`;
  }
}