import { Address, Provider } from '../types';

export const uspsProvider = (apiKey: string): Provider => ({
  name: 'usps',
  
  async health() {
    const ok = !!apiKey;
    return { name: 'usps', ok, latency_ms: 0 };
  },
  
  async normalize(addr: Address) {
    // TODO: USPS Address Validation API
    return { address: addr };
  },
});