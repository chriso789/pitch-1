import { Address, Provider } from '../types';

export const melissaProvider = (apiKey: string): Provider => ({
  name: 'melissa',
  
  async health() {
    const ok = !!apiKey;
    return { name: 'melissa', ok, latency_ms: 0 };
  },
  
  async normalize(addr: Address) {
    // TODO: Melissa Data Address Verification
    return { address: addr };
  },
  
  async property(addr: Address | { place_id: string }) {
    // TODO: Melissa Property API
    return { apn: undefined, wkt: undefined, owner: undefined };
  },
});