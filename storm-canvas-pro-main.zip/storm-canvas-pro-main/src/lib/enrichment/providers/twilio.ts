import { Address, Provider } from '../types';

export const twilioLookupProvider = (sid: string, token: string): Provider => ({
  name: 'twilio',
  
  async health() {
    const ok = !!(sid && token);
    return { name: 'twilio', ok, latency_ms: 0 };
  },
  
  async phoneVerify(numbers: string[]) {
    // TODO: Twilio Lookup API for phone verification
    return numbers.map(n => ({ number: n, type: undefined, score: undefined }));
  },
});