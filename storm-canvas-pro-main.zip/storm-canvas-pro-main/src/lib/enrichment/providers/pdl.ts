import { Address, Provider } from '../types';

export const pdlProvider = (apiKey: string): Provider => ({
  name: 'pdl',
  
  async health() {
    const ok = !!apiKey;
    return { name: 'pdl', ok, latency_ms: 0 };
  },
  
  async people(input: { name?: string; address: Address }) {
    // TODO: People Data Labs Person Enrichment API
    return { phones: [], emails: [] };
  },
});