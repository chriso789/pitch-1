import { Address, Provider, Health } from '../types';

export const mapboxProvider = (token: string): Provider => ({
  name: 'mapbox',
  
  async health() {
    const startTime = Date.now();
    
    if (!token) {
      return { 
        name: 'mapbox', 
        ok: false, 
        error: 'No access token provided'
      };
    }

    try {
      // Test token validity with a simple geocoding request
      const response = await fetch(
        `https://api.mapbox.com/geocoding/v5/mapbox.places/test.json?access_token=${token}&limit=1`,
        { 
          method: 'GET',
          headers: { 'User-Agent': 'Canvass-IQ/1.0' }
        }
      );
      
      const latency = Date.now() - startTime;
      
      if (response.ok) {
        return { 
          name: 'mapbox', 
          ok: true, 
          latency_ms: latency,
          quota: 'See Mapbox dashboard'
        };
      } else {
        const error = await response.text();
        return { 
          name: 'mapbox', 
          ok: false, 
          latency_ms: latency,
          error: `HTTP ${response.status}: ${error}`
        };
      }
    } catch (error) {
      return { 
        name: 'mapbox', 
        ok: false, 
        latency_ms: Date.now() - startTime,
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  },

  async geocode(addr: Address) {
    if (!token) {
      throw new Error('Mapbox access token not configured');
    }

    const query = `${addr.line1} ${addr.city} ${addr.state} ${addr.postal_code}`;
    const encodedQuery = encodeURIComponent(query);
    
    const response = await fetch(
      `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodedQuery}.json?access_token=${token}&limit=1&country=US`,
      {
        method: 'GET',
        headers: { 'User-Agent': 'Canvass-IQ/1.0' }
      }
    );

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Mapbox geocoding failed: ${response.status} ${error}`);
    }

    const data = await response.json();
    
    if (!data.features || data.features.length === 0) {
      throw new Error('No geocoding results found');
    }

    const feature = data.features[0];
    const [lng, lat] = feature.center;
    
    // TODO: fetch Mapbox geocoding; use session tokens; handle rate limits
    return {
      place_id: feature.id,
      lat: parseFloat(lat.toFixed(6)),
      lng: parseFloat(lng.toFixed(6))
    };
  }
});