import { Address, Provider, Health } from '../types';
import { normalizePhoneNumber } from '../utils';

export const mockProvider = (): Provider => ({
  name: 'mock',
  
  async health() {
    await new Promise(resolve => setTimeout(resolve, 10)); // Simulate network delay
    return { 
      name: 'mock', 
      ok: true, 
      latency_ms: 10,
      quota: 'unlimited'
    };
  },

  async normalize(addr: Address) {
    await new Promise(resolve => setTimeout(resolve, 100));
    
    // Basic normalization
    const normalized = {
      ...addr,
      line1: addr.line1.toUpperCase().replace(/\b(ST|STREET)\b/g, 'ST').replace(/\b(AVE|AVENUE)\b/g, 'AVE'),
      city: addr.city.toUpperCase(),
      state: addr.state.toUpperCase(),
      postal_code: addr.postal_code.replace(/[^0-9]/g, '').substring(0, 5)
    };
    
    return { address: normalized };
  },

  async geocode(addr: Address) {
    await new Promise(resolve => setTimeout(resolve, 150));
    
    // Mock geocoding with some variance based on address
    const hash = addr.line1.split('').reduce((a, b) => a + b.charCodeAt(0), 0);
    const latOffset = (hash % 100) / 1000;
    const lngOffset = (hash % 200) / 1000;
    
    return { 
      place_id: `mock_${btoa(addr.line1 + addr.city).replace(/[^a-zA-Z0-9]/g, '').substring(0, 16)}`,
      lat: 27.95 + latOffset, 
      lng: -82.46 - lngOffset 
    };
  },

  async property(input: Address | { place_id: string }) {
    await new Promise(resolve => setTimeout(resolve, 200));
    
    const seed = 'place_id' in input ? input.place_id : input.line1;
    const hash = seed.split('').reduce((a, b) => a + b.charCodeAt(0), 0);
    
    // Generate mock property data
    const ownerNames = [
      'John Smith', 'Sarah Johnson', 'Michael Williams', 'Emily Brown', 
      'David Jones', 'Jessica Garcia', 'Robert Miller', 'Ashley Davis',
      'James Rodriguez', 'Amanda Martinez', 'Christopher Wilson', 'Lisa Moore'
    ];
    
    return {
      apn: `MOCK-${(hash % 900000 + 100000).toString()}-${(hash % 900 + 100).toString()}`,
      wkt: `POLYGON((-82.46 27.95, -82.45 27.95, -82.45 27.96, -82.46 27.96, -82.46 27.95))`,
      owner: ownerNames[hash % ownerNames.length]
    };
  },

  async people(input: { name?: string; address: Address }) {
    await new Promise(resolve => setTimeout(resolve, 300));
    
    const { name, address } = input;
    const seed = (name || '') + address.line1;
    const hash = seed.split('').reduce((a, b) => a + b.charCodeAt(0), 0);
    
    // Generate mock contact data
    const areaCode = Math.floor((hash % 800) + 200);
    const exchange = Math.floor((hash % 800) + 200);
    const number = Math.floor((hash % 9000) + 1000);
    const phone = normalizePhoneNumber(`${areaCode}${exchange}${number}`);
    
    const domains = ['gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com', 'aol.com'];
    const username = Math.abs(hash).toString(36).substring(0, 8);
    const email = `${username}@${domains[hash % domains.length]}`;
    
    return {
      phones: [phone],
      emails: [email]
    };
  },

  async phoneVerify(numbers: string[]) {
    await new Promise(resolve => setTimeout(resolve, 100));
    
    return numbers.map((number, index) => {
      const hash = number.split('').reduce((a, b) => a + b.charCodeAt(0), 0);
      const types = ['mobile', 'landline', 'voip'];
      const carriers = ['Verizon', 'AT&T', 'T-Mobile', 'Sprint', 'Other'];
      
      return {
        number,
        type: types[hash % types.length],
        score: 0.7 + (hash % 30) / 100 // 0.7-1.0
      };
    });
  }
});