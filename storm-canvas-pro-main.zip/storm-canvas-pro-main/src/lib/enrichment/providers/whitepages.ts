import { Address, Provider } from '../types';

export const whitepagesProvider = (apiKey: string): Provider => ({
  name: 'whitepages',
  
  async health() {
    const ok = !!apiKey;
    return { name: 'whitepages', ok, latency_ms: 0 };
  },
  
  async people(input: { name?: string; address: Address }) {
    // TODO: Whitepages Identity Check API
    return { phones: [], emails: [] };
  },
  
  async phoneVerify(numbers: string[]) {
    // TODO: Whitepages Phone Intelligence API
    return numbers.map(n => ({ number: n, type: undefined, score: undefined }));
  },
});