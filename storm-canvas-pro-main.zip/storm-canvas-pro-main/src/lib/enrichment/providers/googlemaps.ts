import { Address, Provider, Health } from '../types';

export const googleMapsProvider = (apiKey: string): Provider => ({
  name: 'googlemaps',
  
  async health(): Promise<Health> {
    const startTime = Date.now();
    
    if (!apiKey) {
      return { 
        name: 'googlemaps', 
        ok: false, 
        error: 'No API key provided'
      };
    }

    try {
      // Test API key validity with a simple geocoding request
      const response = await fetch(
        `https://maps.googleapis.com/maps/api/geocode/json?address=test&key=${apiKey}`,
        { 
          method: 'GET',
          headers: { 'User-Agent': 'Canvass-IQ/1.0' }
        }
      );
      
      const latency = Date.now() - startTime;
      
      if (response.ok) {
        const data = await response.json();
        if (data.status === 'OK' || data.status === 'ZERO_RESULTS') {
        return { 
          name: 'googlemaps', 
          ok: true, 
          latency_ms: latency,
          quota: 'See Google Cloud Console'
        };
        } else {
        return { 
          name: 'googlemaps', 
          ok: false, 
          latency_ms: latency,
          error: `API Error: ${data.status} - ${data.error_message || data.status}`
        };
        }
      } else {
        const error = await response.text();
        return { 
          name: 'googlemaps', 
          ok: false, 
          latency_ms: latency,
          error: `HTTP ${response.status}: ${error}`
        };
      }
    } catch (error) {
      return { 
        name: 'googlemaps', 
        ok: false, 
        latency_ms: Date.now() - startTime,
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }
  },

  async geocode(addr: Address) {
    if (!apiKey) {
      throw new Error('Google Maps API key not configured');
    }

    const query = `${addr.line1}, ${addr.city}, ${addr.state} ${addr.postal_code}`;
    
    const response = await fetch(
      `https://maps.googleapis.com/maps/api/geocode/json?` +
      new URLSearchParams({
        address: query,
        key: apiKey,
        region: 'US'
      }),
      {
        method: 'GET',
        headers: { 'User-Agent': 'Canvass-IQ/1.0' }
      }
    );

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Google Maps geocoding failed: ${response.status} ${error}`);
    }

    const data = await response.json();
    
    if (data.status !== 'OK' || !data.results || data.results.length === 0) {
      throw new Error(`Geocoding failed: ${data.status} - ${data.error_message || 'No results found'}`);
    }

    const result = data.results[0];
    const location = result.geometry.location;
    
    return {
      place_id: result.place_id,
      lat: parseFloat(location.lat.toFixed(6)),
      lng: parseFloat(location.lng.toFixed(6))
    };
  }
});