// Main enrichment service exports
export { EnrichmentService } from './service';
export { mockProvider } from './providers/mock';
export { googleMapsProvider } from './providers/googlemaps';
export { mapboxProvider } from './providers/mapbox';
export { uspsProvider } from './providers/usps';
export { melissaProvider } from './providers/melissa';
export { pdlProvider } from './providers/pdl';
export { whitepagesProvider } from './providers/whitepages';
export { twilioLookupProvider } from './providers/twilio';
export { MemoryEnrichmentCache, LocalStorageEnrichmentCache, HybridEnrichmentCache } from './cache';

// Types
export type {
  Address,
  Enrichment,
  Provider,
  Health,
  PipelineOptions,
  EnrichmentCache
} from './types';

// Schemas
export {
  AddressSchema,
  EnrichmentSchema
} from './types';

// Utils
export {
  hashAddress,
  redactConfig,
  normalizePhoneNumber,
  formatPhoneNumber,
  isValidEmail,
  generateIdempotencyKey
} from './utils';

// Configuration and service creation
import { EnrichmentService } from './service';
import { mockProvider } from './providers/mock';
import { googleMapsProvider } from './providers/googlemaps';
import { config } from '../config';

let enrichmentService: EnrichmentService | null = null;

export function createEnrichmentService(): EnrichmentService {
  if (enrichmentService) {
    return enrichmentService;
  }

  const providers = [];
  
  // Always include mock provider
  providers.push(mockProvider());
  
  // Add real providers based on configuration
  if (config?.googleMaps?.apiKey) {
    providers.push(googleMapsProvider(config.googleMaps.apiKey));
  }
  
  // TODO: Add other providers as they're implemented
  // if (config?.usps?.userId) providers.push(uspsProvider(config.usps.userId));
  // if (config?.melissa?.apiKey) providers.push(melissaProvider(config.melissa.apiKey));
  // if (config?.pdl?.apiKey) providers.push(pdlProvider(config.pdl.apiKey));
  // if (config?.whitepages?.apiKey) providers.push(whitepagesProvider(config.whitepages.apiKey));
  // if (config?.twilio?.sid && config?.twilio?.token) providers.push(twilioLookupProvider(config.twilio.sid, config.twilio.token));

  enrichmentService = new EnrichmentService(providers);
  return enrichmentService;
}

export function getEnrichmentService(): EnrichmentService {
  return createEnrichmentService();
}