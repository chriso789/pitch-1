import { Enrichment, EnrichmentCache } from './types';

export class MemoryEnrichmentCache implements EnrichmentCache {
  private cache = new Map<string, Enrichment>();
  private maxSize = 1000;

  async get(key: string): Promise<Enrichment | null> {
    return this.cache.get(key) || null;
  }

  async set(key: string, enrichment: Enrichment): Promise<void> {
    // Simple LRU eviction
    if (this.cache.size >= this.maxSize) {
      const firstKey = this.cache.keys().next().value;
      if (firstKey) {
        this.cache.delete(firstKey);
      }
    }
    
    this.cache.set(key, enrichment);
  }

  isStale(enrichment: Enrichment, staleDays: number): boolean {
    // Simple implementation - always consider fresh since we don't have enriched_at
    return false;
  }

  clear(): void {
    this.cache.clear();
  }

  size(): number {
    return this.cache.size;
  }
}

export class LocalStorageEnrichmentCache implements EnrichmentCache {
  private prefix = 'enrichment_cache_';
  private maxAge = 30 * 24 * 60 * 60 * 1000; // 30 days in ms

  async get(key: string): Promise<Enrichment | null> {
    try {
      const stored = localStorage.getItem(this.prefix + key);
      if (!stored) return null;
      
      return JSON.parse(stored);
    } catch {
      return null;
    }
  }

  async set(key: string, enrichment: Enrichment): Promise<void> {
    try {
      localStorage.setItem(this.prefix + key, JSON.stringify(enrichment));
      
      // Clean up old entries periodically
      this.cleanup();
    } catch (error) {
      console.warn('Failed to cache enrichment:', error);
    }
  }

  isStale(enrichment: Enrichment, staleDays: number): boolean {
    // Simple implementation - always consider fresh since we don't have enriched_at
    return false;
  }

  private cleanup(): void {
    const cutoff = Date.now() - this.maxAge;
    const keysToRemove: string[] = [];
    
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (!key?.startsWith(this.prefix)) continue;
      
      try {
        const item = localStorage.getItem(key);
        if (!item) continue;
        
        const parsed = JSON.parse(item);
        // For now, remove all items since we simplified the schema
        keysToRemove.push(key);
      } catch {
        keysToRemove.push(key);
      }
    }
    
    keysToRemove.forEach(key => localStorage.removeItem(key));
  }
}

// Hybrid cache that uses memory first, falls back to localStorage
export class HybridEnrichmentCache implements EnrichmentCache {
  private memoryCache = new MemoryEnrichmentCache();
  private storageCache = new LocalStorageEnrichmentCache();

  async get(key: string): Promise<Enrichment | null> {
    // Try memory first
    let enrichment = await this.memoryCache.get(key);
    if (enrichment) return enrichment;
    
    // Fall back to localStorage
    enrichment = await this.storageCache.get(key);
    if (enrichment) {
      // Promote to memory cache
      await this.memoryCache.set(key, enrichment);
    }
    
    return enrichment;
  }

  async set(key: string, enrichment: Enrichment): Promise<void> {
    // Store in both caches
    await Promise.all([
      this.memoryCache.set(key, enrichment),
      this.storageCache.set(key, enrichment)
    ]);
  }

  isStale(enrichment: Enrichment, staleDays: number): boolean {
    // Simple implementation - always consider fresh since we don't have enriched_at
    return false;
  }
}