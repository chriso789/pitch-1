import { z } from 'zod';

// Branded types for type safety
export const UUIDSchema = z.string().uuid().brand<'UUID'>();
export const EmailSchema = z.string().email().brand<'Email'>();
export const PhoneSchema = z.string().regex(/^\+?[1-9]\d{1,14}$/).brand<'Phone'>();

// Core entity schemas
export const DispositionSchema = z.object({
  id: UUIDSchema,
  name: z.string().min(1, 'Disposition name is required'),
  description: z.string().nullable(),
  color: z.string().regex(/^#[0-9A-F]{6}$/i, 'Invalid color format'),
  created_at: z.string().datetime(),
  updated_at: z.string().datetime(),
});

export const PropertySchema = z.object({
  id: UUIDSchema,
  user_id: UUIDSchema,
  address: z.string().min(1, 'Address is required'),
  latitude: z.number().min(-90).max(90),
  longitude: z.number().min(-180).max(180),
  place_id: z.string().nullable(),
  address_hash: z.string().optional(),
  
  // Homeowner information
  homeowner_name: z.string().nullable(),
  phone: z.string().nullable(),
  email: z.string().email().nullable().or(z.literal('').transform(() => null)),
  credit_score: z.number().int().min(300).max(850).nullable(),
  age: z.number().int().min(0).max(120).nullable(),
  gender: z.enum(['Male', 'Female', 'Other', 'Prefer not to say']).nullable(),
  
  // Property details
  property_value: z.number().int().min(0).nullable(),
  year_built: z.number().int().min(1800).max(new Date().getFullYear()).nullable(),
  square_footage: z.number().int().min(0).nullable(),
  
  // Disposition tracking
  disposition_id: UUIDSchema.nullable(),
  disposition_notes: z.string().nullable(),
  
  // Enrichment tracking
  enriched_at: z.string().datetime().nullable(),
  enrichment_source: z.string().nullable(),
  last_enrichment_attempt: z.string().datetime().nullable(),
  
  created_at: z.string().datetime(),
  updated_at: z.string().datetime(),
});

export const VisitSchema = z.object({
  id: UUIDSchema,
  user_id: UUIDSchema,
  property_id: UUIDSchema,
  disposition_id: UUIDSchema.nullable(),
  notes: z.string().nullable(),
  visit_date: z.string().datetime(),
  duration_minutes: z.number().int().min(0).nullable(),
  follow_up_required: z.boolean().default(false),
  follow_up_date: z.string().datetime().nullable(),
  created_at: z.string().datetime(),
  updated_at: z.string().datetime(),
});

// Input schemas (for creates/updates)
export const CreatePropertySchema = PropertySchema.omit({
  id: true,
  user_id: true,
  address_hash: true,
  created_at: true,
  updated_at: true,
});

export const UpdatePropertySchema = CreatePropertySchema.partial();

export const CreateVisitSchema = VisitSchema.omit({
  id: true,
  user_id: true,
  created_at: true,
  updated_at: true,
});

export const UpdateVisitSchema = CreateVisitSchema.partial();

// Legacy validation for backward compatibility - keep existing schemas
export const emailSchema = z.string().email('Please enter a valid email address');
export const phoneSchema = z.string().regex(
  /^\+?[1-9]\d{1,14}$/,
  'Please enter a valid phone number'
);
export const passwordSchema = z.string()
  .min(8, 'Password must be at least 8 characters')
  .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
  .regex(/[a-z]/, 'Password must contain at least one lowercase letter')
  .regex(/\d/, 'Password must contain at least one number');

export const requiredString = z.string().min(1, 'This field is required');

// Legacy form schemas
export const contactFormSchema = z.object({
  name: requiredString,
  email: emailSchema,
  phone: phoneSchema.optional(),
  message: requiredString.min(10, 'Message must be at least 10 characters'),
});

// Keep legacy PropertyInput exports for backward compatibility
export const PropertyInput = z.object({
  address: z.string().min(10, 'Address must be at least 10 characters'),
  latitude: z.number().min(-90).max(90, 'Invalid latitude'),
  longitude: z.number().min(-180).max(180, 'Invalid longitude'),
  homeowner_name: z.string().min(2, 'Name must be at least 2 characters').optional(),
  phone: z.string().regex(/^\(\d{3}\)\s\d{3}-\d{4}$/, 'Phone must be in format (555) 123-4567').optional(),
  email: z.string().email('Invalid email format').optional(),
  credit_score: z.number().min(300).max(850, 'Credit score must be between 300-850').optional(),
  age: z.number().min(18).max(120, 'Age must be between 18-120').optional(),
  gender: z.enum(['Male', 'Female', 'Other']).optional(),
});

export const DispositionInput = z.object({
  name: z.string().min(1, 'Disposition name required'),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/, 'Must be valid hex color'),
  description: z.string().optional(),
});

export const PropertyVisitSchema = z.object({
  property_id: z.string().uuid('Invalid property ID'),
  disposition_id: z.string().uuid('Invalid disposition ID'),
  notes: z.string().max(500, 'Notes must be under 500 characters').optional(),
  latitude: z.number().min(-90).max(90).optional(),
  longitude: z.number().min(-180).max(180).optional(),
});

// Type exports
export type UUID = z.infer<typeof UUIDSchema>;
export type Email = z.infer<typeof EmailSchema>;
export type Phone = z.infer<typeof PhoneSchema>;
export type Disposition = z.infer<typeof DispositionSchema>;
export type Property = z.infer<typeof PropertySchema>;
export type Visit = z.infer<typeof VisitSchema>;
export type CreateProperty = z.infer<typeof CreatePropertySchema>;
export type UpdateProperty = z.infer<typeof UpdatePropertySchema>;
export type CreateVisit = z.infer<typeof CreateVisitSchema>;
export type UpdateVisit = z.infer<typeof UpdateVisitSchema>;

// Legacy type exports
export type PropertyInput = z.infer<typeof PropertyInput>;
export type DispositionInput = z.infer<typeof DispositionInput>;
export type PropertyVisitInput = z.infer<typeof PropertyVisitSchema>;

// Validation utilities
export function validateAndParse<T>(schema: z.ZodSchema<T>, data: unknown): { success: true; data: T } | { success: false; errors: z.ZodError } {
  const result = schema.safeParse(data);
  if (result.success) {
    return { success: true, data: result.data };
  }
  return { success: false, errors: result.error };
}

export function getValidationErrors(error: z.ZodError): Record<string, string> {
  const errors: Record<string, string> = {};
  error.issues.forEach((issue) => {
    const path = issue.path.join('.');
    errors[path] = issue.message;
  });
  return errors;
}

// Legacy validation functions
export const validateProperty = (data: unknown) => {
  return PropertyInput.safeParse(data);
};

export const validateDisposition = (data: unknown) => {
  return DispositionInput.safeParse(data);
};

export const validatePropertyVisit = (data: unknown) => {
  return PropertyVisitSchema.safeParse(data);
};

// Format phone number helper
export const formatPhoneNumber = (phone: string): string => {
  const cleaned = phone.replace(/\D/g, '');
  if (cleaned.length === 10) {
    return `(${cleaned.slice(0, 3)}) ${cleaned.slice(3, 6)}-${cleaned.slice(6)}`;
  }
  return phone;
};