// src/lib/bbox.ts
import type { LatLng } from "./wkt";

export type BBox = { 
  minLng: number; 
  minLat: number; 
  maxLng: number; 
  maxLat: number; 
};

export function bboxFromCenter(
  center: LatLng, 
  halfWidthKm: number, 
  halfHeightKm?: number
): BBox {
  const R = 6371; // Earth radius in km
  const lat = center.lat * Math.PI / 180;
  
  const dLat = (halfHeightKm ?? halfWidthKm) / R;
  const dLng = halfWidthKm / (R * Math.cos(lat));
  
  return {
    minLng: center.lng - (dLng * 180 / Math.PI),
    maxLng: center.lng + (dLng * 180 / Math.PI),
    minLat: center.lat - (dLat * 180 / Math.PI),
    maxLat: center.lat + (dLat * 180 / Math.PI)
  };
}

export function bboxToQuery(b: BBox) {
  return { 
    minLng: b.minLng, 
    minLat: b.minLat, 
    maxLng: b.maxLng, 
    maxLat: b.maxLat 
  };
}

export function bboxFromPoints(points: LatLng[]): BBox {
  if (points.length === 0) {
    throw new Error("Cannot create bbox from empty points array");
  }
  
  let minLat = points[0].lat;
  let maxLat = points[0].lat;
  let minLng = points[0].lng;
  let maxLng = points[0].lng;
  
  for (const point of points) {
    minLat = Math.min(minLat, point.lat);
    maxLat = Math.max(maxLat, point.lat);
    minLng = Math.min(minLng, point.lng);
    maxLng = Math.max(maxLng, point.lng);
  }
  
  return { minLat, maxLat, minLng, maxLng };
}

export function bboxContains(bbox: BBox, point: LatLng): boolean {
  return point.lat >= bbox.minLat && 
         point.lat <= bbox.maxLat && 
         point.lng >= bbox.minLng && 
         point.lng <= bbox.maxLng;
}

export function bboxExpand(bbox: BBox, paddingKm: number): BBox {
  const center = {
    lat: (bbox.minLat + bbox.maxLat) / 2,
    lng: (bbox.minLng + bbox.maxLng) / 2
  };
  
  const currentWidth = Math.abs(bbox.maxLng - bbox.minLng);
  const currentHeight = Math.abs(bbox.maxLat - bbox.minLat);
  
  return bboxFromCenter(
    center, 
    (currentWidth * 111.32 / 2) + paddingKm, // rough conversion to km
    (currentHeight * 110.54 / 2) + paddingKm
  );
}