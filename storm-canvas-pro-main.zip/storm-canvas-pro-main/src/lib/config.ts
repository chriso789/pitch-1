import { z } from 'zod';

// Environment validation schema
const configSchema = z.object({
  supabase: z.object({
    url: z.string().url('Invalid Supabase URL'),
    anonKey: z.string().min(1, 'Supabase anon key is required'),
  }),
  googleMaps: z.object({
    apiKey: z.string().optional(),
  }).optional(),
  skiptrace: z.object({
    baseUrl: z.string().url('Invalid Skiptrace base URL').optional(),
    apiKey: z.string().optional(),
  }).optional(),
  app: z.object({
    env: z.enum(['development', 'staging', 'production', 'test']),
  }),
  sentry: z.object({
    dsn: z.string().optional(),
  }),
});

export type Config = z.infer<typeof configSchema>;

export interface ConfigValidationError {
  field: string;
  message: string;
  value?: string;
}

class ConfigManager {
  private _config: Config | null = null;
  private _errors: ConfigValidationError[] = [];
  private _isValid = false;

  get config(): Config | null {
    return this._config;
  }

  get errors(): ConfigValidationError[] {
    return this._errors;
  }

  get isValid(): boolean {
    return this._isValid;
  }

  get hasRequiredVars(): boolean {
    return !!(
      import.meta.env.VITE_SUPABASE_URL &&
      (import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY || import.meta.env.VITE_SUPABASE_ANON_KEY) &&
      import.meta.env.VITE_APP_ENV
    );
  }

  validate(): boolean {
    this._errors = [];
    
    if (!this.hasRequiredVars) {
      this._addMissingEnvErrors();
      this._isValid = false;
      return false;
    }

    try {
      const rawConfig = {
        supabase: {
          url: import.meta.env.VITE_SUPABASE_URL,
          anonKey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY || import.meta.env.VITE_SUPABASE_ANON_KEY,
        },
        googleMaps: import.meta.env.VITE_GOOGLE_MAPS_API_KEY ? {
          apiKey: import.meta.env.VITE_GOOGLE_MAPS_API_KEY,
        } : undefined,
        skiptrace: (import.meta.env.VITE_SKIPTRACE_BASE_URL && import.meta.env.VITE_SKIPTRACE_API_KEY) ? {
          baseUrl: import.meta.env.VITE_SKIPTRACE_BASE_URL,
          apiKey: import.meta.env.VITE_SKIPTRACE_API_KEY,
        } : undefined,
        app: {
          env: import.meta.env.VITE_APP_ENV,
        },
        sentry: {
          dsn: import.meta.env.VITE_SENTRY_DSN,
        },
      };

      const result = configSchema.safeParse(rawConfig);
      
      if (result.success) {
        this._config = result.data;
        this._isValid = true;
        return true;
      } else {
        this._parseZodErrors(result.error);
        this._isValid = false;
        return false;
      }
    } catch (error) {
      this._errors.push({
        field: 'general',
        message: 'Failed to parse configuration',
        value: error instanceof Error ? error.message : 'Unknown error',
      });
      this._isValid = false;
      return false;
    }
  }

  private _addMissingEnvErrors(): void {
    const requiredVars = [
      { key: 'VITE_SUPABASE_URL', field: 'supabase.url' },
      { key: 'VITE_APP_ENV', field: 'app.env' },
    ];

    // Check for either VITE_SUPABASE_PUBLISHABLE_KEY or VITE_SUPABASE_ANON_KEY
    if (!import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY && !import.meta.env.VITE_SUPABASE_ANON_KEY) {
      this._errors.push({
        field: 'supabase.anonKey',
        message: 'VITE_SUPABASE_PUBLISHABLE_KEY or VITE_SUPABASE_ANON_KEY environment variable is required',
      });
    }

    requiredVars.forEach(({ key, field }) => {
      if (!import.meta.env[key]) {
        this._errors.push({
          field,
          message: `${key} environment variable is required`,
        });
      }
    });
  }

  private _parseZodErrors(error: z.ZodError): void {
    error.issues.forEach((issue) => {
      this._errors.push({
        field: issue.path.join('.'),
        message: issue.message,
        value: '[REDACTED]', // Never expose actual secret values in errors
      });
    });
  }

  getRedactedConfig(): Record<string, any> {
    if (!this._config) return {};
    
    return {
      supabase: {
        url: this._config.supabase.url,
        anonKey: `${this._config.supabase.anonKey.substring(0, 8)}...`,
      },
      googleMaps: this._config.googleMaps ? {
        apiKey: `${this._config.googleMaps.apiKey?.substring(0, 8)}...`,
      } : { apiKey: 'Not configured' },
      skiptrace: this._config.skiptrace ? {
        baseUrl: this._config.skiptrace.baseUrl,
        apiKey: `${this._config.skiptrace.apiKey?.substring(0, 8)}...`,
      } : { baseUrl: 'Not configured', apiKey: 'Not configured' },
      app: {
        env: this._config.app.env,
      },
      sentry: {
        dsn: this._config.sentry.dsn ? `${this._config.sentry.dsn.substring(0, 20)}...` : undefined,
      },
    };
  }
}

// Single source of truth instance
export const configManager = new ConfigManager();

// Initialize on module load
configManager.validate();

// Export for easy access
export const config = configManager.config;
export const isConfigValid = configManager.isValid;
export const configErrors = configManager.errors;