import React from 'react';
import { Button } from "@/components/ui/button";
import { supabase } from '@/integrations/supabase/client';
import { toast } from "sonner";
import { Plus } from "lucide-react";

const sampleProperties = [
  {
    address: {
      line1: '123 Main St',
      city: 'Dallas',
      state: 'TX',
      postal_code: '75201'
    },
    lat: 32.7767,
    lng: -96.7970,
    homeowner: {
      name: 'John Smith',
      phone: '(555) 123-4567',
      email: 'john.smith@email.com'
    }
  },
  {
    address: {
      line1: '456 Oak Ave',
      city: 'Dallas',
      state: 'TX',
      postal_code: '75202'
    },
    lat: 32.7787,
    lng: -96.7990,
    homeowner: {
      name: 'Sarah Johnson',
      phone: '(555) 987-6543',
      email: 'sarah.j@email.com'
    }
  },
  {
    address: {
      line1: '789 Pine St',
      city: 'Dallas',
      state: 'TX',
      postal_code: '75203'
    },
    lat: 32.7747,
    lng: -96.7950,
    homeowner: {
      name: 'Mike Davis',
      phone: '(555) 456-7890',
      email: 'mike.davis@email.com'
    }
  }
];

export function SampleDataButton() {
  const addSampleData = async () => {
    try {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) {
        toast.error('You must be logged in to add sample data');
        return;
      }

      // Add each property using the RPC function
      for (const property of sampleProperties) {
        const { error } = await supabase.rpc('add_property_pin', {
          addr: property.address,
          lat: property.lat,
          lng: property.lng,
          homeowner_data: property.homeowner,
          created_by_val: user.user.id
        });

        if (error) throw error;
      }

      toast.success('Sample properties added successfully!');
    } catch (error) {
      console.error('Error adding sample data:', error);
      toast.error('Failed to add sample data');
    }
  };

  return (
    <Button 
      onClick={addSampleData}
      variant="outline"
      size="sm"
      className="absolute top-4 right-4 z-10"
    >
      <Plus className="h-4 w-4 mr-1" />
      Add Sample Data
    </Button>
  );
}