import { useState, useEffect, useRef } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Search, MapPin, Loader2, AlertCircle, RefreshCw } from 'lucide-react';
import { useEnhancedSearch, SearchResult } from '@/hooks/useEnhancedSearch';

// Re-export SearchResult for other components
export type { SearchResult };

interface EnhancedSearchProps {
  onSelect: (result: SearchResult) => void;
  placeholder?: string;
  className?: string;
  onDuplicateFound?: (existing: SearchResult, duplicate: SearchResult) => void;
  debounceMs?: number;
}

export function EnhancedSearch({ 
  onSelect, 
  placeholder = "Search addresses...", 
  className,
  onDuplicateFound,
  debounceMs = 300 
}: EnhancedSearchProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [showResults, setShowResults] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  
  const { searchAddresses, loading, error, retry } = useEnhancedSearch({
    debounceMs,
    onDuplicateFound
  });

  useEffect(() => {
    const handleSearch = async () => {
      if (query.length < 3) {
        setResults([]);
        setShowResults(false);
        return;
      }

      try {
        const searchResults = await searchAddresses(query);
        setResults(searchResults);
        setShowResults(true);
      } catch (error) {
        setResults([]);
        setShowResults(false);
      }
    };

    handleSearch();
  }, [query, searchAddresses]);

  const handleSelect = (result: SearchResult) => {
    setQuery(result.formatted_address);
    setShowResults(false);
    onSelect(result);
    inputRef.current?.blur();
  };

  const handleRetry = () => {
    retry();
    if (query.length >= 3) {
      searchAddresses(query).then(setResults).catch(() => setResults([]));
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      setShowResults(false);
      inputRef.current?.blur();
    } else if (e.key === 'ArrowDown' && results.length > 0) {
      e.preventDefault();
      // Focus first result (could implement keyboard navigation)
    }
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence > 0.8) return 'default';
    if (confidence > 0.6) return 'secondary';
    if (confidence > 0.4) return 'outline';
    return 'destructive';
  };

  const getConfidenceText = (confidence: number) => {
    if (confidence > 0.8) return 'High accuracy';
    if (confidence > 0.6) return 'Good match';
    if (confidence > 0.4) return 'Fair match';
    return 'Low accuracy';
  };

  return (
    <div className={`relative ${className}`}>
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          ref={inputRef}
          type="text"
          placeholder={placeholder}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={handleKeyDown}
          onFocus={() => results.length > 0 && setShowResults(true)}
          className="pl-10 pr-10"
        />
        {loading && (
          <Loader2 className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 animate-spin text-muted-foreground" />
        )}
      </div>

      {showResults && results.length > 0 && (
        <Card className="absolute top-full left-0 right-0 z-50 mt-1 max-h-80 overflow-y-auto shadow-lg">
          <CardContent className="p-0">
            {results.map((result, index) => (
              <div
                key={result.place_id || index}
                className="flex items-start gap-3 p-3 hover:bg-muted cursor-pointer border-b last:border-b-0 transition-colors"
                onClick={() => handleSelect(result)}
              >
                <MapPin className={`h-4 w-4 mt-0.5 flex-shrink-0 ${
                  result.confidence > 0.8 ? 'text-green-500' :
                  result.confidence > 0.6 ? 'text-yellow-500' :
                  'text-muted-foreground'
                }`} />
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm leading-tight">
                    {result.formatted_address}
                  </div>
                  <div className="flex items-center gap-2 mt-1 flex-wrap">
                    <span className="text-xs text-muted-foreground">
                      {result.geometry.location.lat.toFixed(4)}, {result.geometry.location.lng.toFixed(4)}
                    </span>
                    <Badge variant={getConfidenceColor(result.confidence)} className="text-xs">
                      {getConfidenceText(result.confidence)}
                    </Badge>
                    {result.partial_match && (
                      <Badge variant="outline" className="text-xs">
                        Partial
                      </Badge>
                    )}
                    {result.location_type === 'ROOFTOP' && (
                      <Badge variant="default" className="text-xs">
                        Exact
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {showResults && results.length === 0 && !loading && query.length >= 3 && (
        <Card className="absolute top-full left-0 right-0 z-50 mt-1">
          <CardContent className="p-3 text-center">
            {error ? (
              <div className="space-y-2">
                <div className="flex items-center justify-center gap-2 text-destructive">
                  <AlertCircle className="h-4 w-4" />
                  <span className="text-sm font-medium">Search Error</span>
                </div>
                <p className="text-xs text-muted-foreground">{error}</p>
                {!error.includes('API key') && (
                  <Button size="sm" variant="outline" onClick={handleRetry} className="mt-2">
                    <RefreshCw className="h-3 w-3 mr-1" />
                    Retry Search
                  </Button>
                )}
                {error.includes('API key') && (
                  <p className="text-xs text-muted-foreground mt-2">
                    💡 To fix this: Add your Google Maps API key in setup
                  </p>
                )}
              </div>
            ) : (
              <div className="text-sm text-muted-foreground">
                No addresses found for "{query}"
                <p className="text-xs mt-1">Try a more specific address or different spelling</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Click outside handler */}
      {showResults && (
        <div 
          className="fixed inset-0 z-40" 
          onClick={() => setShowResults(false)}
        />
      )}
    </div>
  );
}