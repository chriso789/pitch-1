import { useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/components/AuthProvider';
import { toast } from 'sonner';

/**
 * Component to handle authentication redirects
 * Redirects authenticated users to their intended destination
 */
export function AuthRedirect() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (loading) return;

    if (user) {
      // Get intended destination from location state
      const from = location.state?.from?.pathname || '/';
      
      toast.success('Successfully signed in!');
      navigate(from, { replace: true });
    }
  }, [user, loading, navigate, location]);

  return null;
}