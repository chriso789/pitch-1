import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { 
  Cloud, 
  CloudRain, 
  Zap, 
  Eye, 
  EyeOff, 
  RefreshCw,
  X,
  Calendar,
  MapPin
} from 'lucide-react';

interface StormData {
  id: string;
  name: string;
  date: string;
  type: 'hurricane' | 'tornado' | 'hail' | 'flood';
  intensity: number;
  active: boolean;
}

interface StormOverlayProps {
  map: google.maps.Map | null;
  onClose?: () => void;
}

export function StormOverlay({ map, onClose }: StormOverlayProps) {
  const [overlayEnabled, setOverlayEnabled] = useState(false);
  const [selectedStorm, setSelectedStorm] = useState<string>('');
  const [overlayOpacity, setOverlayOpacity] = useState(70);
  const [loading, setLoading] = useState(false);
  const [stormEvents, setStormEvents] = useState<StormData[]>([
    {
      id: 'hurricane-ian-2022',
      name: 'Hurricane Ian',
      date: '2022-09-28',
      type: 'hurricane',
      intensity: 4,
      active: true
    },
    {
      id: 'tornado-outbreak-2023',
      name: 'Tornado Outbreak',
      date: '2023-03-31',
      type: 'tornado', 
      intensity: 3,
      active: true
    },
    {
      id: 'hail-storm-2023',
      name: 'Severe Hail Storm',
      date: '2023-06-15',
      type: 'hail',
      intensity: 2,
      active: true
    }
  ]);
  const [currentOverlay, setCurrentOverlay] = useState<google.maps.ImageMapType | null>(null);

  // NOAA NGS Storm tile URL template
  const getStormTileUrl = (stormId: string, coord: google.maps.Point, zoom: number) => {
    // Mock NOAA NGS tile URL - replace with actual storm data service
    return `https://stormscdn.ngs.noaa.gov/${stormId}/${zoom}/${coord.x}/${coord.y}.png`;
  };

  const createStormOverlay = (stormId: string) => {
    if (!map) return null;

    const stormMapType = new google.maps.ImageMapType({
      getTileUrl: (coord: google.maps.Point, zoom: number) => {
        return getStormTileUrl(stormId, coord, zoom);
      },
      tileSize: new google.maps.Size(256, 256),
      name: 'Storm Data',
      opacity: overlayOpacity / 100,
      maxZoom: 19,
      minZoom: 5
    });

    return stormMapType;
  };

  const toggleOverlay = (enabled: boolean) => {
    if (!map) return;

    if (enabled && selectedStorm) {
      // Remove existing overlay
      if (currentOverlay) {
        map.overlayMapTypes.removeAt(0);
      }

      // Add new overlay
      const overlay = createStormOverlay(selectedStorm);
      if (overlay) {
        map.overlayMapTypes.push(overlay);
        setCurrentOverlay(overlay);
      }
    } else {
      // Remove overlay
      if (currentOverlay) {
        map.overlayMapTypes.removeAt(0);
        setCurrentOverlay(null);
      }
    }

    setOverlayEnabled(enabled);
  };

  const changeStorm = (stormId: string) => {
    setSelectedStorm(stormId);
    
    if (overlayEnabled && map) {
      // Update overlay with new storm data
      if (currentOverlay) {
        map.overlayMapTypes.removeAt(0);
      }

      const overlay = createStormOverlay(stormId);
      if (overlay) {
        map.overlayMapTypes.push(overlay);
        setCurrentOverlay(overlay);
      }
    }
  };

  const updateOpacity = (opacity: number) => {
    setOverlayOpacity(opacity);
    
    if (currentOverlay && map) {
      // Remove and re-add overlay with new opacity
      map.overlayMapTypes.removeAt(0);
      const overlay = createStormOverlay(selectedStorm);
      if (overlay) {
        map.overlayMapTypes.push(overlay);
        setCurrentOverlay(overlay);
      }
    }
  };

  const refreshStormData = async () => {
    setLoading(true);
    
    try {
      // Mock API call to refresh storm data
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // In production, fetch real storm data from NOAA API
      console.log('Storm data refreshed');
    } catch (error) {
      console.error('Failed to refresh storm data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStormIcon = (type: StormData['type']) => {
    switch (type) {
      case 'hurricane':
        return <CloudRain className="h-4 w-4" />;
      case 'tornado':
        return <Zap className="h-4 w-4" />;
      case 'hail':
        return <Cloud className="h-4 w-4" />;
      default:
        return <CloudRain className="h-4 w-4" />;
    }
  };

  const getIntensityColor = (type: StormData['type'], intensity: number) => {
    if (type === 'hurricane') {
      if (intensity >= 4) return 'text-red-600';
      if (intensity >= 3) return 'text-orange-600';
      if (intensity >= 2) return 'text-yellow-600';
      return 'text-blue-600';
    }
    
    if (intensity >= 3) return 'text-red-600';
    if (intensity >= 2) return 'text-orange-600';
    return 'text-yellow-600';
  };

  return (
    <Card className="w-80 max-h-[90vh] overflow-y-auto">
      <CardHeader className="flex flex-row items-center justify-between pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          <CloudRain className="h-5 w-5" />
          Storm Data
        </CardTitle>
        <Button variant="ghost" size="sm" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Overlay Toggle */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {overlayEnabled ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
            <Label htmlFor="overlay-toggle" className="text-sm">Show Storm Overlay</Label>
          </div>
          <Switch
            id="overlay-toggle"
            checked={overlayEnabled}
            onCheckedChange={toggleOverlay}
          />
        </div>

        <Separator />

        {/* Storm Selection */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Label className="text-sm font-medium">Select Storm Event</Label>
            <Button
              variant="outline"
              size="sm"
              onClick={refreshStormData}
              disabled={loading}
            >
              <RefreshCw className={`h-3 w-3 mr-1 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>

          <Select value={selectedStorm} onValueChange={changeStorm}>
            <SelectTrigger>
              <SelectValue placeholder="Select a storm event" />
            </SelectTrigger>
            <SelectContent>
              {stormEvents.map((storm) => (
                <SelectItem key={storm.id} value={storm.id}>
                  <div className="flex items-center gap-2">
                    {getStormIcon(storm.type)}
                    <span>{storm.name}</span>
                    <Badge variant="outline" className={getIntensityColor(storm.type, storm.intensity)}>
                      {storm.type === 'hurricane' ? `Cat ${storm.intensity}` : `Level ${storm.intensity}`}
                    </Badge>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {selectedStorm && (
            <div className="p-3 bg-muted rounded-lg">
              {(() => {
                const storm = stormEvents.find(s => s.id === selectedStorm);
                return storm ? (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium">{storm.name}</h4>
                      <Badge className={getIntensityColor(storm.type, storm.intensity)}>
                        {getStormIcon(storm.type)}
                        <span className="ml-1">
                          {storm.type === 'hurricane' ? `Category ${storm.intensity}` : `Level ${storm.intensity}`}
                        </span>
                      </Badge>
                    </div>
                    
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Calendar className="h-3 w-3" />
                      <span>{new Date(storm.date).toLocaleDateString('en-US', { 
                        year: 'numeric', 
                        month: 'long', 
                        day: 'numeric' 
                      })}</span>
                    </div>
                    
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <MapPin className="h-3 w-3" />
                      <span>Tampa Bay Area</span>
                    </div>
                  </div>
                ) : null;
              })()}
            </div>
          )}
        </div>

        {/* Opacity Control */}
        {overlayEnabled && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="text-sm">Overlay Opacity</Label>
              <span className="text-xs text-muted-foreground">{overlayOpacity}%</span>
            </div>
            
            <input
              type="range"
              min="10"
              max="100"
              step="10"
              value={overlayOpacity}
              onChange={(e) => updateOpacity(Number(e.target.value))}
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
            />
          </div>
        )}

        <Separator />

        {/* Legend */}
        <div className="space-y-2">
          <Label className="text-sm font-medium">Legend</Label>
          
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 bg-red-500 rounded"></div>
              <span>Severe</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 bg-orange-500 rounded"></div>
              <span>Moderate</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 bg-yellow-500 rounded"></div>
              <span>Light</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 bg-blue-500 rounded"></div>
              <span>Minimal</span>
            </div>
          </div>
        </div>

        {/* Data Source */}
        <div className="text-xs text-muted-foreground p-2 bg-muted rounded">
          <p>Storm data provided by NOAA National Weather Service</p>
          <p>Tile imagery: NOAA NGS Storm Database</p>
        </div>
      </CardContent>
    </Card>
  );
}