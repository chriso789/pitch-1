import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { supabase } from '@/integrations/supabase/client';
import { CheckCircle2, XCircle, Loader2, ExternalLink, Copy, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';

export function PitchIntegrationSetup() {
  const [loading, setLoading] = useState(false);
  const [checking, setChecking] = useState(false);
  const [endpoint, setEndpoint] = useState<any>(null);
  const [baseUrl, setBaseUrl] = useState('');
  const [apiKey, setApiKey] = useState('');
  const [webhookUrl, setWebhookUrl] = useState('');

  useEffect(() => {
    loadEndpoint();
    generateWebhookUrl();
  }, []);

  const loadEndpoint = async () => {
    const { data } = await supabase
      .from('integration_endpoints')
      .select('*')
      .eq('type', 'pitch_crm')
      .single();

    if (data) {
      setEndpoint(data);
      setBaseUrl(data.base_url);
    }
  };

  const generateWebhookUrl = () => {
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://bevovurzumbupezcarql.supabase.co';
    setWebhookUrl(`${supabaseUrl}/functions/v1/pitch-webhook`);
  };

  const saveEndpoint = async () => {
    setLoading(true);
    try {
      if (endpoint) {
        // Update existing
        const { error } = await supabase
          .from('integration_endpoints')
          .update({
            base_url: baseUrl,
            secret_key: apiKey || endpoint.secret_key,
            is_enabled: true,
          })
          .eq('id', endpoint.id);

        if (error) throw error;
      } else {
        // Create new
        const { error } = await supabase
          .from('integration_endpoints')
          .insert({
            name: 'PITCH CRM',
            type: 'pitch_crm',
            base_url: baseUrl,
            secret_key: apiKey,
            is_enabled: true,
          });

        if (error) throw error;
      }

      toast.success('PITCH CRM integration configured successfully');
      loadEndpoint();
    } catch (error) {
      console.error('Error saving endpoint:', error);
      toast.error('Failed to save configuration');
    } finally {
      setLoading(false);
    }
  };

  const testConnection = async () => {
    setChecking(true);
    try {
      // Try to call sync-to-pitch with test data
      const { data, error } = await supabase.functions.invoke('sync-to-pitch', {
        body: {
          test: true,
          property_id: null,
        }
      });

      if (error) throw error;

      toast.success('Connection test successful!');
    } catch (error) {
      console.error('Connection test failed:', error);
      toast.error('Connection test failed. Check your configuration.');
    } finally {
      setChecking(false);
    }
  };

  const copyWebhookUrl = () => {
    navigator.clipboard.writeText(webhookUrl);
    toast.success('Webhook URL copied to clipboard');
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            PITCH CRM Integration
            {endpoint?.is_enabled && <Badge variant="outline" className="bg-green-50">Active</Badge>}
          </CardTitle>
          <CardDescription>
            Configure your PITCH CRM integration to automatically sync qualified leads
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="baseUrl">PITCH CRM Base URL</Label>
            <Input
              id="baseUrl"
              value={baseUrl}
              onChange={(e) => setBaseUrl(e.target.value)}
              placeholder="https://api.pitchcrm.com"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="apiKey">API Key</Label>
            <Input
              id="apiKey"
              type="password"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder={endpoint ? '••••••••••••' : 'Enter your PITCH CRM API key'}
            />
          </div>

          <div className="flex gap-2">
            <Button onClick={saveEndpoint} disabled={loading || !baseUrl}>
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                'Save Configuration'
              )}
            </Button>
            <Button variant="outline" onClick={testConnection} disabled={checking || !endpoint}>
              {checking ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Testing...
                </>
              ) : (
                'Test Connection'
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Webhook Configuration</CardTitle>
          <CardDescription>
            Configure this webhook URL in PITCH CRM to receive "Project Completed" updates
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Webhook URL</Label>
            <div className="flex gap-2">
              <Input value={webhookUrl} readOnly />
              <Button variant="outline" size="icon" onClick={copyWebhookUrl}>
                <Copy className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Add this webhook URL to PITCH CRM under Settings → Webhooks. Configure it to send "project.completed" events.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Syncing Rules</CardTitle>
          <CardDescription>
            Which dispositions sync to PITCH CRM
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle2 className="h-4 w-4 text-green-600" />
              <span>Signed Contingency</span>
              <Badge variant="outline" className="ml-auto">⭐ Syncs</Badge>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle2 className="h-4 w-4 text-green-600" />
              <span>Signed Contract</span>
              <Badge variant="outline" className="ml-auto">⭐ Syncs</Badge>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle2 className="h-4 w-4 text-green-600" />
              <span>Go Back (with appointment)</span>
              <Badge variant="outline" className="ml-auto">⭐📅 Syncs</Badge>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <XCircle className="h-4 w-4 text-muted-foreground" />
              <span>All other dispositions</span>
              <Badge variant="outline" className="ml-auto text-muted-foreground">No sync</Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Data Synced to PITCH</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2 text-sm">
            <li className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-green-600" />
              First Name & Last Name (from skip trace or manual entry)
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-green-600" />
              Phone Number & Email
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-green-600" />
              Property Address
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-green-600" />
              Disposition Status
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-green-600" />
              Appointment Date & Time (if scheduled)
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-green-600" />
              Canvasser Notes
            </li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
