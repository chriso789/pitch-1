import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { RefreshCw, CheckCircle, XCircle, Clock, AlertTriangle } from 'lucide-react';
import { getEnrichmentService } from '@/lib/enrichment';
import type { Health } from '@/lib/enrichment/types';

export function HealthCheck() {
  const [healthData, setHealthData] = useState<Health[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [lastCheck, setLastCheck] = useState<Date | null>(null);

  const checkHealth = async () => {
    setIsLoading(true);
    try {
      const service = getEnrichmentService();
      const results = await service.getHealthStatus();
      setHealthData(results);
      setLastCheck(new Date());
    } catch (error) {
      console.error('Health check failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    checkHealth();
  }, []);

  const getStatusIcon = (health: Health) => {
    if (health.ok) {
      return <CheckCircle className="h-4 w-4 text-green-500" />;
    } else {
      return <XCircle className="h-4 w-4 text-red-500" />;
    }
  };

  const getStatusBadge = (health: Health) => {
    if (health.ok) {
      return <Badge variant="default" className="bg-green-100 text-green-800">Healthy</Badge>;
    } else {
      return <Badge variant="destructive">Error</Badge>;
    }
  };

  const getLatencyBadge = (latency?: number) => {
    if (!latency) return null;
    
    let variant: "default" | "secondary" | "destructive" = "default";
    let color = "text-green-600";
    
    if (latency > 1000) {
      variant = "destructive";
      color = "text-red-600";
    } else if (latency > 500) {
      variant = "secondary";
      color = "text-yellow-600";
    }
    
    return (
      <Badge variant={variant} className={`${color}`}>
        <Clock className="h-3 w-3 mr-1" />
        {latency}ms
      </Badge>
    );
  };

  const overallHealth = healthData.every(h => h.ok);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="flex items-center gap-2">
            {overallHealth ? (
              <CheckCircle className="h-5 w-5 text-green-500" />
            ) : (
              <AlertTriangle className="h-5 w-5 text-yellow-500" />
            )}
            Integration Health
          </CardTitle>
          {lastCheck && (
            <p className="text-sm text-muted-foreground">
              Last checked: {lastCheck.toLocaleTimeString()}
            </p>
          )}
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={checkHealth}
          disabled={isLoading}
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {healthData.map((health) => (
            <div
              key={health.name}
              className="flex items-center justify-between p-3 border rounded-lg"
            >
              <div className="flex items-center gap-3">
                {getStatusIcon(health)}
                <div>
                  <div className="font-medium capitalize">{health.name}</div>
                  {health.error && (
                    <div className="text-sm text-red-600">{health.error}</div>
                  )}
                  {health.quota && (
                    <div className="text-sm text-muted-foreground">
                      Quota: {health.quota}
                    </div>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2">
                {getLatencyBadge(health.latency_ms)}
                {getStatusBadge(health)}
              </div>
            </div>
          ))}
          
          {healthData.length === 0 && !isLoading && (
            <div className="text-center text-muted-foreground py-4">
              No health data available
            </div>
          )}
          
          {isLoading && (
            <div className="text-center text-muted-foreground py-4">
              <RefreshCw className="h-4 w-4 animate-spin mx-auto mb-2" />
              Checking health status...
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}