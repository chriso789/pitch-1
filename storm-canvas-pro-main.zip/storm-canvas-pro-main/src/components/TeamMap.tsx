import { MapPin, User } from "lucide-react";

const teamMembers = [
  { id: 1, name: 'Mike Johnson', status: 'active', leads: 12, location: 'North Austin' },
  { id: 2, name: 'Sarah Davis', status: 'active', leads: 8, location: 'South Austin' },
  { id: 3, name: 'Tom Wilson', status: 'break', leads: 15, location: 'West Austin' },
  { id: 4, name: 'Lisa Chen', status: 'active', leads: 6, location: 'East Austin' },
];

export default function TeamMap() {
  return (
    <div className="bg-card border rounded-lg p-6 shadow-soft">
      <h3 className="text-lg font-semibold text-foreground mb-4">Team Status</h3>
      
      {/* Simple map placeholder */}
      <div className="h-48 bg-gradient-secondary rounded-lg mb-4 flex items-center justify-center border-2 border-dashed border-border">
        <div className="text-center text-muted-foreground">
          <MapPin className="h-8 w-8 mx-auto mb-2" />
          <p className="text-sm">Interactive Map View</p>
          <p className="text-xs">Team locations and territories</p>
        </div>
      </div>

      {/* Team list */}
      <div className="space-y-3">
        {teamMembers.map((member) => (
          <div key={member.id} className="flex items-center justify-between p-3 bg-muted rounded-lg">
            <div className="flex items-center gap-3">
              <div className="h-8 w-8 rounded-full bg-gradient-primary flex items-center justify-center">
                <User className="h-4 w-4 text-primary-foreground" />
              </div>
              <div>
                <p className="text-sm font-medium text-foreground">{member.name}</p>
                <p className="text-xs text-muted-foreground">{member.location}</p>
              </div>
            </div>
            <div className="text-right">
              <div className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                member.status === 'active' 
                  ? 'bg-success/10 text-success' 
                  : 'bg-warning/10 text-warning'
              }`}>
                {member.status}
              </div>
              <p className="text-xs text-muted-foreground mt-1">{member.leads} leads</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}