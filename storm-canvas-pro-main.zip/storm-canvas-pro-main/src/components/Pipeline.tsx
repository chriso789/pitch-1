import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DollarSign } from "lucide-react";

const pipelineStages = [
  {
    name: 'New Leads',
    count: 24,
    color: 'bg-accent/10 text-accent',
    deals: [
      { id: 1, address: '123 Oak St', value: '$18,500', priority: 'high' },
      { id: 2, address: '456 Pine Ave', value: '$12,300', priority: 'medium' },
      { id: 3, address: '789 Elm Dr', value: '$22,800', priority: 'high' },
    ]
  },
  {
    name: 'Inspecting',
    count: 18,
    color: 'bg-primary/10 text-primary',
    deals: [
      { id: 4, address: '321 Maple Ct', value: '$15,600', priority: 'medium' },
      { id: 5, address: '654 Cedar Ln', value: '$28,900', priority: 'high' },
    ]
  },
  {
    name: 'Quoted',
    count: 12,
    color: 'bg-warning/10 text-warning',
    deals: [
      { id: 6, address: '987 Birch Way', value: '$19,200', priority: 'high' },
      { id: 7, address: '147 Spruce St', value: '$24,500', priority: 'medium' },
    ]
  },
  {
    name: 'Won',
    count: 8,
    color: 'bg-success/10 text-success',
    deals: [
      { id: 8, address: '258 Willow Dr', value: '$31,400', priority: 'high' },
    ]
  },
];

export default function Pipeline() {
  return (
    <div className="bg-card border rounded-lg p-6 shadow-soft">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-foreground">Sales Pipeline</h3>
        <Badge variant="secondary" className="flex items-center gap-1">
          <DollarSign className="h-3 w-3" />
          $642,700 Total Value
        </Badge>
      </div>
      
      <div className="grid grid-cols-4 gap-4">
        {pipelineStages.map((stage) => (
          <div key={stage.name} className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-medium text-sm text-foreground">{stage.name}</h4>
              <Badge className={stage.color}>{stage.count}</Badge>
            </div>
            
            <div className="space-y-2">
              {stage.deals.slice(0, 3).map((deal) => (
                <Card key={deal.id} className="p-3 cursor-pointer hover:shadow-soft transition-shadow">
                  <div className="space-y-1">
                    <p className="text-xs font-medium text-foreground">{deal.address}</p>
                    <p className="text-sm font-bold text-primary">{deal.value}</p>
                    <div className={`inline-flex px-2 py-1 rounded-full text-xs ${
                      deal.priority === 'high' 
                        ? 'bg-destructive/10 text-destructive' 
                        : 'bg-muted text-muted-foreground'
                    }`}>
                      {deal.priority} priority
                    </div>
                  </div>
                </Card>
              ))}
              
              {stage.deals.length > 3 && (
                <div className="text-xs text-center text-muted-foreground py-2">
                  +{stage.deals.length - 3} more
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}