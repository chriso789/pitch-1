import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { FileText, Download, Send, Loader2 } from 'lucide-react';
import { useProposals } from '@/hooks/useProposals';

interface ProposalGeneratorProps {
  propertyId: string;
  propertyAddress?: string;
  homeownerName?: string;
  designId?: string;
  onProposalGenerated?: (proposal: any) => void;
  className?: string;
}

export function ProposalGenerator({ 
  propertyId, 
  propertyAddress, 
  homeownerName, 
  designId,
  onProposalGenerated,
  className 
}: ProposalGeneratorProps) {
  const [proposalType, setProposalType] = useState<'hail' | 'wind' | 'retail'>('hail');
  const [customerName, setCustomerName] = useState(homeownerName || '');
  const [notes, setNotes] = useState('');
  
  const { generateProposal, generating } = useProposals();

  const handleGenerateProposal = async () => {
    try {
      const result = await generateProposal({
        propertyId,
        proposalType,
        customerName: customerName || undefined,
        designId,
        notes: notes || undefined
      });

      if (onProposalGenerated) {
        onProposalGenerated(result.proposal);
      }

      // Reset form
      setNotes('');
    } catch (error) {
      // Error is handled in the hook
    }
  };

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="h-5 w-5" />
          Generate Proposal
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {propertyAddress && (
          <div className="text-sm text-muted-foreground">
            <strong>Property:</strong> {propertyAddress}
          </div>
        )}

        <div className="space-y-2">
          <Label htmlFor="proposal-type">Proposal Type</Label>
          <Select value={proposalType} onValueChange={(value: any) => setProposalType(value)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="hail">Hail Damage</SelectItem>
              <SelectItem value="wind">Wind Damage</SelectItem>
              <SelectItem value="retail">Retail/Upgrade</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="customer-name">Customer Name</Label>
          <Input
            id="customer-name"
            value={customerName}
            onChange={(e) => setCustomerName(e.target.value)}
            placeholder="Enter customer name"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="notes">Additional Notes (Optional)</Label>
          <Textarea
            id="notes"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Add any specific details or requirements..."
            rows={3}
          />
        </div>

        <div className="pt-2">
          <Button 
            onClick={handleGenerateProposal}
            disabled={generating || !propertyId}
            className="w-full"
          >
            {generating ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Generating Proposal...
              </>
            ) : (
              <>
                <FileText className="h-4 w-4 mr-2" />
                Generate Proposal
              </>
            )}
          </Button>
        </div>

        <div className="text-xs text-muted-foreground">
          <p>This will create a detailed roofing estimate with:</p>
          <ul className="list-disc list-inside mt-1 space-y-1">
            <li>Property information and damage assessment</li>
            <li>Material and labor breakdown</li>
            <li>Total cost estimate with warranty details</li>
            <li>Professional PDF ready for customer review</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}