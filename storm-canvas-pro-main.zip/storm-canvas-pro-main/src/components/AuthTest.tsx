import { useEffect, useState } from 'react';
import { useAuth } from '@/components/AuthProvider';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CheckCircle, XCircle, Clock, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';

interface TestResult {
  name: string;
  status: 'pass' | 'fail' | 'pending';
  message: string;
}

export function AuthTest() {
  const { user, session, loading, signOut } = useAuth();
  const [testResults, setTestResults] = useState<TestResult[]>([]);
  const [isRunningTests, setIsRunningTests] = useState(false);

  useEffect(() => {
    if (!loading) {
      runAuthTests();
    }
  }, [user, session, loading]);

  const runAuthTests = () => {
    setIsRunningTests(true);
    const results: TestResult[] = [];

    // Test 1: User Authentication Status
    results.push({
      name: 'User Authentication',
      status: user ? 'pass' : 'fail',
      message: user ? 'User is authenticated' : 'User is not authenticated'
    });

    // Test 2: Session Persistence
    results.push({
      name: 'Session Persistence',
      status: session ? 'pass' : 'fail',
      message: session ? 'Session exists and is valid' : 'No valid session found'
    });

    // Test 3: User Metadata
    results.push({
      name: 'User Metadata',
      status: user?.email ? 'pass' : 'fail',
      message: user?.email ? `Email: ${user.email}` : 'No user email found'
    });

    // Test 4: User ID
    results.push({
      name: 'User ID',
      status: user?.id ? 'pass' : 'fail',
      message: user?.id ? `ID: ${user.id.substring(0, 8)}...` : 'No user ID found'
    });

    // Test 5: Session Token
    results.push({
      name: 'Session Token',
      status: session?.access_token ? 'pass' : 'fail',
      message: session?.access_token ? 'Access token present' : 'No access token found'
    });

    // Test 6: Email Confirmation
    results.push({
      name: 'Email Confirmation',
      status: user?.email_confirmed_at ? 'pass' : 'fail',
      message: user?.email_confirmed_at ? 'Email is confirmed' : 'Email not confirmed'
    });

    // Test 7: Roles/Claims
    const hasRoles = user?.app_metadata?.roles && user.app_metadata.roles.length > 0;
    results.push({
      name: 'Roles & Claims',
      status: hasRoles ? 'pass' : 'pending',
      message: hasRoles ? `Roles: ${user.app_metadata.roles.join(', ')}` : 'No roles assigned (normal for new users)'
    });

    setTestResults(results);
    setIsRunningTests(false);
  };

  const handleTestSignOut = async () => {
    try {
      await signOut();
      toast.success('Test sign out successful');
    } catch (error) {
      toast.error('Test sign out failed');
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pass':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'fail':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'pending':
        return <Clock className="h-4 w-4 text-yellow-500" />;
      default:
        return null;
    }
  };

  const passedTests = testResults.filter(t => t.status === 'pass').length;
  const totalTests = testResults.length;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            Authentication System Test
            <Button
              size="sm"
              variant="outline"
              onClick={runAuthTests}
              disabled={isRunningTests}
            >
              {isRunningTests ? (
                <RefreshCw className="h-4 w-4 animate-spin" />
              ) : (
                <RefreshCw className="h-4 w-4" />
              )}
              {isRunningTests ? 'Testing...' : 'Re-run Tests'}
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Test Results</span>
              <Badge variant={passedTests === totalTests ? "default" : "secondary"}>
                {passedTests}/{totalTests} Passed
              </Badge>
            </div>

            <div className="space-y-2">
              {testResults.map((result, index) => (
                <div key={index} className="flex items-center justify-between p-2 border rounded">
                  <div className="flex items-center gap-2">
                    {getStatusIcon(result.status)}
                    <span className="font-medium">{result.name}</span>
                  </div>
                  <span className="text-sm text-muted-foreground">{result.message}</span>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {user && (
        <Card>
          <CardHeader>
            <CardTitle>Authentication Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Alert>
                <AlertDescription>
                  Test authentication flows by signing out and signing back in.
                  Your session should persist across page refreshes.
                </AlertDescription>
              </Alert>
              <div className="flex gap-2">
                <Button onClick={handleTestSignOut} variant="outline">
                  Test Sign Out
                </Button>
                <Button onClick={() => window.location.reload()} variant="outline">
                  Test Page Refresh
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}