import { useCallback, useState, useRef } from 'react';
import { GoogleMap, LoadScript, Marker, MarkerClusterer } from '@react-google-maps/api';
import { useProperties } from '@/hooks/useProperties';
import { usePropertyFilters } from '@/hooks/usePropertyFilters';
import { useGoogleMapsKey } from '@/hooks/useGoogleMapsKey';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { LocationDetails } from './LocationDetails';
import { DrawingTools } from './DrawingTools';
import { PhotoCapture } from './PhotoCapture';
import { StormOverlay } from './StormOverlay';
import { EnhancedSearch, SearchResult } from './EnhancedSearch';
import { PropertyFilters } from './PropertyFilters';
import { useDesigns } from '@/hooks/useDesigns';
import { toast } from 'sonner';
import { 
  Ruler, 
  Camera, 
  Search, 
  Cloud,
  Layers,
  X
} from 'lucide-react';

const mapContainerStyle = {
  width: '100%',
  height: '500px'
};

const defaultCenter = {
  lat: 27.9506,
  lng: -82.4572
};

const mapOptions = {
  disableDefaultUI: false,
  zoomControl: true,
  streetViewControl: false,
  mapTypeControl: true,
  fullscreenControl: false,
  libraries: ['drawing', 'geometry'],
  tilt: 0,
  heading: 0,
};

interface PropertyPin {
  id: string;
  addressHash: string;
  lat: number;
  lng: number;
  status?: string;
  flags?: Record<string, any>;
}

interface GoogleMapComponentProps {
  onLocationSelect?: (pin: PropertyPin) => void;
  center?: { lat: number; lng: number };
}

export default function GoogleMapComponent({ onLocationSelect, center }: GoogleMapComponentProps) {
  const [map, setMap] = useState<google.maps.Map | null>(null);
  const [bounds, setBounds] = useState<google.maps.LatLngBounds | null>(null);
  const [zoom, setZoom] = useState(12);
  const [selectedPropertyHash, setSelectedPropertyHash] = useState<string | null>(null);
  const [activePropertyId, setActivePropertyId] = useState<string | null>(null);
  const [showDrawingTools, setShowDrawingTools] = useState(false);
  const [showPhotoCapture, setShowPhotoCapture] = useState(false);
  const [showStormOverlay, setShowStormOverlay] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const mapRef = useRef<google.maps.Map | null>(null);
  
  const { apiKey: googleMapsApiKey, loading: keyLoading } = useGoogleMapsKey();
  const { createDesign } = useDesigns();
  const { filters, updateFilters, clearFilters } = usePropertyFilters();
  
  // Get properties with filters applied
  const { data: properties = [] } = useProperties(filters);

  const onLoad = useCallback((map: google.maps.Map) => {
    setMap(map);
    mapRef.current = map;
  }, []);

  const onUnmount = useCallback(() => {
    setMap(null);
    mapRef.current = null;
  }, []);

  const onBoundsChanged = useCallback(() => {
    if (mapRef.current) {
      const newBounds = mapRef.current.getBounds();
      const newZoom = mapRef.current.getZoom();
      setBounds(newBounds);
      setZoom(newZoom || 12);
    }
  }, []);

  // Convert properties to pins format
  const propertyPins: PropertyPin[] = properties.map(property => ({
    id: property.id,
    addressHash: property.address || '', // TODO: Use actual address_hash field
    lat: Number(property.latitude),
    lng: Number(property.longitude),
    status: property.disposition_id ? 'visited' : 'unvisited',
    flags: {
      homeownerConfirmed: !!property.homeowner_name,
      enriched: !!property.enriched_at,
    }
  }));

  const handleMarkerClick = (pin: PropertyPin) => {
    setSelectedPropertyHash(pin.addressHash);
    setActivePropertyId(pin.id);
    onLocationSelect?.(pin);
  };

  const handleSaveDesign = (design: any) => {
    createDesign(design);
    setShowDrawingTools(false);
  };

  const handlePhotoUploaded = (photo: any) => {
    console.log('Photo uploaded successfully:', photo);
  };

  const handleSearch = (query: string, filters: any) => {
    console.log('Search:', query, filters);
    // TODO: Implement search functionality
  };

  const handleLocationSelect = (searchResult: SearchResult) => {
    const newCenter = {
      lat: searchResult.geometry.location.lat,
      lng: searchResult.geometry.location.lng
    };
    
    // Center the map on the selected location
    if (map) {
      map.panTo(newCenter);
      map.setZoom(18); // Zoom in for detailed view
    }
    
    // Show success toast with confidence info
    const confidenceText = searchResult.confidence > 0.8 ? 'High accuracy' :
                          searchResult.confidence > 0.6 ? 'Good match' :
                          searchResult.confidence > 0.4 ? 'Fair match' : 'Low accuracy';
    
    toast.success(`Located: ${searchResult.formatted_address}`, {
      description: `${confidenceText} • ${searchResult.geometry.location.lat.toFixed(4)}, ${searchResult.geometry.location.lng.toFixed(4)}`
    });
    
    setShowSearch(false);
  };

  const handleDuplicateFound = (existing: SearchResult, duplicate: SearchResult) => {
    toast.warning('Duplicate address detected', {
      description: `"${duplicate.formatted_address}" has already been selected`
    });
  };

  // Custom marker icon based on status
  const getMarkerIcon = (pin: PropertyPin) => {
    const color = pin.status === 'visited' ? '#10b981' : '#ef4444';
    return {
      path: google.maps.SymbolPath.CIRCLE,
      fillColor: color,
      fillOpacity: 0.8,
      strokeColor: '#ffffff',
      strokeWeight: 2,
      scale: 8,
    };
  };

  if (keyLoading) {
    return (
      <Card className="p-6 text-center">
        <p className="text-muted-foreground">Loading Google Maps...</p>
      </Card>
    );
  }
  
  if (!googleMapsApiKey) {
    return (
      <Card className="p-6 text-center">
        <p className="text-muted-foreground">
          Google Maps API key not configured. 
          <br />
          Please configure it in the Setup Wizard.
        </p>
      </Card>
    );
  }

  return (
    <div className="w-full relative">
      {/* Map Toolbar */}
      <div className="absolute top-4 left-4 z-20 flex gap-2">
        <Button
          variant={showSearch ? "default" : "outline"}
          size="sm"
          onClick={() => setShowSearch(!showSearch)}
        >
          <Search className="h-4 w-4 mr-1" />
          Search
        </Button>
        
        <Button
          variant={showFilters ? "default" : "outline"}
          size="sm"
          onClick={() => setShowFilters(!showFilters)}
        >
          <Layers className="h-4 w-4 mr-1" />
          Filters
        </Button>
        
        <Button
          variant={showDrawingTools ? "default" : "outline"}
          size="sm"
          onClick={() => setShowDrawingTools(!showDrawingTools)}
        >
          <Ruler className="h-4 w-4 mr-1" />
          Measure
        </Button>
        
        <Button
          variant={showPhotoCapture ? "default" : "outline"}
          size="sm"
          onClick={() => setShowPhotoCapture(!showPhotoCapture)}
        >
          <Camera className="h-4 w-4 mr-1" />
          Photos
        </Button>
        
        <Button
          variant={showStormOverlay ? "default" : "outline"}
          size="sm"
          onClick={() => setShowStormOverlay(!showStormOverlay)}
        >
          <Cloud className="h-4 w-4 mr-1" />
          Storms
        </Button>
      </div>

      <LoadScript
        googleMapsApiKey={googleMapsApiKey}
        libraries={['drawing', 'geometry']}
      >
        <GoogleMap
          mapContainerStyle={mapContainerStyle}
          center={center || defaultCenter}
          zoom={zoom}
          options={mapOptions}
          onLoad={onLoad}
          onUnmount={onUnmount}
          onBoundsChanged={onBoundsChanged}
        >
          {zoom >= 15 ? (
            // Show individual markers at high zoom
            propertyPins.map((pin) => (
              <Marker
                key={pin.id}
                position={{ lat: pin.lat, lng: pin.lng }}
                icon={getMarkerIcon(pin)}
                onClick={() => handleMarkerClick(pin)}
                title={`Property ${pin.addressHash}`}
              />
            ))
          ) : (
            // Use clustering at low zoom for performance
            <MarkerClusterer>
              {(clusterer) => (
                <>
                  {propertyPins.map((pin) => (
                    <Marker
                      key={pin.id}
                      position={{ lat: pin.lat, lng: pin.lng }}
                      clusterer={clusterer}
                      icon={getMarkerIcon(pin)}
                      onClick={() => handleMarkerClick(pin)}
                      title={`Property ${pin.addressHash}`}
                    />
                  ))}
                </>
              )}
            </MarkerClusterer>
          )}
        </GoogleMap>
      </LoadScript>
      
      {/* Tool Panels */}
      {showSearch && (
        <div className="absolute top-16 left-4 z-10">
          <EnhancedSearch
            onSelect={handleLocationSelect}
            onDuplicateFound={handleDuplicateFound}
            placeholder="Search for addresses..."
            className="w-80"
          />
        </div>
      )}
      
      {showFilters && (
        <div className="absolute top-16 right-4 z-10">
          <PropertyFilters
            filters={filters}
            onFiltersChange={updateFilters}
            totalResults={properties.length}
            filteredResults={properties.length}
            onClear={clearFilters}
            className="w-80"
          />
        </div>
      )}
      
      {showDrawingTools && (
        <div className="absolute top-4 left-96 z-10">
          <DrawingTools
            map={map}
            propertyId={activePropertyId}
            onSaveDesign={handleSaveDesign}
            onClose={() => setShowDrawingTools(false)}
          />
        </div>
      )}
      
      {showPhotoCapture && (
        <div className="absolute top-4 left-[800px] z-10">
          <PhotoCapture
            propertyId={activePropertyId}
            onPhotoUploaded={handlePhotoUploaded}
            onClose={() => setShowPhotoCapture(false)}
          />
        </div>
      )}
      
      {showStormOverlay && (
        <div className="absolute top-4 right-96 z-10">
          <StormOverlay
            map={map}
            onClose={() => setShowStormOverlay(false)}
          />
        </div>
      )}
      
      {/* Location Details Panel */}
      {selectedPropertyHash && (
        <div className="absolute top-4 right-4 z-10">
          <LocationDetails 
            addressHash={selectedPropertyHash} 
            onClose={() => {
              setSelectedPropertyHash(null);
              setActivePropertyId(null);
            }}
          />
        </div>
      )}
    </div>
  );
}