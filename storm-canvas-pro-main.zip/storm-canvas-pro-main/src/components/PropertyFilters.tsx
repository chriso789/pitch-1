import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { useDispositions } from '@/hooks/useDispositions';
import { CalendarIcon, X, Filter, RotateCcw } from 'lucide-react';
import { format } from 'date-fns';

export interface PropertyFilters {
  dispositions: string[];
  dateRange: {
    from?: Date;
    to?: Date;
  };
  creditScoreRange: {
    min?: number;
    max?: number;
  };
  propertyValueRange: {
    min?: number;
    max?: number;
  };
  yearBuiltRange: {
    min?: number;
    max?: number;
  };
  hasHomeowner: boolean | null;
  isEnriched: boolean | null;
  hasVisits: boolean | null;
}

interface PropertyFiltersProps {
  filters: PropertyFilters;
  onFiltersChange: (filters: PropertyFilters) => void;
  totalResults: number;
  filteredResults: number;
  onClear: () => void;
  className?: string;
}

export function PropertyFilters({
  filters,
  onFiltersChange,
  totalResults,
  filteredResults,
  onClear,
  className
}: PropertyFiltersProps) {
  const { data: dispositions = [] } = useDispositions();
  const [isOpen, setIsOpen] = useState(false);

  const updateFilters = (updates: Partial<PropertyFilters>) => {
    onFiltersChange({ ...filters, ...updates });
  };

  const getActiveFilterCount = () => {
    let count = 0;
    if (filters.dispositions.length > 0) count++;
    if (filters.dateRange.from || filters.dateRange.to) count++;
    if (filters.creditScoreRange.min || filters.creditScoreRange.max) count++;
    if (filters.propertyValueRange.min || filters.propertyValueRange.max) count++;
    if (filters.yearBuiltRange.min || filters.yearBuiltRange.max) count++;
    if (filters.hasHomeowner !== null) count++;
    if (filters.isEnriched !== null) count++;
    if (filters.hasVisits !== null) count++;
    return count;
  };

  const activeFilterCount = getActiveFilterCount();

  return (
    <div className={className}>
      <div className="flex items-center gap-2 mb-4">
        <Popover open={isOpen} onOpenChange={setIsOpen}>
          <PopoverTrigger asChild>
            <Button variant="outline" size="sm" className="relative">
              <Filter className="h-4 w-4 mr-2" />
              Filters
              {activeFilterCount > 0 && (
                <Badge variant="secondary" className="ml-2 h-5 w-5 p-0 text-xs">
                  {activeFilterCount}
                </Badge>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-96 p-0" align="start">
            <Card className="border-0 shadow-none">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base">Filter Properties</CardTitle>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={onClear}
                    disabled={activeFilterCount === 0}
                  >
                    <RotateCcw className="h-4 w-4 mr-1" />
                    Clear
                  </Button>
                </div>
                <div className="text-sm text-muted-foreground">
                  {filteredResults} of {totalResults} properties
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Disposition Filter */}
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Disposition</Label>
                  <div className="grid grid-cols-1 gap-2 max-h-32 overflow-y-auto">
                    {dispositions.map((disposition: any) => (
                      <div key={disposition.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={`disposition-${disposition.id}`}
                          checked={filters.dispositions.includes(disposition.id)}
                          onCheckedChange={(checked) => {
                            const newDispositions = checked
                              ? [...filters.dispositions, disposition.id]
                              : filters.dispositions.filter(id => id !== disposition.id);
                            updateFilters({ dispositions: newDispositions });
                          }}
                        />
                        <Label
                          htmlFor={`disposition-${disposition.id}`}
                          className="text-sm cursor-pointer flex items-center gap-2"
                        >
                          <div
                            className="w-3 h-3 rounded-full"
                            style={{ backgroundColor: disposition.color }}
                          />
                          {disposition.name}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Date Range Filter */}
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Date Created</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          size="sm"
                          className={cn(
                            "justify-start text-left font-normal",
                            !filters.dateRange.from && "text-muted-foreground"
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {filters.dateRange.from ? (
                            format(filters.dateRange.from, "MMM dd")
                          ) : (
                            "From"
                          )}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={filters.dateRange.from}
                          onSelect={(date) => updateFilters({
                            dateRange: { ...filters.dateRange, from: date }
                          })}
                          initialFocus
                          className="pointer-events-auto"
                        />
                      </PopoverContent>
                    </Popover>

                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          size="sm"
                          className={cn(
                            "justify-start text-left font-normal",
                            !filters.dateRange.to && "text-muted-foreground"
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {filters.dateRange.to ? (
                            format(filters.dateRange.to, "MMM dd")
                          ) : (
                            "To"
                          )}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={filters.dateRange.to}
                          onSelect={(date) => updateFilters({
                            dateRange: { ...filters.dateRange, to: date }
                          })}
                          initialFocus
                          className="pointer-events-auto"
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>

                {/* Credit Score Range */}
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Credit Score</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <Select
                      value={filters.creditScoreRange.min?.toString() || ""}
                      onValueChange={(value) => updateFilters({
                        creditScoreRange: {
                          ...filters.creditScoreRange,
                          min: value ? parseInt(value) : undefined
                        }
                      })}
                    >
                      <SelectTrigger className="text-sm">
                        <SelectValue placeholder="Min" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="300">300+</SelectItem>
                        <SelectItem value="500">500+</SelectItem>
                        <SelectItem value="600">600+</SelectItem>
                        <SelectItem value="700">700+</SelectItem>
                        <SelectItem value="800">800+</SelectItem>
                      </SelectContent>
                    </Select>

                    <Select
                      value={filters.creditScoreRange.max?.toString() || ""}
                      onValueChange={(value) => updateFilters({
                        creditScoreRange: {
                          ...filters.creditScoreRange,
                          max: value ? parseInt(value) : undefined
                        }
                      })}
                    >
                      <SelectTrigger className="text-sm">
                        <SelectValue placeholder="Max" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="500">500</SelectItem>
                        <SelectItem value="600">600</SelectItem>
                        <SelectItem value="700">700</SelectItem>
                        <SelectItem value="800">800</SelectItem>
                        <SelectItem value="850">850</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Property Value Range */}
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Property Value</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <Select
                      value={filters.propertyValueRange.min?.toString() || ""}
                      onValueChange={(value) => updateFilters({
                        propertyValueRange: {
                          ...filters.propertyValueRange,
                          min: value ? parseInt(value) : undefined
                        }
                      })}
                    >
                      <SelectTrigger className="text-sm">
                        <SelectValue placeholder="Min" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="50000">$50K+</SelectItem>
                        <SelectItem value="100000">$100K+</SelectItem>
                        <SelectItem value="200000">$200K+</SelectItem>
                        <SelectItem value="300000">$300K+</SelectItem>
                        <SelectItem value="500000">$500K+</SelectItem>
                      </SelectContent>
                    </Select>

                    <Select
                      value={filters.propertyValueRange.max?.toString() || ""}
                      onValueChange={(value) => updateFilters({
                        propertyValueRange: {
                          ...filters.propertyValueRange,
                          max: value ? parseInt(value) : undefined
                        }
                      })}
                    >
                      <SelectTrigger className="text-sm">
                        <SelectValue placeholder="Max" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="200000">$200K</SelectItem>
                        <SelectItem value="300000">$300K</SelectItem>
                        <SelectItem value="500000">$500K</SelectItem>
                        <SelectItem value="1000000">$1M</SelectItem>
                        <SelectItem value="2000000">$2M+</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Boolean Filters */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-medium">Has Homeowner Info</Label>
                    <Select
                      value={filters.hasHomeowner === null ? "" : filters.hasHomeowner.toString()}
                      onValueChange={(value) => updateFilters({
                        hasHomeowner: value === "" ? null : value === "true"
                      })}
                    >
                      <SelectTrigger className="w-20 text-sm">
                        <SelectValue placeholder="All" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">All</SelectItem>
                        <SelectItem value="true">Yes</SelectItem>
                        <SelectItem value="false">No</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-medium">Is Enriched</Label>
                    <Select
                      value={filters.isEnriched === null ? "" : filters.isEnriched.toString()}
                      onValueChange={(value) => updateFilters({
                        isEnriched: value === "" ? null : value === "true"
                      })}
                    >
                      <SelectTrigger className="w-20 text-sm">
                        <SelectValue placeholder="All" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">All</SelectItem>
                        <SelectItem value="true">Yes</SelectItem>
                        <SelectItem value="false">No</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-medium">Has Visits</Label>
                    <Select
                      value={filters.hasVisits === null ? "" : filters.hasVisits.toString()}
                      onValueChange={(value) => updateFilters({
                        hasVisits: value === "" ? null : value === "true"
                      })}
                    >
                      <SelectTrigger className="w-20 text-sm">
                        <SelectValue placeholder="All" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">All</SelectItem>
                        <SelectItem value="true">Yes</SelectItem>
                        <SelectItem value="false">No</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>
          </PopoverContent>
        </Popover>
        
        {/* Active Filter Tags */}
        {activeFilterCount > 0 && (
          <div className="flex flex-wrap gap-1">
            {filters.dispositions.length > 0 && (
              <Badge variant="secondary" className="text-xs">
                {filters.dispositions.length} disposition{filters.dispositions.length > 1 ? 's' : ''}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => updateFilters({ dispositions: [] })}
                  className="ml-1 h-3 w-3 p-0 hover:bg-transparent"
                >
                  <X className="h-2 w-2" />
                </Button>
              </Badge>
            )}
            {(filters.dateRange.from || filters.dateRange.to) && (
              <Badge variant="secondary" className="text-xs">
                Date range
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => updateFilters({ dateRange: { from: undefined, to: undefined } })}
                  className="ml-1 h-3 w-3 p-0 hover:bg-transparent"
                >
                  <X className="h-2 w-2" />
                </Button>
              </Badge>
            )}
          </div>
        )}
      </div>
    </div>
  );
}