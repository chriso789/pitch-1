import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { RealtimeIndicator } from '@/components/RealtimeIndicator';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { 
  Home, 
  Map, 
  Camera,
  Database,
  FileText, 
  Users, 
  Settings, 
  User, 
  LogOut,
  Shield,
  AlertTriangle,
  ToggleLeft,
  ToggleRight,
  Zap
} from 'lucide-react';
import { configManager } from '@/lib/config';
import { useState, useEffect } from 'react';
import { useAuth } from '@/components/AuthProvider';

export function Navigation() {
  const { user, signOut, isAdmin } = useAuth();
  const location = useLocation();
  const [setupComplete, setSetupComplete] = useState(false);
  const [mockMode, setMockMode] = useState(false);
  const [demoData, setDemoData] = useState(false);

  useEffect(() => {
    // Check setup status
    setSetupComplete(configManager.isValid);
    
    // Check feature flags from localStorage
    setMockMode(localStorage.getItem('feature_mock_skiptrace') === 'true');
    setDemoData(localStorage.getItem('feature_demo_data') === 'true');
  }, []);

  const navItems = [
    { path: '/', label: 'Dashboard', icon: Home },
    { path: '/canvassing', label: 'Canvassing', icon: Map },
    { path: '/skip-trace', label: 'Skip Trace', icon: Zap },
    { path: '/photos', label: 'Photos', icon: Camera },
    { path: '/properties', label: 'Properties', icon: Database },
    { path: '/proposals', label: 'Proposals', icon: FileText },
    { path: '/team', label: 'Team', icon: Users },
  ];

  // Add admin-only items
  if (isAdmin) {
    navItems.push({ path: '/admin', label: 'Admin', icon: Shield });
  }

  const toggleFeatureFlag = (flag: string, currentValue: boolean) => {
    const newValue = !currentValue;
    localStorage.setItem(`feature_${flag}`, newValue.toString());
    
    if (flag === 'mock_skiptrace') {
      setMockMode(newValue);
    } else if (flag === 'demo_data') {
      setDemoData(newValue);
    }
  };

  const getUserInitials = () => {
    if (user?.user_metadata?.full_name) {
      return user.user_metadata.full_name
        .split(' ')
        .map(n => n[0])
        .join('')
        .toUpperCase()
        .slice(0, 2);
    }
    if (user?.email) {
      return user.email[0].toUpperCase();
    }
    return 'U';
  };
  
  return (
    <nav className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <div className="flex items-center space-x-4">
            <Link to="/" className="flex items-center space-x-2">
              <div className="h-8 w-8 rounded-md bg-primary flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-sm">CQ</span>
              </div>
              <span className="font-bold text-lg">Canvass-IQ</span>
            </Link>

            {/* Setup Status Badge */}
            {!setupComplete && (
              <Badge variant="destructive" className="flex items-center gap-1">
                <AlertTriangle className="h-3 w-3" />
                Setup Required
              </Badge>
            )}
          </div>

          {/* Navigation Items */}
          <div className="hidden md:flex items-center space-x-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
              
              return (
                <Button
                  key={item.path}
                  asChild
                  variant={isActive ? "default" : "ghost"}
                  size="sm"
                  className="flex items-center gap-2"
                >
                  <Link to={item.path}>
                    <Icon className="h-4 w-4" />
                    {item.label}
                  </Link>
                </Button>
              );
            })}
          </div>
          {/* Right side - Real-time Indicator, Feature Flags & User Menu */}
          <div className="flex items-center space-x-2">
            {/* Real-time Status Indicator */}
            <RealtimeIndicator />
            
            {/* Feature Flags Dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm">
                  <Settings className="h-4 w-4" />
                  <span className="hidden sm:inline ml-2">Flags</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <div className="px-2 py-1.5 text-sm font-semibold">Feature Flags</div>
                <DropdownMenuSeparator />
                
                <DropdownMenuItem 
                  onClick={() => toggleFeatureFlag('mock_skiptrace', mockMode)}
                  className="flex items-center justify-between"
                >
                  <span>Mock Skiptrace</span>
                  {mockMode ? (
                    <ToggleRight className="h-4 w-4 text-green-600" />
                  ) : (
                    <ToggleLeft className="h-4 w-4 text-muted-foreground" />
                  )}
                </DropdownMenuItem>
                
                <DropdownMenuItem 
                  onClick={() => toggleFeatureFlag('demo_data', demoData)}
                  className="flex items-center justify-between"
                >
                  <span>Demo Data</span>
                  {demoData ? (
                    <ToggleRight className="h-4 w-4 text-green-600" />
                  ) : (
                    <ToggleLeft className="h-4 w-4 text-muted-foreground" />
                  )}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            {/* User Menu */}
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="relative">
                    <Avatar className="h-6 w-6">
                      <AvatarFallback className="text-xs">
                        {getUserInitials()}
                      </AvatarFallback>
                    </Avatar>
                    <span className="hidden sm:inline ml-2">
                      {user.user_metadata?.full_name || user.email}
                    </span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <div className="px-2 py-1.5 text-sm">
                    <div className="font-medium">{user.user_metadata?.full_name || 'User'}</div>
                    <div className="text-xs text-muted-foreground">{user.email}</div>
                  </div>
                  <DropdownMenuSeparator />
                  
                  <DropdownMenuItem asChild>
                    <Link to="/auth/test" className="flex items-center">
                      <User className="h-4 w-4 mr-2" />
                      Profile & Test
                    </Link>
                  </DropdownMenuItem>
                  
                  {!setupComplete && (
                    <DropdownMenuItem asChild>
                      <Link to="/setup" className="flex items-center text-orange-600">
                        <Settings className="h-4 w-4 mr-2" />
                        Complete Setup
                      </Link>
                    </DropdownMenuItem>
                  )}
                  
                  <DropdownMenuSeparator />
                  
                  <DropdownMenuItem 
                    onClick={() => signOut()}
                    className="flex items-center text-red-600"
                  >
                    <LogOut className="h-4 w-4 mr-2" />
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <div className="flex items-center space-x-2">
                <Button asChild variant="ghost" size="sm">
                  <Link to="/auth">Sign In</Link>
                </Button>
                <Button asChild size="sm">
                  <Link to="/auth?mode=signup">Sign Up</Link>
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}

export default Navigation;