import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, CalendarIcon, Phone, Mail, User, Check } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { StatusQuickActions } from '@/components/Canvassing/StatusQuickActions';

interface Disposition {
  id: string;
  name: string;
  color: string;
  description: string;
  sync_to_pitch?: boolean;
  requires_appointment?: boolean;
}

interface HomeownerContactModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  propertyId: string;
  propertyAddress: string;
  propertyLat: number;
  propertyLng: number;
  onContactConfirmed: (contactId: string, dispositionId: string, appointmentDate?: Date) => void;
  locationDetails?: {
    owner?: {
      name?: string;
      type?: string;
      mailing_address?: string;
    };
    cached?: boolean;
    cacheAgedays?: number;
  } | null;
}

export function HomeownerContactModal({
  open,
  onOpenChange,
  propertyId,
  propertyAddress,
  propertyLat,
  propertyLng,
  onContactConfirmed,
  locationDetails,
}: HomeownerContactModalProps) {
  const [step, setStep] = useState<'contact' | 'disposition' | 'appointment'>('contact');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [dispositions, setDispositions] = useState<Disposition[]>([]);
  const [selectedDisposition, setSelectedDisposition] = useState<string>('');
  const [appointmentDate, setAppointmentDate] = useState<Date>();
  const [appointmentTime, setAppointmentTime] = useState('09:00');
  const [saving, setSaving] = useState(false);

  // Load dispositions
  useEffect(() => {
    if (open) {
      loadDispositions();
    }
  }, [open]);

  // Populate contact fields from location details (already fetched by locations-details)
  useEffect(() => {
    if (open && locationDetails?.owner?.name) {
      const nameParts = locationDetails.owner.name.split(' ');
      setFirstName(nameParts[0] || '');
      setLastName(nameParts.slice(1).join(' ') || '');
    }
  }, [open, locationDetails]);

  const loadDispositions = async () => {
    const { data } = await supabase
      .from('dispositions')
      .select('*')
      .order('name');
    if (data) {
      setDispositions(data);
    }
  };

  const handleContactConfirm = () => {
    if (!firstName || !lastName) {
      toast.error('First and last name are required');
      return;
    }
    setStep('disposition');
  };

  const handleDispositionSelect = (dispositionId: string) => {
    setSelectedDisposition(dispositionId);
    const disposition = dispositions.find(d => d.id === dispositionId);
    
    if (disposition?.requires_appointment) {
      setStep('appointment');
    } else {
      handleSave(dispositionId);
    }
  };

  const handleSave = async (dispositionId?: string) => {
    const dispId = dispositionId || selectedDisposition;
    if (!dispId) return;

    setSaving(true);
    try {
      // Get user
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      // Save contact
      const { data: contact, error: contactError } = await supabase
        .from('contacts')
        .insert({
          property_id: propertyId,
          first_name: firstName,
          last_name: lastName,
          name: `${firstName} ${lastName}`,
          phone: phone || null,
          email: email || null,
          provider: 'searchbug',
          confidence: 75,
        })
        .select()
        .single();

      if (contactError) throw contactError;

      // Combine date and time for appointment
      let finalAppointmentDate: Date | undefined;
      if (appointmentDate && appointmentTime) {
        const [hours, minutes] = appointmentTime.split(':').map(Number);
        finalAppointmentDate = new Date(appointmentDate);
        finalAppointmentDate.setHours(hours, minutes, 0, 0);
      }

      // Create visit with disposition
      const { error: visitError } = await supabase
        .from('visits')
        .insert({
          property_id: propertyId,
          user_id: user.id,
          disposition_id: dispId,
          appointment_date: finalAppointmentDate?.toISOString() || null,
          notes: `Contact: ${firstName} ${lastName}, Phone: ${phone || 'N/A'}, Email: ${email || 'N/A'}`,
        });

      if (visitError) throw visitError;

      // Check if disposition should sync to PITCH CRM
      const disposition = dispositions.find(d => d.id === dispId);
      if (disposition?.sync_to_pitch) {
        try {
          const { error: syncError } = await supabase.functions.invoke('sync-to-pitch', {
            body: {
              property_id: propertyId,
              disposition_id: dispId,
              contact_email: email,
              contact_phone: phone,
              user_id: user.id,
            }
          });

          if (syncError) {
            console.error('PITCH CRM sync error:', syncError);
            toast.warning('Saved locally, but PITCH CRM sync failed');
          } else {
            toast.success('Saved and synced to PITCH CRM ⭐');
          }
        } catch (syncError) {
          console.error('PITCH CRM sync error:', syncError);
          toast.warning('Saved locally, but PITCH CRM sync failed');
        }
      } else {
        toast.success('Contact and disposition saved');
      }

      onContactConfirmed(contact.id, dispId, finalAppointmentDate);
      handleClose();
    } catch (error) {
      console.error('Save error:', error);
      toast.error('Failed to save contact');
    } finally {
      setSaving(false);
    }
  };

  const handleClose = () => {
    setStep('contact');
    setFirstName('');
    setLastName('');
    setPhone('');
    setEmail('');
    setSelectedDisposition('');
    setAppointmentDate(undefined);
    setAppointmentTime('09:00');
    onOpenChange(false);
  };

  const timeOptions = Array.from({ length: 13 }, (_, i) => {
    const hour = i + 8; // 8 AM to 8 PM
    return [`${hour.toString().padStart(2, '0')}:00`, `${hour.toString().padStart(2, '0')}:15`, `${hour.toString().padStart(2, '0')}:30`, `${hour.toString().padStart(2, '0')}:45`];
  }).flat();

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>
            {step === 'contact' && 'Confirm Homeowner Details'}
            {step === 'disposition' && 'Select Disposition'}
            {step === 'appointment' && 'Schedule Appointment'}
          </DialogTitle>
          <DialogDescription className="text-sm text-muted-foreground">
            {propertyAddress}
          </DialogDescription>
        </DialogHeader>

        {/* Contact Confirmation */}
        {step === 'contact' && (
          <div className="space-y-4">
            {locationDetails?.cached && (
              <div className="flex items-center gap-2 p-3 bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-md">
                <div className="flex-1 text-sm">
                  <span className="font-medium text-blue-900 dark:text-blue-100">
                    Using cached data
                  </span>
                  {locationDetails.cacheAgedays !== undefined && (
                    <span className="text-blue-700 dark:text-blue-300 ml-2">
                      ({locationDetails.cacheAgedays} days old)
                    </span>
                  )}
                </div>
              </div>
            )}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="firstName">First Name *</Label>
                <div className="relative">
                  <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="firstName"
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    className="pl-9"
                    placeholder="John"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName">Last Name *</Label>
                <Input
                  id="lastName"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  placeholder="Smith"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">Phone</Label>
              <div className="relative">
                <Phone className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="phone"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="pl-9"
                  placeholder="(555) 123-4567"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-9"
                  placeholder="john@example.com"
                />
              </div>
            </div>

            <div className="flex gap-2 pt-4">
              <Button variant="outline" onClick={handleClose} className="flex-1">
                Cancel
              </Button>
              <Button onClick={handleContactConfirm} className="flex-1">
                <Check className="mr-2 h-4 w-4" />
                Confirm & Continue
              </Button>
            </div>
          </div>
        )}

        {/* Disposition Selection */}
        {step === 'disposition' && (
          <div className="py-2">
            <StatusQuickActions
              dispositions={dispositions}
              selectedStatus={selectedDisposition}
              onStatusChange={handleDispositionSelect}
              loading={saving}
            />
          </div>
        )}

        {/* Appointment Scheduling */}
        {step === 'appointment' && (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Select Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !appointmentDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {appointmentDate ? format(appointmentDate, "PPP") : "Pick a date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={appointmentDate}
                    onSelect={setAppointmentDate}
                    disabled={(date) => date < new Date(new Date().setHours(0, 0, 0, 0))}
                    initialFocus
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label>Select Time</Label>
              <Select value={appointmentTime} onValueChange={setAppointmentTime}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="max-h-[200px]">
                  {timeOptions.map((time) => (
                    <SelectItem key={time} value={time}>
                      {format(new Date(`2000-01-01T${time}`), 'h:mm a')}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex gap-2 pt-4">
              <Button variant="outline" onClick={handleClose} className="flex-1" disabled={saving}>
                Cancel
              </Button>
              <Button onClick={() => handleSave()} className="flex-1" disabled={saving || !appointmentDate}>
                {saving ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  'Schedule & Save'
                )}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
