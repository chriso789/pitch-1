import { useRealtimeSync } from '@/hooks/useRealtimeSync';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Wifi, WifiOff, Activity, Users } from 'lucide-react';
import { useState } from 'react';

export function RealtimeIndicator() {
  const { isConnected, activeSubscriptions } = useRealtimeSync();
  const [showDetails, setShowDetails] = useState(false);

  return (
    <Popover open={showDetails} onOpenChange={setShowDetails}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="sm" className="relative">
          {isConnected ? (
            <Wifi className="h-4 w-4 text-green-500" />
          ) : (
            <WifiOff className="h-4 w-4 text-red-500" />
          )}
          <span className="ml-2 text-xs hidden sm:inline">
            {isConnected ? 'Live' : 'Offline'}
          </span>
          {isConnected && (
            <div className="absolute -top-1 -right-1 w-2 h-2 bg-green-500 rounded-full animate-pulse" />
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-64" align="end">
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Activity className="h-4 w-4" />
            <span className="font-medium">Real-time Status</span>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Connection</span>
            <Badge variant={isConnected ? "default" : "destructive"}>
              {isConnected ? 'Connected' : 'Disconnected'}
            </Badge>
          </div>

          {isConnected && (
            <>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Users className="h-3 w-3 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">Active Subscriptions</span>
                </div>
                <div className="flex flex-wrap gap-1">
                  {activeSubscriptions.map((subscription) => (
                    <Badge key={subscription} variant="outline" className="text-xs">
                      {subscription}
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="text-xs text-muted-foreground">
                Changes from teammates will appear instantly
              </div>
            </>
          )}

          {!isConnected && (
            <div className="text-xs text-muted-foreground">
              Real-time updates are not available. Changes may not sync immediately.
            </div>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}