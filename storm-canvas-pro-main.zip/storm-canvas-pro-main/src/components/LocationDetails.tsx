import React, { useEffect, useState } from 'react';
import { useLocationDetails } from '@/hooks/useLocationDetails';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import { EstimateWorkflow } from './EstimateWorkflow';
import { 
  MapPin, 
  User, 
  Phone, 
  Mail, 
  FileImage, 
  AlertCircle,
  Calculator,
  X 
} from 'lucide-react';

interface LocationDetailsProps {
  addressHash: string | null;
  onClose: () => void;
}

export function LocationDetails({ addressHash, onClose }: LocationDetailsProps) {
  const { details, loading, fetchLocationDetails } = useLocationDetails();
  const [showEstimateWorkflow, setShowEstimateWorkflow] = useState(false);

  useEffect(() => {
    if (addressHash) {
      fetchLocationDetails(addressHash);
    }
  }, [addressHash, fetchLocationDetails]);

  if (!addressHash) return null;

  if (loading) {
    return (
      <Card className="w-full max-w-md">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-lg">Loading Details...</CardTitle>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>
        <CardContent className="space-y-4">
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-3/4" />
          <Skeleton className="h-20 w-full" />
        </CardContent>
      </Card>
    );
  }

  if (!details) {
    return (
      <Card className="w-full max-w-md">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-lg">No Details Available</CardTitle>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-2 text-muted-foreground">
            <AlertCircle className="h-4 w-4" />
            <span>Unable to load location details for this address.</span>
          </div>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => addressHash && fetchLocationDetails(addressHash)} 
            className="mt-4"
          >
            Try Again
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-md max-h-[80vh] overflow-y-auto">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-lg">Property Details</CardTitle>
        <Button variant="ghost" size="sm" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Actions */}
        <div className="flex gap-2">
          <Button 
            size="sm" 
            onClick={() => setShowEstimateWorkflow(true)}
            className="flex items-center gap-2"
          >
            <Calculator className="h-4 w-4" />
            Create Estimate
          </Button>
        </div>

        <Separator />

        {/* Address Hash */}
        <div className="flex items-center gap-3">
          <MapPin className="h-5 w-5 text-primary" />
          <div>
            <p className="font-medium text-sm">Address Hash: {details.addressHash}</p>
          </div>
        </div>

        <Separator />

        {/* Owner Information */}
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <User className="h-4 w-4" />
            <span className="font-medium">Owner Information</span>
          </div>
          {details.owner?.name ? (
            <div className="ml-6">
              <p className="text-sm">{details.owner.name}</p>
            </div>
          ) : (
            <p className="text-sm text-muted-foreground ml-6">
              No owner information available
            </p>
          )}
        </div>

        <Separator />

        {/* Photos */}
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <FileImage className="h-4 w-4" />
            <span className="font-medium">Photos ({details.photos?.length || 0})</span>
          </div>
          {details.photos && details.photos.length > 0 ? (
            <div className="ml-6 grid grid-cols-2 gap-2">
              {details.photos.slice(0, 4).map((photo) => (
                <div key={photo.id} className="aspect-square bg-muted rounded border">
                  <img 
                    src={photo.url} 
                    alt="Property photo"
                    className="w-full h-full object-cover rounded"
                  />
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground ml-6">
              No photos available
            </p>
          )}
        </div>

        <Separator />

        {/* Visits */}
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <MapPin className="h-4 w-4" />
            <span className="font-medium">Recent Visits ({details.lastVisits?.length || 0})</span>
          </div>
          {details.lastVisits && details.lastVisits.length > 0 ? (
            <div className="ml-6 space-y-2">
              {details.lastVisits.map((visit, index) => (
                <p key={index} className="text-sm text-muted-foreground">
                  Visit {index + 1}
                </p>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground ml-6">
              No visits recorded
            </p>
          )}
        </div>

        {/* Estimate Workflow Modal */}
        {showEstimateWorkflow && details && (
          <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <EstimateWorkflow 
              propertyId={details.addressHash} // Using address hash as property ID for now
              onClose={() => setShowEstimateWorkflow(false)}
            />
          </div>
        )}
      </CardContent>
    </Card>
  );
}