import React, { createContext, useContext, ReactNode } from 'react';
import { useJsApiLoader } from '@react-google-maps/api';
import { useGoogleMapsKey } from '@/hooks/useGoogleMapsKey';

const libraries: ("geometry" | "drawing" | "places")[] = ['geometry', 'drawing', 'places'];

interface GoogleMapsContextType {
  isLoaded: boolean;
  loadError: Error | undefined;
  loading: boolean;
}

const GoogleMapsContext = createContext<GoogleMapsContextType | undefined>(undefined);

interface GoogleMapsProviderProps {
  children: ReactNode;
}

// Inner component that only renders once we have a valid API key
function GoogleMapsLoaderInner({ apiKey, children }: { apiKey: string; children: ReactNode }) {
  const { isLoaded, loadError } = useJsApiLoader({
    googleMapsApiKey: apiKey,
    libraries,
    id: 'google-map-script',
    preventGoogleFontsLoading: true
  });

  return (
    <GoogleMapsContext.Provider value={{ isLoaded, loadError, loading: !isLoaded }}>
      {children}
    </GoogleMapsContext.Provider>
  );
}

export function GoogleMapsProvider({ children }: GoogleMapsProviderProps) {
  const { apiKey, loading: keyLoading } = useGoogleMapsKey();
  
  // Wait for the API key to load before initializing the Google Maps loader
  if (keyLoading) {
    return (
      <GoogleMapsContext.Provider value={{ isLoaded: false, loadError: undefined, loading: true }}>
        {children}
      </GoogleMapsContext.Provider>
    );
  }

  // If no API key is available, provide a non-loaded state
  if (!apiKey) {
    return (
      <GoogleMapsContext.Provider value={{ isLoaded: false, loadError: undefined, loading: false }}>
        {children}
      </GoogleMapsContext.Provider>
    );
  }

  // Only render the inner loader once we have a valid API key
  return <GoogleMapsLoaderInner apiKey={apiKey}>{children}</GoogleMapsLoaderInner>;
}

export function useGoogleMapsContext() {
  const context = useContext(GoogleMapsContext);
  if (context === undefined) {
    throw new Error('useGoogleMapsContext must be used within GoogleMapsProvider');
  }
  return context;
}
