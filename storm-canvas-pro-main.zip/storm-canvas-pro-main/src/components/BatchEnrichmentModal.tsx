import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { 
  Play, 
  Pause, 
  X, 
  CheckCircle, 
  XCircle, 
  Clock, 
  Zap,
  AlertCircle 
} from 'lucide-react';
import { batchEnrichmentService, BatchProgress, BatchResult } from '@/services/batchEnrichment';
import { toast } from 'sonner';

interface BatchEnrichmentModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  selectedPropertyIds: string[];
  onComplete?: (result: BatchResult) => void;
}

export function BatchEnrichmentModal({
  open,
  onOpenChange,
  selectedPropertyIds,
  onComplete
}: BatchEnrichmentModalProps) {
  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState<BatchProgress | null>(null);
  const [result, setResult] = useState<BatchResult | null>(null);
  const [rateLimitStatus, setRateLimitStatus] = useState<{ tokensRemaining: number } | null>(null);

  const startEnrichment = async () => {
    if (selectedPropertyIds.length === 0) {
      toast.error('No properties selected for enrichment');
      return;
    }

    setIsRunning(true);
    setProgress(null);
    setResult(null);

    try {
      const batchResult = await batchEnrichmentService.enrichPropertiesBatch(
        selectedPropertyIds,
        {
          concurrency: 3,
          progressCallback: (newProgress) => {
            setProgress(newProgress);
            setRateLimitStatus(batchEnrichmentService.getRateLimiterStatus());
          }
        }
      );

      setResult(batchResult);
      onComplete?.(batchResult);
      
    } catch (error) {
      console.error('Batch enrichment failed:', error);
      toast.error(`Batch enrichment failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    } finally {
      setIsRunning(false);
    }
  };

  const formatDuration = (ms: number): string => {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    if (minutes > 0) {
      return `${minutes}m ${seconds % 60}s`;
    }
    return `${seconds}s`;
  };

  const handleClose = () => {
    if (!isRunning) {
      onOpenChange(false);
      setProgress(null);
      setResult(null);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5" />
            Batch Property Enrichment
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Status Overview */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="text-sm text-muted-foreground">Properties Selected</div>
              <div className="text-2xl font-bold">{selectedPropertyIds.length}</div>
            </div>
            {rateLimitStatus && (
              <div className="space-y-2">
                <div className="text-sm text-muted-foreground">Rate Limit Tokens</div>
                <div className="text-2xl font-bold flex items-center gap-2">
                  {rateLimitStatus.tokensRemaining}
                  <Badge variant={rateLimitStatus.tokensRemaining > 0 ? "default" : "destructive"} className="text-xs">
                    {rateLimitStatus.tokensRemaining > 0 ? "Available" : "Limited"}
                  </Badge>
                </div>
              </div>
            )}
          </div>

          {/* Progress Section */}
          {progress && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Progress</span>
                <span className="text-sm text-muted-foreground">
                  {progress.completed + progress.failed} of {progress.total} ({progress.percentage}%)
                </span>
              </div>
              
              <Progress value={progress.percentage} className="h-2" />
              
              <div className="grid grid-cols-4 gap-4 text-center">
                <div className="space-y-1">
                  <div className="text-xs text-muted-foreground">Completed</div>
                  <div className="flex items-center justify-center gap-1">
                    <CheckCircle className="h-3 w-3 text-success" />
                    <span className="font-medium">{progress.completed}</span>
                  </div>
                </div>
                <div className="space-y-1">
                  <div className="text-xs text-muted-foreground">In Progress</div>
                  <div className="flex items-center justify-center gap-1">
                    <Clock className="h-3 w-3 text-warning" />
                    <span className="font-medium">{progress.inProgress}</span>
                  </div>
                </div>
                <div className="space-y-1">
                  <div className="text-xs text-muted-foreground">Failed</div>
                  <div className="flex items-center justify-center gap-1">
                    <XCircle className="h-3 w-3 text-destructive" />
                    <span className="font-medium">{progress.failed}</span>
                  </div>
                </div>
                <div className="space-y-1">
                  <div className="text-xs text-muted-foreground">Remaining</div>
                  <div className="flex items-center justify-center gap-1">
                    <span className="font-medium">{progress.total - progress.completed - progress.failed}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Results Section */}
          {result && (
            <div className="space-y-4">
              <Alert variant={result.success ? "default" : "destructive"}>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  <div className="font-medium mb-2">Batch Enrichment Complete</div>
                  <div className="text-sm space-y-1">
                    <div>✅ Enriched: {result.enriched} properties</div>
                    <div>❌ Failed: {result.failed} properties</div>
                    <div>⏭️ Skipped: {result.skipped} properties (recently enriched)</div>
                    <div>⏱️ Duration: {formatDuration(result.duration)}</div>
                  </div>
                </AlertDescription>
              </Alert>
            </div>
          )}

          {/* Error List */}
          {(progress?.errors.length || 0) > 0 && (
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium">Errors</span>
                <Badge variant="destructive">{progress?.errors.length}</Badge>
              </div>
              <ScrollArea className="h-32 border rounded-md p-2">
                <div className="space-y-2">
                  {progress?.errors.map((error, index) => (
                    <div key={index} className="text-xs space-y-1">
                      <div className="font-medium truncate">{error.address}</div>
                      <div className="text-muted-foreground">{error.error}</div>
                      {index < (progress?.errors.length || 0) - 1 && <Separator />}
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={handleClose}
              disabled={isRunning}
            >
              <X className="h-4 w-4 mr-2" />
              {isRunning ? 'Running...' : 'Close'}
            </Button>
            
            <div className="flex gap-2">
              {!result && (
                <Button
                  onClick={startEnrichment}
                  disabled={isRunning || selectedPropertyIds.length === 0}
                  className="min-w-[120px]"
                >
                  {isRunning ? (
                    <>
                      <Pause className="h-4 w-4 mr-2" />
                      Running...
                    </>
                  ) : (
                    <>
                      <Play className="h-4 w-4 mr-2" />
                      Start Enrichment
                    </>
                  )}
                </Button>
              )}
            </div>
          </div>

          {/* Rate Limiting Info */}
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="text-xs">
              <strong>Rate Limiting:</strong> This process respects API rate limits with automatic backoff and retry logic. 
              Large batches may take several minutes to complete.
            </AlertDescription>
          </Alert>
        </div>
      </DialogContent>
    </Dialog>
  );
}