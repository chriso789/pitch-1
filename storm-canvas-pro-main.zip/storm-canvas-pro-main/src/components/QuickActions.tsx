import { Button } from "@/components/ui/button";
import { MapPin, Camera, FileText, CloudRain, Plus } from "lucide-react";
import { useNavigate } from "react-router-dom";

const actions = [
  {
    title: 'Start Canvassing',
    description: 'Begin door-to-door in your territory',
    icon: MapPin,
    variant: 'default' as const,
  },
  {
    title: 'Capture Photos',
    description: 'Document property damage',
    icon: Camera,
    variant: 'secondary' as const,
  },
  {
    title: 'Create Proposal',
    description: 'Generate estimate and contract',
    icon: FileText,
    variant: 'secondary' as const,
  },
  {
    title: 'Check Storm Data',
    description: 'View recent weather events',
    icon: CloudRain,
    variant: 'secondary' as const,
  },
];

export default function QuickActions() {
  const navigate = useNavigate();

  const handleActionClick = (title: string) => {
    switch (title) {
      case 'Start Canvassing':
        navigate('/canvassing');
        break;
      case 'Capture Photos':
        navigate('/photos');
        break;
      case 'Create Proposal':
        navigate('/proposals');
        break;
      case 'Check Storm Data':
        navigate('/storm');
        break;
      default:
        break;
    }
  };

  return (
    <div className="bg-card border rounded-lg p-6 shadow-soft">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-foreground">Quick Actions</h3>
        <Button size="sm" variant="outline">
          <Plus className="h-4 w-4 mr-2" />
          Add Custom
        </Button>
      </div>
      <div className="grid grid-cols-2 gap-4">
        {actions.map((action) => (
          <Button
            key={action.title}
            variant={action.variant}
            size="lg"
            className="h-auto p-4 flex-col items-start gap-2"
            onClick={() => handleActionClick(action.title)}
          >
            <div className="flex items-center gap-2 w-full">
              <action.icon className="h-5 w-5" />
              <span className="font-medium">{action.title}</span>
            </div>
            <span className="text-xs text-left text-muted-foreground">
              {action.description}
            </span>
          </Button>
        ))}
      </div>
    </div>
  );
}