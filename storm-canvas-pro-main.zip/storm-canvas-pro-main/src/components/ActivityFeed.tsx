import { Clock, MapPin, Camera, FileText, CheckCircle } from "lucide-react";

const activities = [
  {
    id: 1,
    type: 'knock',
    description: 'New lead generated from canvassing',
    location: '123 Oak Street, Austin, TX',
    time: '2 minutes ago',
    icon: MapPin,
    status: 'success'
  },
  {
    id: 2,
    type: 'photo',
    description: 'Photo report completed',
    location: '456 Pine Avenue, Austin, TX',
    time: '15 minutes ago',
    icon: Camera,
    status: 'success'
  },
  {
    id: 3,
    type: 'proposal',
    description: 'Proposal sent to homeowner',
    location: '789 Elm Drive, Austin, TX',
    time: '32 minutes ago',
    icon: FileText,
    status: 'pending'
  },
  {
    id: 4,
    type: 'signed',
    description: 'Contract signed - $24,500',
    location: '321 Maple Court, Austin, TX',
    time: '1 hour ago',
    icon: CheckCircle,
    status: 'success'
  },
];

export default function ActivityFeed() {
  return (
    <div className="bg-card border rounded-lg p-6 shadow-soft">
      <h3 className="text-lg font-semibold text-foreground mb-4">Recent Activity</h3>
      <div className="space-y-4">
        {activities.map((activity) => (
          <div key={activity.id} className="flex items-start gap-4">
            <div className="h-10 w-10 rounded-lg bg-gradient-primary flex items-center justify-center flex-shrink-0">
              <activity.icon className="h-5 w-5 text-primary-foreground" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-foreground">{activity.description}</p>
              <p className="text-sm text-muted-foreground">{activity.location}</p>
              <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                <Clock className="h-3 w-3" />
                {activity.time}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}