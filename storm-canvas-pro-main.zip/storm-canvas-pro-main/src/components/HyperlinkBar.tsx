import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Calculator, DollarSign, Hammer, Building, TrendingUp, Target } from 'lucide-react';
import { useEstimates, type HyperlinkBarData } from '@/hooks/useEstimates';

interface HyperlinkBarProps {
  estimateId: string;
}

export const HyperlinkBar: React.FC<HyperlinkBarProps> = ({ estimateId }) => {
  const [data, setData] = useState<HyperlinkBarData | null>(null);
  const [loading, setLoading] = useState(true);
  const { getHyperlinkBarData } = useEstimates();

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      const result = await getHyperlinkBarData(estimateId);
      setData(result);
      setLoading(false);
    };

    loadData();
  }, [estimateId, getHyperlinkBarData]);

  const getSectionIcon = (key: string) => {
    switch (key) {
      case 'measurements': return <Calculator className="h-4 w-4" />;
      case 'materials': return <Building className="h-4 w-4" />;
      case 'labor': return <Hammer className="h-4 w-4" />;
      case 'overhead': return <TrendingUp className="h-4 w-4" />;
      case 'profit': return <Target className="h-4 w-4" />;
      case 'total': return <DollarSign className="h-4 w-4" />;
      default: return <Calculator className="h-4 w-4" />;
    }
  };

  const formatCurrency = (amount: number, currency: string = 'USD') => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency
    }).format(amount);
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Pricing Breakdown</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {Array.from({ length: 6 }).map((_, index) => (
              <div key={index} className="space-y-2">
                <Skeleton className="h-4 w-20" />
                <Skeleton className="h-8 w-full" />
                <Skeleton className="h-4 w-16" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!data) {
    return (
      <Card>
        <CardContent className="p-6">
          <p className="text-center text-muted-foreground">
            Unable to load pricing data
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Pricing Breakdown</CardTitle>
        <div className="flex items-center space-x-2">
          <Badge variant={data.ready ? 'default' : 'secondary'}>
            {data.ready ? 'Ready' : 'Pending'}
          </Badge>
          <span className="text-sm text-muted-foreground">
            {data.currency}
          </span>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {data.sections.map((section) => (
            <div key={section.key} className="space-y-2">
              <div className="flex items-center space-x-2">
                {getSectionIcon(section.key)}
                <span className="text-sm font-medium">{section.label}</span>
              </div>
              
              <div className={`text-2xl font-bold ${
                section.pending ? 'text-muted-foreground' : 'text-foreground'
              }`}>
                {section.key === 'measurements' 
                  ? `${section.extra?.squares || 0} sq`
                  : formatCurrency(section.amount || 0, data.currency)
                }
              </div>
              
              {section.pending && (
                <Badge variant="outline" className="text-xs">
                  Pending
                </Badge>
              )}

              {section.key === 'profit' && section.extra && (
                <div className="text-xs text-muted-foreground">
                  {section.extra.mode === 'margin' 
                    ? `${section.extra.margin_pct || 0}% margin`
                    : `${section.extra.markup_pct || 0}% markup`
                  }
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Summary Section */}
        <div className="mt-6 pt-6 border-t">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div>
              <span className="text-muted-foreground">Template:</span>
              <div className="font-medium">
                {data.template_bound ? 'Bound' : 'Not Bound'}
              </div>
            </div>
            <div>
              <span className="text-muted-foreground">Measurements:</span>
              <div className="font-medium">
                {data.measurements_present ? `${data.squares} sq` : 'Missing'}
              </div>
            </div>
            <div>
              <span className="text-muted-foreground">Cost (Pre-Profit):</span>
              <div className="font-medium">
                {formatCurrency(data.cost_pre_profit, data.currency)}
              </div>
            </div>
            <div>
              <span className="text-muted-foreground">Final Price:</span>
              <div className="font-medium text-lg">
                {formatCurrency(data.sale_price, data.currency)}
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};