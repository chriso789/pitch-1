import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAuth } from './AuthProvider';
import { toast } from 'sonner';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AuthModal({ isOpen, onClose }: AuthModalProps) {
  const [isSignUp, setIsSignUp] = useState(false);
  const [isMagicLink, setIsMagicLink] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { signUp, signIn, signInWithMagicLink } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (isMagicLink) {
        await signInWithMagicLink(email);
        toast.success('Magic link sent! Check your email.');
        onClose();
      } else if (isSignUp) {
        await signUp(email, password);
        toast.success('Account created! Check your email to verify.');
        onClose();
      } else {
        await signIn(email, password);
        toast.success('Signed in successfully!');
        onClose();
      }
    } catch (error: any) {
      const message = error.message || 'Authentication failed';
      toast.error(message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>
            {isMagicLink ? 'Magic Link Sign In' : (isSignUp ? 'Create Account' : 'Sign In')}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          {!isMagicLink && (
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
          )}
          <Button 
            type="submit" 
            className="w-full" 
            disabled={loading || (!isMagicLink && (!email || !password)) || (isMagicLink && !email)}
          >
            {loading ? 'Loading...' : (
              isMagicLink ? 'Send Magic Link' : (isSignUp ? 'Sign Up' : 'Sign In')
            )}
          </Button>
          
          <div className="space-y-2">
            <Button
              type="button"
              variant="ghost"
              className="w-full"
              onClick={() => {
                setIsMagicLink(false);
                setIsSignUp(!isSignUp);
              }}
            >
              {isSignUp ? 'Already have an account? Sign In' : "Don't have an account? Sign Up"}
            </Button>
            
            {!isSignUp && (
              <Button
                type="button"
                variant="ghost"
                className="w-full text-sm"
                onClick={() => {
                  setIsMagicLink(!isMagicLink);
                  setIsSignUp(false);
                }}
              >
                {isMagicLink ? 'Use password instead' : 'Use magic link instead'}
              </Button>
            )}
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}