import { useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { useRealtimeSync } from '@/hooks/useRealtimeSync';

interface RealTimeUpdatesProps {
  userId?: string;
}

export function RealTimeUpdates({ userId }: RealTimeUpdatesProps) {
  // Use the new enhanced real-time sync hook
  const { isConnected, activeSubscriptions } = useRealtimeSync({
    enablePropertySync: true,
    enableVisitSync: true,
    enablePhotoSync: true,
    enableProposalSync: true,
    enableDispositionSync: true,
    enableDesignSync: true,
    onUpdate: (table, event, payload) => {
      console.log(`📡 Real-time update received: ${table}.${event}`, payload);
    }
  });

  useEffect(() => {
    if (isConnected) {
      console.log(`🚀 Real-time sync active for: ${activeSubscriptions.join(', ')}`);
    }
  }, [isConnected, activeSubscriptions]);

  return null; // This component doesn't render anything
}