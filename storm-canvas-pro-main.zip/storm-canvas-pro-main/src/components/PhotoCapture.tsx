import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Camera, 
  Upload, 
  Image as ImageIcon, 
  MapPin, 
  X,
  Check,
  AlertCircle
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

interface PhotoCaptureProps {
  propertyId?: string;
  designId?: string;
  onPhotoUploaded?: (photo: any) => void;
  onClose?: () => void;
}

export function PhotoCapture({ propertyId, designId, onPhotoUploaded, onClose }: PhotoCaptureProps) {
  const [isCapturing, setIsCapturing] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [caption, setCaption] = useState('');
  const [location, setLocation] = useState<GeolocationPosition | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const getCurrentLocation = () => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => setLocation(position),
        (error) => console.warn('Location access denied:', error)
      );
    }
  };

  const startCamera = async () => {
    try {
      setIsCapturing(true);
      getCurrentLocation();
      
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' } // Use back camera on mobile
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (error) {
      console.error('Error accessing camera:', error);
      setIsCapturing(false);
    }
  };

  const stopCamera = () => {
    if (videoRef.current?.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    setIsCapturing(false);
  };

  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');

    if (!ctx) return;

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    ctx.drawImage(video, 0, 0);

    canvas.toBlob((blob) => {
      if (blob) {
        const file = new File([blob], `photo-${Date.now()}.jpg`, { type: 'image/jpeg' });
        setSelectedFiles([file]);
        stopCamera();
      }
    }, 'image/jpeg', 0.9);
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    setSelectedFiles(files);
    getCurrentLocation();
  };

  const compressImage = (file: File): Promise<File> => {
    return new Promise((resolve) => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d')!;
      const img = new Image();

      img.onload = () => {
        // Calculate new dimensions (max 1920px)
        const maxSize = 1920;
        let { width, height } = img;
        
        if (width > height && width > maxSize) {
          height = (height * maxSize) / width;
          width = maxSize;
        } else if (height > maxSize) {
          width = (width * maxSize) / height;
          height = maxSize;
        }

        canvas.width = width;
        canvas.height = height;
        ctx.drawImage(img, 0, 0, width, height);

        canvas.toBlob((blob) => {
          if (blob) {
            resolve(new File([blob], file.name, { type: 'image/jpeg' }));
          }
        }, 'image/jpeg', 0.85);
      };

      img.src = URL.createObjectURL(file);
    });
  };

  const extractExifData = (file: File): Promise<any> => {
    return new Promise((resolve) => {
      // Simple EXIF extraction - in production, use a proper EXIF library
      const reader = new FileReader();
      reader.onload = () => {
        resolve({
          filename: file.name,
          size: file.size,
          type: file.type,
          lastModified: new Date(file.lastModified),
        });
      };
      reader.readAsArrayBuffer(file);
    });
  };

  const uploadPhotos = async () => {
    if (!selectedFiles.length || !propertyId) return;

    setUploading(true);
    setUploadProgress(0);

    try {
      for (let i = 0; i < selectedFiles.length; i++) {
        const file = selectedFiles[i];
        
        // Compress image
        const compressedFile = await compressImage(file);
        
        // Extract EXIF data
        const exifData = await extractExifData(file);

        // Step 1: Get presigned upload URL
        const { data: presignData, error: presignError } = await supabase.functions.invoke('photos-presign', {
          body: {
            filename: compressedFile.name,
            contentType: compressedFile.type
          }
        });

        if (presignError) throw presignError;

        // Step 2: Upload file to storage using presigned URL
        const uploadResponse = await fetch(presignData.uploadUrl, {
          method: 'PUT',
          body: compressedFile,
          headers: {
            'Content-Type': compressedFile.type
          }
        });

        if (!uploadResponse.ok) {
          throw new Error('Upload failed');
        }

        // Step 3: Attach photo record to database
        const { data: attachData, error: attachError } = await supabase.functions.invoke('photos-attach', {
          body: {
            propertyId,
            storageKey: presignData.storageKey,
            exifData: {
              ...exifData,
              GPS: location ? {
                GPSLatitude: location.coords.latitude,
                GPSLongitude: location.coords.longitude
              } : undefined
            },
            caption: caption || null,
            originalFilename: file.name,
            fileSize: compressedFile.size,
            mimeType: compressedFile.type
          }
        });

        if (attachError) throw attachError;

        onPhotoUploaded?.(attachData.photo);
        setUploadProgress(((i + 1) / selectedFiles.length) * 100);
      }

      // Reset form
      setSelectedFiles([]);
      setCaption('');
      setLocation(null);
      
    } catch (error) {
      console.error('Error uploading photos:', error);
    } finally {
      setUploading(false);
      setUploadProgress(0);
    }
  };

  return (
    <Card className="w-96 max-h-[90vh] overflow-y-auto">
      <CardHeader className="flex flex-row items-center justify-between pb-3">
        <CardTitle className="text-lg">Photo Capture</CardTitle>
        <Button variant="ghost" size="sm" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Camera Section */}
        <div className="space-y-3">
          <Label className="text-sm font-medium">Capture New Photo</Label>
          
          {!isCapturing ? (
            <div className="grid grid-cols-2 gap-2">
              <Button onClick={startCamera} variant="outline">
                <Camera className="h-4 w-4 mr-2" />
                Use Camera
              </Button>
              <Button onClick={() => fileInputRef.current?.click()} variant="outline">
                <Upload className="h-4 w-4 mr-2" />
                Select Files
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="relative">
                <video
                  ref={videoRef}
                  className="w-full h-48 bg-black rounded-lg"
                  autoPlay
                  playsInline
                  muted
                />
                <canvas ref={canvasRef} className="hidden" />
              </div>
              
              <div className="flex gap-2">
                <Button onClick={capturePhoto} className="flex-1">
                  <Camera className="h-4 w-4 mr-2" />
                  Capture
                </Button>
                <Button onClick={stopCamera} variant="outline">
                  Cancel
                </Button>
              </div>
            </div>
          )}

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            multiple
            onChange={handleFileSelect}
            className="hidden"
          />
        </div>

        {/* Selected Files Preview */}
        {selectedFiles.length > 0 && (
          <div className="space-y-3">
            <Label className="text-sm font-medium">Selected Photos</Label>
            
            <div className="space-y-2">
              {selectedFiles.map((file, index) => (
                <div key={index} className="flex items-center gap-3 p-2 border rounded-lg">
                  <ImageIcon className="h-6 w-6 text-muted-foreground" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{file.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {(file.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                  </div>
                  {location && (
                    <Badge variant="secondary">
                      <MapPin className="h-3 w-3 mr-1" />
                      GPS
                    </Badge>
                  )}
                </div>
              ))}
            </div>

            <div>
              <Label htmlFor="caption" className="text-sm">Caption (Optional)</Label>
              <Input
                id="caption"
                value={caption}
                onChange={(e) => setCaption(e.target.value)}
                placeholder="Add a caption for these photos"
                className="mt-1"
              />
            </div>

            {location && (
              <div className="flex items-center gap-2 text-sm text-green-600">
                <MapPin className="h-4 w-4" />
                <span>Location: {location.coords.latitude.toFixed(6)}, {location.coords.longitude.toFixed(6)}</span>
              </div>
            )}
          </div>
        )}

        {/* Upload Progress */}
        {uploading && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span>Uploading photos...</span>
              <span>{Math.round(uploadProgress)}%</span>
            </div>
            <Progress value={uploadProgress} />
          </div>
        )}

        {/* Upload Button */}
        {selectedFiles.length > 0 && !uploading && (
          <Button 
            onClick={uploadPhotos} 
            className="w-full"
            disabled={!propertyId}
          >
            <Upload className="h-4 w-4 mr-2" />
            Upload {selectedFiles.length} Photo{selectedFiles.length > 1 ? 's' : ''}
          </Button>
        )}

        {!propertyId && (
          <div className="flex items-center gap-2 p-3 bg-orange-50 rounded-lg border border-orange-200">
            <AlertCircle className="h-4 w-4 text-orange-600" />
            <p className="text-sm text-orange-700">
              Select a property pin on the map to enable photo upload
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}