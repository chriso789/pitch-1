import React from 'react';

interface DispositionBubbleProps {
  disposition?: string;
  color?: string;
  position: { lat: number; lng: number };
  zoom?: number;
}

export function DispositionBubble({ disposition, color, zoom = 16 }: DispositionBubbleProps) {
  const hasDisposition = disposition && color;
  
  // Dynamic sizing based on zoom level - smaller when zoomed out, larger when zoomed in
  const getSize = () => {
    if (zoom <= 15) return 'w-2 h-2';   // 8px at far zoom
    if (zoom <= 17) return 'w-3 h-3';   // 12px at medium zoom
    if (zoom <= 19) return 'w-4 h-4';   // 16px at high zoom
    return 'w-5 h-5';                   // 20px at very high zoom
  };

  const getBorderWidth = () => {
    if (zoom <= 15) return 'border-[1px]';
    if (zoom <= 17) return 'border-[1.5px]';
    return 'border-2';
  };

  const getTextSize = () => {
    if (zoom <= 15) return 'text-[5px]';
    if (zoom <= 17) return 'text-[6px]';
    if (zoom <= 19) return 'text-[7px]';
    return 'text-[8px]';
  };

  const getPadding = () => {
    if (zoom <= 15) return 'px-0.5 py-0';
    if (zoom <= 17) return 'px-1 py-0.5';
    return 'px-1.5 py-0.5';
  };
  
  return (
    <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-10">
      <div className="relative flex items-center justify-center">
        {/* Outer ring - always visible */}
        <div 
          className={`${getSize()} rounded-full ${getBorderWidth()} flex items-center justify-center transition-all duration-200 shadow-sm hover:shadow-md hover:scale-110 cursor-pointer`}
          style={{
            borderColor: hasDisposition ? color : 'hsl(var(--muted-foreground))',
            backgroundColor: hasDisposition ? `${color}20` : 'hsl(var(--background))',
          }}
        >
          {/* Inner badge - only when contacted */}
          {hasDisposition && (
            <div 
              className={`${getPadding()} rounded-full ${getTextSize()} font-semibold text-white shadow-lg whitespace-nowrap`}
              style={{ 
                backgroundColor: color,
              }}
            >
              {disposition}
            </div>
          )}
          {/* Unvisited indicator */}
          {!hasDisposition && (
            <div className="w-1.5 h-1.5 rounded-full bg-muted-foreground" />
          )}
        </div>
      </div>
    </div>
  );
}