import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CheckCircle, AlertCircle, Key, Map, Database, RefreshCw, Shield, ArrowRight, Play } from 'lucide-react';
import { SkiptraceService } from '@/services/skiptraceApi';
import { supabase } from '@/integrations/supabase/client';
import { configManager, type ConfigValidationError } from '@/lib/config';
import { useGoogleMapsKey } from '@/hooks/useGoogleMapsKey';
import { toast } from 'sonner';
import { useProperties } from '@/hooks/useProperties';

interface SetupStep {
  id: string;
  title: string;
  description: string;
  completed: boolean;
  icon: any;
  optional?: boolean;
}

export function SetupWizard() {
  const [currentStep, setCurrentStep] = useState(0);
  const [steps, setSteps] = useState<SetupStep[]>([
    {
      id: 'supabase',
      title: 'Connect Supabase',
      description: 'Database connection for storing property data',
      completed: false,
      icon: Database
    },
    {
      id: 'mapbox',
      title: 'Configure Google Maps',
      description: 'Map service for property visualization and geocoding',
      completed: false,
      icon: Map
    },
    {
      id: 'skiptrace',
      title: 'Setup Skiptrace API (Optional)', 
      description: 'Free skip trace service is already enabled - paid services optional',
      completed: true, // Mark as completed since free service is available
      optional: true,
      icon: Key
    },
    {
      id: 'sentry',
      title: 'Configure Sentry (Optional)',
      description: 'Error monitoring and performance tracking',
      completed: false,
      optional: true,
      icon: Shield
    },
    {
      id: 'finalize',
      title: 'Finalize Setup',
      description: 'Review configuration and seed demo data',
      completed: false,
      icon: Play
    }
  ]);

  const { saveApiKey } = useGoogleMapsKey();
  const [googleMapsKey, setGoogleMapsKey] = useState('');
  const [skiptraceKey, setSkiptraceKey] = useState('');
  const [sentryDsn, setSentryDsn] = useState('');
  const [testing, setTesting] = useState<string | null>(null);
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});
  const [configErrors, setConfigErrors] = useState<ConfigValidationError[]>([]);
  const [seedingData, setSeedingData] = useState(false);

  // Calculate progress excluding optional steps that haven't been started
  const requiredSteps = steps.filter(s => !s.optional || s.completed);
  const progress = (requiredSteps.filter(s => s.completed).length / requiredSteps.length) * 100;

  useEffect(() => {
    checkSupabaseConnection();
    checkExistingTokens();
    loadConfigErrors();
    
    // Update wizard completion status
    updateWizardCompletionStatus();
  }, []);

  const loadConfigErrors = () => {
    setConfigErrors(configManager.errors);
  };

  const checkSupabaseConnection = async () => {
    try {
      const { data, error } = await supabase.from('dispositions').select('count').limit(1);
      const completed = !error;
      
      setSteps(prev => prev.map(step => 
        step.id === 'supabase' ? { ...step, completed } : step
      ));
    } catch {
      // Supabase not connected
    }
  };

  const checkExistingTokens = async () => {
    // Check Supabase secrets first
    try {
      const { data: functions } = await supabase.functions.invoke('check-secrets');
      if (functions?.google_maps_api_key) {
        setSteps(prev => prev.map(step => 
          step.id === 'mapbox' ? { ...step, completed: true } : step
        ));
      }
      if (functions?.skiptrace_api_key) {
        setSteps(prev => prev.map(step => 
          step.id === 'skiptrace' ? { ...step, completed: true } : step
        ));
      }
    } catch (error) {
      console.log('Secrets not available, checking environment variables');
    }

    // Fallback to environment variables
    const googleMapsStored = import.meta.env.VITE_GOOGLE_MAPS_API_KEY;
    const skiptraceStored = import.meta.env.VITE_SKIPTRACE_API_KEY;
    const sentryStored = import.meta.env.VITE_SENTRY_DSN;

    if (googleMapsStored) {
      setGoogleMapsKey(googleMapsStored);
      setSteps(prev => prev.map(step => 
        step.id === 'mapbox' ? { ...step, completed: true } : step
      ));
    }

    if (skiptraceStored) {
      setSkiptraceKey(skiptraceStored);
      setSteps(prev => prev.map(step => 
        step.id === 'skiptrace' ? { ...step, completed: true } : step
      ));
    }

    if (sentryStored) {
      setSentryDsn(sentryStored);
      setSteps(prev => prev.map(step => 
        step.id === 'sentry' ? { ...step, completed: true } : step
      ));
    }
  };

  const testAndSaveGoogleMapsKey = async () => {
    if (!googleMapsKey) return;
    
    setTesting('mapbox');
    setValidationErrors(prev => ({ ...prev, mapbox: '' }));
    
    try {
      // Save to Supabase secrets and test
      const success = await saveApiKey(googleMapsKey);
      
      if (success) {
        setSteps(prev => prev.map(step => 
          step.id === 'mapbox' ? { ...step, completed: true } : step
        ));
        setValidationErrors(prev => ({ ...prev, mapbox: '' }));
        toast.success('Google Maps API key saved and validated!');
      } else {
        throw new Error('Failed to save API key');
      }
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Failed to save Google Maps API key';
      setValidationErrors(prev => ({ ...prev, mapbox: errorMsg }));
      toast.error(errorMsg);
    } finally {
      setTesting(null);
    }
  };

  const testSkiptraceKey = async () => {
    try {
      setTesting('skiptrace');
      setValidationErrors(prev => ({ ...prev, skiptrace: '' }));
      
      // Test the free skip trace service
      const { FreeSkipTraceService } = await import('@/services/freeSkipTrace');
      const result = await FreeSkipTraceService.health();
      
      if (result.ok) {
        setSteps(prev => prev.map(step => 
          step.id === 'skiptrace' ? { ...step, completed: true } : step
        ));
        setValidationErrors(prev => ({ ...prev, skiptrace: '' }));
        toast.success(`Free skip trace service is working! (${result.latency_ms}ms)`);
      } else {
        throw new Error(result.error || 'Service test failed');
      }
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Failed to test skip trace service';
      setValidationErrors(prev => ({ ...prev, skiptrace: errorMsg }));
      toast.error(errorMsg);
    } finally {
      setTesting(null);
    }
  };

  const testSentryDsn = async () => {
    if (!sentryDsn) return;
    
    setTesting('sentry');
    setValidationErrors(prev => ({ ...prev, sentry: '' }));
    
    try {
      // Basic URL validation for Sentry DSN
      const url = new URL(sentryDsn);
      if (!url.hostname.includes('sentry')) {
        throw new Error('DSN must be a valid Sentry URL');
      }
      setSteps(prev => prev.map(step => 
        step.id === 'sentry' ? { ...step, completed: true } : step
      ));
      setValidationErrors(prev => ({ ...prev, sentry: '' }));
      toast.success('Sentry DSN validated!');
    } catch (error) {
      const errorMsg = 'Invalid Sentry DSN format. Please ensure it follows the format: https://[key]@[organization].ingest.sentry.io/[project-id]';
      setValidationErrors(prev => ({ ...prev, sentry: errorMsg }));
      toast.error(errorMsg);
    } finally {
      setTesting(null);
    }
  };

  const seedDemoData = async () => {
    setSeedingData(true);
    try {
      // Create a few sample properties for demo
      const demoProperties = [
        {
          address: '1600 Amphitheatre Parkway, Mountain View, CA',
          latitude: 37.4221,
          longitude: -122.0841,
          homeowner_name: 'Demo Owner 1',
          property_value: 1200000,
          year_built: 2010
        },
        {
          address: '1 Hacker Way, Menlo Park, CA',
          latitude: 37.4845,
          longitude: -122.1477,
          homeowner_name: 'Demo Owner 2',
          property_value: 1500000,
          year_built: 2015
        }
      ];

      for (const property of demoProperties) {
        await supabase.from('properties').insert(property);
      }

      toast.success('Demo data seeded successfully!');
    } catch (error) {
      console.error('Error seeding demo data:', error);
      toast.error('Failed to seed demo data');
    } finally {
      setSeedingData(false);
    }
  };

  const completeSetup = () => {
    // Mark finalize step as completed
    setSteps(prev => prev.map(step => 
      step.id === 'finalize' ? { ...step, completed: true } : step
    ));
    
    toast.success('Setup completed! Redirecting to dashboard...');
    setTimeout(() => {
      window.location.href = '/';
    }, 1500);
  };

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const canAdvance = () => {
    const current = steps[currentStep];
    return current.completed || current.optional;
  };

  const updateWizardCompletionStatus = () => {
    const allRequiredCompleted = steps
      .filter(s => !s.optional)
      .every(s => s.completed);
    
    if (allRequiredCompleted && configManager.isValid) {
      toast.success('All gates completed! System ready for use.');
    }
  };

  const retryConfiguration = () => {
    configManager.validate();
    loadConfigErrors();
    checkSupabaseConnection();
    checkExistingTokens();
    if (configManager.isValid) {
      toast.success('Configuration valid! Redirecting to dashboard...');
      setTimeout(() => {
        window.location.href = '/';
      }, 1500);
    }
  };

  const currentStepData = steps[currentStep];

  return (
    <div className="max-w-4xl mx-auto p-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Key className="h-5 w-5" />
            Canvass-IQ Setup Wizard
            <span className="text-sm font-normal text-muted-foreground ml-2">
              Step {currentStep + 1} of {steps.length}
            </span>
          </CardTitle>
          
          {configErrors.length > 0 && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                <strong>Configuration Error:</strong> Missing or invalid environment variables detected.
                <details className="mt-2">
                  <summary className="cursor-pointer">View Details</summary>
                  <ul className="mt-1 text-sm">
                    {configErrors.map((error, index) => (
                      <li key={index}>• {error.field}: {error.message}</li>
                    ))}
                  </ul>
                </details>
              </AlertDescription>
            </Alert>
          )}
          
          <div className="flex items-center gap-2">
            <Progress value={progress} className="flex-1" />
            <span className="text-sm text-muted-foreground">
              {Math.round(progress)}% Complete
            </span>
          </div>

          {/* Step indicators */}
          <div className="flex gap-2 mt-4">
            {steps.map((step, index) => (
              <div
                key={step.id}
                className={`flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium ${
                  index === currentStep
                    ? 'bg-primary text-primary-foreground'
                    : step.completed
                    ? 'bg-success/20 text-success'
                    : step.optional
                    ? 'bg-muted text-muted-foreground'
                    : 'bg-muted text-muted-foreground'
                }`}
              >
                {step.completed ? (
                  <CheckCircle className="h-3 w-3" />
                ) : (
                  <step.icon className="h-3 w-3" />
                )}
                {step.title}
                {step.optional && <span className="opacity-60">(Optional)</span>}
              </div>
            ))}
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Current Step Content */}
          <div className="min-h-[300px]">
            <div className="flex items-start gap-4 p-6 border rounded-lg">
              <div className="flex-shrink-0">
                {currentStepData.completed ? (
                  <CheckCircle className="h-8 w-8 text-success" />
                ) : (
                  <currentStepData.icon className="h-8 w-8 text-primary" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <h2 className="text-xl font-semibold mb-2">{currentStepData.title}</h2>
                <p className="text-muted-foreground mb-4">{currentStepData.description}</p>
                
                {currentStepData.id === 'supabase' && (
                  <div>
                    {currentStepData.completed ? (
                      <div className="flex items-center gap-2 text-success mb-4">
                        <CheckCircle className="h-5 w-5" />
                        <span className="font-medium">Supabase connection successful!</span>
                      </div>
                    ) : (
                      <Alert className="mb-4">
                        <Database className="h-4 w-4" />
                        <AlertDescription>
                          Supabase connection is required for the application to function. 
                          Make sure your environment variables are set correctly.
                        </AlertDescription>
                      </Alert>
                    )}
                    <Button
                      onClick={checkSupabaseConnection}
                      disabled={testing === 'supabase'}
                      className="mb-4"
                    >
                      {testing === 'supabase' ? (
                        <>
                          <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                          Testing Connection...
                        </>
                      ) : (
                        <>
                          <RefreshCw className="h-4 w-4 mr-2" />
                          Retry Connection
                        </>
                      )}
                    </Button>
                  </div>
                )}

                {currentStepData.id === 'mapbox' && (
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="google-maps-key">Google Maps API Key</Label>
                      <p className="text-sm text-muted-foreground mb-2">
                        Get your API key from the Google Cloud Console with Maps JavaScript API and Geocoding API enabled.
                      </p>
                      <div className="flex gap-2">
                        <Input
                          id="google-maps-key"
                          value={googleMapsKey}
                          onChange={(e) => setGoogleMapsKey(e.target.value)}
                          placeholder="AIzaSyC..."
                          className={`flex-1 ${validationErrors.mapbox ? 'border-destructive' : ''}`}
                        />
                        <Button
                          onClick={testAndSaveGoogleMapsKey}
                          disabled={!googleMapsKey || testing === 'mapbox'}
                          size="sm"
                        >
                          {testing === 'mapbox' ? (
                            <>
                              <RefreshCw className="h-3 w-3 mr-1 animate-spin" />
                              Saving...
                            </>
                          ) : (
                            'Save & Test'
                          )}
                        </Button>
                      </div>
                      {validationErrors.mapbox && (
                        <Alert variant="destructive" className="mt-2">
                          <AlertCircle className="h-4 w-4" />
                          <AlertDescription>{validationErrors.mapbox}</AlertDescription>
                        </Alert>
                      )}
                    </div>
                    
                    {!currentStepData.completed && (
                      <Alert>
                        <Key className="h-4 w-4" />
                        <AlertDescription>
                          <strong>Setup Instructions:</strong>
                          <ol className="mt-2 ml-4 list-decimal text-sm space-y-1">
                            <li>Go to <a href="https://console.cloud.google.com" target="_blank" rel="noopener" className="text-primary underline">Google Cloud Console</a></li>
                            <li>Enable the Maps JavaScript API and Geocoding API</li>
                            <li>Create credentials and copy your API key</li>
                            <li>For production, add this to your Supabase Edge Function secrets</li>
                          </ol>
                        </AlertDescription>
                      </Alert>
                    )}
                    
                    {currentStepData.completed && (
                      <div className="flex items-center gap-2 text-success">
                        <CheckCircle className="h-4 w-4" />
                        <span className="text-sm">Google Maps API key validated successfully!</span>
                      </div>
                    )}
                  </div>
                )}

                {currentStepData.id === 'skiptrace' && (
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="skiptrace-key">Free Skip Trace Service</Label>
                      <p className="text-sm text-muted-foreground mb-2">
                        Our free skip trace service uses public records and open data sources.
                      </p>
                      <div className="flex gap-2">
                        <Button
                          onClick={testSkiptraceKey}
                          disabled={testing === 'skiptrace'}
                          size="sm"
                          className="flex-1"
                        >
                          {testing === 'skiptrace' ? (
                            <>
                              <RefreshCw className="h-3 w-3 mr-1 animate-spin" />
                              Testing Free Service...
                            </>
                          ) : (
                            'Test Free Skip Trace Service'
                          )}
                        </Button>
                      </div>
                      {validationErrors.skiptrace && (
                        <Alert variant="destructive" className="mt-2">
                          <AlertCircle className="h-4 w-4" />
                          <AlertDescription>{validationErrors.skiptrace}</AlertDescription>
                        </Alert>
                      )}
                    </div>
                    
                    {!currentStepData.completed && (
                      <Alert>
                        <Key className="h-4 w-4" />
                        <AlertDescription>
                          <strong>Setup Instructions:</strong>
                          <ol className="mt-2 ml-4 list-decimal text-sm space-y-1">
                            <li>Sign up at <a href="https://skiptrace.com" target="_blank" rel="noopener" className="text-primary underline">Skiptrace.com</a></li>
                            <li>Navigate to your API settings</li>
                            <li>Generate or copy your API key</li>
                            <li>For production, add this to your Supabase Edge Function secrets</li>
                          </ol>
                        </AlertDescription>
                      </Alert>
                    )}
                    
                    {currentStepData.completed && (
                      <div className="flex items-center gap-2 text-success">
                        <CheckCircle className="h-4 w-4" />
                        <span className="text-sm">Skiptrace API key validated successfully!</span>
                      </div>
                    )}
                  </div>
                )}

                {currentStepData.id === 'sentry' && (
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="sentry-dsn">Sentry DSN (Optional)</Label>
                      <p className="text-sm text-muted-foreground mb-2">
                        Configure error monitoring with Sentry. This step is optional but recommended for production.
                      </p>
                      <div className="flex gap-2">
                         <Input
                           id="sentry-dsn"
                           value={sentryDsn}
                           onChange={(e) => setSentryDsn(e.target.value)}
                           placeholder="https://..."
                           className={`flex-1 ${validationErrors.sentry ? 'border-destructive' : ''}`}
                         />
                         <Button
                           onClick={testSentryDsn}
                           disabled={!sentryDsn || testing === 'sentry'}
                           size="sm"
                         >
                           {testing === 'sentry' ? (
                             <>
                               <RefreshCw className="h-3 w-3 mr-1 animate-spin" />
                               Testing...
                             </>
                           ) : (
                             'Test'
                           )}
                         </Button>
                       </div>
                       {validationErrors.sentry && (
                         <Alert variant="destructive" className="mt-2">
                           <AlertCircle className="h-4 w-4" />
                           <AlertDescription>{validationErrors.sentry}</AlertDescription>
                         </Alert>
                       )}
                     </div>

                     {!currentStepData.completed && (
                       <Alert>
                         <Shield className="h-4 w-4" />
                         <AlertDescription>
                           <strong>Setup Instructions:</strong>
                           <ol className="mt-2 ml-4 list-decimal text-sm space-y-1">
                             <li>Sign up at <a href="https://sentry.io" target="_blank" rel="noopener" className="text-primary underline">Sentry.io</a></li>
                             <li>Create a new project</li>
                             <li>Copy the DSN from your project settings</li>
                             <li>Optional: Skip this step if you don't need error monitoring</li>
                           </ol>
                         </AlertDescription>
                       </Alert>
                     )}
                    <Button
                      onClick={() => {
                        setSteps(prev => prev.map(step => 
                          step.id === 'sentry' ? { ...step, completed: true } : step
                        ));
                        toast.success('Sentry step skipped');
                      }}
                      variant="outline"
                      size="sm"
                    >
                      Skip Sentry Setup
                    </Button>
                    {currentStepData.completed && (
                      <div className="flex items-center gap-2 text-success">
                        <CheckCircle className="h-4 w-4" />
                        <span className="text-sm">Sentry configuration completed!</span>
                      </div>
                    )}
                  </div>
                )}

                {currentStepData.id === 'finalize' && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <Card className="p-4">
                        <h3 className="font-semibold mb-2">Configuration Summary</h3>
                        <div className="space-y-1 text-sm">
                          <div className="flex justify-between">
                            <span>Supabase:</span>
                            <span className={steps[0].completed ? 'text-success' : 'text-destructive'}>
                              {steps[0].completed ? '✓ Connected' : '✗ Failed'}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span>Google Maps:</span>
                            <span className={steps[1].completed ? 'text-success' : 'text-destructive'}>
                              {steps[1].completed ? '✓ Configured' : '✗ Missing'}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span>Skiptrace:</span>
                            <span className={steps[2].completed ? 'text-success' : 'text-destructive'}>
                              {steps[2].completed ? '✓ Configured' : '✗ Missing'}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span>Sentry:</span>
                            <span className={steps[3].completed ? 'text-success' : 'text-muted-foreground'}>
                              {steps[3].completed ? '✓ Configured' : 'Skipped'}
                            </span>
                          </div>
                        </div>
                      </Card>
                      
                      <Card className="p-4">
                        <h3 className="font-semibold mb-2">Demo Data</h3>
                        <p className="text-sm text-muted-foreground mb-3">
                          Seed the database with sample properties to get started quickly.
                        </p>
                        <Button
                          onClick={seedDemoData}
                          disabled={seedingData}
                          size="sm"
                          className="w-full"
                        >
                          {seedingData ? 'Seeding...' : 'Seed Demo Data'}
                        </Button>
                      </Card>
                    </div>
                    
                    <div className="text-center pt-4">
                      <Button
                        onClick={completeSetup}
                        disabled={!steps.slice(0, 3).every(s => s.completed)}
                        size="lg"
                      >
                        Complete Setup & Launch App
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Navigation */}
          <div className="flex justify-between items-center pt-4 border-t">
            <Button
              onClick={prevStep}
              disabled={currentStep === 0}
              variant="outline"
            >
              Previous
            </Button>
            
            <div className="flex gap-2">
              <Button
                onClick={retryConfiguration}
                variant="outline"
                size="sm"
                disabled={testing !== null}
              >
                <RefreshCw className={`h-4 w-4 mr-2 ${testing ? 'animate-spin' : ''}`} />
                Retry Config
              </Button>
              
              {currentStep < steps.length - 1 && (
                <Button
                  onClick={nextStep}
                  disabled={!canAdvance()}
                >
                  Next
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}