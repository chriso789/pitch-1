import { GoogleMap, MarkerClusterer, Marker } from '@react-google-maps/api';
import { useState, useMemo, useCallback, useEffect } from 'react';
import { useGoogleMaps } from '@/hooks/useGoogleMaps';

interface Pin {
  id: string;
  addressHash: string;
  lat: number;
  lng: number;
  flags?: any;
  consumerId?: string;
}

interface MapShellProps {
  pins: Pin[];
  onMapMoved?: (center: { lat: number; lng: number }) => void;
  onMarkerClick?: (pin: Pin) => void;
  showStormOverlay?: boolean;
  stormEventId?: string;
  apiKey: string;
}

const NOAA_TILE_URL = (eventId: string, z: number, x: number, y: number) =>
  `https://stormscdn.ngs.noaa.gov/${eventId}/${z}/${x}/${y}`;

export default function MapShell({ 
  pins, 
  onMapMoved, 
  onMarkerClick, 
  showStormOverlay = false,
  stormEventId = '20241011b-rgb',
  apiKey
}: MapShellProps) {
  const { isLoaded } = useGoogleMaps();
  
  const [map, setMap] = useState<google.maps.Map | null>(null);
  const [stormOverlay, setStormOverlay] = useState<google.maps.ImageMapType | null>(null);
  
  const center = useMemo(() => ({ lat: 27.09, lng: -82.21 }), []);

  const onLoad = useCallback((mapInstance: google.maps.Map) => {
    setMap(mapInstance);
    
    // Add initial storm overlay if enabled
    if (showStormOverlay) {
      addStormOverlay(mapInstance);
    }
  }, [showStormOverlay, stormEventId]);

  const addStormOverlay = useCallback((mapInstance: google.maps.Map) => {
    if (stormOverlay) {
      mapInstance.overlayMapTypes.removeAt(0);
    }

    const overlay = new google.maps.ImageMapType({
      tileSize: new google.maps.Size(256, 256),
      getTileUrl: ({ x, y }: google.maps.Point, z: number) => NOAA_TILE_URL(stormEventId, z, x, y),
      name: 'NOAA NGS Storm Data',
      opacity: 0.7,
      maxZoom: 19,
      minZoom: 11
    });

    mapInstance.overlayMapTypes.push(overlay);
    setStormOverlay(overlay);
  }, [stormEventId, stormOverlay]);

  const removeStormOverlay = useCallback((mapInstance: google.maps.Map) => {
    if (stormOverlay) {
      mapInstance.overlayMapTypes.removeAt(0);
      setStormOverlay(null);
    }
  }, [stormOverlay]);

  // Handle storm overlay toggle
  useEffect(() => {
    if (!map) return;

    if (showStormOverlay) {
      addStormOverlay(map);
    } else {
      removeStormOverlay(map);
    }
  }, [showStormOverlay, stormEventId, map, addStormOverlay, removeStormOverlay]);

  const onDragEnd = useCallback(() => {
    if (map && onMapMoved) {
      const center = map.getCenter();
      if (center) {
        onMapMoved({ lat: center.lat(), lng: center.lng() });
      }
    }
  }, [map, onMapMoved]);

  const onZoomChanged = useCallback(() => {
    if (map && onMapMoved) {
      const center = map.getCenter();
      if (center) {
        onMapMoved({ lat: center.lat(), lng: center.lng() });
      }
    }
  }, [map, onMapMoved]);

  if (!isLoaded) {
    return (
      <div className="h-full w-full bg-muted rounded-2xl flex items-center justify-center">
        <div className="text-muted-foreground">Loading map...</div>
      </div>
    );
  }

  return (
    <GoogleMap
      onLoad={onLoad}
      center={center}
      zoom={13}
      onDragEnd={onDragEnd}
      onZoomChanged={onZoomChanged}
      mapContainerClassName="h-full w-full rounded-2xl"
      options={{
        mapTypeControl: true,
        streetViewControl: true,
        fullscreenControl: true,
        zoomControl: true,
      }}
    >
      <MarkerClusterer>
        {(clusterer) => (
          <>
            {pins.map((pin) => (
              <Marker
                key={pin.id}
                position={{ lat: pin.lat, lng: pin.lng }}
                clusterer={clusterer}
                onClick={() => onMarkerClick?.(pin)}
                title={pin.addressHash}
              />
            ))}
          </>
        )}
      </MarkerClusterer>
    </GoogleMap>
  );
}