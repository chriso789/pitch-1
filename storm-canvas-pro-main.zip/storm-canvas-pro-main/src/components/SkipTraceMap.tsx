// Enhanced map component with skip-trace integration
import { GoogleMap, Marker, InfoWindow, DirectionsRenderer } from '@react-google-maps/api';
import { useState, useCallback, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MapPin, Phone, Mail, User, Navigation, Zap } from 'lucide-react';
import { useSkipTrace } from '@/hooks/useSkipTrace';
import { useLeads } from '@/hooks/useLeads';
import { useGoogleMapsKey } from '@/hooks/useGoogleMapsKey';
import { useGoogleMaps } from '@/hooks/useGoogleMaps';
import { toast } from 'sonner';

interface LeadPin {
  id: string;
  lat: number;
  lng: number;
  address: string;
  city?: string;
  state?: string;
  statusTitle?: string;
  frontColor?: string;
  backColor?: string;
  source?: string;
}

interface SkipTraceMapProps {
  center?: { lat: number; lng: number };
  zoom?: number;
  showStormOverlay?: boolean;
  stormEventId?: string;
  onLocationSelect?: (location: { lat: number; lng: number; address?: string }) => void;
}

const NOAA_TILE_URL = (eventId: string, z: number, x: number, y: number) =>
  `https://stormscdn.ngs.noaa.gov/${eventId}/${z}/${x}/${y}`;

export default function SkipTraceMap({
  center = { lat: 27.09, lng: -82.21 },
  zoom = 13,
  showStormOverlay = false,
  stormEventId = '20241011b-rgb',
  onLocationSelect
}: SkipTraceMapProps) {
  const { apiKey, loading: apiKeyLoading } = useGoogleMapsKey();
  const { isLoaded } = useGoogleMaps();

  const [map, setMap] = useState<google.maps.Map | null>(null);
  const [selectedLead, setSelectedLead] = useState<LeadPin | null>(null);
  const [leads, setLeads] = useState<LeadPin[]>([]);
  const [contacts, setContacts] = useState<any[]>([]);
  const [directions, setDirections] = useState<google.maps.DirectionsResult | null>(null);
  const [stormOverlay, setStormOverlay] = useState<google.maps.ImageMapType | null>(null);
  const directionsService = useRef<google.maps.DirectionsService | null>(null);

  const { runSkipTrace, getContacts, loading: skipTraceLoading } = useSkipTrace();
  const { getLeadsGeoJSON, loading: leadsLoading } = useLeads();

  // Initialize Google Maps services
  useEffect(() => {
    if (isLoaded && !directionsService.current) {
      directionsService.current = new google.maps.DirectionsService();
    }
  }, [isLoaded]);

  // Load leads when map loads or bounds change
  const loadLeads = useCallback(async () => {
    try {
      const geoJson = await getLeadsGeoJSON();
      
      const leadPins: LeadPin[] = geoJson.features.map(feature => ({
        id: feature.properties.id,
        lat: feature.geometry.coordinates[1],
        lng: feature.geometry.coordinates[0],
        address: feature.properties.address,
        city: feature.properties.city,
        state: feature.properties.state,
        statusTitle: feature.properties.status_title,
        frontColor: feature.properties.front_color,
        backColor: feature.properties.back_color,
        source: feature.properties.source
      }));

      setLeads(leadPins);
    } catch (error) {
      console.error('Error loading leads:', error);
    }
  }, [getLeadsGeoJSON]);

  useEffect(() => {
    loadLeads();
  }, [loadLeads]);

  // Load contacts when a lead is selected
  useEffect(() => {
    if (selectedLead) {
      loadContacts();
    }
  }, [selectedLead]);

  const loadContacts = async () => {
    if (!selectedLead) return;
    
    try {
      const leadContacts = await getContacts(selectedLead.id);
      setContacts(leadContacts);
    } catch (error) {
      console.error('Error loading contacts:', error);
    }
  };

  // Handle map load
  const onLoad = useCallback((mapInstance: google.maps.Map) => {
    setMap(mapInstance);
    
    // Add storm overlay if enabled
    if (showStormOverlay) {
      addStormOverlay(mapInstance);
    }
  }, [showStormOverlay, stormEventId]);

  // Storm overlay management
  const addStormOverlay = useCallback((mapInstance: google.maps.Map) => {
    if (stormOverlay) {
      mapInstance.overlayMapTypes.removeAt(0);
    }

    const overlay = new google.maps.ImageMapType({
      tileSize: new google.maps.Size(256, 256),
      getTileUrl: ({ x, y }: google.maps.Point, z: number) => NOAA_TILE_URL(stormEventId, z, x, y),
      name: 'NOAA NGS Storm Data',
      opacity: 0.7,
      maxZoom: 19,
      minZoom: 11
    });

    mapInstance.overlayMapTypes.push(overlay);
    setStormOverlay(overlay);
  }, [stormEventId, stormOverlay]);

  const removeStormOverlay = useCallback((mapInstance: google.maps.Map) => {
    if (stormOverlay) {
      mapInstance.overlayMapTypes.removeAt(0);
      setStormOverlay(null);
    }
  }, [stormOverlay]);

  useEffect(() => {
    if (!map) return;

    if (showStormOverlay) {
      addStormOverlay(map);
    } else {
      removeStormOverlay(map);
    }
  }, [showStormOverlay, stormEventId, map, addStormOverlay, removeStormOverlay]);

  // Handle marker click
  const handleMarkerClick = useCallback((lead: LeadPin) => {
    setSelectedLead(lead);
    setDirections(null); // Clear any existing directions
    
    if (onLocationSelect) {
      onLocationSelect({
        lat: lead.lat,
        lng: lead.lng,
        address: lead.address
      });
    }
  }, [onLocationSelect]);

  // Handle skip-trace
  const handleSkipTrace = async () => {
    if (!selectedLead) return;

    try {
      await runSkipTrace({
        leadId: selectedLead.id,
        address: selectedLead.address,
        lat: selectedLead.lat,
        lng: selectedLead.lng
      });
      
      // Reload contacts after skip-trace
      await loadContacts();
    } catch (error) {
      console.error('Skip-trace error:', error);
    }
  };

  // Handle directions
  const handleGetDirections = async () => {
    if (!selectedLead || !map || !directionsService.current) return;

    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const origin = new google.maps.LatLng(
            position.coords.latitude,
            position.coords.longitude
          );
          const destination = new google.maps.LatLng(selectedLead.lat, selectedLead.lng);

          try {
            const result = await directionsService.current!.route({
              origin,
              destination,
              travelMode: google.maps.TravelMode.DRIVING
            });
            setDirections(result);
          } catch (error) {
            console.error('Directions error:', error);
            toast.error('Failed to get directions');
          }
        },
        (error) => {
          console.error('Geolocation error:', error);
          toast.error('Unable to get your location');
        }
      );
    } else {
      toast.error('Geolocation not supported');
    }
  };

  // Create marker icon based on lead status
  const createMarkerIcon = (lead: LeadPin) => ({
    path: google.maps.SymbolPath.CIRCLE,
    scale: 8,
    fillColor: lead.backColor || '#cc0000',
    fillOpacity: 1,
    strokeColor: lead.frontColor || '#ffffff',
    strokeWeight: 2
  });

  if (apiKeyLoading || !isLoaded) {
    return (
      <div className="h-full w-full bg-muted rounded-2xl flex items-center justify-center">
        <div className="text-muted-foreground">Loading map...</div>
      </div>
    );
  }

  if (!apiKey) {
    return (
      <div className="h-full w-full bg-muted rounded-2xl flex items-center justify-center">
        <div className="text-center">
          <div className="text-muted-foreground mb-2">Google Maps API key not configured</div>
          <Button size="sm" onClick={() => window.location.href = '/auth'}>
            Configure API Key
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="relative h-full w-full">
      <GoogleMap
        onLoad={onLoad}
        center={center}
        zoom={zoom}
        mapContainerClassName="h-full w-full rounded-2xl"
        options={{
          mapTypeControl: true,
          streetViewControl: true,
          fullscreenControl: true,
          zoomControl: true,
        }}
      >
        {/* Render lead markers */}
        {leads.map((lead) => (
          <Marker
            key={lead.id}
            position={{ lat: lead.lat, lng: lead.lng }}
            icon={createMarkerIcon(lead)}
            title={`${lead.statusTitle || 'Lead'} - ${lead.address}`}
            onClick={() => handleMarkerClick(lead)}
          />
        ))}

        {/* Show info window for selected lead */}
        {selectedLead && (
          <InfoWindow
            position={{ lat: selectedLead.lat, lng: selectedLead.lng }}
            onCloseClick={() => setSelectedLead(null)}
          >
            <Card className="w-80 p-4 border-none shadow-none">
              <div className="space-y-3">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-semibold flex items-center gap-2">
                      <MapPin className="h-4 w-4" />
                      {selectedLead.address}
                    </h3>
                    {selectedLead.city && selectedLead.state && (
                      <p className="text-sm text-muted-foreground">
                        {selectedLead.city}, {selectedLead.state}
                      </p>
                    )}
                  </div>
                  {selectedLead.statusTitle && (
                    <Badge variant="outline" style={{ backgroundColor: selectedLead.backColor, color: selectedLead.frontColor }}>
                      {selectedLead.statusTitle}
                    </Badge>
                  )}
                </div>

                {/* Contacts */}
                {contacts.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium">Contacts:</h4>
                    {contacts.slice(0, 3).map((contact, index) => (
                      <div key={index} className="text-sm space-y-1">
                        {contact.name && (
                          <div className="flex items-center gap-2">
                            <User className="h-3 w-3" />
                            {contact.name}
                          </div>
                        )}
                        {contact.phone && (
                          <div className="flex items-center gap-2">
                            <Phone className="h-3 w-3" />
                            <a href={`tel:${contact.phone}`} className="text-primary hover:underline">
                              {contact.phone}
                            </a>
                          </div>
                        )}
                        {contact.email && (
                          <div className="flex items-center gap-2">
                            <Mail className="h-3 w-3" />
                            <a href={`mailto:${contact.email}`} className="text-primary hover:underline">
                              {contact.email}
                            </a>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                {/* Actions */}
                <div className="flex gap-2 pt-2">
                  <Button
                    size="sm"
                    onClick={handleSkipTrace}
                    disabled={skipTraceLoading}
                    className="flex items-center gap-1"
                  >
                    <Zap className="h-3 w-3" />
                    {skipTraceLoading ? 'Running...' : 'Skip Trace'}
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleGetDirections}
                    className="flex items-center gap-1"
                  >
                    <Navigation className="h-3 w-3" />
                    Directions
                  </Button>
                </div>
              </div>
            </Card>
          </InfoWindow>
        )}

        {/* Show directions */}
        {directions && (
          <DirectionsRenderer
            directions={directions}
            options={{
              suppressMarkers: true
            }}
          />
        )}
      </GoogleMap>
    </div>
  );
}