import React from 'react';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin, Phone, Mail, User } from "lucide-react";

interface PropertyInfo {
  id: string;
  address: string;
  homeowner_name?: string;
  phone?: string;
  email?: string;
  disposition?: string;
  disposition_color?: string;
}

interface PropertyInfoWindowProps {
  property: PropertyInfo;
  onStatusClick: () => void;
}

export function PropertyInfoWindow({ property, onStatusClick }: PropertyInfoWindowProps) {
  return (
    <div className="p-3 min-w-[280px] max-w-[320px]">
      <div className="flex items-start justify-between mb-2">
        <div className="flex-1 min-w-0">
          <h3 className="font-medium text-sm leading-tight mb-1 text-gray-900">
            <MapPin className="h-3 w-3 inline mr-1" />
            {property.address}
          </h3>
        </div>
      </div>
      
      {property.homeowner_name && (
        <div className="flex items-center gap-1 text-xs text-gray-600 mb-1">
          <User className="h-3 w-3" />
          <span>{property.homeowner_name}</span>
        </div>
      )}
      
      {property.phone && (
        <div className="flex items-center gap-1 text-xs text-gray-600 mb-1">
          <Phone className="h-3 w-3" />
          <span>{property.phone}</span>
        </div>
      )}
      
      {property.email && (
        <div className="flex items-center gap-1 text-xs text-gray-600 mb-2">
          <Mail className="h-3 w-3" />
          <span className="truncate">{property.email}</span>
        </div>
      )}
      
      <div className="flex items-center justify-between pt-2 border-t">
        {property.disposition ? (
          <Badge 
            className="text-xs px-2 py-1 cursor-pointer hover:opacity-80"
            style={{ 
              backgroundColor: property.disposition_color || '#9ca3af',
              color: 'white'
            }}
            onClick={onStatusClick}
          >
            {property.disposition}
          </Badge>
        ) : (
          <Badge 
            variant="outline" 
            className="text-xs px-2 py-1 cursor-pointer hover:bg-gray-50"
            onClick={onStatusClick}
          >
            Set Status
          </Badge>
        )}
        
        <Button 
          size="sm" 
          variant="outline" 
          className="text-xs h-6 px-2"
          onClick={onStatusClick}
        >
          Update
        </Button>
      </div>
    </div>
  );
}