import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Ruler, Wand2, Pencil, Loader2 } from 'lucide-react';
import { useMeasurements } from '@/hooks/useMeasurements';
import { RoofMeasurementTools } from './RoofMeasurementTools';
import type { LinearFeature } from '@/lib/measure/types';

interface MeasurePanelProps {
  addressHash: string | null;
  address?: any;
  lat?: number;
  lng?: number;
}

export default function MeasurePanel({ addressHash, address, lat, lng }: MeasurePanelProps) {
  const [mode, setMode] = useState<'idle' | 'manual'>('idle');
  
  const { latestMeasurement, saveManual, autoMeasure } = useMeasurements(addressHash);

  const handleAutoMeasure = async () => {
    if (!addressHash) return;
    
    await autoMeasure.mutateAsync({
      propertyId: addressHash,
      address,
      lat,
      lng,
      waste_pct: 12,
    });
  };

  const handleStartManual = () => {
    setMode('manual');
  };

  const handleMeasurementComplete = async (data: {
    faces: any[];
    linear_features: LinearFeature[];
    waste_pct: number;
  }) => {
    if (!addressHash) return;

    await saveManual.mutateAsync({
      propertyId: addressHash,
      faces: data.faces,
      linear_features: data.linear_features,
      waste_pct: data.waste_pct,
    });

    setMode('idle');
  };

  const handleCancelManual = () => {
    setMode('idle');
  };

  return (
    <Card className="p-4 border rounded-2xl bg-background">
      <div className="flex items-center gap-2 mb-4">
        <Ruler className="h-4 w-4" />
        <h3 className="font-semibold">Roof Measure</h3>
      </div>

      <div className="space-y-4">
        {mode === 'idle' && (
          <>
            <div className="grid grid-cols-2 gap-2">
              <Button 
                onClick={handleAutoMeasure}
                disabled={!addressHash || autoMeasure.isPending}
                variant="outline"
              >
                {autoMeasure.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Auto...
                  </>
                ) : (
                  <>
                    <Wand2 className="h-4 w-4 mr-2" />
                    Auto
                  </>
                )}
              </Button>
              
              <Button 
                onClick={handleStartManual}
                disabled={!addressHash}
                variant="outline"
              >
                <Pencil className="h-4 w-4 mr-2" />
                Manual
              </Button>
            </div>

            {latestMeasurement && (
              <>
                <Separator />
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Source:</span>
                    <span className="font-medium capitalize">{latestMeasurement.source}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Area:</span>
                    <span className="font-medium">
                      {latestMeasurement.summary.total_area_sqft.toFixed(0)} sqft
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Squares:</span>
                    <span className="font-medium">
                      {latestMeasurement.summary.total_squares.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Faces:</span>
                    <span className="font-medium">{latestMeasurement.faces.length}</span>
                  </div>
                  {latestMeasurement.linear_features && latestMeasurement.linear_features.length > 0 && (
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Linear:</span>
                      <span className="font-medium">
                        {latestMeasurement.linear_features.reduce((sum, f) => sum + f.length_ft, 0).toFixed(1)} ft
                      </span>
                    </div>
                  )}
                </div>
              </>
            )}
          </>
        )}

        {mode === 'manual' && (
          <RoofMeasurementTools
            onComplete={handleMeasurementComplete}
            onCancel={handleCancelManual}
          />
        )}
      </div>
    </Card>
  );
}
