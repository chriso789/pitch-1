import React from 'react';
import { 
  Home, 
  Cloud, 
  CheckCircle2, 
  FileSignature, 
  FileCheck, 
  Trophy,
  XCircle, 
  ThumbsUp, 
  ThumbsDown, 
  Sun, 
  HomeIcon,
  Calendar
} from "lucide-react";
import type { Disposition } from "@/hooks/useCanvassing";

interface HeaderDispositionButtonsProps {
  dispositions: Disposition[];
  selectedStatus?: string;
  onStatusChange: (dispositionId: string) => void;
  loading?: boolean;
}

const getStatusIcon = (name: string) => {
  const iconMap: Record<string, typeof Home> = {
    'Old Roof Marketing': Home,
    'Storm Damage': Cloud,
    'New Roof': CheckCircle2,
    'Signed Contingency': FileSignature,
    'Signed Contract': FileCheck,
    'Project Completed': Trophy,
    'Unqualified': XCircle,
    'Interested': ThumbsUp,
    'Not Interested': ThumbsDown,
    'Already Solar': Sun,
    'Abandoned House': HomeIcon,
    'Go Back': Calendar,
  };
  return iconMap[name] || Home;
};

export function HeaderDispositionButtons({ 
  dispositions, 
  selectedStatus, 
  onStatusChange, 
  loading 
}: HeaderDispositionButtonsProps) {
  return (
    <div className="bg-background/95 backdrop-blur rounded-lg shadow-lg p-3">
      <div className="flex gap-2 overflow-x-auto scrollbar-thin scrollbar-thumb-muted scrollbar-track-transparent">
        {dispositions.map((disposition) => {
          const Icon = getStatusIcon(disposition.name);
          const isSelected = selectedStatus === disposition.id;
          
          return (
            <button
              key={disposition.id}
              onClick={() => onStatusChange(disposition.id)}
              disabled={loading}
              className="flex flex-col items-center justify-center min-w-[80px] p-2 rounded-lg transition-all hover:scale-105 disabled:opacity-50"
              style={{
                borderWidth: '2px',
                borderStyle: 'solid',
                borderColor: isSelected ? disposition.color : `${disposition.color}60`,
                backgroundColor: isSelected ? `${disposition.color}20` : 'transparent',
              }}
            >
              <div className="relative">
                <Icon 
                  className="h-6 w-6 mb-1" 
                  style={{ color: disposition.color }}
                />
                {((disposition as any).sync_to_pitch || (disposition as any).requires_appointment) && (
                  <div className="absolute -top-1 -right-1 flex gap-0.5">
                    {(disposition as any).sync_to_pitch && (
                      <span className="text-[10px]">⭐</span>
                    )}
                    {(disposition as any).requires_appointment && (
                      <span className="text-[10px]">📅</span>
                    )}
                  </div>
                )}
              </div>
              <span 
                className="text-[10px] font-medium text-center leading-tight"
                style={{ color: isSelected ? disposition.color : 'inherit' }}
              >
                {disposition.name}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
