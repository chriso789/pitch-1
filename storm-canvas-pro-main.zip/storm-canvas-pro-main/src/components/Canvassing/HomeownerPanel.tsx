import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { User, RefreshCw, MapPin } from 'lucide-react';
interface LocationDetails {
  addressHash: string;
  owner?: { name?: string };
  parcel?: { apn?: string; wkt?: string };
  lastVisits: any[];
  dispositions: any[];
  photos: Array<{
    id: string;
    key: string;
    url: string;
    created_at: string;
  }>;
}

interface HomeownerPanelProps {
  addressHash: string | null;
  details: LocationDetails | null;
  onRefresh: () => void;
}

export default function HomeownerPanel({
  addressHash,
  details,
  onRefresh
}: HomeownerPanelProps) {
  if (!addressHash) {
    return (
      <Card className="p-4 border rounded-2xl bg-background">
        <div className="flex items-center justify-center text-center py-8">
          <div className="text-muted-foreground">
            <MapPin className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p className="text-sm">Select a property on the map to view homeowner details</p>
          </div>
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-4 border rounded-2xl bg-background">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold flex items-center gap-2">
          <User className="h-4 w-4" />
          Homeowner
        </h3>
        <Button size="sm" variant="outline" onClick={onRefresh}>
          <RefreshCw className="h-4 w-4" />
        </Button>
      </div>

      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Address Hash:</span>
          <span className="text-sm font-mono bg-muted px-2 py-1 rounded text-xs">
            {details?.addressHash || addressHash}
          </span>
        </div>

        <Separator />

        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Owner:</span>
          <span className="text-sm font-medium">
            {details?.owner?.name || 'Unknown'}
          </span>
        </div>

        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">APN:</span>
          <span className="text-sm">
            {details?.parcel?.apn || '—'}
          </span>
        </div>

        {details?.lastVisits && details.lastVisits.length > 0 && (
          <div>
            <div className="text-sm text-muted-foreground mb-2">Recent Visits:</div>
            <div className="text-xs bg-muted p-2 rounded">
              {details.lastVisits.length} visit(s) recorded
            </div>
          </div>
        )}
      </div>
    </Card>
  );
}