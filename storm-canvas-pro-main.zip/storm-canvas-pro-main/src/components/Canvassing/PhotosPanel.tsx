import React, { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { FileImage, Upload, Loader2 } from 'lucide-react';
import { usePhotoUpload } from '@/hooks/usePhotoUpload';
import { toast } from 'sonner';

interface PhotosPanelProps {
  addressHash: string | null;
}

interface Photo {
  id: string;
  key: string;
  url: string;
  created_at: string;
}

export default function PhotosPanel({ addressHash }: PhotosPanelProps) {
  const [busy, setBusy] = useState(false);
  const [feed, setFeed] = useState<Photo[]>([]);
  const { uploadPhoto, getPhotoFeed } = usePhotoUpload();

  const loadFeed = async () => {
    if (!addressHash) return;
    
    try {
      const result = await getPhotoFeed(addressHash);
      setFeed(result.data || []);
    } catch (error) {
      console.error('Error loading photo feed:', error);
    }
  };

  useEffect(() => {
    loadFeed();
  }, [addressHash]);

  const onFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!addressHash) return;
    
    const file = e.target.files?.[0];
    if (!file) return;

    setBusy(true);
    try {
      await uploadPhoto({
        propertyId: addressHash,
        file,
        createdBy: addressHash // Placeholder - should use actual user ID
      });
      
      await loadFeed();
      toast.success('Photo uploaded successfully');
    } catch (error) {
      console.error('Error uploading photo:', error);
      toast.error('Failed to upload photo');
    } finally {
      setBusy(false);
    }

    // Reset the input
    e.target.value = '';
  };

  return (
    <Card className="p-4 border rounded-2xl bg-background">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <FileImage className="h-4 w-4" />
          <h3 className="font-semibold">Photos</h3>
          <span className="text-xs text-muted-foreground">({feed.length})</span>
        </div>
        
        <label className="cursor-pointer">
          <Button size="sm" variant="outline" disabled={busy || !addressHash} asChild>
            <span>
              {busy ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Upload className="h-4 w-4" />
              )}
            </span>
          </Button>
          <input
            type="file"
            accept="image/*"
            onChange={onFileSelect}
            className="sr-only"
            disabled={busy || !addressHash}
          />
        </label>
      </div>

      <Separator className="mb-4" />

      <div className="space-y-3">
        {feed.length > 0 ? (
          <div className="grid grid-cols-3 gap-2">
            {feed.slice(0, 9).map((photo) => (
              <div key={photo.id} className="aspect-square bg-muted rounded-lg overflow-hidden">
                <img
                  src={photo.url}
                  alt="Property photo"
                  className="w-full h-full object-cover"
                />
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-6">
            <FileImage className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p className="text-xs text-muted-foreground">No photos yet</p>
          </div>
        )}

        <Button
          variant="outline"
          className="w-full"
          disabled={busy || !addressHash}
          asChild
        >
          <label className="cursor-pointer">
            {busy ? 'Uploading…' : 'Add Photos'}
            <input
              type="file"
              accept="image/*"
              multiple
              onChange={onFileSelect}
              className="sr-only"
              disabled={busy || !addressHash}
            />
          </label>
        </Button>
      </div>
    </Card>
  );
}