import React, { useEffect, useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Ruler, Pentagon, Minus, Trash2, Edit2 } from 'lucide-react';
import { bus, EVT_POLY_CREATED, EVT_LINE_CREATED, EVT_MEASURE_MODE } from '@/lib/eventBus';
import { toast } from 'sonner';
import { PITCH_FACTORS, pitchFactor, applyWaste } from '@/lib/measure/util';
import type { RoofFace, LinearFeature, EdgeType } from '@/lib/measure/types';

interface RoofMeasurementToolsProps {
  onComplete: (data: {
    faces: RoofFace[];
    linear_features: LinearFeature[];
    waste_pct: number;
  }) => void;
  onCancel: () => void;
}

const EDGE_TYPES: { value: EdgeType; label: string }[] = [
  { value: 'ridge', label: 'Ridge' },
  { value: 'hip', label: 'Hip' },
  { value: 'valley', label: 'Valley' },
  { value: 'eave', label: 'Eave' },
  { value: 'rake', label: 'Rake' },
  { value: 'wall_flashing', label: 'Wall Flashing' },
  { value: 'step_flashing', label: 'Step Flashing' },
  { value: 'other', label: 'Other' },
];

export function RoofMeasurementTools({ onComplete, onCancel }: RoofMeasurementToolsProps) {
  const [drawMode, setDrawMode] = useState<'face' | 'line'>('face');
  const [currentPitch, setCurrentPitch] = useState<string>('6/12');
  const [wastePct, setWastePct] = useState<number>(12);
  const [currentEdgeType, setCurrentEdgeType] = useState<EdgeType>('ridge');
  const [currentLabel, setCurrentLabel] = useState<string>('');
  const [faces, setFaces] = useState<RoofFace[]>([]);
  const [linearFeatures, setLinearFeatures] = useState<LinearFeature[]>([]);
  const [editingFeature, setEditingFeature] = useState<{ type: 'face' | 'line'; id: string } | null>(null);

  // Listen for polygon (face) creation
  useEffect(() => {
    const unsubscribe = bus.on(EVT_POLY_CREATED, (payload: { 
      path: { lat: number; lng: number }[]; 
      areaSqft: number; 
      wkt: string 
    }) => {
      if (drawMode !== 'face') return;

      const factor = pitchFactor(currentPitch);
      const adjustedArea = applyWaste(payload.areaSqft * factor, wastePct);

      const face: RoofFace = {
        id: String.fromCharCode(65 + faces.length),
        wkt: payload.wkt,
        area_sqft: adjustedArea,
        pitch: currentPitch,
        linear_features: [],
      };

      setFaces(prev => [...prev, face]);
      toast.success(`Face ${face.id} added: ${adjustedArea.toFixed(0)} sqft (${currentPitch} pitch)`);
    });

    return unsubscribe;
  }, [drawMode, currentPitch, wastePct, faces.length]);

  // Listen for line creation
  useEffect(() => {
    const unsubscribe = bus.on(EVT_LINE_CREATED, (payload: {
      path: { lat: number; lng: number }[];
      lengthFt: number;
      wkt: string;
    }) => {
      if (drawMode !== 'line') return;

      const feature: LinearFeature = {
        id: `L${linearFeatures.length + 1}`,
        wkt: payload.wkt,
        length_ft: payload.lengthFt,
        type: currentEdgeType,
        label: currentLabel || undefined,
      };

      setLinearFeatures(prev => [...prev, feature]);
      toast.success(`${EDGE_TYPES.find(t => t.value === currentEdgeType)?.label}: ${payload.lengthFt.toFixed(1)} ft`);
      setCurrentLabel('');
    });

    return unsubscribe;
  }, [drawMode, currentEdgeType, currentLabel, linearFeatures.length]);

  // Emit mode changes to map component
  useEffect(() => {
    bus.emit(EVT_MEASURE_MODE, { mode: drawMode });
  }, [drawMode]);

  const handleComplete = () => {
    if (faces.length === 0) {
      toast.error('Draw at least one roof face');
      return;
    }
    onComplete({ faces, linear_features: linearFeatures, waste_pct: wastePct });
  };

  const deleteFace = (id: string) => {
    setFaces(prev => prev.filter(f => f.id !== id));
    toast.info(`Face ${id} removed`);
  };

  const deleteLinearFeature = (id: string) => {
    setLinearFeatures(prev => prev.filter(f => f.id !== id));
    toast.info('Linear feature removed');
  };

  const totalArea = faces.reduce((sum, f) => sum + f.area_sqft, 0);
  const totalSquares = totalArea / 100;

  return (
    <Card className="p-4 border rounded-2xl bg-background">
      <div className="space-y-4">
        {/* Mode Selector */}
        <div className="flex gap-2">
          <Button
            variant={drawMode === 'face' ? 'default' : 'outline'}
            onClick={() => setDrawMode('face')}
            className="flex-1"
            size="sm"
          >
            <Pentagon className="h-4 w-4 mr-2" />
            Roof Face
          </Button>
          <Button
            variant={drawMode === 'line' ? 'default' : 'outline'}
            onClick={() => setDrawMode('line')}
            className="flex-1"
            size="sm"
          >
            <Minus className="h-4 w-4 mr-2" />
            Linear
          </Button>
        </div>

        <Separator />

        {/* Face Mode Controls */}
        {drawMode === 'face' && (
          <div className="space-y-3">
            <div>
              <Label className="text-sm">Pitch</Label>
              <Select value={currentPitch} onValueChange={setCurrentPitch}>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.keys(PITCH_FACTORS).map(p => (
                    <SelectItem key={p} value={p}>{p}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-sm">Waste %</Label>
              <Select value={String(wastePct)} onValueChange={v => setWastePct(Number(v))}>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="10">10%</SelectItem>
                  <SelectItem value="12">12%</SelectItem>
                  <SelectItem value="15">15%</SelectItem>
                  <SelectItem value="20">20%</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="text-xs text-muted-foreground p-2 bg-muted/50 rounded">
              Click map to draw roof face polygon. Click first point to close.
            </div>
          </div>
        )}

        {/* Line Mode Controls */}
        {drawMode === 'line' && (
          <div className="space-y-3">
            <div>
              <Label className="text-sm">Edge Type</Label>
              <Select value={currentEdgeType} onValueChange={(v) => setCurrentEdgeType(v as EdgeType)}>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {EDGE_TYPES.map(type => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-sm">Label (optional)</Label>
              <Input
                value={currentLabel}
                onChange={(e) => setCurrentLabel(e.target.value)}
                placeholder="e.g., North ridge"
                className="mt-1"
              />
            </div>

            <div className="text-xs text-muted-foreground p-2 bg-muted/50 rounded">
              Click map to draw line. Double-click to finish.
            </div>
          </div>
        )}

        <Separator />

        {/* Faces List */}
        {faces.length > 0 && (
          <div className="space-y-2">
            <div className="text-sm font-medium">Roof Faces ({faces.length})</div>
            {faces.map(face => (
              <div key={face.id} className="flex items-center justify-between text-sm p-2 bg-muted/30 rounded">
                <div className="flex-1">
                  <div className="font-medium">Face {face.id}</div>
                  <div className="text-xs text-muted-foreground">
                    {face.area_sqft.toFixed(0)} sqft • {face.pitch}
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => deleteFace(face.id)}
                  className="h-7 w-7 p-0"
                >
                  <Trash2 className="h-3 w-3" />
                </Button>
              </div>
            ))}
            <div className="flex justify-between text-sm font-medium pt-2 border-t">
              <span>Total:</span>
              <span>{totalSquares.toFixed(2)} squares ({totalArea.toFixed(0)} sqft)</span>
            </div>
          </div>
        )}

        {/* Linear Features List */}
        {linearFeatures.length > 0 && (
          <div className="space-y-2">
            <div className="text-sm font-medium">Linear Features ({linearFeatures.length})</div>
            {linearFeatures.map(feature => (
              <div key={feature.id} className="flex items-center justify-between text-sm p-2 bg-muted/30 rounded">
                <div className="flex-1">
                  <div className="font-medium">
                    {EDGE_TYPES.find(t => t.value === feature.type)?.label}
                    {feature.label && ` - ${feature.label}`}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {feature.length_ft.toFixed(1)} ft
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => deleteLinearFeature(feature.id)}
                  className="h-7 w-7 p-0"
                >
                  <Trash2 className="h-3 w-3" />
                </Button>
              </div>
            ))}
            <div className="flex justify-between text-sm font-medium pt-2 border-t">
              <span>Total Linear:</span>
              <span>{linearFeatures.reduce((sum, f) => sum + f.length_ft, 0).toFixed(1)} ft</span>
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-2 pt-2">
          <Button
            onClick={handleComplete}
            disabled={faces.length === 0}
            className="flex-1"
          >
            <Ruler className="h-4 w-4 mr-2" />
            Save Measurement
          </Button>
          <Button
            onClick={onCancel}
            variant="outline"
          >
            Cancel
          </Button>
        </div>
      </div>
    </Card>
  );
}
