import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { FileText, ExternalLink, Loader2 } from 'lucide-react';
import { useProposals } from '@/hooks/useProposals';
import { toast } from 'sonner';

interface ReportsPanelProps {
  addressHash: string | null;
}

export default function ReportsPanel({ addressHash }: ReportsPanelProps) {
  const [link, setLink] = useState<string | undefined>();
  const [busy, setBusy] = useState(false);
  const { generateProposal } = useProposals();

  const onGenerate = async () => {
    if (!addressHash) return;

    setBusy(true);
    try {
      const result = await generateProposal({
        propertyId: addressHash,
        proposalType: 'hail',
        customerName: 'Property Owner',
        designId: 'default',
        notes: 'Generated from canvassing'
      });
      
      if (result.url) {
        setLink(result.url);
        toast.success('Proposal generated successfully');
      } else {
        toast.error('Proposal generated but no URL returned');
      }
    } catch (error) {
      console.error('Error generating proposal:', error);
      toast.error('Failed to generate proposal');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card className="p-4 border rounded-2xl bg-background">
      <div className="flex items-center gap-2 mb-4">
        <FileText className="h-4 w-4" />
        <h3 className="font-semibold">Reports</h3>
      </div>

      <div className="space-y-4">
        <Button
          className="w-full"
          onClick={onGenerate}
          disabled={busy || !addressHash}
        >
          {busy ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Building…
            </>
          ) : (
            <>
              <FileText className="h-4 w-4 mr-2" />
              Generate Proposal
            </>
          )}
        </Button>

        {link && (
          <>
            <Separator />
            <a
              href={link}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-2 text-sm text-primary hover:underline"
            >
              <ExternalLink className="h-4 w-4" />
              Open PDF Report
            </a>
          </>
        )}

        <div className="text-xs text-muted-foreground text-center">
          Generate professional proposals for property owners
        </div>
      </div>
    </Card>
  );
}