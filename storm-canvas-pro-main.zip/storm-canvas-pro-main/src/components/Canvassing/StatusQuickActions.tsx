import React from 'react';
import { 
  Home, 
  Cloud, 
  CheckCircle2, 
  FileSignature, 
  FileCheck, 
  Trophy,
  XCircle, 
  ThumbsUp, 
  ThumbsDown, 
  Sun, 
  HomeIcon,
  Calendar
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { Disposition } from "@/hooks/useCanvassing";

interface StatusQuickActionsProps {
  dispositions: Disposition[];
  selectedStatus?: string;
  onStatusChange: (dispositionId: string) => void;
  loading?: boolean;
}

// Icon mapping for dispositions
const getStatusIcon = (name: string) => {
  const iconMap: Record<string, typeof Home> = {
    'Old Roof Marketing': Home,
    'Storm Damage': Cloud,
    'New Roof': CheckCircle2,
    'Signed Contingency': FileSignature,
    'Signed Contract': FileCheck,
    'Project Completed': Trophy,
    'Unqualified': XCircle,
    'Interested': ThumbsUp,
    'Not Interested': ThumbsDown,
    'Already Solar': Sun,
    'Abandoned House': HomeIcon,
    'Go Back': Calendar,
  };
  return iconMap[name] || Home;
};


export function StatusQuickActions({ 
  dispositions, 
  selectedStatus, 
  onStatusChange, 
  loading 
}: StatusQuickActionsProps) {
  
  return (
    <div className="flex flex-wrap gap-3 p-2">
      {dispositions.map((disposition) => {
        const Icon = getStatusIcon(disposition.name);
        const isSelected = selectedStatus === disposition.id;
        
        return (
          <button
            key={disposition.id}
            onClick={() => onStatusChange(disposition.id)}
            disabled={loading}
            className={cn(
              "flex flex-col items-center gap-1.5 min-w-[70px] group transition-all",
              loading && "opacity-50 cursor-not-allowed"
            )}
          >
            <div
              className={cn(
                "relative w-12 h-12 rounded-full flex items-center justify-center transition-all",
                "border-2",
                isSelected 
                  ? "scale-110 shadow-lg" 
                  : "hover:scale-105"
              )}
              style={{
                borderColor: disposition.color,
                backgroundColor: isSelected ? disposition.color : `${disposition.color}20`,
              }}
            >
              <Icon 
                className="w-5 h-5" 
                style={{ 
                  color: isSelected ? '#ffffff' : disposition.color 
                }} 
              />
              
              {/* Badges */}
              {((disposition as any).sync_to_pitch || (disposition as any).requires_appointment) && (
                <div className="absolute -top-1 -right-1 flex gap-0.5">
                  {(disposition as any).sync_to_pitch && (
                    <span className="text-xs">⭐</span>
                  )}
                  {(disposition as any).requires_appointment && (
                    <span className="text-xs">📅</span>
                  )}
                </div>
              )}
            </div>
            
            <span 
              className={cn(
                "text-xs text-center leading-tight max-w-[70px] transition-colors",
                isSelected 
                  ? "font-semibold text-foreground" 
                  : "font-medium text-muted-foreground group-hover:text-foreground"
              )}
            >
              {disposition.name}
            </span>
          </button>
        );
      })}
    </div>
  );
}
