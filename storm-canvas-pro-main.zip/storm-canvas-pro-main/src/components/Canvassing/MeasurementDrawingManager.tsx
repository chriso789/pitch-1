import { useEffect, useRef, useState } from 'react';
import { bus, EVT_POLY_CREATED, EVT_LINE_CREATED, EVT_MEASURE_MODE } from '@/lib/eventBus';

interface MeasurementDrawingManagerProps {
  map: google.maps.Map | null;
}

export function MeasurementDrawingManager({ map }: MeasurementDrawingManagerProps) {
  const drawingManagerRef = useRef<google.maps.drawing.DrawingManager | null>(null);
  const currentPolylineRef = useRef<google.maps.Polyline | null>(null);
  const [mode, setMode] = useState<'face' | 'line'>('face');

  // Listen for mode changes
  useEffect(() => {
    const unsubscribe = bus.on(EVT_MEASURE_MODE, (payload: { mode: 'face' | 'line' }) => {
      setMode(payload.mode);
    });
    return unsubscribe;
  }, []);

  useEffect(() => {
    if (!map || !window.google) return;

    // Create drawing manager
    const drawingManager = new google.maps.drawing.DrawingManager({
      drawingMode: null,
      drawingControl: false,
      polygonOptions: {
        fillColor: '#3b82f6',
        fillOpacity: 0.3,
        strokeColor: '#3b82f6',
        strokeWeight: 2,
        clickable: true,
        editable: false,
        zIndex: 1,
      },
      polylineOptions: {
        strokeColor: '#ef4444',
        strokeWeight: 3,
        clickable: true,
        editable: false,
        zIndex: 1,
      },
    });

    drawingManager.setMap(map);
    drawingManagerRef.current = drawingManager;

    // Handle polygon completion
    google.maps.event.addListener(drawingManager, 'polygoncomplete', (polygon: google.maps.Polygon) => {
      const path = polygon.getPath();
      const coords = path.getArray();

      // Calculate area
      const areaSqMeters = google.maps.geometry.spherical.computeArea(path);
      const areaSqft = areaSqMeters * 10.7639;

      // Create WKT
      const wkt = `POLYGON((${coords.map(c => `${c.lng()} ${c.lat()}`).join(', ')}, ${coords[0].lng()} ${coords[0].lat()}))`;

      bus.emit(EVT_POLY_CREATED, {
        path: coords.map(c => ({ lat: c.lat(), lng: c.lng() })),
        areaSqft,
        wkt,
      });

      // Remove polygon after event
      polygon.setMap(null);
      
      // Stay in drawing mode
      drawingManager.setDrawingMode(google.maps.drawing.OverlayType.POLYGON);
    });

    // Handle polyline completion
    google.maps.event.addListener(drawingManager, 'polylinecomplete', (polyline: google.maps.Polyline) => {
      const path = polyline.getPath();
      const coords = path.getArray();

      // Calculate length
      let lengthMeters = 0;
      for (let i = 0; i < coords.length - 1; i++) {
        lengthMeters += google.maps.geometry.spherical.computeDistanceBetween(coords[i], coords[i + 1]);
      }
      const lengthFt = lengthMeters * 3.28084;

      // Create WKT
      const wkt = `LINESTRING(${coords.map(c => `${c.lng()} ${c.lat()}`).join(', ')})`;

      bus.emit(EVT_LINE_CREATED, {
        path: coords.map(c => ({ lat: c.lat(), lng: c.lng() })),
        lengthFt,
        wkt,
      });

      // Remove polyline after event
      polyline.setMap(null);
      
      // Stay in drawing mode
      drawingManager.setDrawingMode(google.maps.drawing.OverlayType.POLYLINE);
    });

    return () => {
      if (drawingManagerRef.current) {
        drawingManagerRef.current.setMap(null);
      }
    };
  }, [map]);

  // Update drawing mode based on measurement mode
  useEffect(() => {
    if (!drawingManagerRef.current) return;

    if (mode === 'face') {
      drawingManagerRef.current.setDrawingMode(google.maps.drawing.OverlayType.POLYGON);
    } else if (mode === 'line') {
      drawingManagerRef.current.setDrawingMode(google.maps.drawing.OverlayType.POLYLINE);
    }
  }, [mode]);

  return null; // This component doesn't render anything
}
