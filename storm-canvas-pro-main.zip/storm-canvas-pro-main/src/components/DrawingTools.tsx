import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { bus, EVT_POLY_CREATED } from '@/lib/eventBus';
import { 
  Square, 
  Circle, 
  Pentagon, 
  Ruler, 
  Save, 
  Trash2, 
  Calculator,
  X 
} from 'lucide-react';

interface DrawingToolsProps {
  map: google.maps.Map | null;
  propertyId?: string;
  onSaveDesign?: (design: any) => void;
  onClose?: () => void;
}

export function DrawingTools({ map, propertyId, onSaveDesign, onClose }: DrawingToolsProps) {
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentTool, setCurrentTool] = useState<'rectangle' | 'polygon' | 'circle'>('rectangle');
  const [drawingManager, setDrawingManager] = useState<google.maps.drawing.DrawingManager | null>(null);
  const [currentOverlay, setCurrentOverlay] = useState<google.maps.Polygon | google.maps.Rectangle | google.maps.Circle | null>(null);
  const [area, setArea] = useState<number>(0);
  const [designName, setDesignName] = useState('');
  const [materialType, setMaterialType] = useState('shingle');
  const [pitchEstimate, setPitchEstimate] = useState(6);
  const [estimatedCost, setEstimatedCost] = useState(0);

  // Material costs per square foot
  const materialCosts = {
    shingle: 8.50,
    metal: 12.00,
    tile: 15.00,
    tpo: 6.50,
    epdm: 5.75
  };

  useEffect(() => {
    if (!map || !google.maps.drawing) return;

    const manager = new google.maps.drawing.DrawingManager({
      drawingMode: null,
      drawingControl: false,
      polygonOptions: {
        fillColor: '#ff0000',
        fillOpacity: 0.3,
        strokeColor: '#ff0000',
        strokeWeight: 2,
        editable: true,
        draggable: false
      },
      rectangleOptions: {
        fillColor: '#00ff00',
        fillOpacity: 0.3,
        strokeColor: '#00ff00',
        strokeWeight: 2,
        editable: true,
        draggable: false
      },
      circleOptions: {
        fillColor: '#0000ff',
        fillOpacity: 0.3,
        strokeColor: '#0000ff',
        strokeWeight: 2,
        editable: true,
        draggable: false
      }
    });

    manager.setMap(map);
    setDrawingManager(manager);

    // Listen for overlay completion
    google.maps.event.addListener(manager, 'overlaycomplete', (event: any) => {
      const overlay = event.overlay;
      const type = event.type;
      
      // Clear previous overlay
      if (currentOverlay) {
        currentOverlay.setMap(null);
      }

      setCurrentOverlay(overlay);
      setIsDrawing(false);
      manager.setDrawingMode(null);

      // Calculate area and emit event
      const areaResult = calculateArea(overlay, type);
      
      // Emit polygon creation event for MeasurePanel
      if (type === 'polygon') {
        const path = overlay.getPath().getArray().map((coord: google.maps.LatLng) => ({
          lat: coord.lat(),
          lng: coord.lng()
        }));
        
        const wkt = `POLYGON((${path.map(p => `${p.lng} ${p.lat}`).join(', ')}, ${path[0].lng} ${path[0].lat}))`;
        
        bus.emit(EVT_POLY_CREATED, {
          path,
          areaSqft: areaResult,
          wkt
        });
      }

      // Add edit listeners
      if (type === 'polygon') {
        google.maps.event.addListener(overlay.getPath(), 'set_at', () => calculateArea(overlay, type));
        google.maps.event.addListener(overlay.getPath(), 'insert_at', () => calculateArea(overlay, type));
      } else if (type === 'rectangle') {
        google.maps.event.addListener(overlay, 'bounds_changed', () => calculateArea(overlay, type));
      } else if (type === 'circle') {
        google.maps.event.addListener(overlay, 'radius_changed', () => calculateArea(overlay, type));
      }
    });

    return () => {
      if (manager) {
        manager.setMap(null);
      }
    };
  }, [map]);

  const calculateArea = (overlay: any, type: string): number => {
    let calculatedArea = 0;

    if (type === 'polygon') {
      calculatedArea = google.maps.geometry.spherical.computeArea(overlay.getPath());
    } else if (type === 'rectangle') {
      const bounds = overlay.getBounds();
      const ne = bounds.getNorthEast();
      const sw = bounds.getSouthWest();
      const nw = new google.maps.LatLng(ne.lat(), sw.lng());
      const se = new google.maps.LatLng(sw.lat(), ne.lng());
      
      const path = [nw, ne, se, sw];
      calculatedArea = google.maps.geometry.spherical.computeArea(path);
    } else if (type === 'circle') {
      const radius = overlay.getRadius();
      calculatedArea = Math.PI * radius * radius;
    }

    // Convert to square feet
    const sqft = calculatedArea * 10.764;
    setArea(sqft);
    
    // Calculate estimated cost
    const cost = sqft * materialCosts[materialType as keyof typeof materialCosts];
    setEstimatedCost(cost);
    
    return sqft;
  };

  const startDrawing = (tool: 'rectangle' | 'polygon' | 'circle') => {
    if (!drawingManager) return;

    setCurrentTool(tool);
    setIsDrawing(true);
    
    const drawingMode = tool === 'rectangle' 
      ? google.maps.drawing.OverlayType.RECTANGLE
      : tool === 'polygon' 
        ? google.maps.drawing.OverlayType.POLYGON
        : google.maps.drawing.OverlayType.CIRCLE;
    
    drawingManager.setDrawingMode(drawingMode);
  };

  const clearDrawing = () => {
    if (currentOverlay) {
      currentOverlay.setMap(null);
      setCurrentOverlay(null);
    }
    setArea(0);
    setEstimatedCost(0);
    setIsDrawing(false);
    if (drawingManager) {
      drawingManager.setDrawingMode(null);
    }
  };

  const saveDesign = () => {
    if (!currentOverlay || !propertyId) return;

    let geometry: any = null;

    if (currentOverlay instanceof google.maps.Polygon) {
      const path = currentOverlay.getPath();
      geometry = {
        type: 'Polygon',
        coordinates: [[
          ...path.getArray().map(coord => [coord.lng(), coord.lat()]),
          [path.getAt(0).lng(), path.getAt(0).lat()] // Close the polygon
        ]]
      };
    } else if (currentOverlay instanceof google.maps.Rectangle) {
      const bounds = currentOverlay.getBounds()!;
      const ne = bounds.getNorthEast();
      const sw = bounds.getSouthWest();
      geometry = {
        type: 'Polygon',
        coordinates: [[
          [sw.lng(), sw.lat()],
          [ne.lng(), sw.lat()],
          [ne.lng(), ne.lat()],
          [sw.lng(), ne.lat()],
          [sw.lng(), sw.lat()]
        ]]
      };
    } else if (currentOverlay instanceof google.maps.Circle) {
      const center = currentOverlay.getCenter()!;
      const radius = currentOverlay.getRadius();
      geometry = {
        type: 'Point',
        coordinates: [center.lng(), center.lat()],
        properties: { radius }
      };
    }

    const design = {
      property_id: propertyId,
      name: designName || `${materialType} design - ${new Date().toLocaleDateString()}`,
      type: 'FAST_ESTIMATES',
      geometry,
      area_sqft: Math.round(area),
      pitch_estimate: pitchEstimate,
      material_type: materialType,
      estimated_cost: Math.round(estimatedCost),
    };

    onSaveDesign?.(design);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  return (
    <Card className="w-80 max-h-[90vh] overflow-y-auto">
      <CardHeader className="flex flex-row items-center justify-between pb-3">
        <CardTitle className="text-lg">Measurement Tools</CardTitle>
        <Button variant="ghost" size="sm" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Drawing Tools */}
        <div className="space-y-2">
          <Label className="text-sm font-medium">Drawing Tools</Label>
          <div className="flex gap-2">
            <Button
              variant={currentTool === 'rectangle' && isDrawing ? 'default' : 'outline'}
              size="sm"
              onClick={() => startDrawing('rectangle')}
              disabled={isDrawing && currentTool !== 'rectangle'}
            >
              <Square className="h-4 w-4 mr-1" />
              Rectangle
            </Button>
            <Button
              variant={currentTool === 'polygon' && isDrawing ? 'default' : 'outline'}
              size="sm"
              onClick={() => startDrawing('polygon')}
              disabled={isDrawing && currentTool !== 'polygon'}
            >
              <Pentagon className="h-4 w-4 mr-1" />
              Polygon
            </Button>
          </div>
          <div className="flex gap-2">
            <Button
              variant={currentTool === 'circle' && isDrawing ? 'default' : 'outline'}
              size="sm"
              onClick={() => startDrawing('circle')}
              disabled={isDrawing && currentTool !== 'circle'}
            >
              <Circle className="h-4 w-4 mr-1" />
              Circle
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={clearDrawing}
              disabled={!currentOverlay}
            >
              <Trash2 className="h-4 w-4 mr-1" />
              Clear
            </Button>
          </div>
        </div>

        {isDrawing && (
          <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
            <p className="text-sm text-blue-700">
              Click on the map to start drawing your {currentTool}
            </p>
          </div>
        )}

        <Separator />

        {/* Measurements */}
        {area > 0 && (
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Ruler className="h-4 w-4" />
              <Label className="text-sm font-medium">Measurements</Label>
            </div>
            
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div>
                <span className="text-muted-foreground">Area:</span>
                <Badge variant="outline" className="ml-1">
                  {Math.round(area).toLocaleString()} sq ft
                </Badge>
              </div>
              <div>
                <span className="text-muted-foreground">Cost:</span>
                <Badge variant="outline" className="ml-1">
                  {formatCurrency(estimatedCost)}
                </Badge>
              </div>
            </div>
          </div>
        )}

        <Separator />

        {/* Design Parameters */}
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Calculator className="h-4 w-4" />
            <Label className="text-sm font-medium">Design Parameters</Label>
          </div>

          <div className="space-y-3">
            <div>
              <Label htmlFor="design-name" className="text-sm">Design Name</Label>
              <Input
                id="design-name"
                value={designName}
                onChange={(e) => setDesignName(e.target.value)}
                placeholder="Enter design name"
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="material-type" className="text-sm">Material Type</Label>
              <Select value={materialType} onValueChange={setMaterialType}>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="shingle">Asphalt Shingle ({formatCurrency(materialCosts.shingle)}/sqft)</SelectItem>
                  <SelectItem value="metal">Metal Roofing ({formatCurrency(materialCosts.metal)}/sqft)</SelectItem>
                  <SelectItem value="tile">Clay Tile ({formatCurrency(materialCosts.tile)}/sqft)</SelectItem>
                  <SelectItem value="tpo">TPO Membrane ({formatCurrency(materialCosts.tpo)}/sqft)</SelectItem>
                  <SelectItem value="epdm">EPDM Membrane ({formatCurrency(materialCosts.epdm)}/sqft)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="pitch-estimate" className="text-sm">Roof Pitch</Label>
              <Input
                id="pitch-estimate"
                type="number"
                value={pitchEstimate}
                onChange={(e) => setPitchEstimate(Number(e.target.value))}
                min={1}
                max={12}
                step={0.5}
                className="mt-1"
              />
              <p className="text-xs text-muted-foreground mt-1">
                Rise over 12 inch run (e.g., 6 = 6:12 pitch)
              </p>
            </div>
          </div>
        </div>

        {/* Save Button */}
        {currentOverlay && area > 0 && (
          <Button 
            onClick={saveDesign} 
            className="w-full"
            disabled={!propertyId}
          >
            <Save className="h-4 w-4 mr-2" />
            Save Design
          </Button>
        )}
      </CardContent>
    </Card>
  );
}