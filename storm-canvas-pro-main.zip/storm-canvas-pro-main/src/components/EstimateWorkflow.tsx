import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Calculator, FileText, Home, Ruler, Settings } from 'lucide-react';
import { useEstimates, type Estimate, type EstimateStatus } from '@/hooks/useEstimates';
import { useTemplates, type Template } from '@/hooks/useTemplates';
import { HyperlinkBar } from './HyperlinkBar';

interface EstimateWorkflowProps {
  propertyId: string;
  onClose?: () => void;
}

export const EstimateWorkflow: React.FC<EstimateWorkflowProps> = ({ propertyId, onClose }) => {
  const [selectedEstimate, setSelectedEstimate] = useState<Estimate | null>(null);
  const [estimateStatus, setEstimateStatus] = useState<EstimateStatus | null>(null);
  const [selectedTemplateId, setSelectedTemplateId] = useState('');
  const [squares, setSquares] = useState('');
  const [complexityFactor, setComplexityFactor] = useState('1.0');
  const [step, setStep] = useState<'select' | 'template' | 'measurements' | 'pricing'>('select');

  const { 
    estimates, 
    loading: estimatesLoading, 
    fetchEstimates, 
    createEstimate,
    getEstimateStatus,
    bindTemplate,
    addMeasurements
  } = useEstimates();

  const { 
    templates, 
    loading: templatesLoading, 
    fetchTemplates 
  } = useTemplates();

  useEffect(() => {
    fetchEstimates(propertyId);
    fetchTemplates();
  }, [propertyId, fetchEstimates, fetchTemplates]);

  useEffect(() => {
    if (selectedEstimate) {
      getEstimateStatus(selectedEstimate.id).then(setEstimateStatus);
    }
  }, [selectedEstimate, getEstimateStatus]);

  const handleCreateEstimate = async () => {
    try {
      const estimate = await createEstimate(propertyId, `Estimate ${new Date().toLocaleDateString()}`);
      setSelectedEstimate(estimate);
      setStep('template');
    } catch (error) {
      console.error('Failed to create estimate:', error);
    }
  };

  const handleBindTemplate = async () => {
    if (!selectedEstimate || !selectedTemplateId) return;
    
    try {
      await bindTemplate(selectedEstimate.id, selectedTemplateId);
      const status = await getEstimateStatus(selectedEstimate.id);
      setEstimateStatus(status);
      setStep('measurements');
    } catch (error) {
      console.error('Failed to bind template:', error);
    }
  };

  const handleAddMeasurements = async () => {
    if (!selectedEstimate || !squares) return;

    try {
      await addMeasurements(selectedEstimate.id, parseFloat(squares), parseFloat(complexityFactor));
      const status = await getEstimateStatus(selectedEstimate.id);
      setEstimateStatus(status);
      setStep('pricing');
    } catch (error) {
      console.error('Failed to add measurements:', error);
    }
  };

  const getStepIcon = (stepName: string) => {
    switch (stepName) {
      case 'select': return <Home className="h-4 w-4" />;
      case 'template': return <Settings className="h-4 w-4" />;
      case 'measurements': return <Ruler className="h-4 w-4" />;
      case 'pricing': return <Calculator className="h-4 w-4" />;
      default: return <FileText className="h-4 w-4" />;
    }
  };

  if (estimatesLoading || templatesLoading) {
    return (
      <Card className="w-full max-w-4xl mx-auto">
        <CardContent className="p-6">
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-xl font-semibold">Property Estimate Workflow</CardTitle>
        {onClose && (
          <Button variant="ghost" onClick={onClose}>
            Close
          </Button>
        )}
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Progress Steps */}
        <div className="flex items-center space-x-4 mb-6">
          {['select', 'template', 'measurements', 'pricing'].map((stepName, index) => (
            <div key={stepName} className="flex items-center">
              <div className={`flex items-center justify-center w-8 h-8 rounded-full border-2 ${
                step === stepName 
                  ? 'border-primary bg-primary text-primary-foreground' 
                  : index < ['select', 'template', 'measurements', 'pricing'].indexOf(step)
                    ? 'border-primary bg-primary text-primary-foreground'
                    : 'border-muted-foreground text-muted-foreground'
              }`}>
                {getStepIcon(stepName)}
              </div>
              {index < 3 && (
                <div className={`w-16 h-0.5 mx-2 ${
                  index < ['select', 'template', 'measurements', 'pricing'].indexOf(step)
                    ? 'bg-primary'
                    : 'bg-muted-foreground'
                }`} />
              )}
            </div>
          ))}
        </div>

        {/* Step Content */}
        {step === 'select' && (
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Select or Create Estimate</h3>
            
            {estimates.length > 0 && (
              <div className="space-y-2">
                <Label>Existing Estimates</Label>
                {estimates.map((estimate) => (
                  <Card key={estimate.id} className="p-4 cursor-pointer hover:bg-accent" 
                        onClick={() => {
                          setSelectedEstimate(estimate);
                          setStep('template');
                        }}>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">{estimate.name || `Estimate ${estimate.id.slice(0, 8)}`}</p>
                        <p className="text-sm text-muted-foreground">
                          Created {new Date(estimate.created_at).toLocaleDateString()}
                        </p>
                      </div>
                      <Badge variant="secondary">{estimate.status}</Badge>
                    </div>
                  </Card>
                ))}
              </div>
            )}

            <div className="pt-4 border-t">
              <Button onClick={handleCreateEstimate} className="w-full">
                Create New Estimate
              </Button>
            </div>
          </div>
        )}

        {step === 'template' && selectedEstimate && (
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Bind Template</h3>
            
            <div className="space-y-2">
              <Label>Select Template</Label>
              <Select value={selectedTemplateId} onValueChange={setSelectedTemplateId}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose a pricing template" />
                </SelectTrigger>
                <SelectContent>
                  {templates.map((template) => (
                    <SelectItem key={template.id} value={template.id}>
                      {template.name} ({template.currency})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex space-x-2">
              <Button 
                onClick={handleBindTemplate} 
                disabled={!selectedTemplateId}
                className="flex-1"
              >
                Bind Template
              </Button>
              <Button variant="outline" onClick={() => setStep('select')}>
                Back
              </Button>
            </div>
          </div>
        )}

        {step === 'measurements' && selectedEstimate && (
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Add Measurements</h3>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Roof Squares</Label>
                <Input
                  type="number"
                  step="0.1"
                  value={squares}
                  onChange={(e) => setSquares(e.target.value)}
                  placeholder="e.g. 25.5"
                />
              </div>
              <div className="space-y-2">
                <Label>Complexity Factor</Label>
                <Input
                  type="number"
                  step="0.1"
                  value={complexityFactor}
                  onChange={(e) => setComplexityFactor(e.target.value)}
                  placeholder="1.0"
                />
              </div>
            </div>

            <div className="flex space-x-2">
              <Button 
                onClick={handleAddMeasurements} 
                disabled={!squares}
                className="flex-1"
              >
                Add Measurements
              </Button>
              <Button variant="outline" onClick={() => setStep('template')}>
                Back
              </Button>
            </div>
          </div>
        )}

        {step === 'pricing' && selectedEstimate && estimateStatus?.ready && (
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Pricing Overview</h3>
            <HyperlinkBar estimateId={selectedEstimate.id} />
            
            <div className="flex space-x-2">
              <Button variant="outline" onClick={() => setStep('measurements')}>
                Back
              </Button>
              <Button className="flex-1">
                Generate Proposal
              </Button>
            </div>
          </div>
        )}

        {/* Status Messages */}
        {estimateStatus && estimateStatus.messages.length > 0 && (
          <div className="mt-4 p-4 bg-muted rounded-lg">
            <h4 className="font-medium mb-2">Status</h4>
            <ul className="space-y-1">
              {estimateStatus.messages.map((message, index) => (
                <li key={index} className="text-sm text-muted-foreground">
                  • {message}
                </li>
              ))}
            </ul>
          </div>
        )}
      </CardContent>
    </Card>
  );
};