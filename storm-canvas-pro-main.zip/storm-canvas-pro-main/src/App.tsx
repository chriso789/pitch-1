import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "@/components/AuthProvider";
import { RequireAuth } from "@/components/RequireAuth";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { RealTimeUpdates } from "@/components/RealTimeUpdates";
import { GoogleMapsProvider } from "@/components/GoogleMapsProvider";
import { configManager } from "@/lib/config";
import Index from "./pages/Index";
import Canvassing from "./pages/Canvassing";
import Photos from "./pages/Photos";
import Properties from "./pages/Properties";
import Proposals from "./pages/Proposals";
import Team from "./pages/Team";
import Storm from "./pages/Storm";
import AuthTest from "./pages/AuthTest";
import Auth from "./pages/Auth";
import SkipTrace from "./pages/SkipTrace";
import Health from "./pages/Health";
import Healthz from "./pages/Healthz";
import { SetupWizard } from "./components/SetupWizard";
import Admin from "./pages/Admin";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => {
  // Check configuration on app load
  const isConfigValid = configManager.isValid;
  const hasRequiredVars = configManager.hasRequiredVars;

  // If environment variables are missing or invalid, force setup
  if (!hasRequiredVars || !isConfigValid) {
    return (
      <ErrorBoundary>
        <QueryClientProvider client={queryClient}>
          <TooltipProvider>
            <Toaster />
            <Sonner />
            <BrowserRouter>
              <Routes>
                <Route path="/setup" element={<SetupWizard />} />
                <Route path="*" element={<Navigate to="/setup" replace />} />
              </Routes>
            </BrowserRouter>
          </TooltipProvider>
        </QueryClientProvider>
      </ErrorBoundary>
    );
  }

  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <AuthProvider>
          <GoogleMapsProvider>
            <RealTimeUpdates userId={undefined} />
            <TooltipProvider>
              <Toaster />
              <Sonner />
              <BrowserRouter>
                <Routes>
                <Route path="/" element={<Index />} />
                <Route path="/dashboard" element={<Index />} />
                <Route path="/canvassing" element={<Canvassing />} />
                <Route path="/photos" element={
                  <RequireAuth>
                    <Photos />
                  </RequireAuth>
                } />
                <Route path="/properties" element={
                  <RequireAuth>
                    <Properties />
                  </RequireAuth>
                } />
                <Route path="/proposals" element={
                  <RequireAuth>
                    <Proposals />
                  </RequireAuth>
                } />
                <Route path="/team" element={
                  <RequireAuth>
                    <Team />
                  </RequireAuth>
                } />
                <Route path="/storm" element={
                  <RequireAuth>
                    <Storm />
                  </RequireAuth>
                } />
                <Route path="/admin" element={
                  <RequireAuth>
                    <Admin />
                  </RequireAuth>
                } />
                <Route path="/skip-trace" element={
                  <RequireAuth>
                    <SkipTrace />
                  </RequireAuth>
                } />
                <Route path="/auth/test" element={
                  <RequireAuth>
                    <AuthTest />
                  </RequireAuth>
                } />
                <Route path="/auth" element={<Auth />} />
                <Route path="/health" element={<Health />} />
                <Route path="/healthz" element={<Healthz />} />
                <Route path="/setup" element={<SetupWizard />} />
                {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
                <Route path="*" element={<NotFound />} />
                </Routes>
              </BrowserRouter>
            </TooltipProvider>
          </GoogleMapsProvider>
        </AuthProvider>
      </QueryClientProvider>
    </ErrorBoundary>
  );
};

export default App;
