import { useState } from 'react';
import { useProperties } from '@/hooks/useProperties';
import { usePropertyFilters } from '@/hooks/usePropertyFilters';
import { useAuth } from '@/components/AuthProvider';
import { PropertyFilters } from '@/components/PropertyFilters';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Search, MapPin, Phone, Mail, Calendar, DollarSign, Home, User } from 'lucide-react';
import { format } from 'date-fns';
import Navigation from '@/components/Navigation';

export default function Properties() {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [page, setPage] = useState(1);
  const pageSize = 25;
  
  const { filters, updateFilters, clearFilters, hasActiveFilters } = usePropertyFilters();
  const { data: properties = [], isLoading } = useProperties(filters, { page, pageSize });

  // Client-side search filtering
  const filteredProperties = properties.filter(property => {
    if (!searchTerm.trim()) return true;
    const term = searchTerm.toLowerCase();
    return (
      property.address?.toLowerCase().includes(term) ||
      property.homeowner_name?.toLowerCase().includes(term) ||
      property.email?.toLowerCase().includes(term) ||
      property.phone?.toLowerCase().includes(term)
    );
  });

  const formatCurrency = (value: number | null) => {
    if (!value) return 'N/A';
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  const formatDate = (dateString: string) => {
    return format(new Date(dateString), 'MMM dd, yyyy');
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-surface">
        <Navigation />
        <div className="flex items-center justify-center min-h-[80vh]">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle className="text-center">Authentication Required</CardTitle>
              <CardDescription className="text-center">
                Please sign in to access your properties.
              </CardDescription>
            </CardHeader>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-surface">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Properties</h1>
            <p className="text-muted-foreground">
              Manage and filter your property database
            </p>
          </div>
        </div>

        {/* Search and Filters */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="flex gap-4 items-center mb-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search properties by address, homeowner, email, or phone..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            
            <PropertyFilters
              filters={filters}
              onFiltersChange={updateFilters}
              totalResults={properties.length}
              filteredResults={filteredProperties.length}
              onClear={clearFilters}
            />
          </CardContent>
        </Card>

        {/* Properties Table */}
        {isLoading ? (
          <Card>
            <CardContent className="p-6">
              <div className="animate-pulse space-y-4">
                {Array.from({ length: 10 }).map((_, i) => (
                  <div key={i} className="h-12 bg-muted rounded"></div>
                ))}
              </div>
            </CardContent>
          </Card>
        ) : filteredProperties.length > 0 ? (
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Address</TableHead>
                    <TableHead>Homeowner</TableHead>
                    <TableHead>Contact</TableHead>
                    <TableHead>Property Value</TableHead>
                    <TableHead>Credit Score</TableHead>
                    <TableHead>Disposition</TableHead>
                    <TableHead>Created</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredProperties.map((property) => (
                    <TableRow key={property.id} className="hover:bg-muted/50">
                      <TableCell>
                        <div className="flex items-start gap-2">
                          <MapPin className="h-4 w-4 text-muted-foreground mt-0.5 flex-shrink-0" />
                          <div>
                            <div className="font-medium text-sm">{property.address}</div>
                            <div className="text-xs text-muted-foreground">
                              {property.latitude?.toFixed(4)}, {property.longitude?.toFixed(4)}
                            </div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        {property.homeowner_name ? (
                          <div className="flex items-center gap-2">
                            <User className="h-4 w-4 text-muted-foreground" />
                            <span className="font-medium">{property.homeowner_name}</span>
                          </div>
                        ) : (
                          <span className="text-muted-foreground">Unknown</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          {property.phone && (
                            <div className="flex items-center gap-2 text-sm">
                              <Phone className="h-3 w-3 text-muted-foreground" />
                              <span>{property.phone}</span>
                            </div>
                          )}
                          {property.email && (
                            <div className="flex items-center gap-2 text-sm">
                              <Mail className="h-3 w-3 text-muted-foreground" />
                              <span>{property.email}</span>
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <DollarSign className="h-4 w-4 text-muted-foreground" />
                          <span className="font-medium">
                            {formatCurrency(property.property_value)}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        {property.credit_score ? (
                          <Badge
                            variant={
                              property.credit_score >= 750 ? 'default' :
                              property.credit_score >= 650 ? 'secondary' :
                              'destructive'
                            }
                          >
                            {property.credit_score}
                          </Badge>
                        ) : (
                          <span className="text-muted-foreground">N/A</span>
                        )}
                      </TableCell>
                      <TableCell>
                        {property.disposition ? (
                          <Badge
                            variant="outline"

                            style={{ borderColor: (property.disposition as any).color }}
                          >
                            <div
                              className="w-2 h-2 rounded-full mr-2"
                              style={{ backgroundColor: (property.disposition as any).color }}
                            />
                            {(property.disposition as any).name}
                          </Badge>
                        ) : (
                          <span className="text-muted-foreground">None</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Calendar className="h-3 w-3" />
                          {formatDate(property.created_at)}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardContent className="p-12 text-center">
              <Home className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Properties Found</h3>
              <p className="text-muted-foreground mb-4">
                {hasActiveFilters ? 
                  "No properties match your current filters. Try adjusting your search criteria." :
                  "You haven't added any properties yet. Start by searching for addresses on the map."
                }
              </p>
              {hasActiveFilters && (
                <Button variant="outline" onClick={clearFilters}>
                  Clear Filters
                </Button>
              )}
            </CardContent>
          </Card>
        )}

        {/* Pagination would go here */}
        <div className="mt-6 flex justify-center">
          <div className="text-sm text-muted-foreground">
            Showing {filteredProperties.length} of {properties.length} properties
          </div>
        </div>
      </div>
    </div>
  );
}