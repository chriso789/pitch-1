// Skip-trace page with enhanced map and lead management
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { MapPin, Zap, Plus, Settings, Cloud } from 'lucide-react';
import SkipTraceMap from '@/components/SkipTraceMap';
import { useLeads } from '@/hooks/useLeads';
import { useSkipTrace } from '@/hooks/useSkipTrace';
import { toast } from 'sonner';

export default function SkipTrace() {
  const [showStormOverlay, setShowStormOverlay] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState<{
    lat: number;
    lng: number;
    address?: string;
  } | null>(null);
  const [newLeadAddress, setNewLeadAddress] = useState('');

  const { createLead, loading: leadsLoading } = useLeads();
  const { getProviderHealth } = useSkipTrace();

  const handleLocationSelect = (location: { lat: number; lng: number; address?: string }) => {
    setSelectedLocation(location);
    setNewLeadAddress(location.address || '');
  };

  const handleCreateLead = async () => {
    if (!selectedLocation || !newLeadAddress.trim()) {
      toast.error('Please select a location and enter an address');
      return;
    }

    try {
      await createLead({
        address: newLeadAddress,
        lat: selectedLocation.lat,
        lng: selectedLocation.lng,
        statusTypeId: 1,
        statusTitle: 'New Lead',
        statusBackColor: '#3b82f6',
        statusFrontColor: '#ffffff',
        source: 'manual'
      });

      setNewLeadAddress('');
      setSelectedLocation(null);
    } catch (error) {
      console.error('Error creating lead:', error);
    }
  };

  const checkProviderHealth = async () => {
    try {
      const health = await getProviderHealth();
      const healthMessage = health
        .map(h => `${h.name}: ${h.ok ? '✅' : '❌'} (${h.latency_ms}ms)`)
        .join('\\n');
      
      toast.success(`Provider Health: ${healthMessage}`);
    } catch (error) {
      toast.error('Failed to check provider health');
    }
  };

  return (
    <div className="h-screen flex flex-col">
      {/* Header */}
      <div className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="h-6 w-6" />
            <h1 className="text-xl font-semibold">Skip Trace & Prospecting</h1>
          </div>
          
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-2">
              <Label htmlFor="storm-overlay" className="text-sm">Storm Overlay</Label>
              <Switch
                id="storm-overlay"
                checked={showStormOverlay}
                onCheckedChange={setShowStormOverlay}
              />
            </div>
            <Button size="sm" variant="outline" onClick={checkProviderHealth}>
              <Settings className="h-4 w-4 mr-1" />
              Health Check
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 grid grid-cols-12 gap-4 p-4">
        {/* Map */}
        <div className="col-span-8 h-full">
          <SkipTraceMap
            showStormOverlay={showStormOverlay}
            onLocationSelect={handleLocationSelect}
          />
        </div>

        {/* Sidebar */}
        <div className="col-span-4 space-y-4 overflow-y-auto">
          <Tabs defaultValue="leads" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="leads">Leads</TabsTrigger>
              <TabsTrigger value="tools">Tools</TabsTrigger>
            </TabsList>

            <TabsContent value="leads" className="space-y-4">
              {/* Create New Lead */}
              <Card className="p-4">
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <Plus className="h-4 w-4" />
                  Add New Lead
                </h3>
                
                <div className="space-y-3">
                  <div>
                    <Label htmlFor="address">Address</Label>
                    <Input
                      id="address"
                      value={newLeadAddress}
                      onChange={(e) => setNewLeadAddress(e.target.value)}
                      placeholder="123 Main St, City, State 12345"
                    />
                  </div>
                  
                  {selectedLocation && (
                    <div className="text-sm text-muted-foreground">
                      📍 Coordinates: {selectedLocation.lat.toFixed(6)}, {selectedLocation.lng.toFixed(6)}
                    </div>
                  )}
                  
                  <Button
                    onClick={handleCreateLead}
                    disabled={!selectedLocation || !newLeadAddress.trim() || leadsLoading}
                    className="w-full"
                  >
                    {leadsLoading ? 'Creating...' : 'Create Lead'}
                  </Button>
                </div>
              </Card>

              {/* Lead Stats */}
              <Card className="p-4">
                <h3 className="font-semibold mb-3">Lead Statistics</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-2xl font-bold text-primary">0</div>
                    <div className="text-sm text-muted-foreground">Total Leads</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-green-600">0</div>
                    <div className="text-sm text-muted-foreground">Skip Traced</div>
                  </div>
                </div>
              </Card>
            </TabsContent>

            <TabsContent value="tools" className="space-y-4">
              {/* Skip Trace Tools */}
              <Card className="p-4">
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <Zap className="h-4 w-4" />
                  Skip Trace Tools
                </h3>
                
                <div className="space-y-3">
                  <div className="text-sm text-muted-foreground">
                    Click on any lead marker to run skip-trace and get contact information.
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium">Available Providers:</h4>
                    <div className="space-y-1">
                      <Badge variant="outline" className="flex items-center gap-1 w-fit">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        Mock Provider
                      </Badge>
                      <Badge variant="outline" className="flex items-center gap-1 w-fit">
                        <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                        Estated (Configure API Key)
                      </Badge>
                      <Badge variant="outline" className="flex items-center gap-1 w-fit">
                        <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                        PDL (Configure API Key)
                      </Badge>
                    </div>
                  </div>
                </div>
              </Card>

              {/* NOAA Storm Data */}
              <Card className="p-4">
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <Cloud className="h-4 w-4" />
                  Storm Data
                </h3>
                
                <div className="space-y-3">
                  <div className="text-sm text-muted-foreground">
                    Toggle storm overlay to see NOAA emergency imagery for prospecting storm-damaged properties.
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Current Dataset:</span>
                    <Badge variant="outline">20241011b-rgb</Badge>
                  </div>
                </div>
              </Card>

              {/* Navigation Tools */}
              <Card className="p-4">
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  Navigation
                </h3>
                
                <div className="text-sm text-muted-foreground">
                  Click "Directions" on any lead info window to get driving directions from your current location.
                </div>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}