import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import Navigation from "@/components/Navigation";
import MetricCard from "@/components/MetricCard";
import ActivityFeed from "@/components/ActivityFeed";
import QuickActions from "@/components/QuickActions";
import TeamMap from "@/components/TeamMap";
import Pipeline from "@/components/Pipeline";
import { useAuth } from '@/components/AuthProvider';
import { 
  TrendingUp, 
  MapPin, 
  Camera, 
  FileText, 
  Users,
  DollarSign,
  Target,
  Clock
} from "lucide-react";

const Index = () => {
  const { user } = useAuth();
  const location = useLocation();

  // Get current time for greeting
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good morning";
    if (hour < 17) return "Good afternoon";
    return "Good evening";
  };

  // Show auth modal if user came from a protected route
  useEffect(() => {
    if (!user && location.state?.from) {
      // This effect could trigger auth modal opening, but we'll let Navigation handle it
    }
  }, [user, location.state]);

  return (
    <div className="min-h-screen bg-gradient-surface">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">
            {getGreeting()}! Here's your field overview.
          </h1>
          <p className="text-muted-foreground">
            Track your team's performance, manage leads, and close more deals.
          </p>
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-4 gap-6 mb-8">
          <MetricCard
            title="Active Leads"
            value="127"
            change="+12% from last week"
            changeType="positive"
            icon={Target}
          />
          <MetricCard
            title="Proposals Sent"
            value="43"
            change="+8% from last week"
            changeType="positive"
            icon={FileText}
          />
          <MetricCard
            title="Revenue This Month"
            value="$284K"
            change="+23% from last month"
            changeType="positive"
            icon={DollarSign}
          />
          <MetricCard
            title="Avg Response Time"
            value="1.2hrs"
            change="-15 min from last week"
            changeType="positive"
            icon={Clock}
          />
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-3 gap-6 mb-8">
          <div className="col-span-2">
            <Pipeline />
          </div>
          <div>
            <QuickActions />
          </div>
        </div>

        {/* Bottom Section */}
        <div className="grid grid-cols-2 gap-6">
          <ActivityFeed />
          <TeamMap />
        </div>
      </div>
    </div>
  );
};

export default Index;
