import { useEffect, useState } from 'react';

type Health = { name: string; ok: boolean; latency_ms?: number; quota?: string; error?: string };

export default function Healthz() {
  const [items, setItems] = useState<Health[]>([]);
  
  useEffect(() => { 
    fetch('https://bevovurzumbupezcarql.supabase.co/functions/v1/healthz')
      .then(r => r.json())
      .then(setItems)
      .catch(err => console.error('Failed to fetch health data:', err));
  }, []);
  
  return (
    <div className="p-6">
      <h1 className="text-xl font-bold text-foreground">Integration Health</h1>
      <ul className="mt-4 space-y-2">
        {items.map(h => (
          <li key={h.name} className={`p-3 rounded ${h.ok ? 'bg-success/10 border border-success/20' : 'bg-destructive/10 border border-destructive/20'}`}>
            <div className="font-medium text-foreground">{h.name}</div>
            <div className="text-sm text-muted-foreground">
              {h.ok ? 'OK' : h.error || 'DOWN'} — {h.latency_ms ?? 0}ms {h.quota ? `— ${h.quota}` : ''}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}