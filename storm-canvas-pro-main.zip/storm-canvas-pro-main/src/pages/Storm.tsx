import { useState, useEffect } from 'react';
import { useAuth } from '@/components/AuthProvider';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CloudRain, Search, MapPin, Calendar, AlertTriangle, TrendingUp, Eye, Download } from 'lucide-react';
import { format, subDays } from 'date-fns';
import Navigation from '@/components/Navigation';

// Mock storm data
const mockStorms = [
  {
    id: '1',
    name: 'Severe Thunderstorm Event',
    type: 'Hail',
    date: new Date('2024-01-15'),
    severity: 'High',
    location: 'Dallas County, TX',
    affected_area: '50 sq miles',
    max_hail_size: '2.5 inches',
    wind_speed: '70 mph',
    properties_affected: 1250,
    claims_filed: 890,
    estimated_damage: '$15.2M'
  },
  {
    id: '2',
    name: 'Winter Storm Atlas',
    type: 'Ice/Snow',
    date: new Date('2024-01-10'),
    severity: 'Medium',
    location: 'Tarrant County, TX',
    affected_area: '75 sq miles',
    max_hail_size: null,
    wind_speed: '45 mph',
    properties_affected: 800,
    claims_filed: 340,
    estimated_damage: '$8.7M'
  },
  {
    id: '3',
    name: 'Supercell Complex',
    type: 'Tornado',
    date: new Date('2024-01-08'),
    severity: 'Critical',
    location: 'Collin County, TX',
    affected_area: '25 sq miles',
    max_hail_size: '3.0 inches',
    wind_speed: '120 mph',
    properties_affected: 2100,
    claims_filed: 1650,
    estimated_damage: '$32.8M'
  }
];

export default function Storm() {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const [selectedStorm, setSelectedStorm] = useState<any>(null);

  const filteredStorms = mockStorms.filter(storm => {
    const matchesSearch = 
      storm.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      storm.location.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesType = typeFilter === 'all' || storm.type === typeFilter;
    const matchesSeverity = severityFilter === 'all' || storm.severity === severityFilter;
    
    return matchesSearch && matchesType && matchesSeverity;
  });

  const getSeverityColor = (severity: string) => {
    switch (severity.toLowerCase()) {
      case 'critical': return 'bg-red-100 text-red-800 border-red-200';
      case 'high': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-blue-100 text-blue-800 border-blue-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case 'hail': return '🧊';
      case 'tornado': return '🌪️';
      case 'ice/snow': return '❄️';
      case 'wind': return '💨';
      default: return '⛈️';
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-surface">
        <Navigation />
        <div className="flex items-center justify-center min-h-[80vh]">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle className="text-center">Authentication Required</CardTitle>
              <CardDescription className="text-center">
                Please sign in to access storm data.
              </CardDescription>
            </CardHeader>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-surface">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Storm Data Center</h1>
            <p className="text-muted-foreground">
              Track severe weather events and their impact on your service area
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Export Data
            </Button>
            <Button>
              <AlertTriangle className="h-4 w-4 mr-2" />
              Set Alert
            </Button>
          </div>
        </div>

        {/* Storm Overview Stats */}
        <div className="grid grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Active Storms</p>
                  <p className="text-2xl font-bold">3</p>
                </div>
                <CloudRain className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Damage</p>
                  <p className="text-2xl font-bold">$56.7M</p>
                </div>
                <TrendingUp className="h-8 w-8 text-red-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Properties Affected</p>
                  <p className="text-2xl font-bold">4,150</p>
                </div>
                <MapPin className="h-8 w-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Claims Filed</p>
                  <p className="text-2xl font-bold">2,880</p>
                </div>
                <AlertTriangle className="h-8 w-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="flex gap-4 items-center flex-wrap">
              <div className="relative flex-1 min-w-64">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by storm name or location..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Storm Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="Hail">Hail</SelectItem>
                  <SelectItem value="Tornado">Tornado</SelectItem>
                  <SelectItem value="Ice/Snow">Ice/Snow</SelectItem>
                  <SelectItem value="Wind">Wind</SelectItem>
                </SelectContent>
              </Select>
              <Select value={severityFilter} onValueChange={setSeverityFilter}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Severity" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Severity</SelectItem>
                  <SelectItem value="Critical">Critical</SelectItem>
                  <SelectItem value="High">High</SelectItem>
                  <SelectItem value="Medium">Medium</SelectItem>
                  <SelectItem value="Low">Low</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Storm Events List */}
        <div className="space-y-4">
          {filteredStorms.map((storm) => (
            <Card key={storm.id} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div className="space-y-3 flex-1">
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{getTypeIcon(storm.type)}</span>
                      <div>
                        <h3 className="text-lg font-semibold">{storm.name}</h3>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <MapPin className="h-4 w-4" />
                          {storm.location}
                          <Calendar className="h-4 w-4 ml-2" />
                          {format(storm.date, 'MMM d, yyyy')}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Badge className={getSeverityColor(storm.severity)}>
                          {storm.severity} Severity
                        </Badge>
                        <Badge variant="outline">
                          {storm.type}
                        </Badge>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-4 gap-6 text-sm">
                      <div>
                        <p className="text-muted-foreground">Affected Area</p>
                        <p className="font-medium">{storm.affected_area}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Max Wind Speed</p>
                        <p className="font-medium">{storm.wind_speed}</p>
                      </div>
                      {storm.max_hail_size && (
                        <div>
                          <p className="text-muted-foreground">Max Hail Size</p>
                          <p className="font-medium">{storm.max_hail_size}</p>
                        </div>
                      )}
                      <div>
                        <p className="text-muted-foreground">Properties Affected</p>
                        <p className="font-medium">{storm.properties_affected.toLocaleString()}</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-6 text-sm pt-2 border-t">
                      <div>
                        <p className="text-muted-foreground">Claims Filed</p>
                        <p className="font-medium text-blue-600">{storm.claims_filed.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Estimated Damage</p>
                        <p className="font-medium text-red-600">{storm.estimated_damage}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Claim Rate</p>
                        <p className="font-medium">
                          {((storm.claims_filed / storm.properties_affected) * 100).toFixed(1)}%
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2 ml-4">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setSelectedStorm(storm)}
                    >
                      <Eye className="h-4 w-4 mr-2" />
                      View Details
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                    >
                      <MapPin className="h-4 w-4 mr-2" />
                      View on Map
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredStorms.length === 0 && (
          <Card className="text-center py-12">
            <CardContent>
              <CloudRain className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-2">No storm events found</h3>
              <p className="text-muted-foreground">
                {searchTerm || typeFilter !== 'all' || severityFilter !== 'all' 
                  ? 'Try adjusting your search criteria' 
                  : 'No recent storm activity in your area'
                }
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}