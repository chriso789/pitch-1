import { useState } from 'react';
import { usePhotos } from '@/hooks/usePhotos';
import { useAuth } from '@/components/AuthProvider';
import { PhotoCapture } from '@/components/PhotoCapture';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Camera, Search, Filter, Download, Trash2, MapPin, Calendar, User } from 'lucide-react';
import { format } from 'date-fns';
import Navigation from '@/components/Navigation';

export default function Photos() {
  const { user } = useAuth();
  const [showCapture, setShowCapture] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedProperty, setSelectedProperty] = useState<string | null>(null);
  
  const { data: photos = [], isLoading } = usePhotos();

  const filteredPhotos = photos.filter(photo =>
    photo.caption?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    photo.original_filename?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handlePhotoUploaded = (photoData: any) => {
    setShowCapture(false);
    // Photos will be automatically refetched due to query invalidation
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-surface">
        <Navigation />
        <div className="flex items-center justify-center min-h-[80vh]">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle className="text-center">Authentication Required</CardTitle>
              <CardDescription className="text-center">
                Please sign in to access your photos.
              </CardDescription>
            </CardHeader>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-surface">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Photo Gallery</h1>
            <p className="text-muted-foreground">
              Manage and organize your property photos
            </p>
          </div>
          <Button onClick={() => setShowCapture(true)} className="flex items-center gap-2">
            <Camera className="h-4 w-4" />
            Take Photo
          </Button>
        </div>

        {/* Search and Filters */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="flex gap-4 items-center">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search photos by caption or filename..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Button variant="outline" size="sm">
                <Filter className="h-4 w-4 mr-2" />
                Filters
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Photos Grid */}
        {isLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {Array.from({ length: 8 }).map((_, i) => (
              <Card key={i} className="animate-pulse">
                <div className="aspect-square bg-muted rounded-lg mb-4"></div>
                <CardContent className="p-4">
                  <div className="h-4 bg-muted rounded mb-2"></div>
                  <div className="h-3 bg-muted rounded w-2/3"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredPhotos.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {filteredPhotos.map((photo) => (
              <Card key={photo.id} className="group hover:shadow-lg transition-shadow">
                <div className="relative aspect-square overflow-hidden rounded-t-lg">
                  <img
                    src={`https://bevovurzumbupezcarql.supabase.co/storage/v1/object/public/photos/${photo.storage_path}`}
                    alt={photo.caption || 'Property photo'}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                  />
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <div className="flex gap-2">
                      <Button size="sm" variant="secondary">
                        <Download className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="destructive">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
                <CardContent className="p-4">
                  <h3 className="font-medium text-sm mb-2 truncate">
                    {photo.caption || photo.original_filename}
                  </h3>
                  <div className="space-y-1 text-xs text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {format(new Date(photo.created_at), 'MMM d, yyyy')}
                    </div>
                    {photo.latitude && photo.longitude && (
                      <div className="flex items-center gap-1">
                        <MapPin className="h-3 w-3" />
                        Location: {photo.latitude.toFixed(6)}, {photo.longitude.toFixed(6)}
                      </div>
                    )}
                    <div className="flex items-center gap-1">
                      <User className="h-3 w-3" />
                      Size: {photo.file_size ? Math.round(photo.file_size / 1024) + 'KB' : 'Unknown'}
                    </div>
                  </div>
                  {photo.property_id && (
                    <Badge variant="secondary" className="mt-2 text-xs">
                      Property Linked
                    </Badge>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="text-center py-12">
            <CardContent>
              <Camera className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-2">No photos yet</h3>
              <p className="text-muted-foreground mb-4">
                Start capturing photos of properties to build your gallery
              </p>
              <Button onClick={() => setShowCapture(true)}>
                <Camera className="h-4 w-4 mr-2" />
                Take Your First Photo
              </Button>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Photo Capture Modal */}
      {showCapture && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <PhotoCapture
            onClose={() => setShowCapture(false)}
            onPhotoUploaded={handlePhotoUploaded}
            propertyId={selectedProperty}
          />
        </div>
      )}
    </div>
  );
}