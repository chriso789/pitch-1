import { useState } from 'react';
import { useAuth } from '@/components/AuthProvider';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Users, Plus, Search, MapPin, Phone, Mail, Calendar, Target, TrendingUp, Clock } from 'lucide-react';
import Navigation from '@/components/Navigation';
import { toast } from 'sonner';

// Mock data for team members
const mockTeamMembers = [
  {
    id: '1',
    name: 'John Smith',
    email: 'john.smith@company.com',
    phone: '(555) 123-4567',
    role: 'Senior Canvasser',
    avatar_url: null,
    status: 'active',
    last_active: '2 hours ago',
    stats: {
      properties_visited: 45,
      leads_generated: 12,
      conversion_rate: 26.7,
      avg_response_time: '1.2hrs'
    },
    current_location: '123 Main St, Anytown, USA'
  },
  {
    id: '2',
    name: 'Sarah Johnson',
    email: 'sarah.johnson@company.com',
    phone: '(555) 234-5678',
    role: 'Team Lead',
    avatar_url: null,
    status: 'active',
    last_active: '30 minutes ago',
    stats: {
      properties_visited: 67,
      leads_generated: 23,
      conversion_rate: 34.3,
      avg_response_time: '0.8hrs'
    },
    current_location: '456 Oak Ave, Anytown, USA'
  },
  {
    id: '3',
    name: 'Mike Rodriguez',
    email: 'mike.rodriguez@company.com',
    phone: '(555) 345-6789',
    role: 'Canvasser',
    avatar_url: null,
    status: 'offline',
    last_active: '1 day ago',
    stats: {
      properties_visited: 32,
      leads_generated: 8,
      conversion_rate: 25.0,
      avg_response_time: '1.5hrs'
    },
    current_location: null
  }
];

export default function Team() {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');

  const filteredMembers = mockTeamMembers.filter(member =>
    member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    member.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    member.role.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleInviteTeamMember = () => {
    toast.info('Team invitation feature coming soon');
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'busy': return 'bg-yellow-100 text-yellow-800';
      case 'offline': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-surface">
        <Navigation />
        <div className="flex items-center justify-center min-h-[80vh]">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle className="text-center">Authentication Required</CardTitle>
              <CardDescription className="text-center">
                Please sign in to access team management.
              </CardDescription>
            </CardHeader>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-surface">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Team Management</h1>
            <p className="text-muted-foreground">
              Manage your canvassing team and track performance
            </p>
          </div>
          <Button onClick={handleInviteTeamMember} className="flex items-center gap-2">
            <Plus className="h-4 w-4" />
            Invite Team Member
          </Button>
        </div>

        {/* Team Overview Stats */}
        <div className="grid grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Members</p>
                  <p className="text-2xl font-bold">{mockTeamMembers.length}</p>
                </div>
                <Users className="h-8 w-8 text-muted-foreground" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Active Now</p>
                  <p className="text-2xl font-bold">
                    {mockTeamMembers.filter(m => m.status === 'active').length}
                  </p>
                </div>
                <Target className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Leads</p>
                  <p className="text-2xl font-bold">
                    {mockTeamMembers.reduce((sum, m) => sum + m.stats.leads_generated, 0)}
                  </p>
                </div>
                <TrendingUp className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Avg Conversion</p>
                  <p className="text-2xl font-bold">
                    {(mockTeamMembers.reduce((sum, m) => sum + m.stats.conversion_rate, 0) / mockTeamMembers.length).toFixed(1)}%
                  </p>
                </div>
                <Target className="h-8 w-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search team members by name, email, or role..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </CardContent>
        </Card>

        {/* Team Members Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredMembers.map((member) => (
            <Card key={member.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-4">
                <div className="flex items-center gap-4">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={member.avatar_url || undefined} />
                    <AvatarFallback>{getInitials(member.name)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <CardTitle className="text-lg">{member.name}</CardTitle>
                      <Badge className={getStatusColor(member.status)}>
                        {member.status}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{member.role}</p>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                {/* Contact Info */}
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <span className="truncate">{member.email}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <span>{member.phone}</span>
                  </div>
                  {member.current_location && (
                    <div className="flex items-center gap-2 text-sm">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <span className="truncate">{member.current_location}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-2 text-sm">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span>Last active: {member.last_active}</span>
                  </div>
                </div>

                {/* Performance Stats */}
                <div className="border-t pt-4">
                  <h4 className="font-medium text-sm mb-3">Performance This Week</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">Properties Visited</p>
                      <p className="font-medium">{member.stats.properties_visited}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Leads Generated</p>
                      <p className="font-medium">{member.stats.leads_generated}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Conversion Rate</p>
                      <p className="font-medium">{member.stats.conversion_rate}%</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Response Time</p>
                      <p className="font-medium">{member.stats.avg_response_time}</p>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-2 pt-2">
                  <Button variant="outline" size="sm" className="flex-1">
                    View Details
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1">
                    Message
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredMembers.length === 0 && (
          <Card className="text-center py-12">
            <CardContent>
              <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-2">No team members found</h3>
              <p className="text-muted-foreground mb-4">
                {searchTerm ? 'Try adjusting your search criteria' : 'Invite team members to get started'}
              </p>
              {!searchTerm && (
                <Button onClick={handleInviteTeamMember}>
                  <Plus className="h-4 w-4 mr-2" />
                  Invite First Team Member
                </Button>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}