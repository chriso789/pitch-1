import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle, XCircle, AlertCircle, RefreshCw, Clock } from "lucide-react";
import { healthChecker, type HealthStatus } from "@/lib/healthz";
import { configManager } from "@/lib/config";

export default function Health() {
  const [healthChecks, setHealthChecks] = useState<HealthStatus[]>([]);
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  const runHealthChecks = async () => {
    setLoading(true);
    try {
      const results = await healthChecker.checkAll();
      setHealthChecks(results);
      setLastUpdated(new Date());
    } catch (error) {
      console.error('Health check failed:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    runHealthChecks();
  }, []);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "healthy":
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case "unhealthy":
        return <XCircle className="h-4 w-4 text-red-500" />;
      default:
        return <AlertCircle className="h-4 w-4 text-yellow-500" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const variant = status === "healthy" ? "default" : status === "unhealthy" ? "destructive" : "secondary";
    return <Badge variant={variant}>{status}</Badge>;
  };

  const overallHealth = healthChecks.every(check => check.status === 'healthy') ? 'healthy' : 
                      healthChecks.some(check => check.status === 'unhealthy') ? 'unhealthy' : 'unknown';

  return (
    <div className="container mx-auto py-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-foreground">System Health</h1>
            <p className="text-muted-foreground mt-2">
              Monitor the status of all integrated services and APIs
            </p>
          </div>
          <Button 
            onClick={runHealthChecks} 
            disabled={loading}
            size="sm"
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>

        {/* Overall Status */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {getStatusIcon(overallHealth)}
              Overall System Status
              {getStatusBadge(overallHealth)}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-muted-foreground">Environment:</span>
                <span className="ml-2 font-medium">{configManager.config?.app.env || 'Unknown'}</span>
              </div>
              <div>
                <span className="text-muted-foreground">Configuration:</span>
                <span className="ml-2 font-medium">
                  {configManager.isValid ? '✓ Valid' : '✗ Invalid'}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Individual Service Health */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {healthChecks.map((check) => (
            <Card key={check.name}>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center justify-between text-lg">
                  <div className="flex items-center gap-2">
                    {getStatusIcon(check.status)}
                    {check.name}
                  </div>
                  {getStatusBadge(check.status)}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {check.error && (
                    <p className="text-sm text-red-600">{check.error}</p>
                  )}
                  
                  {check.latency && (
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      {check.latency}ms
                    </div>
                  )}
                  
                  {check.details && (
                    <div className="text-xs text-muted-foreground">
                      {Object.entries(check.details).map(([key, value]) => (
                        <div key={key}>
                          {key}: {String(value)}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Configuration Errors */}
        {configManager.errors.length > 0 && (
          <Card className="mt-6 border-red-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-red-600">
                <XCircle className="h-5 w-5" />
                Configuration Issues
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {configManager.errors.map((error, index) => (
                  <div key={index} className="text-sm">
                    <span className="font-medium">{error.field}:</span>
                    <span className="text-red-600 ml-2">{error.message}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
        
        <div className="mt-8 text-center">
          <div className="mb-4 p-4 bg-muted/50 rounded-lg">
            <h2 className="text-lg font-semibold mb-2">About Health Checks</h2>
            <div className="text-sm text-muted-foreground space-y-2">
              <p>
                • <strong>Supabase:</strong> Database connectivity and authentication
              </p>
              <p>
                • <strong>Google Maps:</strong> Geocoding and mapping services  
              </p>
              <p>
                • <strong>Skiptrace:</strong> Property data enrichment services
              </p>
              <p>
                • <strong>Latency:</strong> Response time in milliseconds
              </p>
              <p>
                • <strong>Green:</strong> Service is healthy and responding normally
              </p>
              <p>
                • <strong>Red:</strong> Service is experiencing issues or unavailable
              </p>
            </div>
          </div>
          
          <p className="text-sm text-muted-foreground flex items-center justify-center gap-1">
            <Clock className="h-3 w-3" />
            Last updated: {lastUpdated?.toLocaleString() || 'Never'}
          </p>
        </div>
      </div>
    </div>
  );
}