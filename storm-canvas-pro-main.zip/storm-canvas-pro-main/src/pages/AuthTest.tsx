import { useAuth } from '@/components/AuthProvider';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { User, Mail, Key, Calendar, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function AuthTest() {
  const { user } = useAuth();

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-surface flex items-center justify-center p-6">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-destructive">Not Authenticated</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              You need to be signed in to view this page.
            </p>
            <Button asChild className="w-full">
              <Link to="/">Go to Dashboard</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-surface p-6">
      <div className="max-w-2xl mx-auto">
        <div className="mb-6">
          <Button asChild variant="outline" size="sm">
            <Link to="/">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Link>
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              Authentication Test Page
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* User ID */}
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Key className="h-4 w-4" />
                <span className="font-medium">User ID</span>
              </div>
              <div className="bg-muted p-3 rounded-md font-mono text-sm">
                {user.id}
              </div>
            </div>

            <Separator />

            {/* Email */}
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Mail className="h-4 w-4" />
                <span className="font-medium">Email</span>
              </div>
              <div className="bg-muted p-3 rounded-md">
                {user.email}
              </div>
            </div>

            <Separator />

            {/* Email Confirmed */}
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="font-medium">Email Confirmed</span>
              </div>
              <Badge variant={user.email_confirmed_at ? "default" : "destructive"}>
                {user.email_confirmed_at ? "Confirmed" : "Not Confirmed"}
              </Badge>
            </div>

            <Separator />

            {/* Created At */}
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Calendar className="h-4 w-4" />
                <span className="font-medium">Account Created</span>
              </div>
              <div className="bg-muted p-3 rounded-md">
                {new Date(user.created_at).toLocaleString()}
              </div>
            </div>

            <Separator />

            {/* Last Sign In */}
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Calendar className="h-4 w-4" />
                <span className="font-medium">Last Sign In</span>
              </div>
              <div className="bg-muted p-3 rounded-md">
                {user.last_sign_in_at ? new Date(user.last_sign_in_at).toLocaleString() : 'Never'}
              </div>
            </div>

            <Separator />

            {/* App Metadata */}
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="font-medium">App Metadata</span>
              </div>
              <div className="bg-muted p-3 rounded-md">
                <pre className="text-sm font-mono">
                  {JSON.stringify(user.app_metadata, null, 2)}
                </pre>
              </div>
            </div>

            <Separator />

            {/* User Metadata */}
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="font-medium">User Metadata</span>
              </div>
              <div className="bg-muted p-3 rounded-md">
                <pre className="text-sm font-mono">
                  {JSON.stringify(user.user_metadata, null, 2)}
                </pre>
              </div>
            </div>

            <Separator />

            {/* Role/Claims Information */}
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="font-medium">Roles & Claims</span>
              </div>
              <div className="space-y-2">
                {user.app_metadata?.roles && user.app_metadata.roles.length > 0 ? (
                  <div className="flex flex-wrap gap-2">
                    {user.app_metadata.roles.map((role: string, index: number) => (
                      <Badge key={index} variant="secondary">
                        {role}
                      </Badge>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground">No roles assigned</p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}