import React, { useState, useEffect, useRef } from 'react';
import { GoogleMap, Marker, InfoWindow, OverlayView } from '@react-google-maps/api';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Loader2, Target, Plus, Navigation, Car, Search } from "lucide-react";
import { EnhancedSearch } from "@/components/EnhancedSearch";
import { useCanvassing, type Property, type Disposition } from "@/hooks/useCanvassing";
import { useNearestLocations } from "@/hooks/useNearestLocations";
import { usePins } from "@/hooks/usePins";
import { useLocationDetails } from "@/hooks/useLocationDetails";
import { useGeolocation } from "@/hooks/useGeolocation";
import { useGoogleMapsKey } from "@/hooks/useGoogleMapsKey";
import { useGoogleMaps } from "@/hooks/useGoogleMaps";
import { DispositionBubble } from "@/components/DispositionBubble";
import { DrawingTools } from "@/components/DrawingTools";
import { MeasurementDrawingManager } from "@/components/Canvassing/MeasurementDrawingManager";
import HomeownerPanel from "@/components/Canvassing/HomeownerPanel";
import MeasurePanel from "@/components/Canvassing/MeasurePanel";
import PhotosPanel from "@/components/Canvassing/PhotosPanel";
import ReportsPanel from "@/components/Canvassing/ReportsPanel";
import { StatusQuickActions } from "@/components/Canvassing/StatusQuickActions";
import { PropertyInfoWindow } from "@/components/Canvassing/PropertyInfoWindow";
import { HeaderDispositionButtons } from "@/components/Canvassing/HeaderDispositionButtons";
import { HomeownerContactModal } from "@/components/HomeownerContactModal";
import { toast } from "sonner";
import { useAuth } from "@/components/AuthProvider";
import { useAutoPopulate } from "@/hooks/useAutoPopulate";

// Google Maps API Key - now loaded from Supabase secrets with environment fallback

const mapContainerStyle = {
  width: '100%',
  height: '100%',
};

const mapOptions = {
  disableDefaultUI: false,
  clickableIcons: false,
  scrollwheel: true,
  gestureHandling: 'auto',
  zoomControl: true,
  mapTypeControl: true,
  streetViewControl: false,
  fullscreenControl: false,
  mapTypeId: 'satellite',
  tilt: 0,
  heading: 0,
  // Keep labels visible at all times on satellite view
  styles: [
    {
      featureType: 'all',
      elementType: 'labels',
      stylers: [{ visibility: 'on' }]
    }
  ],
};

export default function Canvassing() {
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [mapCenter, setMapCenter] = useState({ lat: 26.37, lng: -80.10 }); // Boca Raton, FL (where property data is located)
  const [mapZoom, setMapZoom] = useState(15); // Wider initial zoom to show property area
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [mapBounds, setMapBounds] = useState<google.maps.LatLngBounds | null>(null);
  const [isMobileView, setIsMobileView] = useState(window.innerWidth < 768);
  const [showDrawingTools, setShowDrawingTools] = useState(false);
  const [mapInstance, setMapInstance] = useState<google.maps.Map | null>(null);
  const [showStatusPanel, setShowStatusPanel] = useState(false);
  const [locationAccuracy, setLocationAccuracy] = useState<number | null>(null);
  const [showContactModal, setShowContactModal] = useState(false);
  const [selectedPinForContact, setSelectedPinForContact] = useState<any>(null);
  const [canvassingMode, setCanvassingMode] = useState<'knock' | 'search'>(() => {
    return (localStorage.getItem('canvassingMode') as 'knock' | 'search') || 'search';
  });
  const [showSearch, setShowSearch] = useState(false);
  const watchIdRef = useRef<number | null>(null);
  
  const { user } = useAuth();
  const { apiKey: GOOGLE_MAPS_API_KEY, loading: apiKeyLoading, error: apiKeyError } = useGoogleMapsKey();
  const { isLoaded } = useGoogleMaps();
  const { populateArea, autoDetectProperties, isPopulating } = useAutoPopulate();

  const { 
    properties, 
    dispositions, 
    loading, 
    error,
    updateProperty, 
    setPropertyDisposition 
  } = useCanvassing();

  const { pins, loading: pinsLoading, fetchNearestLocations, addProperty } = useNearestLocations();
  const { pins: bboxPins, loading: bboxLoading, fetchPinsBbox } = usePins("supabase");
  const { details, loading: detailsLoading, fetchLocationDetails, clearDetails } = useLocationDetails();
  const { coordinates, getCurrentPosition, loading: locationLoading } = useGeolocation();
  const [selectedPin, setSelectedPin] = useState<any>(null);
  const [locationPermissionRequested, setLocationPermissionRequested] = useState(false);

  // Helper function to calculate distance between two points in meters
  const calculateDistance = (lat1: number, lng1: number, lat2: number, lng2: number): number => {
    const R = 6371e3; // Earth's radius in meters
    const φ1 = (lat1 * Math.PI) / 180;
    const φ2 = (lat2 * Math.PI) / 180;
    const Δφ = ((lat2 - lat1) * Math.PI) / 180;
    const Δλ = ((lng2 - lng1) * Math.PI) / 180;

    const a =
      Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
      Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return R * c;
  };

  // Helper to calculate buffered bbox with adaptive buffering based on zoom and mode
  const getBufferedBounds = (bounds: google.maps.LatLngBounds, zoom: number = 17, mode: 'knock' | 'search' = 'search') => {
    const ne = bounds.getNorthEast();
    const sw = bounds.getSouthWest();
    
    // Much larger buffer in knock mode for aggressive following (50-75%)
    // Normal buffer in search mode (30-50%)
    const bufferPercent = mode === 'knock' 
      ? (zoom >= 19 ? 0.75 : zoom >= 17 ? 0.60 : 0.50)
      : (zoom >= 19 ? 0.50 : zoom >= 17 ? 0.40 : 0.30);
    
    const lngBuffer = (ne.lng() - sw.lng()) * bufferPercent;
    const latBuffer = (ne.lat() - sw.lat()) * bufferPercent;
    
    // Minimum buffer distance: 200m in search mode, 300m in knock mode
    const minBufferDegrees = mode === 'knock' ? 0.003 : 0.002;
    const finalLngBuffer = Math.max(lngBuffer, minBufferDegrees);
    const finalLatBuffer = Math.max(latBuffer, minBufferDegrees);

    return {
      minLng: sw.lng() - finalLngBuffer,
      minLat: sw.lat() - finalLatBuffer,
      maxLng: ne.lng() + finalLngBuffer,
      maxLat: ne.lat() + finalLatBuffer
    };
  };

  // Handle window resize for mobile detection
  useEffect(() => {
    const handleResize = () => setIsMobileView(window.innerWidth < 768);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Request location on component mount
  useEffect(() => {
    if (!locationPermissionRequested) {
      setLocationPermissionRequested(true);
      getCurrentPosition();
    }
  }, [getCurrentPosition, locationPermissionRequested]);

  // Update map center when user location is obtained
  useEffect(() => {
    if (coordinates && !userLocation) {
      const newCenter = { lat: coordinates.lat, lng: coordinates.lng };
      setMapCenter(newCenter);
      setUserLocation(newCenter);
      setLocationAccuracy(coordinates.accuracy);
      setMapZoom(19); // High zoom for parcel-level detail
      toast.success(`Centered on your location (±${Math.round(coordinates.accuracy)}m)`);
    }
  }, [coordinates, userLocation]);

  // Persist mode preference
  useEffect(() => {
    localStorage.setItem('canvassingMode', canvassingMode);
  }, [canvassingMode]);

  // Knock Mode: GPS tracking with auto-follow and aggressive pin loading
  useEffect(() => {
    if (canvassingMode === 'knock' && 'geolocation' in navigator) {
      watchIdRef.current = navigator.geolocation.watchPosition(
        (position) => {
          const newLocation = {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          };
          setUserLocation(newLocation);
          setMapCenter(newLocation); // Auto-follow in knock mode
          setLocationAccuracy(position.coords.accuracy);
          setMapZoom(20); // Very high zoom for knock mode
          
          // Force map bounds update when GPS location changes
          if (mapInstance) {
            const currentBounds = mapInstance.getBounds();
            if (currentBounds) {
              setMapBounds(currentBounds);
            }
          }
        },
        (error) => {
          console.error('GPS tracking error:', error);
        },
        {
          enableHighAccuracy: true,
          maximumAge: 1000,
          timeout: 5000,
        }
      );

      return () => {
        if (watchIdRef.current !== null) {
          navigator.geolocation.clearWatch(watchIdRef.current);
        }
      };
    }
  }, [canvassingMode, mapInstance]);

  // Intelligent auto-detection with density checking - uses CURRENT map view
  useEffect(() => {
    if (mapBounds && mapInstance && isLoaded && !isPopulating) {
      // Get fresh center coordinates from the map instance
      const center = mapInstance.getCenter();
      if (!center) return;

      const bounds = mapBounds;
      const ne = bounds.getNorthEast();
      const sw = bounds.getSouthWest();
      
      // Calculate area in square kilometers
      const latDistance = calculateDistance(sw.lat(), sw.lng(), ne.lat(), sw.lng()) / 1000;
      const lngDistance = calculateDistance(sw.lat(), sw.lng(), sw.lat(), ne.lng()) / 1000;
      const areaSqKm = latDistance * lngDistance;
      
      // Calculate pin density
      const pinDensity = bboxPins.length / areaSqKm;
      const zoom = mapInstance.getZoom() || 17;
      
      // Expected density based on zoom (pins per sq km)
      const expectedDensity = zoom >= 19 ? 5000 : zoom >= 17 ? 1000 : zoom >= 15 ? 200 : 50;
      
      // Debounce auto-detection
      const timeoutId = setTimeout(() => {
        // More aggressive auto-detection: trigger at 60% of expected density or at high zoom
        if (pinDensity < expectedDensity * 0.60 || zoom >= 18 || bboxPins.length < 5) {
          // Use FRESH coordinates from map, not cached state
          const freshCenter = mapInstance.getCenter();
          if (!freshCenter) return;
          
          const centerLat = freshCenter.lat();
          const centerLng = freshCenter.lng();
          
          console.log(`🎯 Auto-detect at: ${centerLat.toFixed(4)}, ${centerLng.toFixed(4)} (density: ${pinDensity.toFixed(0)}/${expectedDensity.toFixed(0)})`);
          
          const radiusMeters = Math.max(
            calculateDistance(centerLat, centerLng, ne.lat(), ne.lng()),
            calculateDistance(centerLat, centerLng, sw.lat(), sw.lng())
          );
          
          autoDetectProperties(centerLat, centerLng, Math.min(radiusMeters, 1000)).then(() => {
            fetchPinsBbox(sw.lng(), sw.lat(), ne.lng(), ne.lat());
          });
        }
      }, 2000); // Increased to 2s to reduce over-triggering
      
      return () => clearTimeout(timeoutId);
    }
  }, [mapBounds, mapInstance, isLoaded, isPopulating, bboxPins.length, autoDetectProperties, fetchPinsBbox, calculateDistance]);

  // GPS-based pin loading for knock mode - follows the blue dot aggressively
  useEffect(() => {
    if (canvassingMode === 'knock' && userLocation && mapInstance && isLoaded) {
      // Create bounds around GPS location
      const zoom = mapInstance.getZoom() || 20;
      const latDelta = 0.001; // ~111 meters
      const lngDelta = 0.001;
      
      const gpsBounds = new google.maps.LatLngBounds(
        new google.maps.LatLng(userLocation.lat - latDelta, userLocation.lng - lngDelta),
        new google.maps.LatLng(userLocation.lat + latDelta, userLocation.lng + lngDelta)
      );
      
      // Use large buffer for knock mode
      const buffered = getBufferedBounds(gpsBounds, zoom, 'knock');
      
      console.log('🚗 GPS Pin Loading (Knock Mode):', {
        gps: `${userLocation.lat.toFixed(6)}, ${userLocation.lng.toFixed(6)}`,
        buffered: `${buffered.minLng.toFixed(4)} to ${buffered.maxLng.toFixed(4)} (lng), ${buffered.minLat.toFixed(4)} to ${buffered.maxLat.toFixed(4)} (lat)`,
        bufferMeters: `~${((buffered.maxLng - userLocation.lng) * 111000).toFixed(0)}m`,
        pinsLoaded: bboxPins.length
      });
      
      // Minimal debounce for GPS updates (100ms to prevent thrashing)
      const timeoutId = setTimeout(async () => {
        await fetchPinsBbox(buffered.minLng, buffered.minLat, buffered.maxLng, buffered.maxLat);
        
        // Auto-detect and populate if low pin count in GPS area
        if (bboxPins.length < 5 && !isPopulating) {
          console.log('🚗 Auto-populating around GPS (low pin count)');
          const radiusMeters = Math.max(
            calculateDistance(userLocation.lat, userLocation.lng, buffered.maxLat, buffered.maxLng),
            500 // Minimum 500m radius
          );
          autoDetectProperties(userLocation.lat, userLocation.lng, Math.min(radiusMeters, 1000));
        }
      }, 100);
      
      return () => clearTimeout(timeoutId);
    }
  }, [canvassingMode, userLocation, mapInstance, isLoaded, fetchPinsBbox, bboxPins.length, isPopulating, autoDetectProperties, calculateDistance]);

  // Load pins using viewport bounds for search mode with zoom-based debouncing
  useEffect(() => {
    if (canvassingMode === 'search' && mapBounds && isLoaded && mapInstance) {
      const ne = mapBounds.getNorthEast();
      const sw = mapBounds.getSouthWest();
      const zoom = mapInstance.getZoom() || 17;
      
      // Calculate buffered bounds with adaptive zoom-based buffering
      const buffered = getBufferedBounds(mapBounds, zoom, 'search');
      
      // Enhanced logging for debugging coverage issues
      const center = mapInstance.getCenter();
      const bufferSizeLng = Math.abs(buffered.maxLng - ne.lng());
      const bufferSizeLat = Math.abs(buffered.maxLat - ne.lat());
      const bufferPercent = (bufferSizeLng / Math.abs(ne.lng() - sw.lng()) * 100).toFixed(0);
      
      console.log('🔍 Search Mode Pin Loading:', {
        center: center ? `${center.lat().toFixed(4)}, ${center.lng().toFixed(4)}` : 'unknown',
        viewport: `${sw.lng().toFixed(4)} to ${ne.lng().toFixed(4)} (lng), ${sw.lat().toFixed(4)} to ${ne.lat().toFixed(4)} (lat)`,
        buffered: `${buffered.minLng.toFixed(4)} to ${buffered.maxLng.toFixed(4)} (lng), ${buffered.minLat.toFixed(4)} to ${buffered.maxLat.toFixed(4)} (lat)`,
        bufferSize: `${bufferPercent}% (${(bufferSizeLng * 111).toFixed(0)}m x ${(bufferSizeLat * 111).toFixed(0)}m)`,
        zoom,
        pinsInView: bboxPins.length
      });
      
      // Longer debounce at lower zoom levels to reduce API calls
      const debounceMs = zoom >= 18 ? 200 : zoom >= 16 ? 400 : 600;
      
      const timeoutId = setTimeout(() => {
        fetchPinsBbox(buffered.minLng, buffered.minLat, buffered.maxLng, buffered.maxLat);
      }, debounceMs);
      
      return () => clearTimeout(timeoutId);
    }
  }, [canvassingMode, mapBounds, isLoaded, mapInstance, fetchPinsBbox]);

  // Handle clicking on a pin from the new API - triggers skip trace
  const handlePinClick = (pin: any) => {
    console.log('📍 Pin clicked:', pin);
    setSelectedPin(pin);
    setSelectedPinForContact({
      id: pin.id,
      address: pin.address,
      latitude: pin.lat,
      longitude: pin.lng,
    });
    setShowContactModal(true);
    // Fetch detailed information for this location
    fetchLocationDetails(pin.addressHash);
  };

  // Handle map load - fetch initial pins
  const handleMapLoad = (map: google.maps.Map) => {
    setMapInstance(map);
    
    // Immediately fetch pins for the initial viewport
    const bounds = map.getBounds();
    if (bounds) {
      setMapBounds(bounds);
      const ne = bounds.getNorthEast();
      const sw = bounds.getSouthWest();
      fetchPinsBbox(sw.lng(), sw.lat(), ne.lng(), ne.lat());
    }
    
    const zoom = map.getZoom();
    if (zoom) {
      setMapZoom(zoom);
    }
  };

  // Handle bounds changed to load pins in viewport
  const handleBoundsChanged = () => {
    if (mapInstance) {
      const bounds = mapInstance.getBounds();
      if (bounds) {
        setMapBounds(bounds);
      }
      const zoom = mapInstance.getZoom();
      if (zoom) {
        setMapZoom(zoom);
      }
    }
  };

  // Handle auto-populate button click
  const handleAutoPopulate = async () => {
    if (!mapInstance) return;
    
    const bounds = mapInstance.getBounds();
    if (!bounds) return;

    const ne = bounds.getNorthEast();
    const sw = bounds.getSouthWest();
    
    const result = await populateArea({
      minLng: sw.lng(),
      minLat: sw.lat(),
      maxLng: ne.lng(),
      maxLat: ne.lat()
    });
    
    if (result.success && result.inserted > 0) {
      // Refresh pins after successful population
      fetchPinsBbox(sw.lng(), sw.lat(), ne.lng(), ne.lat());
    }
  };

  const handleContactConfirmed = async (contactId: string, dispositionId: string, appointmentDate?: Date) => {
    try {
      // Refresh pins to show updated disposition color
      fetchNearestLocations({ lat: mapCenter.lat, lng: mapCenter.lng });
      setSelectedPin(null);
      setSelectedPinForContact(null);
      toast.success('Contact and disposition saved successfully');
    } catch (error) {
      console.error('Error after contact confirmation:', error);
    }
  };

  const handleDispositionChange = async (dispositionId: string) => {
    if (!selectedProperty) return;
    
    if (!user) {
      toast.error('Please sign in to update property status');
      return;
    }

    try {
      const updatedProperty = await setPropertyDisposition(selectedProperty.id, dispositionId);
      setSelectedProperty(updatedProperty);
      setShowStatusPanel(false);
      toast.success('Property status updated successfully');
    } catch (error) {
      toast.error('Failed to update property status');
    }
  };

  const handlePropertyUpdate = async (field: string, value: string | number) => {
    if (!selectedProperty) return;

    try {
      const updatedProperty = await updateProperty(selectedProperty.id, { [field]: value });
      setSelectedProperty(updatedProperty);
      toast.success('Property updated successfully');
    } catch (error) {
      toast.error('Failed to update property');
    }
  };

  const handleMarkerClick = (property: Property) => {
    setSelectedProperty(property);
  };


  const centerOnUserLocation = () => {
    if (userLocation) {
      setMapCenter(userLocation);
      setMapZoom(canvassingMode === 'knock' ? 20 : 19);
    } else {
      getCurrentPosition();
    }
  };

  const handleSearchSelect = (result: any) => {
    if (mapInstance && result.lat && result.lng) {
      const newCenter = { lat: result.lat, lng: result.lng };
      setMapCenter(newCenter);
      mapInstance.panTo(newCenter);
      mapInstance.setZoom(18);
      setShowSearch(false);
    }
  };

  if (apiKeyLoading || !isLoaded) {
    return (
      <div className="min-h-screen bg-gradient-surface flex items-center justify-center">
        <div className="flex items-center gap-2">
          <Loader2 className="h-5 w-5 animate-spin" />
          <span>Loading Google Maps...</span>
        </div>
      </div>
    );
  }

  if (!GOOGLE_MAPS_API_KEY) {
    return (
      <div className="min-h-screen bg-gradient-surface flex items-center justify-center p-6">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-destructive">
              <MapPin className="h-5 w-5" />
              Google Maps Setup Required
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              Google Maps API key is not configured. Please set it up in the setup wizard.
            </p>
            <Button onClick={() => window.location.href = '/auth'} className="w-full">
              Go to Setup
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-surface flex items-center justify-center">
        <div className="flex items-center gap-2">
          <Loader2 className="h-5 w-5 animate-spin" />
          <span>Loading properties...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-surface flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-destructive">Error</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">{error}</p>
            <Button onClick={() => window.location.reload()} className="w-full">
              Retry
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-surface">
      <div className="p-4 h-screen">
        {/* Map Container - Full width */}
        <div className="w-full h-full relative">
          <GoogleMap
            mapContainerStyle={mapContainerStyle}
            center={mapCenter}
            zoom={mapZoom}
            options={mapOptions}
            onLoad={handleMapLoad}
            onBoundsChanged={handleBoundsChanged}
          >
            {/* User location marker */}
            {userLocation && isLoaded && (
              <Marker
                position={userLocation}
                icon={{
                  path: google.maps.SymbolPath.CIRCLE,
                  fillColor: '#3b82f6',
                  fillOpacity: 1,
                  strokeColor: '#ffffff',
                  strokeWeight: 2,
                  scale: 8,
                }}
                title="Your Location"
                zIndex={1000}
              />
            )}

            {/* Measurement Drawing Manager */}
            <MeasurementDrawingManager map={mapInstance} />

            {/* Render properties from viewport-based fetch with disposition bubbles */}
            {bboxPins.map((property) => (
              <React.Fragment key={property.id}>
                {/* Invisible marker for click handling */}
                <Marker
                  position={{
                    lat: property.lat,
                    lng: property.lng,
                  }}
                  onClick={() => handlePinClick(property)}
                  icon={{
                    path: google.maps.SymbolPath.CIRCLE,
                    scale: 0.1,
                    fillColor: 'transparent',
                    fillOpacity: 0,
                    strokeWeight: 0,
                  }}
                />
                {/* Always show bubble - transparent for uncontacted, colored for contacted */}
                <OverlayView
                  position={{
                    lat: property.lat,
                    lng: property.lng,
                  }}
                  mapPaneName={OverlayView.OVERLAY_MOUSE_TARGET}
                >
                  <div onClick={() => handlePinClick(property)} className="cursor-pointer">
                    <DispositionBubble
                      disposition={property.disposition}
                      color={property.disposition_color}
                      position={{ lat: property.lat, lng: property.lng }}
                      zoom={mapZoom}
                    />
                  </div>
                </OverlayView>
              </React.Fragment>
            ))}

            
            {selectedProperty && (
              <InfoWindow
                position={{
                  lat: selectedProperty.latitude,
                  lng: selectedProperty.longitude,
                }}
                onCloseClick={() => {
                  setSelectedProperty(null);
                  setShowStatusPanel(false);
                }}
              >
                <PropertyInfoWindow
                  property={selectedProperty}
                  onStatusClick={() => setShowStatusPanel(true)}
                />
              </InfoWindow>
            )}
          </GoogleMap>
          

          {/* Mode Toggle - Move down when disposition buttons are shown */}
          <div className={`absolute left-1/2 -translate-x-1/2 z-10 ${(selectedProperty || selectedPin) ? 'top-20' : 'top-4'}`}>
            <div className="flex items-center gap-2 bg-background/95 backdrop-blur rounded-lg shadow-lg p-1">
              <Button
                size="sm"
                variant={canvassingMode === 'knock' ? 'default' : 'ghost'}
                onClick={() => setCanvassingMode('knock')}
                className="gap-2"
              >
                <Car className="h-4 w-4" />
                Knock Mode
              </Button>
              <Button
                size="sm"
                variant={canvassingMode === 'search' ? 'default' : 'ghost'}
                onClick={() => setCanvassingMode('search')}
                className="gap-2"
              >
                <Search className="h-4 w-4" />
                Search Mode
              </Button>
            </div>
          </div>

          {/* Location Status Indicator */}
          {locationLoading && (
            <div className="absolute top-16 left-1/2 -translate-x-1/2 z-10">
              <Badge variant="secondary" className="shadow-lg bg-background/95 backdrop-blur">
                <Loader2 className="h-3 w-3 animate-spin mr-2" />
                Getting your location...
              </Badge>
            </div>
          )}
          
          {userLocation && !locationLoading && canvassingMode === 'knock' && (
            <div className="absolute top-16 left-1/2 -translate-x-1/2 z-10">
              <Badge variant="secondary" className="shadow-lg bg-background/95 backdrop-blur">
                <Navigation className="h-3 w-3 mr-2 text-primary" />
                GPS Tracking Active (±{locationAccuracy ? Math.round(locationAccuracy) : '?'}m)
              </Badge>
            </div>
          )}

          {/* Property Count & Location Indicator */}
          <div className="absolute top-4 left-4 z-10 flex flex-col gap-2">
            <Card className="shadow-lg bg-background/95 backdrop-blur border">
              <CardContent className="p-3 space-y-2">
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-primary" />
                  <div className="text-sm">
                    <span className="font-semibold">{bboxPins.length}</span>
                    <span className="ml-1 text-muted-foreground">
                      {bboxPins.length === 1 ? 'pin' : 'pins'} visible
                    </span>
                  </div>
                </div>
                {mapInstance && (() => {
                  const center = mapInstance.getCenter();
                  return center ? (
                    <div className="text-xs text-muted-foreground font-mono">
                      {center.lat().toFixed(4)}, {center.lng().toFixed(4)}
                    </div>
                  ) : null;
                })()}
                {mapBounds && mapInstance && (() => {
                  const ne = mapBounds.getNorthEast();
                  const sw = mapBounds.getSouthWest();
                  const latDist = calculateDistance(sw.lat(), sw.lng(), ne.lat(), sw.lng()) / 1000;
                  const lngDist = calculateDistance(sw.lat(), sw.lng(), sw.lat(), ne.lng()) / 1000;
                  const areaSqKm = latDist * lngDist;
                  const density = bboxPins.length / areaSqKm;
                  const zoom = mapInstance.getZoom() || 17;
                  const expectedDensity = zoom >= 19 ? 5000 : zoom >= 17 ? 1000 : zoom >= 15 ? 200 : 50;
                  const coveragePercent = Math.min(100, (density / expectedDensity) * 100);
                  
                  return coveragePercent < 50 ? (
                    <Badge variant="outline" className="text-xs bg-yellow-500/10 border-yellow-500/50 text-yellow-700 dark:text-yellow-400">
                      Low coverage ({coveragePercent.toFixed(0)}%)
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="text-xs bg-green-500/10 border-green-500/50 text-green-700 dark:text-green-400">
                      Good coverage ({coveragePercent.toFixed(0)}%)
                    </Badge>
                  );
                })()}
              </CardContent>
            </Card>
          </div>

          {/* Map controls */}
          <div className="absolute top-4 right-4 z-10 flex flex-col gap-2">
            {canvassingMode === 'search' && (
              <>
                <Button 
                  size="sm"
                  variant={showSearch ? "default" : "outline"}
                  className="shadow-lg"
                  onClick={() => setShowSearch(!showSearch)}
                  title="Search address"
                >
                  <Search className="h-4 w-4" />
                </Button>
                <Button 
                  size="sm"
                  onClick={async () => {
                    if (!mapInstance) return;
                    const center = mapInstance.getCenter();
                    if (!center) return;
                    
                    const zoom = mapInstance.getZoom() || 17;
                    console.log(`🎯 Manual scan at: ${center.lat()}, ${center.lng()}`);
                    
                    const result = await autoDetectProperties(
                      center.lat(),
                      center.lng(),
                      zoom >= 17 ? 500 : zoom >= 16 ? 750 : 1000
                    );
                    
                    if (result.success) {
                      const bounds = mapInstance.getBounds();
                      if (bounds) {
                        const ne = bounds.getNorthEast();
                        const sw = bounds.getSouthWest();
                        await fetchPinsBbox(sw.lng(), sw.lat(), ne.lng(), ne.lat());
                      }
                    }
                  }}
                  disabled={isPopulating || !mapInstance}
                  className="shadow-lg bg-primary hover:bg-primary/90"
                  title="Scan & load properties in current view"
                >
                  {isPopulating ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin mr-1" />
                      <span className="text-xs">Scanning...</span>
                    </>
                  ) : (
                    <>
                      <Plus className="h-4 w-4 mr-1" />
                      <span className="text-xs">Scan Area</span>
                    </>
                  )}
                </Button>
              </>
            )}
            <Button
              size="sm"
              className="shadow-lg"
              onClick={centerOnUserLocation}
              disabled={locationLoading}
              title="Center on my location"
            >
              {locationLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Target className="h-4 w-4" />
              )}
            </Button>
            <Button 
              size="sm"
              className="shadow-lg"
              onClick={() => setShowDrawingTools(!showDrawingTools)}
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>

          {/* Search Panel - Search Mode Only */}
          {canvassingMode === 'search' && showSearch && (
            <div className="absolute top-4 left-4 z-10 w-96">
              <Card className="shadow-lg bg-background/95 backdrop-blur">
                <CardContent className="p-4">
                  <EnhancedSearch
                    onSelect={handleSearchSelect}
                  />
                </CardContent>
              </Card>
            </div>
          )}

          {/* Drawing Tools */}
          {showDrawingTools && (
            <div className="absolute top-4 left-4 z-10">
              <DrawingTools
                map={mapInstance}
                propertyId={selectedPin?.address_hash}
                onClose={() => setShowDrawingTools(false)}
              />
            </div>
          )}
        </div>
      </div>

      {/* Homeowner Contact Modal */}
      {selectedPinForContact && (
        <HomeownerContactModal
          open={showContactModal}
          onOpenChange={setShowContactModal}
          propertyId={selectedPinForContact.id || ''}
          propertyAddress={selectedPinForContact.address?.line1 || 'Unknown Address'}
          propertyLat={selectedPinForContact.latitude || 0}
          propertyLng={selectedPinForContact.longitude || 0}
          onContactConfirmed={handleContactConfirmed}
          locationDetails={details}
        />
      )}
    </div>
  );
}