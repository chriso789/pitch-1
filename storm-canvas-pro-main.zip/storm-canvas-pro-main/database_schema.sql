-- Database Schema for Canvassing App
-- Run this SQL in your Supabase SQL Editor

-- Create properties table
CREATE TABLE IF NOT EXISTS properties (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  address TEXT NOT NULL,
  latitude DECIMAL(10, 8) NOT NULL,
  longitude DECIMAL(11, 8) NOT NULL,
  homeowner_name TEXT,
  phone TEXT,
  email TEXT,
  credit_score INTEGER,
  age INTEGER,
  gender TEXT,
  disposition TEXT,
  disposition_color TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW()),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW()),
  created_by UUID REFERENCES auth.users(id),
  team_id UUID
);

-- Create dispositions table
CREATE TABLE IF NOT EXISTS dispositions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  color TEXT NOT NULL,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW())
);

-- Create property_visits table to track interactions
CREATE TABLE IF NOT EXISTS property_visits (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id UUID REFERENCES properties(id) ON DELETE CASCADE,
  user_id UUID REFERENCES auth.users(id),
  disposition_id UUID REFERENCES dispositions(id),
  notes TEXT,
  visited_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW()),
  latitude DECIMAL(10, 8),
  longitude DECIMAL(11, 8)
);

-- Insert default dispositions
INSERT INTO dispositions (name, color, description) VALUES
  ('Not Home', '#94a3b8', 'Nobody answered'),
  ('Interested', '#22c55e', 'Showed interest'),
  ('Not Interested', '#ef4444', 'Declined service'),
  ('Callback', '#f59e0b', 'Requested callback'),
  ('Appointment Set', '#3b82f6', 'Meeting scheduled'),
  ('Do Not Contact', '#6b7280', 'Requested no contact')
ON CONFLICT (name) DO NOTHING;

-- Insert sample properties for testing
INSERT INTO properties (address, latitude, longitude, homeowner_name, phone, email, credit_score, age, gender) VALUES
  ('123 Main St, Dallas, TX 75201', 32.7767, -96.7970, 'John Smith', '(555) 123-4567', 'john.smith@email.com', 720, 45, 'Male'),
  ('456 Oak Ave, Dallas, TX 75202', 32.7787, -96.7990, 'Sarah Johnson', '(555) 987-6543', 'sarah.j@email.com', 680, 38, 'Female'),
  ('789 Pine St, Dallas, TX 75203', 32.7747, -96.7950, 'Mike Davis', '(555) 456-7890', 'mike.davis@email.com', 750, 52, 'Male');

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_properties_location ON properties (latitude, longitude);
CREATE INDEX IF NOT EXISTS idx_properties_team ON properties (team_id);
CREATE INDEX IF NOT EXISTS idx_property_visits_property ON property_visits (property_id);
CREATE INDEX IF NOT EXISTS idx_property_visits_user ON property_visits (user_id);

-- Enable Row Level Security
ALTER TABLE properties ENABLE ROW LEVEL SECURITY;
ALTER TABLE dispositions ENABLE ROW LEVEL SECURITY;
ALTER TABLE property_visits ENABLE ROW LEVEL SECURITY;

-- RLS Policies for properties
CREATE POLICY "Users can view all properties" ON properties
  FOR SELECT USING (true);

CREATE POLICY "Users can insert properties" ON properties
  FOR INSERT WITH CHECK (auth.uid() = created_by);

CREATE POLICY "Users can update properties" ON properties
  FOR UPDATE USING (true);

-- RLS Policies for dispositions
CREATE POLICY "Anyone can view dispositions" ON dispositions
  FOR SELECT USING (true);

-- RLS Policies for property_visits
CREATE POLICY "Users can view all visits" ON property_visits
  FOR SELECT USING (true);

CREATE POLICY "Users can insert their own visits" ON property_visits
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = TIMEZONE('utc', NOW());
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Add trigger for properties table
CREATE TRIGGER update_properties_updated_at 
  BEFORE UPDATE ON properties 
  FOR EACH ROW 
  EXECUTE FUNCTION update_updated_at_column();