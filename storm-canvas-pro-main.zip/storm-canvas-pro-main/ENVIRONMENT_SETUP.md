# Canvass-IQ Environment Setup Guide

## Quick Start

1. Copy the environment template:
   ```bash
   cp .env.local.example .env.local
   ```

2. Fill in your actual values in `.env.local`

3. Verify your configuration:
   ```bash
   node scripts/verify-env.js
   # OR
   bash scripts/run-verify-env.sh
   ```

## Required Environment Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `VITE_SUPABASE_URL` | Your Supabase project URL | `https://your-project.supabase.co` |
| `VITE_SUPABASE_ANON_KEY` | Supabase anonymous key | `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...` |
| `VITE_MAPBOX_TOKEN` | Mapbox public token | `pk.eyJ1IjoieW91ci11c...` |
| `VITE_SKIPTRACE_BASE_URL` | Skiptrace API base URL | `https://api.skiptracing-provider.com/v1` |
| `VITE_SKIPTRACE_API_KEY` | Skiptrace API key | `sk_live_...` |
| `VITE_APP_ENV` | Application environment | `development`, `staging`, `production` |

## Optional Environment Variables

| Variable | Description |
|----------|-------------|
| `VITE_SENTRY_DSN` | Sentry error tracking DSN |

## CI/CD Integration

Add this to your CI/CD pipeline:

```yaml
# GitHub Actions example
- name: Verify Environment
  run: node scripts/verify-env.js
```

```bash
# Shell script
bash scripts/run-verify-env.sh
```

## Configuration Validation

The app uses Zod for runtime validation of all environment variables. If any required variables are missing or invalid:

1. The app will automatically redirect to `/setup`
2. Detailed error messages will be shown
3. No sensitive values will be logged

## Security Notes

- Never commit `.env.local` files
- Use the `.env.test` file for automated testing
- All secret values are redacted in error messages
- The setup wizard provides user-friendly configuration guidance

## Gate 0 Acceptance Criteria ✅

- [x] `.env.local.example` exists with all keys and comments
- [x] Boot without secrets routes to `/setup`; with secrets proceeds to Dashboard
- [x] Environment verification script available (`verify:env`)
- [x] No secrets printed in logs (redacted in errors)
- [x] Single source of truth config module with Zod validation
- [x] App shows specific setup errors without console stack dumps