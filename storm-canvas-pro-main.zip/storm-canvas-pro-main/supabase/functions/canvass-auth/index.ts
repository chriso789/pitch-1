import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { z } from "https://deno.land/x/zod@v3.22.4/mod.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Input validation schema
const authRequestSchema = z.object({
  api_key: z.string().min(1, "API key is required"),
  rep_email: z.string().email("Valid email is required")
});

serve(async (req) => {
  console.log(`📥 ${req.method} /canvass-auth`);
  
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  if (req.method !== 'POST') {
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: 'Method not allowed. Use POST.' 
      }),
      { 
        status: 405, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }

  try {
    // Get the stored Storm Canvass API key from secrets
    const stormCanvassApiKey = Deno.env.get('STORM_CANVASS_API_KEY');
    
    if (!stormCanvassApiKey) {
      console.error('❌ STORM_CANVASS_API_KEY not configured');
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: 'Storm Canvass API not configured' 
        }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Parse and validate request body
    const requestBody = await req.json();
    console.log('📝 Request body received:', { 
      api_key: requestBody.api_key ? '[REDACTED]' : 'missing',
      rep_email: requestBody.rep_email || 'missing'
    });

    const validationResult = authRequestSchema.safeParse(requestBody);
    
    if (!validationResult.success) {
      console.log('❌ Validation failed:', validationResult.error.issues);
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: 'Invalid request data',
          details: validationResult.error.issues 
        }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    const { api_key, rep_email } = validationResult.data;

    // Validate the provided API key against our stored key
    if (api_key !== stormCanvassApiKey) {
      console.log('❌ Invalid API key provided');
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: 'Invalid API key' 
        }),
        { 
          status: 401, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // TODO: Make authentication request to Storm Canvass API
    // This is where you would integrate with the actual Storm Canvass API
    // For now, we'll simulate a successful authentication
    
    console.log(`✅ Authentication successful for ${rep_email}`);
    
    // Return successful authentication response
    return new Response(
      JSON.stringify({ 
        success: true,
        message: 'Authentication successful',
        rep_email: rep_email,
        authenticated_at: new Date().toISOString()
      }),
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error) {
    console.error('💥 Error in canvass-auth function:', error);
    
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: 'Internal server error',
        message: error instanceof Error ? error.message : 'Unknown error'
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});