import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { estimateId } = await req.json();

    if (!estimateId) {
      return new Response(
        JSON.stringify({ error: 'estimateId is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`[Compute] Starting computation for estimate ${estimateId}`);

    // 1. Get estimate and verify it exists
    const { data: estimate, error: estimateError } = await supabase
      .from('estimates')
      .select('*')
      .eq('id', estimateId)
      .single();

    if (estimateError || !estimate) {
      console.error('[Compute] Estimate not found:', estimateError);
      return new Response(
        JSON.stringify({ error: 'Estimate not found' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // 2. Get template binding
    const { data: binding, error: bindingError } = await supabase
      .from('estimate_bindings')
      .select('template_id')
      .eq('estimate_id', estimateId)
      .single();

    if (bindingError || !binding) {
      console.log('[Compute] No template bound yet');
      return new Response(
        JSON.stringify({ ok: true, message: 'No template bound' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // 3. Get template with items
    const { data: template, error: templateError } = await supabase
      .from('templates')
      .select('*, template_items(*)')
      .eq('id', binding.template_id)
      .single();

    if (templateError || !template) {
      console.error('[Compute] Template not found:', templateError);
      return new Response(
        JSON.stringify({ error: 'Template not found' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // 4. Get measurements
    const { data: measurement, error: measurementError } = await supabase
      .from('estimate_measurements')
      .select('*')
      .eq('estimate_id', estimateId)
      .single();

    if (measurementError || !measurement) {
      console.log('[Compute] No measurements yet');
      return new Response(
        JSON.stringify({ ok: true, message: 'No measurements' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const squares = measurement.squares || 0;
    const complexity = measurement.complexity_factor || 1.0;

    console.log(`[Compute] Squares: ${squares}, Complexity: ${complexity}`);

    // 5. Compute item costs
    const items: any[] = template.template_items || [];
    const costItems: any[] = [];
    let totalMaterialsCost = 0;

    for (const item of items) {
      if (!item.active) continue;

      // Evaluate formula (for now, simple mapping)
      let qty = 0;
      if (item.qty_formula === 'squares') {
        qty = squares;
      } else if (item.qty_formula === 'squares * complexity') {
        qty = squares * complexity;
      } else {
        // Default to squares
        qty = squares;
      }

      // Apply waste
      const wasteFactor = 1 + ((item.waste_pct || 0) / 100);
      qty = qty * wasteFactor;

      const lineTotal = qty * item.unit_cost;
      totalMaterialsCost += lineTotal;

      costItems.push({
        estimate_id: estimateId,
        template_item_id: item.id,
        item_name: item.item_name,
        qty,
        unit_cost: item.unit_cost,
        line_total: lineTotal,
      });
    }

    console.log(`[Compute] Materials: $${totalMaterialsCost.toFixed(2)}`);

    // 6. Compute labor
    const laborConfig = template.labor || { rate_per_square: 125, complexity: {} };
    const laborRatePerSquare = laborConfig.rate_per_square || 125;
    const totalLaborCost = squares * laborRatePerSquare * complexity;

    console.log(`[Compute] Labor: $${totalLaborCost.toFixed(2)}`);

    // 7. Compute overhead
    const overheadConfig = template.overhead || { type: 'percent', percent: 15 };
    let totalOverheadCost = 0;

    if (overheadConfig.type === 'percent') {
      const overheadPct = overheadConfig.percent || 15;
      totalOverheadCost = (totalMaterialsCost + totalLaborCost) * (overheadPct / 100);
    } else if (overheadConfig.type === 'fixed') {
      totalOverheadCost = overheadConfig.amount || 0;
    }

    console.log(`[Compute] Overhead: $${totalOverheadCost.toFixed(2)}`);

    // 8. Compute cost pre-profit and final sale price
    const costPreProfit = totalMaterialsCost + totalLaborCost + totalOverheadCost;

    // Get existing profit settings or defaults
    const { data: existingCosts } = await supabase
      .from('estimate_costs')
      .select('mode, margin_pct, markup_pct')
      .eq('estimate_id', estimateId)
      .single();

    const mode = existingCosts?.mode || 'margin';
    const marginPct = existingCosts?.margin_pct || 25;
    const markupPct = existingCosts?.markup_pct || 33.33;

    let salePrice = 0;
    let profit = 0;

    if (mode === 'margin') {
      salePrice = costPreProfit / (1 - (marginPct / 100));
      profit = salePrice - costPreProfit;
    } else {
      // markup
      profit = costPreProfit * (markupPct / 100);
      salePrice = costPreProfit + profit;
    }

    console.log(`[Compute] Sale Price: $${salePrice.toFixed(2)}, Profit: $${profit.toFixed(2)}`);

    // 9. Delete old cost items
    await supabase
      .from('estimate_cost_items')
      .delete()
      .eq('estimate_id', estimateId);

    // 10. Insert new cost items
    if (costItems.length > 0) {
      const { error: itemsError } = await supabase
        .from('estimate_cost_items')
        .insert(costItems);

      if (itemsError) {
        console.error('[Compute] Error inserting cost items:', itemsError);
      }
    }

    // 11. Upsert estimate_costs
    const { error: costsError } = await supabase
      .from('estimate_costs')
      .upsert({
        estimate_id: estimateId,
        materials: totalMaterialsCost,
        labor: totalLaborCost,
        overhead: totalOverheadCost,
        cost_pre_profit: costPreProfit,
        profit,
        sale_price: salePrice,
        mode,
        margin_pct: marginPct,
        markup_pct: markupPct,
        currency: template.currency || 'USD',
        computed_at: new Date().toISOString(),
      });

    if (costsError) {
      console.error('[Compute] Error upserting costs:', costsError);
      return new Response(
        JSON.stringify({ error: 'Failed to save costs' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('[Compute] Computation complete');

    return new Response(
      JSON.stringify({
        ok: true,
        data: {
          materials: totalMaterialsCost,
          labor: totalLaborCost,
          overhead: totalOverheadCost,
          cost_pre_profit: costPreProfit,
          profit,
          sale_price: salePrice,
        },
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('[Compute] Error:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
