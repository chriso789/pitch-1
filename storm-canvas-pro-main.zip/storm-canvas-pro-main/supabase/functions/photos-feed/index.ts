import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Get user from JWT
    const authHeader = req.headers.get('Authorization')
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Missing authorization header' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(
      authHeader.replace('Bearer ', '')
    )

    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: 'Invalid token' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    const body = await req.json()
    const { 
      propertyId,
      page = 1, 
      limit = 20,
      sortBy = 'created_at',
      sortOrder = 'desc'
    } = body

    const offset = (page - 1) * limit

    // Build query
    let query = supabase
      .from('photos')
      .select(`
        id,
        filename,
        original_filename,
        caption,
        storage_path,
        mime_type,
        file_size,
        latitude,
        longitude,
        created_at,
        property_id,
        properties!inner(
          id,
          address,
          latitude,
          longitude
        )
      `)
      .eq('user_id', user.id)

    // Filter by property if specified
    if (propertyId) {
      query = query.eq('property_id', propertyId)
    }

    // Apply sorting and pagination
    query = query
      .order(sortBy, { ascending: sortOrder === 'asc' })
      .range(offset, offset + limit - 1)

    const { data: photos, error: queryError } = await query

    if (queryError) {
      console.error('Photos query error:', queryError)
      return new Response(
        JSON.stringify({ error: 'Failed to fetch photos' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Add public URLs to photos
    const photosWithUrls = photos.map(photo => {
      const { data: urlData } = supabase.storage
        .from('photos')
        .getPublicUrl(photo.storage_path)
      
      return {
        ...photo,
        public_url: urlData.publicUrl,
        thumbnail_url: `${urlData.publicUrl}?width=300&height=300&resize=cover`
      }
    })

    // Get total count for pagination
    const { count, error: countError } = await supabase
      .from('photos')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', user.id)
      .eq(propertyId ? 'property_id' : 'user_id', propertyId || user.id)

    if (countError) {
      console.error('Count error:', countError)
    }

    return new Response(
      JSON.stringify({
        photos: photosWithUrls,
        pagination: {
          page,
          limit,
          total: count || 0,
          totalPages: Math.ceil((count || 0) / limit)
        }
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Photos feed error:', error)
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})