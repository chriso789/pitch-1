import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { place_id, formatted_address, lat, lng } = await req.json();

    if (!place_id && (!formatted_address || !lat || !lng)) {
      return new Response(
        JSON.stringify({ ok: false, error: 'Either place_id or (formatted_address, lat, lng) required' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
      );
    }

    const googleMapsApiKey = Deno.env.get('GOOGLE_MAPS_API_KEY');
    if (!googleMapsApiKey) {
      return new Response(
        JSON.stringify({ ok: false, error: 'Google Maps API key not configured' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
      );
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    let placeData: any;
    let placeIdToUse = place_id;
    let latToUse = lat;
    let lngToUse = lng;

    // If place_id provided, fetch details
    if (place_id) {
      const detailsUrl = new URL('https://maps.googleapis.com/maps/api/place/details/json');
      detailsUrl.searchParams.set('place_id', place_id);
      detailsUrl.searchParams.set('fields', 'address_components,formatted_address,geometry');
      detailsUrl.searchParams.set('key', googleMapsApiKey);

      const detailsResponse = await fetch(detailsUrl.toString());
      const detailsData = await detailsResponse.json();

      if (detailsData.status !== 'OK') {
        return new Response(
          JSON.stringify({ ok: false, error: `Could not fetch place details: ${detailsData.status}` }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
        );
      }

      placeData = detailsData.result;
      latToUse = placeData.geometry.location.lat;
      lngToUse = placeData.geometry.location.lng;
    } else {
      // If no place_id, use provided address and coordinates
      placeData = {
        formatted_address: formatted_address,
        geometry: { location: { lat: latToUse, lng: lngToUse } },
        address_components: []
      };
    }

    console.log(`🔨 Force-adding property: ${placeData.formatted_address}`);

    // Parse address components
    const components = placeData.address_components || [];
    const address: any = {
      formatted: placeData.formatted_address,
    };

    for (const component of components) {
      const types = component.types;
      if (types.includes('street_number')) {
        address.street_number = component.long_name;
      } else if (types.includes('route')) {
        address.street = component.long_name;
      } else if (types.includes('locality')) {
        address.city = component.long_name;
      } else if (types.includes('administrative_area_level_1')) {
        address.state = component.short_name;
      } else if (types.includes('postal_code')) {
        address.zip = component.long_name;
      } else if (types.includes('country')) {
        address.country = component.short_name;
      }
    }

    // Check if property already exists with this place_id
    if (placeIdToUse) {
      const { data: existing } = await supabase
        .from('properties')
        .select('id')
        .eq('place_id', placeIdToUse)
        .maybeSingle();

      if (existing) {
        return new Response(
          JSON.stringify({ 
            ok: false, 
            error: 'Property already exists with this place_id',
            property_id: existing.id 
          }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 409 }
        );
      }
    }

    // Generate address hash
    const addressHash = await crypto.subtle.digest(
      'SHA-256',
      new TextEncoder().encode(`${address.formatted}`)
    );
    const hashArray = Array.from(new Uint8Array(addressHash));
    const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');

    // Force insert property (bypassing proximity checks)
    const { data: insertData, error: insertError } = await supabase.rpc('add_property_pin', {
      addr: address,
      lat: latToUse,
      lng: lngToUse,
      homeowner_data: null,
      property_flags: { force_added: true },
      consumer_id_val: null,
      created_by_val: null,
    });

    if (insertError) {
      console.error('Error inserting property:', insertError);
      return new Response(
        JSON.stringify({ ok: false, error: insertError.message }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
      );
    }

    // Update with place_id if provided
    if (placeIdToUse) {
      await supabase
        .from('properties')
        .update({ place_id: placeIdToUse })
        .eq('address_hash', hashHex);
    }

    console.log(`✅ Property force-added successfully`);

    return new Response(
      JSON.stringify({
        ok: true,
        property_id: insertData,
        address: address.formatted,
        message: 'Property added successfully (forced)'
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error in force-add-property:', error);
    return new Response(
      JSON.stringify({ ok: false, error: error.message }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    );
  }
});
