import { serve } from 'https://deno.land/std/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { authenticateRequest } from '../_shared/auth.ts';
import { Logger } from '../_shared/logger.ts';
import { checkRateLimit, rateLimitResponse } from '../_shared/rateLimit.ts';
import { z } from 'https://deno.land/x/zod@v3.22.4/mod.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Nearest locations validation schema
const nearestSchema = z.object({
  lat: z.number().min(-90).max(90),
  lng: z.number().min(-180).max(180),
  radiusKm: z.number().min(0.1).max(50).default(2)
});

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const logger = Logger.create(req, 'maps-getNearestLocations');

  try {
    // 1. Authenticate request
    const { user, error: authError } = await authenticateRequest(req);
    if (!user) {
      logger.warn('Authentication failed', { error: authError });
      return new Response(
        JSON.stringify({ ok: false, error: authError || 'Authentication required' }),
        { status: 401, headers: { ...corsHeaders, 'content-type': 'application/json' } }
      );
    }

    // 2. Validate input
    let lat: number, lng: number, radiusKm: number;
    try {
      const body = await req.json();
      const validated = nearestSchema.parse(body);
      lat = validated.lat;
      lng = validated.lng;
      radiusKm = validated.radiusKm;
    } catch (error) {
      logger.warn('Input validation failed', { error });
      return new Response(
        JSON.stringify({ 
          ok: false, 
          error: 'Invalid input',
          details: error instanceof z.ZodError ? error.errors : String(error)
        }),
        { status: 400, headers: { ...corsHeaders, 'content-type': 'application/json' } }
      );
    }

    // 3. Check rate limit (10 requests per minute)
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    const rateLimit = await checkRateLimit(
      supabaseAdmin,
      user.id,
      'maps-getNearestLocations',
      10,
      1
    );

    if (!rateLimit.allowed) {
      logger.warn('Rate limit exceeded', { userId: user.id });
      return rateLimitResponse(rateLimit, corsHeaders);
    }

    // 4. Create authenticated Supabase client (respects RLS)
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_ANON_KEY')!,
      {
        global: {
          headers: {
            Authorization: req.headers.get('Authorization')!
          }
        }
      }
    );

    logger.info('Fetching nearest locations', { lat, lng, radiusKm });

    const { data, error } = await supabase.rpc('get_nearest_locations', {
      center_lat: lat,
      center_lng: lng, 
      radius_km: radiusKm
    });

    if (error) {
      logger.error('Database query failed', error);
      throw error;
    }

    // 5. Limit results to prevent excessive data transfer
    const limitedData = (data ?? []).slice(0, 500);
    if ((data ?? []).length > 500) {
      logger.warn('Result set limited', { 
        total: data.length, 
        returned: 500 
      });
    }

    logger.info('Query completed successfully', { count: limitedData.length });

    const features = limitedData.map((r: any) => ({
      type: 'Feature',
      geometry: { type: 'Point', coordinates: [r.lng, r.lat] },
      properties: {
        id: r.id,
        addressHash: r.address_hash,
        address: r.address,
        homeowner: r.homeowner,
        consumerId: r.consumer_id,
        flags: r.flags || {},
        createdAt: r.created_at,
        dispositionId: r.disposition_id,
        disposition: r.disposition,
        dispositionColor: r.disposition_color
      }
    }));

    return new Response(
      JSON.stringify({ ok: true, count: features.length, features }), 
      { headers: { ...corsHeaders, 'content-type': 'application/json' } }
    );
  } catch (e) {
    logger.error('Unexpected error in maps-getNearestLocations', e);
    return new Response(
      JSON.stringify({ ok: false, error: 'Internal server error' }), 
      { status: 500, headers: { ...corsHeaders, 'content-type': 'application/json' } }
    );
  }
});