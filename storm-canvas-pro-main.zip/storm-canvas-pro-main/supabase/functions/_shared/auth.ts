import { createClient, SupabaseClient } from 'https://esm.sh/@supabase/supabase-js@2.57.4';

export interface AuthResult {
  user: { id: string; email?: string } | null;
  error?: string;
}

/**
 * Validates JWT token and returns authenticated user
 * Use this at the start of every edge function that requires authentication
 */
export async function authenticateRequest(req: Request): Promise<AuthResult> {
  const authHeader = req.headers.get('authorization');
  
  if (!authHeader) {
    return { user: null, error: 'Missing authorization header' };
  }

  const token = authHeader.replace('Bearer ', '');
  
  if (!token) {
    return { user: null, error: 'Invalid authorization header format' };
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: authHeader }
        }
      }
    );

    const { data: { user }, error } = await supabase.auth.getUser(token);

    if (error || !user) {
      return { user: null, error: error?.message || 'Authentication failed' };
    }

    return { user };
  } catch (error) {
    console.error('Authentication error:', error);
    return { user: null, error: 'Authentication failed' };
  }
}

/**
 * Check if user has a specific role
 * Uses the has_role() security definer function to query user_roles table
 */
export async function checkUserRole(
  userId: string, 
  roleName: 'admin' | 'moderator' | 'user', 
  supabase: SupabaseClient
): Promise<boolean> {
  try {
    // Call has_role function with correct parameter names and types
    const { data, error } = await supabase.rpc('has_role', {
      _user_id: userId,
      _role: roleName
    });
    
    if (error) {
      console.error('Error checking role:', error);
      return false;
    }
    
    return data === true;
  } catch (error) {
    console.error('Error checking role:', error);
    return false;
  }
}

/**
 * Require admin role or return error response
 */
export async function requireAdmin(
  userId: string,
  supabase: SupabaseClient
): Promise<{ isAdmin: boolean; errorResponse?: Response }> {
  const isAdmin = await checkUserRole(userId, 'admin', supabase);
  
  if (!isAdmin) {
    return {
      isAdmin: false,
      errorResponse: new Response(
        JSON.stringify({ error: 'Unauthorized - Admin role required' }),
        { 
          status: 403, 
          headers: { 'Content-Type': 'application/json' } 
        }
      )
    };
  }
  
  return { isAdmin: true };
}
