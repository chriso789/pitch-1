/**
 * Rate limiting utility for edge functions
 * Prevents API abuse by limiting requests per user per time window
 */

import { SupabaseClient } from 'https://esm.sh/@supabase/supabase-js@2';

interface RateLimitResult {
  allowed: boolean;
  remaining?: number;
  resetAt?: Date;
  retryAfter?: number;
}

/**
 * Check if user has exceeded rate limit
 * @param supabase - Supabase client
 * @param userId - User ID to check
 * @param functionName - Name of function being rate limited
 * @param maxRequests - Maximum requests allowed in window
 * @param windowMinutes - Time window in minutes
 * @returns Rate limit result
 */
export async function checkRateLimit(
  supabase: SupabaseClient,
  userId: string,
  functionName: string,
  maxRequests: number,
  windowMinutes: number
): Promise<RateLimitResult> {
  try {
    const windowStart = new Date();
    windowStart.setMinutes(windowStart.getMinutes() - windowMinutes);

    // Get current window's request count
    const { data: existing, error: fetchError } = await supabase
      .from('rate_limit_tracking')
      .select('request_count, window_start')
      .eq('user_id', userId)
      .eq('function_name', functionName)
      .gte('window_start', windowStart.toISOString())
      .order('window_start', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (fetchError) {
      console.error('Rate limit fetch error:', fetchError);
      // Allow request on error to prevent false positives
      return { allowed: true };
    }

    // If no existing record or old window, create new window
    if (!existing || new Date(existing.window_start) < windowStart) {
      const { error: insertError } = await supabase
        .from('rate_limit_tracking')
        .insert({
          user_id: userId,
          function_name: functionName,
          request_count: 1,
          window_start: new Date().toISOString()
        });

      if (insertError) {
        console.error('Rate limit insert error:', insertError);
        return { allowed: true }; // Allow on error
      }

      return {
        allowed: true,
        remaining: maxRequests - 1,
        resetAt: new Date(Date.now() + windowMinutes * 60 * 1000)
      };
    }

    // Check if limit exceeded
    if (existing.request_count >= maxRequests) {
      const resetAt = new Date(existing.window_start);
      resetAt.setMinutes(resetAt.getMinutes() + windowMinutes);
      const retryAfter = Math.ceil((resetAt.getTime() - Date.now()) / 1000);

      return {
        allowed: false,
        remaining: 0,
        resetAt,
        retryAfter
      };
    }

    // Increment counter
    const { error: updateError } = await supabase
      .from('rate_limit_tracking')
      .update({ request_count: existing.request_count + 1 })
      .eq('user_id', userId)
      .eq('function_name', functionName)
      .eq('window_start', existing.window_start);

    if (updateError) {
      console.error('Rate limit update error:', updateError);
      return { allowed: true }; // Allow on error
    }

    const resetAt = new Date(existing.window_start);
    resetAt.setMinutes(resetAt.getMinutes() + windowMinutes);

    return {
      allowed: true,
      remaining: maxRequests - existing.request_count - 1,
      resetAt
    };
  } catch (error) {
    console.error('Rate limit check error:', error);
    // Allow request on unexpected errors
    return { allowed: true };
  }
}

/**
 * Create rate limit response
 */
export function rateLimitResponse(
  result: RateLimitResult,
  corsHeaders: Record<string, string>
): Response {
  return new Response(
    JSON.stringify({
      error: 'Rate limit exceeded',
      message: `Too many requests. Please try again in ${result.retryAfter} seconds.`,
      retryAfter: result.retryAfter
    }),
    {
      status: 429,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json',
        'Retry-After': result.retryAfter?.toString() || '60',
        'X-RateLimit-Limit': '10',
        'X-RateLimit-Remaining': (result.remaining || 0).toString(),
        'X-RateLimit-Reset': result.resetAt?.toISOString() || ''
      }
    }
  );
}
