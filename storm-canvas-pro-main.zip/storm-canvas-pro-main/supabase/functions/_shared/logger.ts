/**
 * Structured logging utility with PII redaction for edge functions
 * Provides consistent logging format with security features
 */

interface LogMetadata {
  [key: string]: any;
}

export class Logger {
  private requestId: string;
  private functionName: string;

  constructor(requestId: string, functionName: string) {
    this.requestId = requestId;
    this.functionName = functionName;
  }

  /**
   * Log informational message
   */
  info(message: string, metadata?: LogMetadata) {
    this.log('info', message, metadata);
  }

  /**
   * Log warning message
   */
  warn(message: string, metadata?: LogMetadata) {
    this.log('warn', message, metadata);
  }

  /**
   * Log error message
   */
  error(message: string, error?: any, metadata?: LogMetadata) {
    const errorData = error instanceof Error 
      ? { message: error.message, stack: error.stack }
      : { message: String(error) };
    
    this.log('error', message, { ...metadata, error: errorData });
  }

  /**
   * Core logging function with PII redaction
   */
  private log(level: string, message: string, metadata?: LogMetadata) {
    const logEntry = {
      level,
      timestamp: new Date().toISOString(),
      requestId: this.requestId,
      function: this.functionName,
      message,
      ...(metadata && { data: this.redactPII(metadata) })
    };

    const logFn = level === 'error' ? console.error : console.log;
    logFn(JSON.stringify(logEntry));
  }

  /**
   * Redact PII from log data
   * Removes sensitive fields to prevent PII exposure in logs
   */
  private redactPII(data: any): any {
    if (!data) return data;
    if (typeof data !== 'object') return data;

    // Handle arrays
    if (Array.isArray(data)) {
      return data.map(item => this.redactPII(item));
    }

    // Handle objects
    const redacted = { ...data };
    const piiFields = [
      'phone', 'phones', 'email', 'emails', 'name', 'first_name', 'last_name',
      'homeowner', 'mailing_address', 'owner_name', 'consumer_id',
      'ssn', 'dob', 'date_of_birth', 'password', 'api_key', 'apiKey', 'token',
      'secret', 'authorization', 'credit_card', 'ip_address'
    ];

    for (const key of Object.keys(redacted)) {
      const lowerKey = key.toLowerCase();
      
      // Check if key is a PII field
      if (piiFields.some(field => lowerKey.includes(field))) {
        redacted[key] = '[REDACTED]';
      } 
      // Recursively redact nested objects
      else if (typeof redacted[key] === 'object' && redacted[key] !== null) {
        redacted[key] = this.redactPII(redacted[key]);
      }
    }

    return redacted;
  }

  /**
   * Create logger instance with auto-generated request ID
   */
  static create(req: Request, functionName: string): Logger {
    const requestId = crypto.randomUUID();
    return new Logger(requestId, functionName);
  }
}

/**
 * Audit log for security-sensitive operations
 */
export async function auditLog(
  logger: Logger,
  action: string,
  userId: string | null,
  details: Record<string, any>
) {
  logger.info(`AUDIT: ${action}`, {
    userId,
    action,
    timestamp: new Date().toISOString(),
    ...details
  });
}
