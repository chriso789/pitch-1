import { z } from 'https://deno.land/x/zod@v3.22.4/mod.ts';

/**
 * Common validation schemas for edge functions
 */

// Geographic coordinates validation
export const coordinatesSchema = z.object({
  lat: z.number().min(-90).max(90),
  lng: z.number().min(-180).max(180),
});

// Address validation
export const addressSchema = z.object({
  address: z.string().max(500).optional(),
  city: z.string().max(200).optional(),
  state: z.string().max(100).optional(),
  zip: z.string().max(20).optional(),
  country: z.string().max(100).optional(),
}).refine(
  data => data.address || (data.city && data.state),
  { message: 'Either full address or city+state is required' }
);

// Skip trace request validation
export const skipTraceRequestSchema = z.object({
  address: z.string().max(500).optional(),
  lat: z.number().min(-90).max(90).optional(),
  lng: z.number().min(-180).max(180).optional(),
  apn: z.string().max(50).optional(),
  propertyId: z.string().uuid().optional(),
}).refine(
  data => data.address || (data.lat && data.lng) || data.apn || data.propertyId,
  { message: 'At least one of address, coordinates, APN, or propertyId is required' }
);

// Auto-detect properties request validation
export const autoDetectRequestSchema = z.object({
  lat: z.number().min(-90).max(90),
  lng: z.number().min(-180).max(180),
  radiusMeters: z.number().min(100).max(5000).optional().default(1500),
});

// Webhook event validation
export const webhookEventSchema = z.object({
  event: z.string().min(1).max(200),
  data: z.record(z.unknown()),
});

// Master user setup validation
export const masterUserSetupSchema = z.object({
  email: z.string().email().max(255),
  password: z.string().min(8).max(255),
});

// Email validation (standalone)
export const emailSchema = z.string().email().max(255);

// UUID validation (standalone)
export const uuidSchema = z.string().uuid();

/**
 * Validate and parse request body
 * Returns parsed data or throws validation error
 */
export async function validateRequest<T>(
  req: Request,
  schema: z.ZodSchema<T>
): Promise<T> {
  try {
    const body = await req.json();
    return schema.parse(body);
  } catch (error) {
    if (error instanceof z.ZodError) {
      const errors = error.errors.map(e => ({
        field: e.path.join('.'),
        message: e.message
      }));
      throw new ValidationError('Invalid request data', errors);
    }
    throw error;
  }
}

/**
 * Custom validation error class
 */
export class ValidationError extends Error {
  constructor(
    message: string,
    public errors: Array<{ field: string; message: string }>
  ) {
    super(message);
    this.name = 'ValidationError';
  }
  
  toJSON() {
    return {
      error: this.message,
      validation_errors: this.errors
    };
  }
}

/**
 * Sanitize string input to prevent injection
 */
export function sanitizeString(input: string, maxLength: number = 500): string {
  return input
    .trim()
    .slice(0, maxLength)
    .replace(/[<>]/g, '') // Remove potential HTML tags
    .replace(/[\x00-\x1F\x7F]/g, ''); // Remove control characters
}

/**
 * Validate and sanitize address input
 */
export function sanitizeAddress(address: string): string {
  return sanitizeString(address, 500)
    .replace(/[^\w\s,.-]/g, ''); // Only allow alphanumeric, spaces, and common address chars
}
