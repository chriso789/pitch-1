import { serve } from 'https://deno.land/std/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Skip-trace provider interfaces
interface SkipTraceResult {
  parcel?: {
    apn?: string;
    ownerNames?: string[];
    situsAddress?: string;
    mailingAddress?: string;
  };
  contacts: Array<{
    name?: string;
    phone?: string;
    email?: string;
    confidence?: number;
    provider: string;
  }>;
  source?: string;
}

// Mock skip-trace provider for development
class MockSkipTraceProvider {
  name = 'mock';

  async lookup(input: { address?: string; lat?: number; lng?: number }): Promise<SkipTraceResult> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 200));

    const mockContacts = [
      {
        name: 'John Smith',
        phone: '(555) 123-4567',
        email: 'john.smith@email.com',
        confidence: 0.85,
        provider: this.name
      },
      {
        name: 'Jane Smith',
        phone: '(555) 987-6543',
        email: 'jane.smith@email.com',
        confidence: 0.75,
        provider: this.name
      }
    ];

    const mockParcel = {
      apn: Math.random().toString(36).substr(2, 9),
      ownerNames: ['Smith, John & Jane'],
      situsAddress: input.address || '123 Main St',
      mailingAddress: input.address || '123 Main St'
    };

    return {
      parcel: mockParcel,
      contacts: mockContacts,
      source: this.name
    };
  }
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    // Get authenticated user
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Missing authorization header' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(authHeader.replace('Bearer ', ''));
    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { leadId, propertyId, address, lat, lng } = await req.json();

    // Validate input
    if (!address && !(lat && lng)) {
      return new Response(
        JSON.stringify({ error: 'Either address or coordinates must be provided' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Create skip-trace job record
    const { data: jobData, error: jobError } = await supabase
      .from('skip_trace_jobs')
      .insert({
        lead_id: leadId,
        property_id: propertyId,
        status: 'running',
        provider: 'mock',
        input_data: { address, lat, lng },
        created_by: user.id
      })
      .select()
      .single();

    if (jobError) {
      console.error('Error creating skip-trace job:', jobError);
      return new Response(
        JSON.stringify({ error: 'Failed to create skip-trace job' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    try {
      // Run skip-trace using mock provider (in production, use real providers)
      const mockProvider = new MockSkipTraceProvider();
      const result = await mockProvider.lookup({ address, lat, lng });

      // Update job with results
      await supabase
        .from('skip_trace_jobs')
        .update({
          status: 'completed',
          result_data: result,
          completed_at: new Date().toISOString()
        })
        .eq('id', jobData.id);

      // Save contacts to database
      if (result.contacts && result.contacts.length > 0) {
        const contactInserts = result.contacts.map(contact => ({
          lead_id: leadId,
          property_id: propertyId,
          name: contact.name,
          phone: contact.phone,
          email: contact.email,
          provider: contact.provider,
          confidence: contact.confidence,
          is_active: true
        }));

        const { error: contactsError } = await supabase
          .from('contacts')
          .insert(contactInserts);

        if (contactsError) {
          console.error('Error saving contacts:', contactsError);
        }
      }

      return new Response(
        JSON.stringify({ 
          success: true, 
          jobId: jobData.id,
          result: result
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );

    } catch (enrichmentError: any) {
      console.error('Skip-trace enrichment error:', enrichmentError);
      
      const errorMessage = enrichmentError?.message || 'Unknown error occurred';
      
      // Update job with error
      await supabase
        .from('skip_trace_jobs')
        .update({
          status: 'failed',
          error_message: errorMessage,
          completed_at: new Date().toISOString()
        })
        .eq('id', jobData.id);

      return new Response(
        JSON.stringify({ 
          error: 'Skip-trace enrichment failed',
          details: errorMessage
        }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

  } catch (error) {
    console.error('Skip-trace function error:', error);
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});