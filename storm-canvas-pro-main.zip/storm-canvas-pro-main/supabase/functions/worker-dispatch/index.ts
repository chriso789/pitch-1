import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface OutboxEvent {
  id: string;
  event_type: string;
  payload: any;
  retries: number;
  status: string;
  last_error?: string;
  scheduled_at: string;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Worker dispatch started');
    
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Get queued events from outbox
    const { data: events, error } = await supabase
      .from('outbox')
      .select('*')
      .eq('status', 'queued')
      .lte('scheduled_at', new Date().toISOString())
      .order('created_at', { ascending: true })
      .limit(10);

    if (error) {
      console.error('Error fetching outbox events:', error);
      throw error;
    }

    console.log(`Processing ${events?.length || 0} queued events`);

    // Process each event
    for (const event of events || []) {
      await processOutboxEvent(supabase, event);
    }

    return new Response(
      JSON.stringify({ 
        processed: events?.length || 0,
        message: 'Worker dispatch completed successfully' 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Worker dispatch error:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});

async function processOutboxEvent(supabase: any, event: OutboxEvent) {
  console.log(`Processing event: ${event.event_type} (${event.id})`);
  
  try {
    // Mark as processing
    await supabase
      .from('outbox')
      .update({ status: 'processing' })
      .eq('id', event.id);

    // Route event to appropriate handler
    switch (event.event_type) {
      case 'property.pin_drop.created':
      case 'disposition.created':
        await handlePitchCrmEvent(supabase, event);
        break;
      default:
        console.log(`Unknown event type: ${event.event_type}`);
    }

    // Mark as sent
    await supabase
      .from('outbox')
      .update({ 
        status: 'sent',
        processed_at: new Date().toISOString()
      })
      .eq('id', event.id);

    console.log(`Successfully processed event: ${event.id}`);

  } catch (error) {
    console.error(`Error processing event ${event.id}:`, error);
    
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    const newRetries = event.retries + 1;
    const maxRetries = 5;
    
    if (newRetries >= maxRetries) {
      // Move to dead letter
      await supabase
        .from('outbox')
        .update({ 
          status: 'dead_letter',
          retries: newRetries,
          last_error: errorMessage,
          processed_at: new Date().toISOString()
        })
        .eq('id', event.id);
    } else {
      // Schedule retry with exponential backoff
      const backoffMinutes = Math.pow(2, newRetries); // 2, 4, 8, 16, 32 minutes
      const scheduledAt = new Date(Date.now() + backoffMinutes * 60 * 1000);
      
      await supabase
        .from('outbox')
        .update({ 
          status: 'queued',
          retries: newRetries,
          last_error: errorMessage,
          scheduled_at: scheduledAt.toISOString()
        })
        .eq('id', event.id);
    }
  }
}

async function handlePitchCrmEvent(supabase: any, event: OutboxEvent) {
  console.log('Processing PITCH CRM event with enrichment');
  
  let enrichedPayload = event.payload;
  
  // Enrich the property data if it has an address
  if (event.payload.address) {
    console.log('Enriching property data');
    try {
      const { data: enrichmentData, error: enrichmentError } = await supabase.functions.invoke('enrichment-pipeline', {
        body: { address: event.payload.address }
      });

      if (enrichmentError) {
        console.warn('Enrichment failed, proceeding with original data:', enrichmentError);
      } else {
        console.log('Enrichment successful:', enrichmentData);
        enrichedPayload = {
          ...event.payload,
          ...enrichmentData,
          enriched: true
        };
      }
    } catch (error) {
      console.warn('Enrichment error, proceeding with original data:', error);
    }
  }
  
  // Call the sync-to-pitch function with enriched data
  const { data, error } = await supabase.functions.invoke('sync-to-pitch', {
    body: enrichedPayload
  });

  if (error) {
    const errorMessage = error instanceof Error ? error.message : error.toString();
    throw new Error(`PITCH CRM sync failed: ${errorMessage}`);
  }

  console.log('PITCH CRM sync completed:', data);
}