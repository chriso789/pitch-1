import { serve } from 'https://deno.land/std/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { authenticateRequest, requireAdmin } from '../_shared/auth.ts';
import { Logger, auditLog } from '../_shared/logger.ts';
import { z } from 'https://deno.land/x/zod@v3.22.4/mod.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Google Maps API key validation schema
const requestSchema = z.object({
  apiKey: z.string()
    .min(39, 'Invalid Google API key length')
    .max(39, 'Invalid Google API key length')
    .regex(/^AIza[0-9A-Za-z-_]{35}$/, 'Invalid Google API key format')
});

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const logger = Logger.create(req, 'save-google-maps-key');

  try {
    // 1. Authenticate request
    const { user, error: authError } = await authenticateRequest(req);
    if (!user) {
      logger.warn('Authentication failed', { error: authError });
      return new Response(
        JSON.stringify({ ok: false, error: authError || 'Authentication required' }),
        { status: 401, headers: { ...corsHeaders, 'content-type': 'application/json' } }
      );
    }

    // 2. Check admin role
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    const { isAdmin, errorResponse } = await requireAdmin(user.id, supabase);
    if (!isAdmin) {
      logger.warn('Admin check failed', { userId: user.id });
      await auditLog(logger, 'UNAUTHORIZED_API_KEY_SAVE_ATTEMPT', user.id, {});
      return errorResponse!;
    }

    logger.info('Admin authorization passed', { userId: user.id });

    // 3. Validate input
    let apiKey: string;
    try {
      const body = await req.json();
      const validated = requestSchema.parse(body);
      apiKey = validated.apiKey;
    } catch (error) {
      logger.warn('Input validation failed', { error });
      return new Response(
        JSON.stringify({ 
          ok: false, 
          error: 'Invalid input',
          details: error instanceof z.ZodError ? error.errors : String(error)
        }),
        { status: 400, headers: { ...corsHeaders, 'content-type': 'application/json' } }
      );
    }
    // 4. Test the API key first
    logger.info('Testing API key validity');
    const testResponse = await fetch(
      `https://maps.googleapis.com/maps/api/geocode/json?address=test&key=${apiKey}`,
      { method: 'GET' }
    );
    
    if (!testResponse.ok) {
      logger.warn('API key test failed - invalid response');
      return new Response(
        JSON.stringify({ ok: false, error: 'Invalid Google Maps API key' }),
        { status: 400, headers: { ...corsHeaders, 'content-type': 'application/json' } }
      );
    }

    const testData = await testResponse.json();
    if (testData.status !== 'OK' && testData.status !== 'ZERO_RESULTS') {
      logger.warn('API key test failed', { status: testData.status });
      return new Response(
        JSON.stringify({ ok: false, error: `API Error: ${testData.status} - ${testData.error_message || 'Invalid key'}` }),
        { status: 400, headers: { ...corsHeaders, 'content-type': 'application/json' } }
      );
    }

    logger.info('API key validated successfully');

    // 5. Store in Supabase vault
    const { error } = await supabase
      .from('vault.secrets')
      .upsert({
        name: 'GOOGLE_MAPS_API_KEY',
        secret: apiKey
      });

    if (error) {
      logger.error('Error storing API key', error);
      return new Response(
        JSON.stringify({ ok: false, error: 'Failed to store API key' }),
        { status: 500, headers: { ...corsHeaders, 'content-type': 'application/json' } }
      );
    }

    // 6. Audit log successful key update
    await auditLog(logger, 'GOOGLE_MAPS_API_KEY_UPDATED', user.id, {
      keyPrefix: apiKey.substring(0, 10)
    });

    logger.info('API key saved successfully', { userId: user.id });

    return new Response(
      JSON.stringify({ ok: true, message: 'Google Maps API key saved successfully' }),
      { headers: { ...corsHeaders, 'content-type': 'application/json' } }
    );
  } catch (error) {
    logger.error('Unexpected error in save-google-maps-key', error);
    return new Response(
      JSON.stringify({ ok: false, error: 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'content-type': 'application/json' } }
    );
  }
});