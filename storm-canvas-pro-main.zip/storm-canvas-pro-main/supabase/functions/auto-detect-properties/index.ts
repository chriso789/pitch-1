import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.4';
import { authenticateRequest } from '../_shared/auth.ts';
import { validateRequest, autoDetectRequestSchema, ValidationError } from '../_shared/validation.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

/**
 * Offset coordinates to move pins from street centerlines onto properties.
 * Adds a small perpendicular offset (10-20m) to place pins on buildings instead of streets.
 */
function offsetCoordinatesFromStreet(lat: number, lng: number): { lat: number; lng: number } {
  // Offset distance in meters (10-20m to move from street to building)
  const offsetMeters = 12 + Math.random() * 8; // 12-20m random offset
  
  // Random angle perpendicular to street (90° or 270° from street direction)
  // We don't know street orientation, so use random perpendicular offset
  const angle = Math.random() > 0.5 ? Math.PI / 2 : -Math.PI / 2;
  
  // Add slight random variation to spread pins across property
  const angleVariation = (Math.random() - 0.5) * 0.3; // ±15° variation
  const finalAngle = angle + angleVariation;
  
  // Convert meters to degrees (approximate)
  // At equator: 1° lat ≈ 111km, 1° lng ≈ 111km * cos(lat)
  const latOffset = (offsetMeters / 111000) * Math.cos(finalAngle);
  const lngOffset = (offsetMeters / (111000 * Math.cos(lat * Math.PI / 180))) * Math.sin(finalAngle);
  
  return {
    lat: lat + latOffset,
    lng: lng + lngOffset
  };
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Authenticate request
    const { user, error: authError } = await authenticateRequest(req);
    
    if (!user) {
      return new Response(
        JSON.stringify({ error: authError || 'Authentication required' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Validate and parse request body
    const { lat, lng, radiusMeters } = await validateRequest(req, autoDetectRequestSchema);

    if (!lat || !lng) {
      return new Response(
        JSON.stringify({ ok: false, error: 'Missing lat/lng coordinates' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
      );
    }

    const googleMapsApiKey = Deno.env.get('GOOGLE_MAPS_API_KEY');
    if (!googleMapsApiKey) {
      return new Response(
        JSON.stringify({ ok: false, error: 'Google Maps API key not configured' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
      );
    }

    // Get Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    console.log(`🔍 Detecting properties near lat:${lat}, lng:${lng}, radius:${radiusMeters}m`);

    // Use Google Places API to find actual buildings (premises)
    const placesUrl = new URL('https://maps.googleapis.com/maps/api/place/nearbysearch/json');
    placesUrl.searchParams.set('location', `${lat},${lng}`);
    placesUrl.searchParams.set('radius', radiusMeters.toString());
    placesUrl.searchParams.set('type', 'premise'); // Actual building structures
    placesUrl.searchParams.set('key', googleMapsApiKey);

    console.log(`📍 Searching for buildings via Places API`);

    const results: any[] = [];
    const seenPlaceIds = new Set<string>();

    try {
      const placesResponse = await fetch(placesUrl.toString());
      const placesData = await placesResponse.json();

      if (placesData.status === 'OK' && placesData.results?.length > 0) {
        console.log(`🏢 Found ${placesData.results.length} premises from Places API`);

        // For each building, get detailed address information
        for (const place of placesData.results) {
          if (seenPlaceIds.has(place.place_id)) continue;
          
          // Get place details for accurate address
          const detailsUrl = new URL('https://maps.googleapis.com/maps/api/place/details/json');
          detailsUrl.searchParams.set('place_id', place.place_id);
          detailsUrl.searchParams.set('fields', 'address_components,formatted_address,geometry,types');
          detailsUrl.searchParams.set('key', googleMapsApiKey);

          try {
            const detailsResponse = await fetch(detailsUrl.toString());
            const detailsData = await detailsResponse.json();

            if (detailsData.status === 'OK' && detailsData.result) {
              const result = detailsData.result;
              const formatted = result.formatted_address;

              // Filter out clearly commercial places (but be less restrictive)
              const types = result.types || [];
              const isObviouslyCommercial = types.some((t: string) => 
                ['shopping_mall', 'airport', 'train_station', 
                 'hospital', 'stadium', 'parking', 'car_dealer'].includes(t)
              );

              if (isObviouslyCommercial) {
                console.log(`⏩ Skipping obvious commercial: ${formatted}`);
                continue;
              }

              // Filter out highways and major roads only
              const isHighway = /\b(Highway|Hwy|Freeway|Interstate|Turnpike|Expy|Expressway)\b/i.test(formatted);
              if (isHighway) {
                console.log(`⏩ Skipping highway: ${formatted}`);
                continue;
              }

              // Must have a street number (actual building address)
              const hasStreetNumber = result.address_components?.some((comp: any) => 
                comp.types.includes('street_number') && comp.long_name
              );
              if (!hasStreetNumber) {
                console.log(`⏩ Skipping - no street number: ${formatted}`);
                continue;
              }
              
              console.log(`✓ Valid property found: ${formatted}`);

              seenPlaceIds.add(place.place_id);
              results.push({
                place_id: place.place_id,
                formatted_address: formatted,
                geometry: result.geometry,
                address_components: result.address_components
              });
            }
          } catch (error) {
            console.error('Error fetching place details:', error);
          }

          // Limit to prevent quota exhaustion
          if (results.length >= 50) break;
        }
      } else {
        console.log(`⚠️ Places API returned: ${placesData.status}`);
      }
    } catch (error) {
      console.error('Places API error:', error);
    }

    console.log(`🏠 Found ${results.length} unique residential properties`);

    let inserted = 0;
    let skipped = 0;
    let errors = 0;

    // Process each property
    for (const place of results) {
      try {
        const placeId = place.place_id;
        const rawLat = place.geometry.location.lat;
        const rawLng = place.geometry.location.lng;
        
        // Offset coordinates to move pin from street to property
        const offsetCoords = offsetCoordinatesFromStreet(rawLat, rawLng);
        const placeLat = offsetCoords.lat;
        const placeLng = offsetCoords.lng;
        
        console.log(`📍 Offset applied: (${rawLat.toFixed(6)}, ${rawLng.toFixed(6)}) → (${placeLat.toFixed(6)}, ${placeLng.toFixed(6)})`);

        // Check if this place_id already exists (only if place_id is valid)
        if (placeId) {
          const { data: existing } = await supabase
            .from('properties')
            .select('id')
            .eq('place_id', placeId)
            .maybeSingle();

          if (existing) {
            console.log(`⏩ Skipping - place_id exists: ${place.formatted_address}`);
            skipped++;
            continue;
          }
        }

        // Check for nearby properties (spatial deduplication - 3m minimum for very close addresses)
        const { data: nearbyExists } = await supabase.rpc('check_nearby_property', {
          check_lat: placeLat,
          check_lng: placeLng,
          min_distance_meters: 3
        });

        if (nearbyExists) {
          console.log(`⏩ Skipping - property exists within 3m: ${place.formatted_address}`);
          skipped++;
          continue;
        }

        console.log(`✨ Adding new property: ${place.formatted_address}`);

        const components = place.address_components || [];

        // Parse address components
        const address: any = {
          formatted: place.formatted_address,
        };

        for (const component of components) {
          const types = component.types;
          if (types.includes('street_number')) {
            address.street_number = component.long_name;
          } else if (types.includes('route')) {
            address.street = component.long_name;
          } else if (types.includes('locality')) {
            address.city = component.long_name;
          } else if (types.includes('administrative_area_level_1')) {
            address.state = component.short_name;
          } else if (types.includes('postal_code')) {
            address.zip = component.long_name;
          } else if (types.includes('country')) {
            address.country = component.short_name;
          }
        }

        // Generate address hash
        const addressHash = await crypto.subtle.digest(
          'SHA-256',
          new TextEncoder().encode(`${address.formatted}`)
        );
        const hashArray = Array.from(new Uint8Array(addressHash));
        const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');

        // Insert property with PostGIS geometry
        const { error: insertError } = await supabase.rpc('add_property_pin', {
          addr: address,
          lat: placeLat,
          lng: placeLng,
          homeowner_data: null,
          property_flags: null,
          consumer_id_val: null,
          created_by_val: user.id, // Set authenticated user as creator
        });

        if (insertError) {
          console.error('Error inserting property:', insertError);
          errors++;
          continue;
        }

        // Update with place_id (REQUIRED for deduplication)
        const { error: updateError } = await supabase
          .from('properties')
          .update({ place_id: placeId })
          .eq('address_hash', hashHex);

        if (updateError) {
          console.error('Error updating place_id:', updateError);
        }

        inserted++;
      } catch (error) {
        console.error('Error processing place:', error);
        errors++;
      }
    }

    console.log(`✅ Auto-detect complete: ${inserted} inserted, ${skipped} skipped, ${errors} errors`);

    return new Response(
      JSON.stringify({
        ok: true,
        inserted,
        skipped,
        errors,
        total: results.length,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error in auto-detect-properties:', error);
    
    // Handle validation errors
    if (error instanceof ValidationError) {
      return new Response(
        JSON.stringify(error.toJSON()),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ ok: false, error: error.message }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    );
  }
});
