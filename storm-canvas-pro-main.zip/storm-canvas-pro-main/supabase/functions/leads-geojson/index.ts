import { serve } from 'https://deno.land/std/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    // Get authenticated user
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Missing authorization header' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(authHeader.replace('Bearer ', ''));
    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const url = new URL(req.url);
    const statusParam = url.searchParams.get('status');
    const bboxParam = url.searchParams.get('bbox');

    // Parse status filter
    const statusIds = statusParam ? statusParam.split(',').map(s => parseInt(s, 10)).filter(n => !isNaN(n)) : [];

    // Parse bounding box
    let bbox: [number, number, number, number] | undefined;
    if (bboxParam) {
      const coords = bboxParam.split(',').map(Number);
      if (coords.length === 4 && coords.every(n => !isNaN(n))) {
        bbox = coords as [number, number, number, number];
      }
    }

    let data;
    let error;

    if (bbox) {
      // Use bounding box function for better performance
      const result = await supabase.rpc('get_leads_in_bbox', {
        min_lng: bbox[0],
        min_lat: bbox[1],
        max_lng: bbox[2],
        max_lat: bbox[3],
        status_ids: statusIds.length > 0 ? statusIds : null
      });
      data = result.data;
      error = result.error;
    } else {
      // Get all leads with optional status filter
      let query = supabase
        .from('leads')
        .select('*')
        .eq('created_by', user.id);

      if (statusIds.length > 0) {
        query = query.in('status_type_id', statusIds);
      }

      const result = await query;
      data = result.data;
      error = result.error;
    }

    if (error) {
      console.error('Error fetching leads:', error);
      return new Response(
        JSON.stringify({ error: 'Failed to fetch leads' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Convert to GeoJSON format
    const features = (data || []).map((lead: any) => ({
      type: 'Feature',
      geometry: {
        type: 'Point',
        coordinates: [lead.lng, lead.lat]
      },
      properties: {
        id: lead.id,
        address: lead.address,
        city: lead.city,
        state: lead.state,
        zip: lead.zip,
        status_type_id: lead.status_type_id,
        status_title: lead.status_title,
        front_color: lead.status_front_color,
        back_color: lead.status_back_color,
        source: lead.source,
        created_at: lead.created_at
      }
    }));

    const geoJson = {
      type: 'FeatureCollection',
      features,
      count: features.length
    };

    return new Response(
      JSON.stringify(geoJson),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Leads GeoJSON function error:', error);
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});