import { serve } from 'https://deno.land/std/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { minLng, minLat, maxLng, maxLat } = await req.json();
    
    if (typeof minLng !== 'number' || typeof minLat !== 'number' || 
        typeof maxLng !== 'number' || typeof maxLat !== 'number') {
      return new Response(
        JSON.stringify({ ok: false, error: 'invalid_bounds' }), 
        { status: 400, headers: { ...corsHeaders, 'content-type': 'application/json' } }
      );
    }

    // 4. Create authenticated Supabase client (respects RLS)
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_ANON_KEY')!,
      {
        global: {
          headers: {
            Authorization: req.headers.get('Authorization')!
          }
        }
      }
    );

    logger.info('Fetching properties in bbox');

    const { data, error } = await supabase.rpc('get_properties_in_bbox', {
      min_lng: minLng,
      min_lat: minLat,
      max_lng: maxLng,
      max_lat: maxLat
    });

    if (error) throw error;
    
    console.log(`Fetched ${data?.length || 0} properties in bbox`);
    const features = (data ?? []).map((r: any) => ({
      type: 'Feature',
      geometry: { type: 'Point', coordinates: [r.lng, r.lat] },
      properties: {
        id: r.id,
        addressHash: r.address_hash,
        address: r.address,
        homeowner: r.homeowner,
        consumer_id: r.consumer_id,
        flags: r.flags || {},
        created_at: r.created_at,
        disposition_id: r.disposition_id,
        disposition: r.disposition,
        disposition_color: r.disposition_color,
        place_id: r.place_id
      }
    }));

    return new Response(
      JSON.stringify({ ok: true, count: features.length, features }), 
      { headers: { ...corsHeaders, 'content-type': 'application/json' } }
    );
  } catch (e) {
    logger.error('Unexpected error in maps-getPropertiesInBbox', e);
    return new Response(
      JSON.stringify({ ok: false, error: 'Internal server error' }), 
      { status: 500, headers: { ...corsHeaders, 'content-type': 'application/json' } }
    );
  }
});
