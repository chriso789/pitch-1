import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface Address {
  line1: string;
  line2?: string;
  city: string;
  state: string;
  postal_code: string;
}

// Google Maps Geocoding
async function geocodeAddress(address: Address, apiKey: string) {
  const query = `${address.line1}, ${address.city}, ${address.state} ${address.postal_code}`;
  
  const response = await fetch(
    `https://maps.googleapis.com/maps/api/geocode/json?` +
    new URLSearchParams({
      address: query,
      key: apiKey,
      region: 'US'
    }),
    {
      method: 'GET',
      headers: { 'User-Agent': 'Canvass-IQ/1.0' }
    }
  );

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Google Maps geocoding failed: ${response.status} ${error}`);
  }

  const data = await response.json();
  
  if (data.status !== 'OK' || !data.results || data.results.length === 0) {
    throw new Error(`Geocoding failed: ${data.status} - ${data.error_message || 'No results found'}`);
  }

  const result = data.results[0];
  const location = result.geometry.location;
  
  return {
    place_id: result.place_id,
    lat: parseFloat(location.lat.toFixed(6)),
    lng: parseFloat(location.lng.toFixed(6)),
    formatted_address: result.formatted_address
  };
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  if (req.method !== 'POST') {
    return new Response('Method not allowed', { 
      status: 405, 
      headers: corsHeaders 
    });
  }

  try {
    const { address } = await req.json();
    
    if (!address || !address.line1 || !address.city || !address.state || !address.postal_code) {
      return new Response(JSON.stringify({ error: 'Invalid address format' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const googleMapsApiKey = Deno.env.get('GOOGLE_MAPS_API_KEY');
    if (!googleMapsApiKey) {
      return new Response(JSON.stringify({ error: 'Google Maps API key not configured' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    console.log('Enriching address:', address);

    // Geocode with Google Maps
    const geoResult = await geocodeAddress(address, googleMapsApiKey);
    
    const enrichment = {
      place_id: geoResult.place_id,
      address_norm: address,
      location: { lat: geoResult.lat, lng: geoResult.lng },
      formatted_address: geoResult.formatted_address,
      sources: ['googlemaps'],
      enriched_at: new Date().toISOString()
    };

    console.log('Enrichment completed:', enrichment);

    return new Response(JSON.stringify(enrichment), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Enrichment error:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Enrichment failed' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
})