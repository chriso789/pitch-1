import { serve } from 'https://deno.land/std/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { minLng, minLat, maxLng, maxLat } = await req.json();
    
    if (!minLng || !minLat || !maxLng || !maxLat) {
      return new Response(
        JSON.stringify({ ok: false, error: 'Bounding box coordinates required' }),
        { status: 400, headers: { ...corsHeaders, 'content-type': 'application/json' } }
      );
    }

    // Get Google Maps API key
    const apiKey = Deno.env.get('GOOGLE_MAPS_API_KEY');
    if (!apiKey) {
      throw new Error('GOOGLE_MAPS_API_KEY not configured');
    }

    // Calculate center and radius for Places API
    const centerLat = (minLat + maxLat) / 2;
    const centerLng = (minLng + maxLng) / 2;
    const radius = Math.min(
      calculateDistance(minLat, minLng, maxLat, maxLng) / 2,
      500 // Max 500m radius to avoid too many results
    );

    console.log(`🏘️ Searching for properties at ${centerLat},${centerLng} within ${radius}m`);

    // Search for residential properties using Google Places API (Nearby Search)
    // Use 'premise' type to get actual buildings, not just addresses
    const placesUrl = `https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=${centerLat},${centerLng}&radius=${radius}&type=premise&key=${apiKey}`;
    
    const placesResponse = await fetch(placesUrl);
    const placesData = await placesResponse.json();

    if (placesData.status !== 'OK' && placesData.status !== 'ZERO_RESULTS') {
      console.error('Places API error:', placesData);
      return new Response(
        JSON.stringify({ ok: false, error: `Places API error: ${placesData.status}` }),
        { status: 400, headers: { ...corsHeaders, 'content-type': 'application/json' } }
      );
    }

    const results = placesData.results || [];
    console.log(`📍 Found ${results.length} potential properties`);

    // Initialize Supabase client
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    let inserted = 0;
    let skipped = 0;
    let errors = 0;

    // Process each place
    for (const place of results) {
      try {
        const lat = place.geometry.location.lat;
        const lng = place.geometry.location.lng;
        const placeId = place.place_id;

        // Get detailed address using Places Details API
        const detailsUrl = `https://maps.googleapis.com/maps/api/place/details/json?place_id=${placeId}&fields=address_components,formatted_address,types&key=${apiKey}`;
        const detailsResponse = await fetch(detailsUrl);
        const detailsData = await detailsResponse.json();

        if (detailsData.status !== 'OK') {
          console.warn(`⚠️ Could not get details for place ${placeId}`);
          skipped++;
          continue;
        }

        const addressComponents: any = {};
        detailsData.result.address_components.forEach((component: any) => {
          if (component.types.includes('street_number')) {
            addressComponents.street_number = component.long_name;
          }
          if (component.types.includes('route')) {
            addressComponents.route = component.long_name;
          }
          if (component.types.includes('locality')) {
            addressComponents.city = component.long_name;
          }
          if (component.types.includes('administrative_area_level_1')) {
            addressComponents.state = component.short_name;
          }
          if (component.types.includes('postal_code')) {
            addressComponents.postal_code = component.long_name;
          }
        });

        // Skip if no street number (not a specific building)
        if (!addressComponents.street_number || !addressComponents.route) {
          console.log(`⏩ Skipping - no street number: ${detailsData.result.formatted_address}`);
          skipped++;
          continue;
        }

        // Filter out highways, parkways, boulevards, and major roads
        const formattedAddress = detailsData.result.formatted_address || '';
        const isHighwayOrMajorRoad = /\b(Highway|Hwy|Pkwy|Parkway|Blvd|Boulevard|Freeway|Interstate|Turnpike|Expy|Expressway)\b/i.test(formattedAddress);
        if (isHighwayOrMajorRoad) {
          console.log(`⏩ Skipping major road: ${formattedAddress}`);
          skipped++;
          continue;
        }

        // Filter out commercial places
        const types = detailsData.result.types || [];
        const isCommercial = types.some((t: string) => 
          ['shopping_mall', 'store', 'restaurant', 'cafe', 'bank', 
           'gas_station', 'parking', 'airport', 'train_station', 'car_dealer',
           'hospital', 'school', 'university', 'church', 'mosque', 'synagogue',
           'post_office', 'fire_station', 'police', 'city_hall', 'courthouse',
           'library', 'stadium', 'gym', 'spa', 'beauty_salon', 'hair_care',
           'laundry', 'pharmacy', 'veterinary_care', 'pet_store'].includes(t)
        );
        if (isCommercial) {
          console.log(`⏩ Skipping commercial: ${formattedAddress}`);
          skipped++;
          continue;
        }

        const address = {
          line1: `${addressComponents.street_number || ''} ${addressComponents.route || ''}`.trim(),
          city: addressComponents.city || '',
          state: addressComponents.state || '',
          postal_code: addressComponents.postal_code || '',
          formatted: formattedAddress
        };

        // Generate address hash
        const addressText = JSON.stringify(address);
        const encoder = new TextEncoder();
        const data = encoder.encode(addressText);
        const hashBuffer = await crypto.subtle.digest('SHA-256', data);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        const addressHash = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');

        // Check if property already exists
        const { data: existing } = await supabase
          .from('properties')
          .select('id')
          .eq('address_hash', addressHash)
          .single();

        if (existing) {
          skipped++;
          continue;
        }

        // Check for nearby properties (spatial deduplication - 6m minimum for adjacent addresses)
        const { data: nearbyExists } = await supabase.rpc('check_nearby_property', {
          check_lat: lat,
          check_lng: lng,
          min_distance_meters: 6
        });

        if (nearbyExists) {
          console.log(`⏩ Skipping - property exists within 6m: ${formattedAddress}`);
          skipped++;
          continue;
        }

        console.log(`✨ Adding new property: ${formattedAddress}`);

        // Insert new property
        const { error: insertError } = await supabase
          .from('properties')
          .insert({
            address_hash: addressHash,
            address: address,
            geom: `POINT(${lng} ${lat})`,
            place_id: placeId,
            homeowner: {
              name: null,
              type: null,
              emails: [],
              phones: [],
              source: 'google_maps',
              confidence_score: 0
            },
            flags: {}
          });

        if (insertError) {
          console.error(`❌ Error inserting property:`, insertError);
          errors++;
        } else {
          inserted++;
        }

      } catch (error) {
        console.error(`❌ Error processing place:`, error);
        errors++;
      }
    }

    console.log(`✅ Population complete: ${inserted} inserted, ${skipped} skipped, ${errors} errors`);

    return new Response(
      JSON.stringify({
        ok: true,
        inserted,
        skipped,
        errors,
        total: results.length
      }),
      { headers: { ...corsHeaders, 'content-type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in populate-properties:', error);
    return new Response(
      JSON.stringify({ ok: false, error: String(error) }),
      { status: 500, headers: { ...corsHeaders, 'content-type': 'application/json' } }
    );
  }
});

// Helper function to calculate distance between two points in meters
function calculateDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371e3; // Earth's radius in meters
  const φ1 = lat1 * Math.PI / 180;
  const φ2 = lat2 * Math.PI / 180;
  const Δφ = (lat2 - lat1) * Math.PI / 180;
  const Δλ = (lng2 - lng1) * Math.PI / 180;

  const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
            Math.cos(φ1) * Math.cos(φ2) *
            Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c;
}
