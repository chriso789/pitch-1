import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const authHeader = req.headers.get('Authorization')!;
    
    const supabase = createClient(supabaseUrl, supabaseKey, {
      global: { headers: { Authorization: authHeader } },
    });

    // Get authenticated user
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const url = new URL(req.url);
    const path = url.pathname;

    // POST /measure/manual - Save manual measurement
    if (path.includes('/manual') && req.method === 'POST') {
      const body = await req.json();
      const { propertyId, faces, waste_pct = 12 } = body;

      if (!propertyId || !faces || !Array.isArray(faces)) {
        return new Response(
          JSON.stringify({ error: 'Missing required fields: propertyId, faces' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Calculate summary
      const total_area_sqft = faces.reduce((sum: number, face: any) => sum + (face.area_sqft || 0), 0);
      const total_squares = total_area_sqft / 100;

      const measurement = {
        property_id: propertyId,
        source: 'manual',
        faces,
        summary: {
          total_area_sqft,
          total_squares,
          waste_pct,
          pitch_method: 'manual',
        },
        created_by: user.id,
      };

      const { data, error } = await supabase
        .from('measurements')
        .insert(measurement)
        .select()
        .single();

      if (error) {
        console.error('Error saving measurement:', error);
        return new Response(JSON.stringify({ error: error.message }), {
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      return new Response(JSON.stringify({ ok: true, data }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // POST /measure/auto - Auto measurement (provider-based)
    if (path.includes('/auto') && req.method === 'POST') {
      const body = await req.json();
      const { propertyId, address, lat, lng, waste_pct = 12 } = body;

      if (!propertyId || !lat || !lng) {
        return new Response(
          JSON.stringify({ error: 'Missing required fields: propertyId, lat, lng' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Try Regrid API for building footprints
      const regridApiKey = Deno.env.get('REGRID_API_KEY');
      
      if (!regridApiKey) {
        return new Response(
          JSON.stringify({
            error: 'Auto-measure not configured. Please use Manual-Measure.',
            hint: 'Configure REGRID_API_KEY to enable auto-measure.',
          }),
          { status: 501, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      try {
        console.log(`[Auto-Measure] Fetching building footprint for ${lat}, ${lng}`);
        
        // Call Regrid Parcel API to get building footprints
        const regridUrl = `https://app.regrid.com/api/v2/parcels/near?latitude=${lat}&longitude=${lng}&distance=50&limit=1&return_geometry=true`;
        
        const regridResponse = await fetch(regridUrl, {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${regridApiKey}`,
            'accept': 'application/json',
          },
        });

        if (!regridResponse.ok) {
          const errorText = await regridResponse.text();
          console.error('[Regrid] API error:', regridResponse.status, errorText);
          throw new Error(`Regrid API error: ${regridResponse.status}`);
        }

        const regridData = await regridResponse.json();
        
        if (!regridData.parcels || regridData.parcels.length === 0) {
          return new Response(
            JSON.stringify({
              error: 'No building footprint found at this location',
              hint: 'Try Manual-Measure instead',
            }),
            { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        const parcel = regridData.parcels[0];
        const buildingGeometry = parcel.geometry;

        if (!buildingGeometry || buildingGeometry.type !== 'Polygon') {
          return new Response(
            JSON.stringify({
              error: 'Building footprint geometry not available',
              hint: 'Try Manual-Measure instead',
            }),
            { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        // Convert GeoJSON polygon to WKT and calculate area
        const coordinates = buildingGeometry.coordinates[0]; // exterior ring
        const wktCoords = coordinates.map((coord: number[]) => `${coord[0]} ${coord[1]}`).join(', ');
        const wkt = `POLYGON((${wktCoords}))`;

        // Simple planar area calculation (approximate for small areas)
        const area_sqft = calculatePolygonArea(coordinates);
        const total_squares = area_sqft / 100;

        const faces = [{
          id: 'A',
          wkt,
          area_sqft,
          pitch: '4/12', // Default pitch
        }];

        const measurement = {
          property_id: propertyId,
          source: 'regrid',
          faces,
          summary: {
            total_area_sqft: area_sqft,
            total_squares,
            waste_pct,
            pitch_method: 'manual',
          },
          created_by: user.id,
        };

        const { data, error } = await supabase
          .from('measurements')
          .insert(measurement)
          .select()
          .single();

        if (error) {
          console.error('[Auto-Measure] Error saving measurement:', error);
          return new Response(JSON.stringify({ error: error.message }), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }

        console.log(`[Auto-Measure] Success: ${area_sqft} sqft, ${total_squares} squares`);
        
        return new Response(JSON.stringify({ ok: true, data }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      } catch (error) {
        console.error('[Auto-Measure] Error:', error);
        return new Response(
          JSON.stringify({
            error: error instanceof Error ? error.message : 'Auto-measure failed',
            hint: 'Try Manual-Measure instead',
          }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    // GET /measure/:propertyId/latest - Get latest measurement
    if (req.method === 'GET' && path.includes('/measure/')) {
      const parts = path.split('/');
      const propertyId = parts[parts.indexOf('measure') + 1];

      if (!propertyId || propertyId === 'auto' || propertyId === 'manual') {
        return new Response(
          JSON.stringify({ error: 'Invalid property ID' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const { data, error } = await supabase
        .from('measurements')
        .select('*')
        .eq('property_id', propertyId)
        .order('created_at', { ascending: false })
        .limit(1)
        .single();

      if (error && error.code !== 'PGRST116') { // PGRST116 = no rows
        console.error('Error fetching measurement:', error);
        return new Response(JSON.stringify({ error: error.message }), {
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      return new Response(JSON.stringify({ ok: true, data: data || null }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    return new Response(JSON.stringify({ error: 'Not found' }), {
      status: 404,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Measure function error:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

// Helper function to calculate polygon area in square feet
// Uses Shoelace formula for lat/lng coordinates
function calculatePolygonArea(coordinates: number[][]): number {
  if (coordinates.length < 3) return 0;
  
  // Convert to meters using approximate conversion at latitude
  const lat = coordinates[0][1];
  const metersPerDegreeLat = 111320; // ~constant
  const metersPerDegreeLng = 111320 * Math.cos(lat * Math.PI / 180);
  
  let area = 0;
  for (let i = 0; i < coordinates.length - 1; i++) {
    const [x1, y1] = coordinates[i];
    const [x2, y2] = coordinates[i + 1];
    
    const x1m = x1 * metersPerDegreeLng;
    const y1m = y1 * metersPerDegreeLat;
    const x2m = x2 * metersPerDegreeLng;
    const y2m = y2 * metersPerDegreeLat;
    
    area += (x1m * y2m) - (x2m * y1m);
  }
  
  const areaSquareMeters = Math.abs(area / 2);
  const areaSquareFeet = areaSquareMeters * 10.7639; // m² to ft²
  
  return Math.round(areaSquareFeet);
}
