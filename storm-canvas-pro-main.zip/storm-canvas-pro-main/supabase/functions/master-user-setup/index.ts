import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.4';
import { authenticateRequest, requireAdmin } from '../_shared/auth.ts';
import { validateRequest, masterUserSetupSchema, ValidationError } from '../_shared/validation.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Authenticate request
    const { user, error: authError } = await authenticateRequest(req);
    
    if (!user) {
      return new Response(
        JSON.stringify({ error: authError || 'Authentication required' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Create admin client for role checks
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false
        }
      }
    );

    // Check if user is already an admin
    const { isAdmin, errorResponse } = await requireAdmin(user.id, supabaseAdmin);
    if (errorResponse) return errorResponse;

    // Validate request body
    const { email, password } = await validateRequest(req, masterUserSetupSchema);
    
    // Only allow master admin email (additional security layer)
    if (email !== 'chrisobrien91@gmail.com') {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    console.log('Setting up master user:', email)

    // Check if user already exists
    const { data: userList } = await supabaseAdmin.auth.admin.listUsers()
    const existingUser = userList.users?.find(user => user.email === email)
    
    if (existingUser) {
      console.log('Master user already exists')
      return new Response(
        JSON.stringify({ success: true, message: 'Master user already exists' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Create the master user
    const { data: newUser, error: createError } = await supabaseAdmin.auth.admin.createUser({
      email,
      password,
      email_confirm: true, // Auto-confirm email
      user_metadata: {
        full_name: 'Chris O\'Brien',
        name: 'Chris O\'Brien'
      }
    })

    if (createError) {
      console.error('Error creating master user:', createError)
      return new Response(
        JSON.stringify({ error: createError.message }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Ensure profile is created and grant admin role via secure function
    if (newUser.user) {
      // Create profile
      const { error: profileError } = await supabaseAdmin
        .from('profiles')
        .upsert({
          id: newUser.user.id,
          email: newUser.user.email,
          full_name: 'Chris O\'Brien',
        });

      if (profileError) {
        console.error('Error creating profile:', profileError);
      }

      // Grant admin role using secure function
      const { error: roleError } = await supabaseAdmin.rpc('grant_role', {
        target_user_id: newUser.user.id,
        role_name: 'admin',
        granted_by: user.id
      });

      if (roleError) {
        console.error('Error granting admin role:', roleError);
        return new Response(
          JSON.stringify({ error: 'Failed to grant admin role' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      console.log('Master user profile and admin role created successfully');
    }

    console.log('Master user created successfully')
    
    return new Response(
      JSON.stringify({ success: true, message: 'Master user created successfully' }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Master user setup error:', error);
    
    // Handle validation errors
    if (error instanceof ValidationError) {
      return new Response(
        JSON.stringify(error.toJSON()),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})