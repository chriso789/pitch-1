import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Get user from JWT
    const authHeader = req.headers.get('Authorization')
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Missing authorization header' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(
      authHeader.replace('Bearer ', '')
    )

    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: 'Invalid token' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    const body = await req.json()
    const { 
      propertyId, 
      storageKey, 
      exifData, 
      caption, 
      originalFilename,
      fileSize,
      mimeType = 'image/jpeg'
    } = body

    if (!propertyId || !storageKey) {
      return new Response(
        JSON.stringify({ error: 'propertyId and storageKey are required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Extract location from EXIF if available
    let latitude = null
    let longitude = null
    
    if (exifData?.GPS) {
      latitude = exifData.GPS.GPSLatitude
      longitude = exifData.GPS.GPSLongitude
    }

    // Create photo record
    const { data: photo, error: insertError } = await supabase
      .from('photos')
      .insert({
        user_id: user.id,
        property_id: propertyId,
        storage_path: storageKey,
        filename: storageKey.split('/').pop() || 'unknown',
        original_filename: originalFilename,
        caption,
        mime_type: mimeType,
        file_size: fileSize,
        latitude,
        longitude,
        exif_data: exifData
      })
      .select()
      .single()

    if (insertError) {
      console.error('Database insert error:', insertError)
      return new Response(
        JSON.stringify({ error: 'Failed to save photo record' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Get public URL for the photo
    const { data: urlData } = supabase.storage
      .from('photos')
      .getPublicUrl(storageKey)

    return new Response(
      JSON.stringify({
        photo: {
          ...photo,
          public_url: urlData.publicUrl
        }
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Attach photo error:', error)
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})