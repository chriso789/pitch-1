import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { PDFDocument, rgb, StandardFonts } from 'https://esm.sh/pdf-lib@1.17.1'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Get user from JWT
    const authHeader = req.headers.get('Authorization')
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Missing authorization header' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(
      authHeader.replace('Bearer ', '')
    )

    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: 'Invalid token' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    const body = await req.json()
    const { 
      propertyId, 
      proposalType = 'hail', 
      customerName,
      designId,
      notes
    } = body

    if (!propertyId) {
      return new Response(
        JSON.stringify({ error: 'propertyId is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Fetch property and design data
    const { data: property, error: propertyError } = await supabase
      .from('properties')
      .select('*')
      .eq('id', propertyId)
      .eq('user_id', user.id)
      .single()

    if (propertyError || !property) {
      return new Response(
        JSON.stringify({ error: 'Property not found' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    let design = null
    if (designId) {
      const { data: designData, error: designError } = await supabase
        .from('designs')
        .select('*')
        .eq('id', designId)
        .eq('user_id', user.id)
        .single()

      if (!designError && designData) {
        design = designData
      }
    }

    // Create proposal record
    const { data: proposal, error: proposalError } = await supabase
      .from('proposals')
      .insert({
        user_id: user.id,
        property_id: propertyId,
        design_id: designId,
        proposal_type: proposalType,
        customer_name: customerName || property.homeowner_name,
        notes,
        status: 'generating'
      })
      .select()
      .single()

    if (proposalError) {
      console.error('Proposal creation error:', proposalError)
      return new Response(
        JSON.stringify({ error: 'Failed to create proposal' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Generate PDF using pdf-lib
    console.log('[Proposal] Generating PDF...')
    const pdfBytes = await generateProposalPDF({
      proposal,
      property,
      design,
      proposalType
    })

    // Upload PDF to storage
    const pdfKey = `${user.id}/${proposal.id}_${proposalType}.pdf`
    const { data: uploadData, error: uploadError } = await supabase.storage
      .from('proposals')
      .upload(pdfKey, pdfBytes, {
        contentType: 'application/pdf',
        upsert: false,
      })

    if (uploadError) {
      console.error('[Proposal] Upload error:', uploadError)
      return new Response(
        JSON.stringify({ error: 'Failed to upload PDF' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Get public URL
    const { data: { publicUrl } } = supabase.storage
      .from('proposals')
      .getPublicUrl(pdfKey)

    // Update proposal with PDF URL
    const { data: updatedProposal, error: updateError } = await supabase
      .from('proposals')
      .update({
        pdf_url: publicUrl,
        status: 'ready'
      })
      .eq('id', proposal.id)
      .select()
      .single()

    if (updateError) {
      console.error('Proposal update error:', updateError)
    }

    console.log('[Proposal] PDF generated successfully:', publicUrl)

    return new Response(
      JSON.stringify({
        proposal: updatedProposal || proposal,
        pdfUrl: publicUrl,
        downloadUrl: publicUrl
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Proposal generation error:', error)
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})

function generateProposalHTML({ proposal, property, design, proposalType }: any): string {
  const currentDate = new Date().toLocaleDateString()
  
  return `
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Roofing Proposal - ${property.address}</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; color: #333; }
        .header { text-align: center; border-bottom: 2px solid #0066cc; padding-bottom: 20px; margin-bottom: 30px; }
        .header h1 { color: #0066cc; margin: 0; }
        .section { margin-bottom: 25px; }
        .section h2 { color: #0066cc; border-bottom: 1px solid #ccc; padding-bottom: 5px; }
        .property-info { background: #f8f9fa; padding: 15px; border-radius: 5px; }
        .estimate-table { width: 100%; border-collapse: collapse; margin: 15px 0; }
        .estimate-table th, .estimate-table td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        .estimate-table th { background: #0066cc; color: white; }
        .total-row { font-weight: bold; background: #f0f8ff; }
        .footer { margin-top: 40px; text-align: center; font-size: 12px; color: #666; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Storm Canvas Pro</h1>
        <h2>Roofing Estimate Proposal</h2>
        <p>Date: ${currentDate}</p>
    </div>

    <div class="section">
        <h2>Property Information</h2>
        <div class="property-info">
            <p><strong>Address:</strong> ${property.address}</p>
            <p><strong>Customer:</strong> ${proposal.customer_name || 'Property Owner'}</p>
            <p><strong>Property Value:</strong> $${property.property_value?.toLocaleString() || 'N/A'}</p>
            <p><strong>Year Built:</strong> ${property.year_built || 'N/A'}</p>
            <p><strong>Square Footage:</strong> ${property.square_footage?.toLocaleString() || 'N/A'} sq ft</p>
        </div>
    </div>

    <div class="section">
        <h2>Damage Assessment (${proposalType.charAt(0).toUpperCase() + proposalType.slice(1)} Damage)</h2>
        <p>Based on our inspection, we have identified ${proposalType} damage to your roofing system that requires immediate attention.</p>
    </div>

    ${design ? `
    <div class="section">
        <h2>Roof Design Specifications</h2>
        <p><strong>Area:</strong> ${design.area_sqft} sq ft</p>
        <p><strong>Pitch Estimate:</strong> ${design.pitch_estimate || 'Standard'}</p>
        <p><strong>Material Type:</strong> ${design.material_type || 'Architectural Shingles'}</p>
        <p><strong>Design Notes:</strong> ${design.notes || 'Standard installation'}</p>
    </div>
    ` : ''}

    <div class="section">
        <h2>Estimate Breakdown</h2>
        <table class="estimate-table">
            <thead>
                <tr>
                    <th>Item</th>
                    <th>Description</th>
                    <th>Quantity</th>
                    <th>Unit Price</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Roofing Materials</td>
                    <td>Architectural shingles, underlayment, flashing</td>
                    <td>${design?.area_sqft || property.square_footage || 2000} sq ft</td>
                    <td>$8.50</td>
                    <td>$${((design?.area_sqft || property.square_footage || 2000) * 8.5).toLocaleString()}</td>
                </tr>
                <tr>
                    <td>Labor</td>
                    <td>Professional installation and cleanup</td>
                    <td>${design?.area_sqft || property.square_footage || 2000} sq ft</td>
                    <td>$4.50</td>
                    <td>$${((design?.area_sqft || property.square_footage || 2000) * 4.5).toLocaleString()}</td>
                </tr>
                <tr>
                    <td>Permits & Disposal</td>
                    <td>Building permits and debris removal</td>
                    <td>1</td>
                    <td>$750</td>
                    <td>$750</td>
                </tr>
                <tr class="total-row">
                    <td colspan="4"><strong>Total Estimate</strong></td>
                    <td><strong>$${(((design?.area_sqft || property.square_footage || 2000) * 13) + 750).toLocaleString()}</strong></td>
                </tr>
            </tbody>
        </table>
    </div>

    <div class="section">
        <h2>Terms and Conditions</h2>
        <ul>
            <li>This estimate is valid for 30 days from the date above</li>
            <li>Work includes full material and labor warranty</li>
            <li>Insurance claims assistance available</li>
            <li>Payment terms: 10% down, balance due upon completion</li>
        </ul>
    </div>

    ${proposal.notes ? `
    <div class="section">
        <h2>Additional Notes</h2>
        <p>${proposal.notes}</p>
    </div>
    ` : ''}

    <div class="footer">
        <p>Generated by Storm Canvas Pro | Contact us for questions about this estimate</p>
    </div>
</body>
</html>
  `
}

// Generate PDF using pdf-lib
async function generateProposalPDF({ proposal, property, design, proposalType }: any): Promise<Uint8Array> {
  const pdfDoc = await PDFDocument.create()
  const helveticaBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold)
  const helvetica = await pdfDoc.embedFont(StandardFonts.Helvetica)
  
  let page = pdfDoc.addPage([612, 792]) // 8.5" x 11" inches
  const { width, height } = page.getSize()
  let y = height - 60
  
  // Header
  page.drawText('ROOFING PROPOSAL', {
    x: 50,
    y,
    size: 24,
    font: helveticaBold,
    color: rgb(0, 0.4, 0.8),
  })
  y -= 30
  
  page.drawText(`Date: ${new Date().toLocaleDateString()}`, {
    x: 50,
    y,
    size: 11,
    font: helvetica,
    color: rgb(0.3, 0.3, 0.3),
  })
  y -= 40
  
  // Property Information
  page.drawText('PROPERTY INFORMATION', {
    x: 50,
    y,
    size: 14,
    font: helveticaBold,
  })
  y -= 20
  
  const infoItems = [
    `Address: ${property.address || 'N/A'}`,
    `Customer: ${proposal.customer_name || 'Property Owner'}`,
    `Year Built: ${property.year_built || 'N/A'}`,
    `Square Footage: ${property.square_footage?.toLocaleString() || 'N/A'} sq ft`,
  ]
  
  for (const item of infoItems) {
    page.drawText(item, { x: 50, y, size: 10, font: helvetica })
    y -= 16
  }
  y -= 20
  
  // Damage Assessment
  page.drawText(`DAMAGE ASSESSMENT (${proposalType.toUpperCase()} Damage)`, {
    x: 50,
    y,
    size: 14,
    font: helveticaBold,
  })
  y -= 20
  
  page.drawText(`Based on our inspection, we identified ${proposalType} damage requiring attention.`, {
    x: 50,
    y,
    size: 10,
    font: helvetica,
  })
  y -= 30
  
  // Design Specs (if available)
  if (design) {
    page.drawText('ROOF DESIGN SPECIFICATIONS', {
      x: 50,
      y,
      size: 14,
      font: helveticaBold,
    })
    y -= 20
    
    const designItems = [
      `Area: ${design.area_sqft || 'N/A'} sq ft`,
      `Pitch Estimate: ${design.pitch_estimate || 'Standard'}`,
      `Material Type: ${design.material_type || 'Architectural Shingles'}`,
    ]
    
    for (const item of designItems) {
      page.drawText(item, { x: 50, y, size: 10, font: helvetica })
      y -= 16
    }
    y -= 20
  }
  
  // Estimate Breakdown
  page.drawText('ESTIMATE BREAKDOWN', {
    x: 50,
    y,
    size: 14,
    font: helveticaBold,
  })
  y -= 25
  
  // Table header
  const colX = [50, 180, 320, 420, 500]
  page.drawText('Item', { x: colX[0], y, size: 10, font: helveticaBold })
  page.drawText('Description', { x: colX[1], y, size: 10, font: helveticaBold })
  page.drawText('Quantity', { x: colX[2], y, size: 10, font: helveticaBold })
  page.drawText('Unit Price', { x: colX[3], y, size: 10, font: helveticaBold })
  page.drawText('Total', { x: colX[4], y, size: 10, font: helveticaBold })
  y -= 18
  
  // Line
  page.drawLine({
    start: { x: 50, y: y + 5 },
    end: { x: width - 50, y: y + 5 },
    thickness: 1,
    color: rgb(0.7, 0.7, 0.7),
  })
  y -= 5
  
  // Estimate rows
  const sqft = design?.area_sqft || property.square_footage || 2000
  const materialsCost = sqft * 8.5
  const laborCost = sqft * 4.5
  const permitsCost = 750
  const total = materialsCost + laborCost + permitsCost
  
  const rows = [
    ['Roofing Materials', 'Shingles, underlayment', `${sqft} sq ft`, '$8.50', `$${materialsCost.toFixed(0)}`],
    ['Labor', 'Install & cleanup', `${sqft} sq ft`, '$4.50', `$${laborCost.toFixed(0)}`],
    ['Permits & Disposal', 'Permits & removal', '1', '$750', '$750'],
  ]
  
  for (const row of rows) {
    for (let i = 0; i < row.length; i++) {
      page.drawText(row[i], { x: colX[i], y, size: 9, font: helvetica })
    }
    y -= 16
  }
  
  y -= 10
  page.drawLine({
    start: { x: 50, y: y + 5 },
    end: { x: width - 50, y: y + 5 },
    thickness: 2,
    color: rgb(0, 0, 0),
  })
  y -= 10
  
  page.drawText('TOTAL ESTIMATE:', { x: colX[3], y, size: 11, font: helveticaBold })
  page.drawText(`$${total.toLocaleString()}`, { x: colX[4], y, size: 11, font: helveticaBold })
  y -= 30
  
  // Terms
  page.drawText('TERMS AND CONDITIONS', {
    x: 50,
    y,
    size: 14,
    font: helveticaBold,
  })
  y -= 20
  
  const terms = [
    '• This estimate is valid for 30 days from the date above',
    '• Work includes full material and labor warranty',
    '• Insurance claims assistance available',
    '• Payment terms: 10% down, balance due upon completion',
  ]
  
  for (const term of terms) {
    page.drawText(term, { x: 50, y, size: 9, font: helvetica })
    y -= 16
  }
  
  // Footer
  y = 40
  page.drawText('Generated by Storm Canvas Pro', {
    x: width / 2 - 90,
    y,
    size: 10,
    font: helvetica,
    color: rgb(0.5, 0.5, 0.5),
  })
  
  return await pdfDoc.save()
}