import { serve } from 'https://deno.land/std/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { authenticateRequest, checkUserRole } from '../_shared/auth.ts';
import { Logger } from '../_shared/logger.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const logger = Logger.create(req, 'get-google-maps-key');

  try {
    logger.info('Fetching Google Maps API key');

    // Get API key from environment or vault
    let apiKey: string | null = null;

    // First try Lovable's secret system
    const lovableApiKey = Deno.env.get('GOOGLE_MAPS_API_KEY');
    
    if (lovableApiKey) {
      apiKey = lovableApiKey;
      logger.info('API key found in environment');
    } else {
      // Fallback to Supabase vault.secrets
      const supabaseAdmin = createClient(
        Deno.env.get('SUPABASE_URL')!,
        Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
      );

      const { data, error } = await supabaseAdmin
        .from('vault.secrets')
        .select('secret')
        .eq('name', 'GOOGLE_MAPS_API_KEY')
        .single();

      if (!error && data) {
        apiKey = data.secret;
        logger.info('API key found in vault');
      }
    }

    if (!apiKey) {
      logger.warn('API key not found');
      return new Response(
        JSON.stringify({ ok: false, apiKey: null }),
        { headers: { ...corsHeaders, 'content-type': 'application/json' } }
      );
    }

    // Return full API key to all users
    // Security is managed via Google Cloud Console restrictions (HTTP referrers, API restrictions, quotas)
    logger.info('Returning full API key');
    return new Response(
      JSON.stringify({ ok: true, apiKey: apiKey }),
      { headers: { ...corsHeaders, 'content-type': 'application/json' } }
    );
  } catch (error) {
    logger.error('Unexpected error in get-google-maps-key', error);
    return new Response(
      JSON.stringify({ ok: false, apiKey: null }),
      { status: 500, headers: { ...corsHeaders, 'content-type': 'application/json' } }
    );
  }
});