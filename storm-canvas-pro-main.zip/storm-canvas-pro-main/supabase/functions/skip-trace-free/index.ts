import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.4'
import { authenticateRequest } from '../_shared/auth.ts'
import { validateRequest, skipTraceRequestSchema, ValidationError } from '../_shared/validation.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

// Contact interface
interface Contact {
  name: string;
  first_name: string;
  last_name: string;
  phone: string | null;
  email: string | null;
  confidence: number;
  provider: string;
  type: string;
}

// SearchBug Skip Trace Provider
class SearchBugProvider {
  name = 'searchbug';
  private username: string;
  private password: string;
  private baseUrl = 'https://www.searchbug.com/api';

  constructor(username: string, password: string) {
    this.username = username;
    this.password = password;
  }

  // Create Basic Auth header
  private getAuthHeader(): string {
    const credentials = btoa(`${this.username}:${this.password}`);
    return `Basic ${credentials}`;
  }

  // Parse owner name into first_name and last_name
  parseOwnerName(fullName: string): { first_name: string; last_name: string } {
    if (!fullName || fullName.trim() === '') {
      return { first_name: '', last_name: '' };
    }

    const cleaned = fullName.trim();

    // Handle "Last, First" format (common in property records)
    if (cleaned.includes(',')) {
      const [last, first] = cleaned.split(',').map(s => s.trim());
      return { 
        first_name: first || '', 
        last_name: last || '' 
      };
    }

    // Handle business entities (LLC, Inc, Corp, Trust)
    const businessIndicators = /\b(llc|inc|corp|corporation|trust|ltd|limited)\b/i;
    if (businessIndicators.test(cleaned)) {
      // For businesses, put everything in last_name
      return { 
        first_name: '', 
        last_name: cleaned 
      };
    }

    // Handle "First Middle Last" format
    const parts = cleaned.split(/\s+/);
    
    if (parts.length === 1) {
      // Single word - treat as last name
      return { first_name: '', last_name: parts[0] };
    }
    
    if (parts.length === 2) {
      // "First Last"
      return { 
        first_name: parts[0], 
        last_name: parts[1] 
      };
    }
    
    // 3+ words: "First Middle... Last"
    // Everything except last word goes to first_name
    const lastName = parts[parts.length - 1];
    const firstName = parts.slice(0, -1).join(' ');
    
    return { 
      first_name: firstName, 
      last_name: lastName 
    };
  }

  // Property Lookup API call
  async lookupProperty(address: string) {
    console.log('SearchBug property lookup:', address);
    
    const response = await fetch(`${this.baseUrl}/property/lookup`, {
      method: 'POST',
      headers: {
        'Authorization': this.getAuthHeader(),
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({
        address: address,
        output: 'json'
      })
    });

    console.log('SearchBug response status:', response.status);
    console.log('SearchBug response headers:', Object.fromEntries(response.headers.entries()));

    if (!response.ok) {
      const errorText = await response.text();
      console.error('SearchBug property API error:', response.status, errorText);
      throw new Error(`SearchBug API error: ${response.status} - ${errorText}`);
    }

    const contentType = response.headers.get('content-type');
    if (!contentType?.includes('application/json')) {
      const text = await response.text();
      console.error('SearchBug returned non-JSON:', text.substring(0, 500));
      throw new Error('SearchBug API returned non-JSON response. Check credentials and API endpoint.');
    }

    return await response.json();
  }

  // People Search API call for contact enrichment
  async lookupPeople(name: string, address: string) {
    console.log('SearchBug people lookup:', { name, address });
    
    const response = await fetch(`${this.baseUrl}/people/search`, {
      method: 'POST',
      headers: {
        'Authorization': this.getAuthHeader(),
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        name: name,
        address: address,
        output: 'json'
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('SearchBug people API error:', response.status, errorText);
      throw new Error(`SearchBug People API error: ${response.status} - ${errorText}`);
    }

    return await response.json();
  }

  // Parse contacts from SearchBug people results
  parseContacts(peopleResult: any, ownerName: string): Contact[] {
    const contacts: Contact[] = [];
    
    if (!peopleResult || !peopleResult.results || !Array.isArray(peopleResult.results)) {
      return contacts;
    }

    for (const person of peopleResult.results) {
      const { first_name, last_name } = this.parseOwnerName(person.name || ownerName);
      
      // Add contact with phones
      if (person.phones && Array.isArray(person.phones)) {
        for (const phone of person.phones) {
          contacts.push({
            name: person.name || ownerName,
            first_name,
            last_name,
            phone: phone.number || phone,
            email: person.email || null,
            confidence: person.confidence || 0.7,
            provider: this.name,
            type: person.type || 'owner'
          });
        }
      }
      
      // Add contact with email if no phones
      if ((!person.phones || person.phones.length === 0) && person.email) {
        contacts.push({
          name: person.name || ownerName,
          first_name,
          last_name,
          phone: null,
          email: person.email,
          confidence: person.confidence || 0.6,
          provider: this.name,
          type: person.type || 'owner'
        });
      }
    }

    return contacts;
  }

  // Calculate confidence score
  calculateConfidence(contacts: any[]): number {
    if (contacts.length === 0) return 0.3;
    
    let confidence = 0.4; // Base confidence for having data
    
    if (contacts.some(c => c.phone)) confidence += 0.3;
    if (contacts.some(c => c.email)) confidence += 0.2;
    if (contacts.length > 1) confidence += 0.1;
    
    return Math.min(confidence, 1.0);
  }

  // Classify owner type
  classifyOwnerType(ownerName?: string): string {
    if (!ownerName) return 'unknown';
    
    const name = ownerName.toLowerCase();
    if (name.includes('llc') || name.includes('inc') || name.includes('corp')) return 'business';
    if (name.includes('trust')) return 'trust';
    if (name.includes('&') || name.includes('and')) return 'individual';
    
    return 'individual';
  }

  // Main lookup method
  async lookup(input: { address?: string; lat?: number; lng?: number; apn?: string }) {
    console.log('SearchBug lookup started:', input);
    
    try {
      if (!input.address) {
        throw new Error('Address is required for SearchBug lookup');
      }

      // Step 1: Property lookup
      const propertyResult = await this.lookupProperty(input.address);
      
      if (!propertyResult || propertyResult.error) {
        throw new Error(propertyResult?.error || 'Property lookup failed');
      }

      console.log('SearchBug property result:', propertyResult);

      // Step 2: Extract owner name
      const ownerName = propertyResult.owner_name || propertyResult.owner || propertyResult.OwnerName || '';
      
      // Step 3: Contact enrichment if we have owner name
      let contacts: Contact[] = [];
      if (ownerName) {
        try {
          const peopleResult = await this.lookupPeople(ownerName, input.address);
          console.log('SearchBug people result:', peopleResult);
          
          contacts = this.parseContacts(peopleResult, ownerName);
        } catch (error) {
          console.warn('People lookup failed, using property owner only:', error);
          
          // Fallback: create contact from property data
          const { first_name, last_name } = this.parseOwnerName(ownerName);
          contacts = [{
            name: ownerName,
            first_name,
            last_name,
            phone: propertyResult.phone || propertyResult.Phone || null,
            email: propertyResult.email || propertyResult.Email || null,
            confidence: 0.6,
            provider: this.name,
            type: 'owner'
          }];
        }
      } else {
        console.warn('No owner name found in property result');
      }

      // Step 4: Build result
      return {
        parcel: {
          apn: propertyResult.apn || propertyResult.APN || input.apn,
          ownerNames: [ownerName],
          situsAddress: input.address,
          mailingAddress: propertyResult.mailing_address || propertyResult.MailingAddress || input.address,
          propertyValue: propertyResult.assessed_value || propertyResult.AssessedValue || null,
          yearBuilt: propertyResult.year_built || propertyResult.YearBuilt || null,
          squareFootage: propertyResult.square_footage || propertyResult.SquareFootage || null,
          propertyType: propertyResult.property_type || propertyResult.PropertyType || 'residential',
          qualityGrade: propertyResult.quality_grade || 'Standard',
          condition: propertyResult.condition || 'Average'
        },
        contacts: contacts,
        source: this.name,
        processedAt: new Date(),
        confidence: this.calculateConfidence(contacts),
        ownerType: this.classifyOwnerType(ownerName),
        isOwnerOccupied: propertyResult.owner_occupied || false,
        propertyInsights: {
          marketValue: propertyResult.market_value || propertyResult.assessed_value,
          assessedValue: propertyResult.assessed_value,
          valuationConfidence: contacts.length > 0 ? 0.8 : 0.6,
          recentSale: false,
          saleHistory: []
        }
      };

    } catch (error) {
      console.error('SearchBug lookup error:', error);
      throw error;
    }
  }
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  let requestData: any = {};
  
  try {
    // Authenticate request
    const { user, error: authError } = await authenticateRequest(req);
    
    if (!user) {
      return new Response(
        JSON.stringify({ error: authError || 'Authentication required' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Validate and parse request body
    requestData = await validateRequest(req, skipTraceRequestSchema);
    const { address, lat, lng, apn, propertyId: property_id, leadId: lead_id } = requestData;
    
    console.log('Skip trace request received:', { address, lat, lng, apn, property_id, lead_id });

    // Get SearchBug credentials from secrets
    const username = Deno.env.get('SEARCHBUG_USERNAME');
    const password = Deno.env.get('SEARCHBUG_PASSWORD');

    console.log('SearchBug credentials check:', {
      hasUsername: !!username,
      hasPassword: !!password,
      usernameLength: username?.length || 0
    });

    if (!username || !password) {
      console.error('Missing SearchBug credentials');
      return new Response(
        JSON.stringify({ 
          success: false,
          error: 'SearchBug credentials not configured. Please add SEARCHBUG_USERNAME and SEARCHBUG_PASSWORD secrets.',
          statusCode: 500,
          needsSetup: true
        }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Initialize Supabase client
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Initialize the SearchBug provider
    const provider = new SearchBugProvider(username, password);
    
    // Perform the skip trace lookup
    const startTime = Date.now();
    const result = await provider.lookup({ address, lat, lng, apn });
    const processingTime = Date.now() - startTime;
    
    console.log('Skip trace lookup completed in', processingTime, 'ms:', result);

    // Calculate estimated cost
    const estimatedCost = result.contacts.length > 0 ? 0.50 : 0.25; // $0.25 property, $0.50 with contacts

    console.log('SearchBug API usage:', {
      address,
      contacts_found: result.contacts.length,
      estimated_cost: estimatedCost,
      processing_time_ms: processingTime,
      timestamp: new Date().toISOString()
    });

    // Store the job record if property_id or lead_id provided
    if (property_id || lead_id) {
      const { error: insertError } = await supabase
        .from('skip_trace_jobs')
        .insert({
          property_id,
          lead_id,
          status: 'completed',
          provider: provider.name,
          input_data: { address, lat, lng, apn },
          result_data: {
            ...result,
            _meta: {
              estimated_cost: estimatedCost,
              contacts_count: result.contacts.length,
              processing_time_ms: processingTime
            }
          },
          started_at: new Date().toISOString(),
          completed_at: new Date().toISOString(),
          created_by: req.headers.get('x-user-id') // Optional user tracking
        });

      if (insertError) {
        console.error('Failed to store skip trace job:', insertError);
      }

      // Store contacts with proper name splitting
      if (result.contacts && result.contacts.length > 0) {
        const contactInserts = result.contacts.map(contact => {
          // Name is already parsed by SearchBugProvider.parseOwnerName
          return {
            property_id,
            lead_id,
            name: contact.name,              // Full name for compatibility
            first_name: contact.first_name,  // Properly split first name
            last_name: contact.last_name,    // Properly split last name
            phone: contact.phone,
            email: contact.email,
            provider: contact.provider,
            confidence: contact.confidence
          };
        });

        const { error: contactError } = await supabase
          .from('contacts')
          .insert(contactInserts);

        if (contactError) {
          console.error('Failed to store contacts:', contactError);
        } else {
          console.log(`Stored ${contactInserts.length} contacts with split names`);
        }
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        data: result,
        provider: provider.name,
        timestamp: new Date().toISOString(),
        meta: {
          estimated_cost: estimatedCost,
          processing_time_ms: processingTime
        }
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );

  } catch (error) {
    console.error('Skip trace function error:', error);
    
    // Handle validation errors
    if (error instanceof ValidationError) {
      return new Response(
        JSON.stringify(error.toJSON()),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 400,
        }
      );
    }
    
    let statusCode = 500;
    let errorMessage = 'Unknown error';
    
    if (error instanceof Error) {
      errorMessage = error.message;
      
      // Parse HTTP error codes from SearchBug
      if (errorMessage.includes('401')) {
        statusCode = 401;
        errorMessage = 'Invalid SearchBug credentials. Please check your username and password.';
      } else if (errorMessage.includes('402')) {
        statusCode = 402;
        errorMessage = 'Insufficient SearchBug credits. Please add funds to your account.';
      } else if (errorMessage.includes('429')) {
        statusCode = 429;
        errorMessage = 'SearchBug rate limit exceeded. Please try again later.';
      } else if (errorMessage.includes('404')) {
        statusCode = 404;
        errorMessage = 'Property not found in SearchBug database.';
      }
    }
    
    // Store failed job using already parsed data
    const { address, lat, lng, apn, property_id, lead_id } = requestData;
    
    if (property_id || lead_id) {
      try {
        const supabase = createClient(
          Deno.env.get('SUPABASE_URL') ?? '',
          Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
        );
        
        await supabase
          .from('skip_trace_jobs')
          .insert({
            property_id,
            lead_id,
            status: 'failed',
            provider: 'searchbug',
            input_data: { address, lat, lng, apn },
            error_message: errorMessage,
            started_at: new Date().toISOString(),
            completed_at: new Date().toISOString()
          });
      } catch (dbError) {
        console.error('Failed to store error job:', dbError);
      }
    }
    
    return new Response(
      JSON.stringify({ 
        success: false,
        error: errorMessage,
        provider: 'searchbug',
        statusCode: statusCode
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: statusCode,
      }
    );
  }
});
