import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.4';
import { validateRequest, webhookEventSchema, ValidationError } from '../_shared/validation.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-webhook-signature',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Validate request body structure
    const body = await validateRequest(req, webhookEventSchema);
    console.log('PITCH CRM webhook received:', body);

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // MANDATORY webhook signature validation (not optional)
    const signature = req.headers.get('x-webhook-signature');
    const webhookSecret = Deno.env.get('PITCH_WEBHOOK_SECRET');
    
    if (!webhookSecret) {
      console.error('PITCH_WEBHOOK_SECRET not configured');
      return new Response(
        JSON.stringify({ error: 'Webhook not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!signature) {
      console.error('Missing webhook signature');
      return new Response(
        JSON.stringify({ error: 'Missing webhook signature' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
    
    const isValid = await verifyWebhookSignature(body, signature, webhookSecret);
    if (!isValid) {
      console.error('Invalid webhook signature');
      return new Response(
        JSON.stringify({ error: 'Invalid signature' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Extract event data from PITCH CRM
    const { event, data } = body;

    // Only process "project.completed" events
    if (event !== 'project.completed') {
      console.log(`Ignoring event type: ${event}`);
      return new Response(
        JSON.stringify({ message: 'Event type not processed', event }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Find the property by address or custom field
    const propertyId = data.customFields?.propertyId;
    const addressHash = data.customFields?.addressHash;

    let property;
    if (propertyId) {
      const { data: prop } = await supabase
        .from('properties')
        .select('*')
        .eq('id', propertyId)
        .single();
      property = prop;
    } else if (addressHash) {
      const { data: prop } = await supabase
        .from('properties')
        .select('*')
        .eq('address_hash', addressHash)
        .single();
      property = prop;
    }

    if (!property) {
      console.error('Property not found for PITCH webhook:', { propertyId, addressHash });
      return new Response(
        JSON.stringify({ error: 'Property not found' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get the "Project Completed" disposition
    const { data: disposition } = await supabase
      .from('dispositions')
      .select('*')
      .eq('name', 'Project Completed')
      .single();

    if (!disposition) {
      console.error('Project Completed disposition not found');
      return new Response(
        JSON.stringify({ error: 'Project Completed disposition not found' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Create a system visit record to update the disposition
    const { error: visitError } = await supabase
      .from('visits')
      .insert({
        property_id: property.id,
        user_id: property.created_by, // Use the property creator as the user
        disposition_id: disposition.id,
        notes: `Project completed in PITCH CRM. Project ID: ${data.projectId || 'N/A'}, Completed Date: ${data.completedDate || new Date().toISOString()}`
      });

    if (visitError) {
      console.error('Error creating visit:', visitError);
      throw visitError;
    }

    console.log('Successfully updated property disposition to Project Completed:', {
      propertyId: property.id,
      dispositionId: disposition.id
    });

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Property disposition updated to Project Completed',
        propertyId: property.id
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('PITCH webhook error:', error);
    
    // Handle validation errors
    if (error instanceof ValidationError) {
      return new Response(
        JSON.stringify(error.toJSON()),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});

async function verifyWebhookSignature(
  payload: any, 
  signature: string, 
  secret: string
): Promise<boolean> {
  try {
    const encoder = new TextEncoder();
    const data = encoder.encode(JSON.stringify(payload));
    const key = await crypto.subtle.importKey(
      'raw',
      encoder.encode(secret),
      { name: 'HMAC', hash: 'SHA-256' },
      false,
      ['sign', 'verify']
    );
    
    const signatureBuffer = new Uint8Array(
      signature.match(/.{1,2}/g)!.map(byte => parseInt(byte, 16))
    );
    
    return await crypto.subtle.verify(
      'HMAC',
      key,
      signatureBuffer,
      data
    );
  } catch (error) {
    console.error('Signature verification error:', error);
    return false;
  }
}
