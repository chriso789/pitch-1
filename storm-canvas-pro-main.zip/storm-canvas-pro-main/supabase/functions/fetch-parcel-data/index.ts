import { serve } from 'https://deno.land/std/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { address, lat, lng, propertyId } = await req.json();
    
    if (!address && (!lat || !lng)) {
      return new Response(
        JSON.stringify({ ok: false, error: 'Either address or coordinates required' }),
        { status: 400, headers: { ...corsHeaders, 'content-type': 'application/json' } }
      );
    }

    // Get Google Maps API key
    const apiKey = Deno.env.get('GOOGLE_MAPS_API_KEY');
    if (!apiKey) {
      throw new Error('GOOGLE_MAPS_API_KEY not configured');
    }

    let geocodeResult;

    // Geocode address or reverse geocode coordinates
    if (address) {
      const geocodeUrl = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(address)}&key=${apiKey}`;
      const geocodeResponse = await fetch(geocodeUrl);
      geocodeResult = await geocodeResponse.json();
    } else {
      const reverseUrl = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&key=${apiKey}`;
      const reverseResponse = await fetch(reverseUrl);
      geocodeResult = await reverseResponse.json();
    }

    if (geocodeResult.status !== 'OK' || !geocodeResult.results[0]) {
      return new Response(
        JSON.stringify({ ok: false, error: 'Geocoding failed', details: geocodeResult }),
        { status: 400, headers: { ...corsHeaders, 'content-type': 'application/json' } }
      );
    }

    const result = geocodeResult.results[0];
    const location = result.geometry.location;
    const placeId = result.place_id;

    // Extract address components
    const addressComponents: any = {};
    result.address_components.forEach((component: any) => {
      if (component.types.includes('street_number')) {
        addressComponents.street_number = component.long_name;
      }
      if (component.types.includes('route')) {
        addressComponents.route = component.long_name;
      }
      if (component.types.includes('locality')) {
        addressComponents.city = component.long_name;
      }
      if (component.types.includes('administrative_area_level_1')) {
        addressComponents.state = component.short_name;
      }
      if (component.types.includes('postal_code')) {
        addressComponents.postal_code = component.long_name;
      }
    });

    const formattedAddress = {
      line1: `${addressComponents.street_number || ''} ${addressComponents.route || ''}`.trim(),
      city: addressComponents.city || '',
      state: addressComponents.state || '',
      postal_code: addressComponents.postal_code || ''
    };

    // Update property in database if propertyId provided
    if (propertyId) {
      const supabase = createClient(
        Deno.env.get('SUPABASE_URL')!,
        Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
      );

      const { error: updateError } = await supabase
        .from('properties')
        .update({
          geom: `POINT(${location.lng} ${location.lat})`,
          place_id: placeId,
          address: formattedAddress
        })
        .eq('id', propertyId);

      if (updateError) {
        console.error('Error updating property:', updateError);
      }
    }

    return new Response(
      JSON.stringify({
        ok: true,
        lat: location.lat,
        lng: location.lng,
        place_id: placeId,
        formatted_address: result.formatted_address,
        address: formattedAddress
      }),
      { headers: { ...corsHeaders, 'content-type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error in fetch-parcel-data:', error);
    return new Response(
      JSON.stringify({ ok: false, error: String(error) }),
      { status: 500, headers: { ...corsHeaders, 'content-type': 'application/json' } }
    );
  }
});
