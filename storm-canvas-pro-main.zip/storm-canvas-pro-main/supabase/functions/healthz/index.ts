import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

// Google Maps Provider Health Check
async function checkGoogleMapsHealth(apiKey: string) {
  const startTime = Date.now();
  
  if (!apiKey) {
    return { 
      name: 'googlemaps', 
      ok: false, 
      error: 'No API key provided'
    };
  }

  try {
    const response = await fetch(
      `https://maps.googleapis.com/maps/api/geocode/json?address=test&key=${apiKey}`,
      { 
        method: 'GET',
        headers: { 'User-Agent': 'Canvass-IQ/1.0' }
      }
    );
    
    const latency = Date.now() - startTime;
    
    if (response.ok) {
      const data = await response.json();
      if (data.status === 'OK' || data.status === 'ZERO_RESULTS') {
        return { 
          name: 'googlemaps', 
          ok: true, 
          latency_ms: latency,
          quota: 'See Google Cloud Console'
        };
      } else {
        return { 
          name: 'googlemaps', 
          ok: false, 
          latency_ms: latency,
          error: `API Error: ${data.status} - ${data.error_message || data.status}`
        };
      }
    } else {
      const error = await response.text();
      return { 
        name: 'googlemaps', 
        ok: false, 
        latency_ms: latency,
        error: `HTTP ${response.status}: ${error}`
      };
    }
  } catch (error) {
    return { 
      name: 'googlemaps', 
      ok: false, 
      latency_ms: Date.now() - startTime,
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const googleMapsApiKey = Deno.env.get('GOOGLE_MAPS_API_KEY') || '';
    
    const providers = [
      { name: 'mock', ok: true, latency_ms: 0 },
      await checkGoogleMapsHealth(googleMapsApiKey)
    ];
    
    console.log('Health check results:', providers);
    
    return new Response(JSON.stringify(providers), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  } catch (error) {
    console.error('Health check error:', error);
    return new Response(JSON.stringify({ error: 'Health check failed' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
})