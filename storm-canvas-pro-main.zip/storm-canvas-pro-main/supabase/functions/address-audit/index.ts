import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { minLng, minLat, maxLng, maxLat } = await req.json();

    if (!minLng || !minLat || !maxLng || !maxLat) {
      return new Response(
        JSON.stringify({ ok: false, error: 'Missing bounding box coordinates' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
      );
    }

    const googleMapsApiKey = Deno.env.get('GOOGLE_MAPS_API_KEY');
    if (!googleMapsApiKey) {
      return new Response(
        JSON.stringify({ ok: false, error: 'Google Maps API key not configured' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
      );
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Calculate center and radius
    const centerLat = (minLat + maxLat) / 2;
    const centerLng = (minLng + maxLng) / 2;
    const latDiff = maxLat - minLat;
    const lngDiff = maxLng - minLng;
    const radiusMeters = Math.min(
      Math.sqrt(latDiff * latDiff + lngDiff * lngDiff) * 111000 / 2,
      1000
    );

    console.log(`🔍 Auditing area: center(${centerLat}, ${centerLng}) radius:${radiusMeters}m`);

    // Get addresses from Google Places API
    const placesUrl = new URL('https://maps.googleapis.com/maps/api/place/nearbysearch/json');
    placesUrl.searchParams.set('location', `${centerLat},${centerLng}`);
    placesUrl.searchParams.set('radius', radiusMeters.toString());
    placesUrl.searchParams.set('type', 'premise');
    placesUrl.searchParams.set('key', googleMapsApiKey);

    const placesResponse = await fetch(placesUrl.toString());
    const placesData = await placesResponse.json();

    let totalAddressesFound = 0;
    const addressDetails: any[] = [];

    if (placesData.status === 'OK' && placesData.results?.length > 0) {
      totalAddressesFound = placesData.results.length;
      
      // Get details for each address
      for (const place of placesData.results.slice(0, 20)) { // Limit for performance
        const detailsUrl = new URL('https://maps.googleapis.com/maps/api/place/details/json');
        detailsUrl.searchParams.set('place_id', place.place_id);
        detailsUrl.searchParams.set('fields', 'address_components,formatted_address,geometry,types');
        detailsUrl.searchParams.set('key', googleMapsApiKey);

        try {
          const detailsResponse = await fetch(detailsUrl.toString());
          const detailsData = await detailsResponse.json();

          if (detailsData.status === 'OK' && detailsData.result) {
            const result = detailsData.result;
            const lat = result.geometry.location.lat;
            const lng = result.geometry.location.lng;

            // Check if this address has a pin
            const { data: existingPin } = await supabase
              .from('properties')
              .select('id, address, place_id')
              .eq('place_id', place.place_id)
              .maybeSingle();

            addressDetails.push({
              formatted_address: result.formatted_address,
              place_id: place.place_id,
              lat,
              lng,
              types: result.types,
              has_pin: !!existingPin,
              pin_id: existingPin?.id || null
            });
          }
        } catch (error) {
          console.error('Error fetching place details:', error);
        }
      }
    }

    // Get existing properties in the bounding box
    const { data: existingProperties, error: queryError } = await supabase.rpc(
      'get_properties_in_bbox',
      {
        min_lng: minLng,
        min_lat: minLat,
        max_lng: maxLng,
        max_lat: maxLat
      }
    );

    if (queryError) {
      console.error('Error querying properties:', queryError);
    }

    const totalPropertiesInDb = existingProperties?.length || 0;

    // Calculate distance distribution
    const distances: number[] = [];
    if (existingProperties && existingProperties.length > 1) {
      for (let i = 0; i < existingProperties.length - 1; i++) {
        const p1 = existingProperties[i];
        const p2 = existingProperties[i + 1];
        const dist = calculateDistance(p1.lat, p1.lng, p2.lat, p2.lng);
        distances.push(dist);
      }
    }

    const avgDistance = distances.length > 0 
      ? distances.reduce((a, b) => a + b, 0) / distances.length 
      : 0;
    const minDistance = distances.length > 0 ? Math.min(...distances) : 0;
    const maxDistance = distances.length > 0 ? Math.max(...distances) : 0;

    // Gap analysis
    const addressesWithPins = addressDetails.filter(a => a.has_pin).length;
    const addressesWithoutPins = addressDetails.filter(a => !a.has_pin);
    const gapPercentage = totalAddressesFound > 0 
      ? ((totalAddressesFound - addressesWithPins) / totalAddressesFound * 100).toFixed(1)
      : '0.0';

    console.log(`📊 Audit complete: ${totalAddressesFound} addresses found, ${totalPropertiesInDb} pins in DB`);
    console.log(`📉 Gap: ${gapPercentage}% of addresses missing pins`);
    console.log(`📏 Distance stats: min=${minDistance.toFixed(1)}m avg=${avgDistance.toFixed(1)}m max=${maxDistance.toFixed(1)}m`);

    return new Response(
      JSON.stringify({
        ok: true,
        area: {
          center: { lat: centerLat, lng: centerLng },
          radius: radiusMeters,
          bbox: { minLng, minLat, maxLng, maxLat }
        },
        google_places: {
          total_addresses_found: totalAddressesFound,
          addresses_with_pins: addressesWithPins,
          addresses_without_pins: addressesWithoutPins.length,
          sample_missing: addressesWithoutPins.slice(0, 10)
        },
        database: {
          total_properties: totalPropertiesInDb,
          properties_with_place_id: existingProperties?.filter((p: any) => p.place_id).length || 0,
          properties_without_place_id: existingProperties?.filter((p: any) => !p.place_id).length || 0
        },
        distance_analysis: {
          min_distance_meters: minDistance,
          avg_distance_meters: avgDistance,
          max_distance_meters: maxDistance,
          sample_count: distances.length
        },
        gap_analysis: {
          gap_percentage: parseFloat(gapPercentage),
          estimated_missing_pins: totalAddressesFound - addressesWithPins
        }
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error in address-audit:', error);
    return new Response(
      JSON.stringify({ ok: false, error: error.message }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    );
  }
});

function calculateDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371e3; // Earth's radius in meters
  const φ1 = lat1 * Math.PI / 180;
  const φ2 = lat2 * Math.PI / 180;
  const Δφ = (lat2 - lat1) * Math.PI / 180;
  const Δλ = (lng2 - lng1) * Math.PI / 180;

  const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
            Math.cos(φ1) * Math.cos(φ2) *
            Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c;
}
