import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const body = await req.json();
    console.log('PITCH CRM sync request:', body);

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const pitchApiKey = Deno.env.get('PITCH_API_KEY');
    
    if (!pitchApiKey) {
      console.log('PITCH_API_KEY not configured, skipping CRM sync');
      return new Response(
        JSON.stringify({ message: 'PITCH_API_KEY not configured' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Get property data if property_id is provided
    let propertyData = null;
    if (body.property_id) {
      const { data: property, error: propertyError } = await supabase
        .from('properties')
        .select('*')
        .eq('id', body.property_id)
        .single();

      if (propertyError) {
        throw new Error(`Failed to fetch property: ${propertyError.message}`);
      }
      propertyData = property;
    }

    // Get user/rep mapping
    let repMapping = null;
    if (body.user_id || propertyData?.created_by) {
      const userId = body.user_id || propertyData?.created_by;
      const { data: mapping } = await supabase
        .from('rep_integrations')
        .select('*')
        .eq('user_id', userId)
        .eq('is_active', true)
        .single();
      
      repMapping = mapping;
    }

    // Get disposition data if disposition_id is provided
    let dispositionData = null;
    if (body.disposition_id) {
      const { data: disposition, error: dispError } = await supabase
        .from('dispositions')
        .select('*')
        .eq('id', body.disposition_id)
        .single();

      if (!dispError) {
        dispositionData = disposition;
      }
    }

    // Create contact payload for PITCH CRM
    const contactPayload = await buildContactPayload(propertyData, body);
    
    // Generate idempotency key
    const idempotencyKey = await generateIdempotencyKey(propertyData?.address);

    console.log('Syncing to PITCH CRM:', { contactPayload, idempotencyKey });

    // Real PITCH CRM API call
    const pitchResponse = await callPitchCrmApi(contactPayload, {
      apiKey: pitchApiKey,
      idempotencyKey,
      repId: repMapping?.pitch_rep_id
    });

    console.log('PITCH CRM response:', pitchResponse);

    return new Response(
      JSON.stringify({ 
        success: true, 
        pitchResponse,
        message: 'Successfully synced to PITCH CRM'
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('PITCH CRM sync error:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});

async function buildContactPayload(propertyData: any, eventData: any) {
  if (!propertyData) {
    return null;
  }

  const address = propertyData.address || {};
  
  // Extract coordinates from PostGIS geometry if available
  let latitude = null;
  let longitude = null;
  
  if (propertyData.geom && typeof propertyData.geom === 'object') {
    if (propertyData.geom.coordinates && Array.isArray(propertyData.geom.coordinates)) {
      longitude = propertyData.geom.coordinates[0];
      latitude = propertyData.geom.coordinates[1];
    }
  }

  // Fetch contact data from contacts table
  const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
  const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  const supabase = createClient(supabaseUrl, supabaseServiceKey);

  const { data: contact } = await supabase
    .from('contacts')
    .select('*')
    .eq('property_id', propertyData.id)
    .eq('is_active', true)
    .order('confidence', { ascending: false })
    .limit(1)
    .single();

  // Fetch visit data to get appointment_date and disposition
  const { data: visit } = await supabase
    .from('visits')
    .select('*, dispositions(*)')
    .eq('property_id', propertyData.id)
    .order('created_at', { ascending: false })
    .limit(1)
    .single();
  
  return {
    // PITCH CRM required fields - prioritize contact data
    email: contact?.email || address.owner_email || eventData.contact_email || null,
    phone: contact?.phone || address.owner_phone || eventData.contact_phone || null,
    
    // Name fields - prioritize contact data
    firstName: contact?.first_name || address.owner_name?.split(' ')[0] || 'Property',
    lastName: contact?.last_name || address.owner_name?.split(' ').slice(1).join(' ') || 'Owner',
    company: address.business_name || null,
    
    // Property address - PITCH CRM standard fields
    address1: address.line1 || address.street_address || null,
    address2: address.line2 || null,
    city: address.city || null,
    state: address.state || address.state_code || null,
    postalCode: address.postal_code || address.zip_code || null,
    country: address.country || 'US',
    
    // Coordinates for mapping
    latitude: latitude,
    longitude: longitude,

    // Disposition/Status
    status: visit?.dispositions?.name || eventData.disposition_name || 'New Lead',
    
    // Appointment date if scheduled
    appointmentDate: visit?.appointment_date || null,
    
    // Custom fields for PITCH CRM
    customFields: {
      propertyId: propertyData.id,
      addressHash: propertyData.address_hash,
      canvassFlags: propertyData.flags || {},
      visitDate: eventData.created_at || propertyData.created_at,
      leadSource: 'canvass-iq-door-knock',
      propertyType: address.property_type || 'residential',
      ownerOccupied: address.owner_occupied || false,
      contactConfidence: contact?.confidence || 50,
      contactProvider: contact?.provider || 'manual'
    },
    
    // Lead scoring and notes
    leadScore: calculateLeadScore(propertyData, eventData),
    notes: buildContactNotes(propertyData, eventData, contact, visit),
    
    // Timestamps
    createdAt: eventData.created_at || propertyData.created_at,
    updatedAt: new Date().toISOString()
  };
}

function calculateLeadScore(propertyData: any, eventData: any): number {
  let score = 50; // Base score
  
  const address = propertyData.address || {};
  const flags = propertyData.flags || {};
  
  // Increase score based on property indicators
  if (address.property_type === 'single_family') score += 10;
  if (address.owner_occupied === false) score += 15; // Rental properties
  if (flags.storm_damage) score += 20;
  if (flags.roof_age_years && flags.roof_age_years > 15) score += 10;
  if (address.estimated_value && address.estimated_value > 200000) score += 5;
  
  // Cap the score
  return Math.min(score, 100);
}

function buildContactNotes(propertyData: any, eventData: any, contact: any, visit: any): string {
  const notes = [];
  const address = propertyData.address || {};
  const flags = propertyData.flags || {};
  
  notes.push('Lead generated via door-to-door canvassing');
  
  if (contact) {
    notes.push(`Contact Info: ${contact.first_name} ${contact.last_name}`);
    if (contact.phone) notes.push(`Phone: ${contact.phone}`);
    if (contact.email) notes.push(`Email: ${contact.email}`);
    notes.push(`Contact Source: ${contact.provider || 'manual'} (${contact.confidence}% confidence)`);
  }

  if (visit?.appointment_date) {
    notes.push(`Appointment Scheduled: ${new Date(visit.appointment_date).toLocaleString()}`);
  }
  
  if (address.property_type) {
    notes.push(`Property Type: ${address.property_type}`);
  }
  
  if (flags.storm_damage) {
    notes.push('⚠️ Potential storm damage identified');
  }
  
  if (flags.roof_age_years) {
    notes.push(`Roof Age: ~${flags.roof_age_years} years`);
  }
  
  if (visit?.dispositions?.name) {
    notes.push(`Visit Disposition: ${visit.dispositions.name}`);
  }
  
  if (visit?.notes || eventData.notes) {
    notes.push(`Canvasser Notes: ${visit?.notes || eventData.notes}`);
  }
  
  return notes.join('\n');
}

async function generateIdempotencyKey(address: any): Promise<string> {
  if (!address) {
    return crypto.randomUUID();
  }
  
  const addressString = `${address.line1 || ''}${address.postal_code || ''}`.toLowerCase();
  const encoder = new TextEncoder();
  const data = encoder.encode(addressString);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

async function callPitchCrmApi(contactPayload: any, options: any) {
  if (!contactPayload) {
    throw new Error('Contact payload is required');
  }

  console.log('PITCH CRM API call with:', {
    contact: contactPayload,
    apiKey: options.apiKey?.substring(0, 8) + '...',
    idempotencyKey: options.idempotencyKey,
    repId: options.repId
  });

  // Get integration endpoint configuration
  const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
  const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  const supabase = createClient(supabaseUrl, supabaseServiceKey);

  const { data: endpoint } = await supabase
    .from('integration_endpoints')
    .select('base_url')
    .eq('name', 'PITCH CRM')
    .eq('is_enabled', true)
    .single();

  if (!endpoint) {
    throw new Error('PITCH CRM integration endpoint not found or disabled');
  }

  // Create contact in PITCH CRM
  const createContactUrl = `${endpoint.base_url}/contacts`;
  
  const response = await fetch(createContactUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${options.apiKey}`,
      'X-Idempotency-Key': options.idempotencyKey,
      'User-Agent': 'CanvassIQ/1.0'
    },
    body: JSON.stringify({
      ...contactPayload,
      assignedRep: options.repId,
      source: 'canvass-iq-integration',
      tags: ['canvass-lead', 'property-visit']
    })
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error('PITCH CRM API error:', {
      status: response.status,
      statusText: response.statusText,
      error: errorText
    });
    
    // Handle specific error cases
    if (response.status === 401) {
      throw new Error('PITCH CRM authentication failed - check API key');
    } else if (response.status === 429) {
      throw new Error('PITCH CRM rate limit exceeded - will retry later');
    } else if (response.status >= 500) {
      throw new Error(`PITCH CRM server error (${response.status}) - will retry later`);
    } else {
      throw new Error(`PITCH CRM API error: ${response.status} - ${errorText}`);
    }
  }

  const result = await response.json();
  
  console.log('PITCH CRM API success:', {
    contactId: result.id || result.contactId,
    status: result.status || 'created',
    assignedRep: result.assignedRep || options.repId
  });

  return {
    contactId: result.id || result.contactId || crypto.randomUUID(),
    status: result.status || 'created',
    idempotencyKey: options.idempotencyKey,
    assignedRep: result.assignedRep || options.repId || 'default-rep-001',
    timestamp: new Date().toISOString(),
    pitchResponse: result
  };
}