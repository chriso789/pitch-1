// SOP-01: Owner Resolution Service - 5-Method Ladder Implementation

import { ResolutionInput, OwnerResolutionResult, ResolutionMethod, MethodResult, FailureCode } from './types.ts';
import { ConfidenceScorer } from './scoring.ts';
import { ResolutionLogger } from './logging.ts';

// Import all resolution methods
import { DirectParcelMethod } from './methods/direct-parcel.ts';
import { AddressStandardMethod } from './methods/address-standard.ts';
import { SkipTraceMethod } from './methods/skip-trace.ts';
import { ReverseLookupMethod } from './methods/reverse-lookup.ts';
import { PublicRecordsMethod } from './methods/public-records.ts';

export class OwnerResolutionService {
  private methods: ResolutionMethod[];
  
  constructor() {
    // Initialize methods in priority order (1 = highest priority)
    this.methods = [
      {
        name: DirectParcelMethod.name,
        priority: DirectParcelMethod.priority,
        execute: DirectParcelMethod.execute.bind(DirectParcelMethod)
      },
      {
        name: AddressStandardMethod.name,
        priority: AddressStandardMethod.priority,
        execute: AddressStandardMethod.execute.bind(AddressStandardMethod)
      },
      {
        name: SkipTraceMethod.name,
        priority: SkipTraceMethod.priority,
        execute: SkipTraceMethod.execute.bind(SkipTraceMethod)
      },
      {
        name: ReverseLookupMethod.name,
        priority: ReverseLookupMethod.priority,
        execute: ReverseLookupMethod.execute.bind(ReverseLookupMethod)
      },
      {
        name: PublicRecordsMethod.name,
        priority: PublicRecordsMethod.priority,
        execute: PublicRecordsMethod.execute.bind(PublicRecordsMethod)
      }
    ];
    
    // Sort by priority (lowest number = highest priority)
    this.methods.sort((a, b) => a.priority - b.priority);
  }
  
  /**
   * Execute the 5-method owner resolution ladder
   * Tries methods in priority order until acceptable confidence is achieved
   */
  async resolveOwnerForPin(input: ResolutionInput): Promise<OwnerResolutionResult> {
    const startTime = Date.now();
    const methodsAttempted: string[] = [];
    const failureCodes: string[] = [];
    const methodResults: MethodResult[] = [];
    
    // Minimum confidence thresholds for early exit
    const EXCELLENT_THRESHOLD = 90; // Stop immediately if we get this confidence
    const GOOD_THRESHOLD = 75;      // Stop after 3 methods if we get this confidence
    
    let bestResult: MethodResult | null = null;
    let currentConfidence = 0;
    
    for (const method of this.methods) {
      try {
        console.log(`Attempting method: ${method.name}`);
        methodsAttempted.push(method.name);
        
        const result = await method.execute(input);
        methodResults.push(result);
        
        // Log individual method execution
        ResolutionLogger.logMethodExecution(method.name, input.address_hash, result);
        
        if (result.success && result.confidence > currentConfidence) {
          bestResult = result;
          currentConfidence = result.confidence;
          
          console.log(`Method ${method.name} succeeded with confidence: ${result.confidence}`);
          
          // Early exit conditions based on confidence and methods tried
          if (currentConfidence >= EXCELLENT_THRESHOLD) {
            console.log('Excellent confidence achieved, stopping early');
            break;
          }
          
          if (currentConfidence >= GOOD_THRESHOLD && methodsAttempted.length >= 3) {
            console.log('Good confidence achieved after 3 methods, stopping');
            break;
          }
        } else {
          console.log(`Method ${method.name} failed: ${result.failure_code || 'unknown'}`);
          if (result.failure_code) {
            failureCodes.push(result.failure_code);
          }
        }
        
      } catch (error) {
        console.error(`Error in method ${method.name}:`, error);
        failureCodes.push(FailureCode.API_ERROR);
      }
    }
    
    const totalProcessingTime = Date.now() - startTime;
    
    // Apply guardrails and final validation
    const finalResult = this.applyGuardrails(bestResult, methodResults);
    
    // Log overall resolution summary
    ResolutionLogger.logResolutionSummary(
      input.address_hash,
      methodsAttempted,
      finalResult.confidence_score,
      totalProcessingTime,
      finalResult.confidence_score > 0,
      finalResult.owner?.name,
      finalResult.contacts.length
    );
    
    return {
      ...finalResult,
      failure_codes: failureCodes,
      processing_metadata: {
        methods_attempted: methodsAttempted,
        total_processing_time_ms: totalProcessingTime,
        timestamp: new Date().toISOString()
      }
    };
  }
  
  /**
   * Apply guardrails and data validation to final result
   */
  private applyGuardrails(
    bestResult: MethodResult | null,
    allResults: MethodResult[]
  ): OwnerResolutionResult {
    
    if (!bestResult || !bestResult.success) {
      return this.createEmptyResult();
    }
    
    // Cross-validate results from multiple methods
    const validatedOwner = this.validateOwnerData(bestResult, allResults);
    const validatedContacts = this.validateAndDedupeContacts(bestResult, allResults);
    
    // Calculate final confidence with cross-validation bonus
    const crossValidationBonus = this.calculateCrossValidationBonus(bestResult, allResults);
    const finalConfidence = Math.min(100, bestResult.confidence + crossValidationBonus);
    
    // Apply confidence penalties for suspicious data
    const suspiciousPenalty = this.calculateSuspiciousPenalty(validatedOwner);
    const adjustedConfidence = Math.max(0, finalConfidence - suspiciousPenalty);
    
    return {
      owner: validatedOwner,
      parcel: bestResult.parcel,
      contacts: validatedContacts,
      confidence_score: adjustedConfidence,
      resolution_method: bestResult.source,
      sources: [bestResult.source],
      failure_codes: [],
      processing_metadata: {
        methods_attempted: [],
        total_processing_time_ms: 0,
        timestamp: new Date().toISOString()
      }
    };
  }
  
  /**
   * Validate and enhance owner data using cross-validation
   */
  private validateOwnerData(bestResult: MethodResult, allResults: MethodResult[]): any {
    let owner = bestResult.owner;
    
    if (!owner?.name) return null;
    
    // Cross-validate owner name across multiple methods
    const nameConfirmations = allResults.filter(r => 
      r.success && 
      r.owner?.name &&
      this.similarNames(r.owner.name, owner.name)
    ).length;
    
    // Enhance with additional data from other methods
    const enhanced = { ...owner };
    
    for (const result of allResults) {
      if (result.success && result.owner) {
        // Fill in missing fields from other methods
        if (!enhanced.type && result.owner.type) {
          enhanced.type = result.owner.type;
        }
        if (!enhanced.mailing_address && result.owner.mailing_address) {
          enhanced.mailing_address = result.owner.mailing_address;
        }
      }
    }
    
    enhanced.cross_validated = nameConfirmations > 1;
    
    return enhanced;
  }
  
  /**
   * Validate and deduplicate contact information
   */
  private validateAndDedupeContacts(bestResult: MethodResult, allResults: MethodResult[]): any[] {
    const contactMap = new Map<string, any>();
    
    // Collect all contacts from all successful methods
    for (const result of allResults) {
      if (result.success) {
        for (const contact of result.contacts) {
          const key = `${contact.type}:${contact.value.replace(/\D/g, '')}`;
          const existing = contactMap.get(key);
          
          // Keep contact with highest confidence
          if (!existing || contact.confidence > existing.confidence) {
            contactMap.set(key, contact);
          }
        }
      }
    }
    
    return Array.from(contactMap.values()).sort((a, b) => b.confidence - a.confidence);
  }
  
  /**
   * Calculate bonus confidence for cross-validation across methods
   */
  private calculateCrossValidationBonus(bestResult: MethodResult, allResults: MethodResult[]): number {
    let bonus = 0;
    
    // Owner name cross-validation bonus
    const ownerConfirmations = allResults.filter(r => 
      r.success && 
      r.source !== bestResult.source &&
      r.owner?.name &&
      this.similarNames(r.owner.name, bestResult.owner?.name)
    ).length;
    
    bonus += ownerConfirmations * 5; // 5 points per confirmation
    
    // Contact cross-validation bonus
    const contactOverlap = this.calculateContactOverlap(bestResult, allResults);
    bonus += contactOverlap * 3; // 3 points per overlapping contact
    
    return Math.min(15, bonus); // Cap at 15 points
  }
  
  /**
   * Calculate penalty for suspicious data patterns
   */
  private calculateSuspiciousPenalty(owner: any): number {
    let penalty = 0;
    
    if (!owner?.name) return 50; // Major penalty for no name
    
    const name = owner.name.toLowerCase();
    
    // Common suspicious patterns
    if (name.includes('unknown')) penalty += 30;
    if (name.includes('vacant')) penalty += 30;
    if (name.includes('trust') && name.length < 15) penalty += 10; // Very short trust names
    if (name.length > 100) penalty += 15; // Suspiciously long names
    if (name === name.toUpperCase() && name.length > 15) penalty += 10; // All caps
    
    return penalty;
  }
  
  /**
   * Check if two names are similar (for cross-validation)
   */
  private similarNames(name1?: string, name2?: string): boolean {
    if (!name1 || !name2) return false;
    
    const clean1 = name1.toLowerCase().replace(/[^\\w\\s]/g, '');
    const clean2 = name2.toLowerCase().replace(/[^\\w\\s]/g, '');
    
    // Exact match
    if (clean1 === clean2) return true;
    
    // Contains match (for "John Smith" vs "Smith, John")
    const words1 = clean1.split(/\\s+/);
    const words2 = clean2.split(/\\s+/);
    
    let matches = 0;
    for (const word of words1) {
      if (word.length > 2 && words2.some(w => w.includes(word) || word.includes(w))) {
        matches++;
      }
    }
    
    return matches >= 2; // At least 2 word matches
  }
  
  /**
   * Calculate contact overlap between methods
   */
  private calculateContactOverlap(bestResult: MethodResult, allResults: MethodResult[]): number {
    let overlap = 0;
    
    for (const contact of bestResult.contacts) {
      const found = allResults.some(r => 
        r.success && 
        r.source !== bestResult.source &&
        r.contacts.some(c => 
          c.type === contact.type && 
          c.value.replace(/\D/g, '') === contact.value.replace(/\D/g, '')
        )
      );
      
      if (found) overlap++;
    }
    
    return overlap;
  }
  
  /**
   * Create empty result for failed resolutions
   */
  private createEmptyResult(): OwnerResolutionResult {
    return {
      contacts: [],
      confidence_score: 0,
      resolution_method: 'none',
      sources: [],
      failure_codes: [FailureCode.NO_OWNER_DATA],
      processing_metadata: {
        methods_attempted: [],
        total_processing_time_ms: 0,
        timestamp: new Date().toISOString()
      }
    };
  }
}
