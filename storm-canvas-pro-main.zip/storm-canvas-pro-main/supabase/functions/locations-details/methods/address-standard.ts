// SOP-01: Method 2 - Address Standardization + Owner Search

import { ResolutionInput, MethodResult, FailureCode, Contact } from '../types.ts';
import { ConfidenceScorer } from '../scoring.ts';
import { ResolutionLogger } from '../logging.ts';

export class AddressStandardMethod {
  static name = 'address_standard';
  static priority = 2;
  
  static async execute(input: ResolutionInput): Promise<MethodResult> {
    const startTime = Date.now();
    
    try {
      // Step 1: Standardize address using USPS or Google APIs
      const standardizedAddress = await this.standardizeAddress(input.address);
      
      if (!standardizedAddress) {
        return this.createFailureResult(startTime, FailureCode.ADDRESS_NOT_FOUND);
      }
      
      // Step 2: Search for owner using standardized address
      const ownerData = await this.searchOwnerByAddress(standardizedAddress);
      
      if (!ownerData) {
        return this.createFailureResult(startTime, FailureCode.NO_OWNER_DATA);
      }
      
      const contacts = this.extractContacts(ownerData);
      const confidence = ConfidenceScorer.scoreMethodResult(
        ownerData.owner?.name,
        contacts,
        ownerData.parcel,
        Date.now() - startTime,
        85 // Good base confidence for standardized address lookup
      );
      
      return {
        success: true,
        confidence,
        owner: ownerData.owner,
        parcel: ownerData.parcel,
        contacts,
        source: this.name,
        processing_time_ms: Date.now() - startTime
      };
      
    } catch (error) {
      ResolutionLogger.logApiError(
        this.name, 
        'address_standardization', 
        error, 
        input.address_hash, 
        Date.now() - startTime
      );
      
      return this.createFailureResult(startTime, FailureCode.API_ERROR);
    }
  }
  
  private static async standardizeAddress(address: any): Promise<any> {
    // Try Google Maps Geocoding API first for best accuracy
    const googleResult = await this.standardizeWithGoogle(address);
    if (googleResult) return googleResult;
    
    // Fallback to USPS address validation
    const uspsResult = await this.standardizeWithUSPS(address);
    if (uspsResult) return uspsResult;
    
    return null;
  }
  
  private static async standardizeWithGoogle(address: any): Promise<any> {
    const apiKey = Deno.env.get('GOOGLE_MAPS_API_KEY');
    if (!apiKey) return null;
    
    const addressString = `${address.line1}, ${address.city}, ${address.state} ${address.postal_code}`;
    const url = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(addressString)}&key=${apiKey}`;
    
    const response = await fetch(url);
    
    if (!response.ok) return null;
    
    const data = await response.json();
    
    if (data.status !== 'OK' || !data.results?.[0]) return null;
    
    const result = data.results[0];
    
    // Extract standardized address components
    const components = result.address_components.reduce((acc: any, comp: any) => {
      acc[comp.types[0]] = comp.long_name;
      return acc;
    }, {});
    
    return {
      formatted_address: result.formatted_address,
      street_number: components.street_number || '',
      route: components.route || '',
      city: components.locality || components.sublocality || '',
      state: components.administrative_area_level_1 || '',
      postal_code: components.postal_code || '',
      place_id: result.place_id,
      geometry: {
        lat: result.geometry.location.lat,
        lng: result.geometry.location.lng
      }
    };
  }
  
  private static async standardizeWithUSPS(address: any): Promise<any> {
    // USPS Address Validation API
    const userId = Deno.env.get('USPS_USER_ID');
    if (!userId) return null;
    
    const addressString = `${address.line1}`;
    const city = address.city || '';
    const state = address.state || '';
    const zip = address.postal_code || '';
    
    const xmlRequest = `
      <AddressValidateRequest USERID="${userId}">
        <Revision>1</Revision>
        <Address ID="1">
          <Address1></Address1>
          <Address2>${addressString}</Address2>
          <City>${city}</City>
          <State>${state}</State>
          <Zip5>${zip}</Zip5>
          <Zip4></Zip4>
        </Address>
      </AddressValidateRequest>
    `;
    
    const url = `https://secure.shippingapis.com/ShippingAPI.dll?API=Verify&XML=${encodeURIComponent(xmlRequest)}`;
    
    const response = await fetch(url);
    
    if (!response.ok) return null;
    
    const xmlText = await response.text();
    
    // Parse XML response (simplified)
    if (xmlText.includes('<Error>')) return null;
    
    // Extract standardized address from XML
    // This would need proper XML parsing in production
    return {
      formatted_address: `${addressString}, ${city}, ${state} ${zip}`,
      street_address: addressString,
      city: city,
      state: state,
      postal_code: zip
    };
  }
  
  private static async searchOwnerByAddress(standardizedAddress: any): Promise<any> {
    // Search property records using standardized address
    
    // Try multiple property data sources
    const whitePagesResult = await this.searchWhitePages(standardizedAddress);
    if (whitePagesResult) return whitePagesResult;
    
    const publicRecordsResult = await this.searchPublicRecords(standardizedAddress);
    if (publicRecordsResult) return publicRecordsResult;
    
    return null;
  }
  
  private static async searchWhitePages(address: any): Promise<any> {
    const apiKey = Deno.env.get('WHITEPAGES_API_KEY');
    if (!apiKey) return null;
    
    const searchAddress = address.formatted_address || 
      `${address.street_address}, ${address.city}, ${address.state} ${address.postal_code}`;
    
    const url = `https://proapi.whitepages.com/3.0/location?address=${encodeURIComponent(searchAddress)}&api_key=${apiKey}`;
    
    const response = await fetch(url);
    
    if (!response.ok) return null;
    
    const data = await response.json();
    
    if (!data.results?.[0]?.associated_people?.[0]) return null;
    
    const person = data.results[0].associated_people[0];
    const location = data.results[0];
    
    return {
      owner: {
        name: person.name ? `${person.name.first_name} ${person.name.last_name}` : null,
        type: 'individual'
      },
      parcel: {
        standardized_address: location.standard_address_line1,
        city: location.city,
        state: location.state_code,
        postal_code: location.postal_code
      },
      phones: person.phone_numbers?.map((p: any) => ({
        number: p.phone_number,
        type: p.line_type,
        verified: p.is_valid
      })) || []
    };
  }
  
  private static async searchPublicRecords(address: any): Promise<any> {
    // Placeholder for public records search
    // Would integrate with services like TruePeopleSearch, BeenVerified, etc.
    return null;
  }
  
  private static extractContacts(ownerData: any): Contact[] {
    const contacts: Contact[] = [];
    
    if (ownerData.phones) {
      for (const phone of ownerData.phones) {
        contacts.push({
          type: 'phone',
          value: phone.number,
          confidence: phone.verified ? 85 : 70,
          source: this.name,
          verified: phone.verified
        });
      }
    }
    
    if (ownerData.emails) {
      for (const email of ownerData.emails) {
        contacts.push({
          type: 'email',
          value: email.address,
          confidence: 75,
          source: this.name
        });
      }
    }
    
    return contacts;
  }
  
  private static createFailureResult(startTime: number, failureCode: FailureCode): MethodResult {
    return {
      success: false,
      confidence: 0,
      contacts: [],
      source: this.name,
      failure_code: failureCode,
      processing_time_ms: Date.now() - startTime
    };
  }
}