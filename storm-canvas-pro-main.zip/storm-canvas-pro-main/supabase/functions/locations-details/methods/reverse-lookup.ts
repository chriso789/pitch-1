// SOP-01: Method 4 - Reverse Phone/Email Lookup

import { ResolutionInput, MethodResult, FailureCode, Contact } from '../types.ts';
import { ConfidenceScorer } from '../scoring.ts';
import { ResolutionLogger } from '../logging.ts';

export class ReverseLookupMethod {
  static name = 'reverse_lookup';
  static priority = 4;
  
  static async execute(input: ResolutionInput): Promise<MethodResult> {
    const startTime = Date.now();
    
    try {
      // Get any existing contact information to perform reverse lookups
      const existingContacts = this.extractExistingContacts(input.existing_data);
      
      if (existingContacts.length === 0) {
        // No existing contacts to reverse lookup
        return this.createFailureResult(startTime, FailureCode.NO_OWNER_DATA);
      }
      
      // Perform reverse lookups on available contacts
      const reverseResults = await this.performReverseLookups(existingContacts, input.address);
      
      if (!reverseResults) {
        return this.createFailureResult(startTime, FailureCode.NO_OWNER_DATA);
      }
      
      const contacts = this.enhanceContacts(existingContacts, reverseResults);
      const confidence = ConfidenceScorer.scoreMethodResult(
        reverseResults.owner?.name,
        contacts,
        reverseResults.address_match,
        Date.now() - startTime,
        65 // Medium base confidence for reverse lookup
      );
      
      return {
        success: true,
        confidence,
        owner: reverseResults.owner,
        parcel: reverseResults.address_match,
        contacts,
        source: this.name,
        processing_time_ms: Date.now() - startTime
      };
      
    } catch (error) {
      ResolutionLogger.logApiError(
        this.name, 
        'reverse_lookup', 
        error, 
        input.address_hash, 
        Date.now() - startTime
      );
      
      return this.createFailureResult(startTime, FailureCode.API_ERROR);
    }
  }
  
  private static extractExistingContacts(existingData: any): Array<{ type: string; value: string }> {
    const contacts = [];
    
    // Extract from previous method results or cached data
    if (existingData?.homeowner?.phones) {
      for (const phone of existingData.homeowner.phones) {
        contacts.push({ type: 'phone', value: phone });
      }
    }
    
    if (existingData?.homeowner?.emails) {
      for (const email of existingData.homeowner.emails) {
        contacts.push({ type: 'email', value: email });
      }
    }
    
    return contacts;
  }
  
  private static async performReverseLookups(
    contacts: Array<{ type: string; value: string }>,
    targetAddress: any
  ): Promise<any> {
    const results = await Promise.allSettled([
      this.reversePhoneLookups(contacts.filter(c => c.type === 'phone')),
      this.reverseEmailLookups(contacts.filter(c => c.type === 'email'))
    ]);
    
    // Merge and validate results
    return this.mergeReverseLookupResults(results, targetAddress);
  }
  
  private static async reversePhoneLookups(phoneContacts: Array<{ type: string; value: string }>): Promise<any> {
    if (phoneContacts.length === 0) return null;
    
    const results = [];
    
    for (const contact of phoneContacts.slice(0, 3)) { // Limit to 3 phone lookups
      const result = await this.reversePhoneLookup(contact.value);
      if (result) results.push(result);
    }
    
    return results.length > 0 ? results[0] : null; // Return first successful result
  }
  
  private static async reversePhoneLookup(phoneNumber: string): Promise<any> {
    // Try WhitePages reverse phone lookup
    const whitePageResult = await this.whitePagesReverseLookup(phoneNumber);
    if (whitePageResult) return whitePageResult;
    
    // Try TrueCaller or similar service
    const trueCallerResult = await this.trueCallerReverseLookup(phoneNumber);
    if (trueCallerResult) return trueCallerResult;
    
    return null;
  }
  
  private static async whitePagesReverseLookup(phoneNumber: string): Promise<any> {
    const apiKey = Deno.env.get('WHITEPAGES_API_KEY');
    if (!apiKey) return null;
    
    const cleanPhone = phoneNumber.replace(/\D/g, '');
    const url = `https://proapi.whitepages.com/3.0/phone?phone=${cleanPhone}&api_key=${apiKey}`;
    
    const response = await fetch(url);
    
    if (!response.ok) return null;
    
    const data = await response.json();
    
    if (!data.results?.[0]?.belongs_to?.[0]) return null;
    
    const person = data.results[0].belongs_to[0];
    const phone = data.results[0];
    
    return {
      owner: {
        name: person.name ? `${person.name.first_name} ${person.name.last_name}` : null,
        type: 'individual'
      },
      phone_info: {
        line_type: phone.line_type,
        carrier: phone.carrier,
        is_valid: phone.is_valid
      },
      addresses: person.locations?.map((loc: any) => ({
        address: loc.standard_address_line1,
        city: loc.city,
        state: loc.state_code,
        postal_code: loc.postal_code,
        is_current: loc.is_current
      })) || [],
      source: 'whitepages_reverse'
    };
  }
  
  private static async trueCallerReverseLookup(phoneNumber: string): Promise<any> {
    // TrueCaller API integration would go here
    // This is a placeholder for commercial reverse lookup services
    return null;
  }
  
  private static async reverseEmailLookups(emailContacts: Array<{ type: string; value: string }>): Promise<any> {
    if (emailContacts.length === 0) return null;
    
    const results = [];
    
    for (const contact of emailContacts.slice(0, 2)) { // Limit to 2 email lookups
      const result = await this.reverseEmailLookup(contact.value);
      if (result) results.push(result);
    }
    
    return results.length > 0 ? results[0] : null;
  }
  
  private static async reverseEmailLookup(email: string): Promise<any> {
    // Try various email reverse lookup services
    const piplResult = await this.piplEmailLookup(email);
    if (piplResult) return piplResult;
    
    return null;
  }
  
  private static async piplEmailLookup(email: string): Promise<any> {
    const apiKey = Deno.env.get('PIPL_API_KEY');
    if (!apiKey) return null;
    
    const url = `https://api.pipl.com/search/?email=${encodeURIComponent(email)}&key=${apiKey}`;
    
    const response = await fetch(url);
    
    if (!response.ok) return null;
    
    const data = await response.json();
    
    if (!data.person) return null;
    
    const person = data.person;
    
    return {
      owner: {
        name: person.names?.[0]?.display || null,
        type: 'individual'
      },
      addresses: person.addresses?.map((addr: any) => ({
        address: addr.display,
        city: addr.city,
        state: addr.state,
        postal_code: addr.postal_code,
        country: addr.country
      })) || [],
      source: 'pipl_email'
    };
  }
  
  private static mergeReverseLookupResults(results: any[], targetAddress: any): any {
    let merged: any = null;
    
    for (const result of results) {
      if (result.status === 'fulfilled' && result.value) {
        const data = result.value;
        
        if (!merged) {
          merged = data;
        } else {
          // Merge additional information
          if (data.owner?.name && !merged.owner?.name) {
            merged.owner = data.owner;
          }
          
          if (data.addresses) {
            merged.addresses = [...(merged.addresses || []), ...data.addresses];
          }
        }
      }
    }
    
    if (!merged) return null;
    
    // Validate that reverse lookup results match target address
    const addressMatch = this.validateAddressMatch(merged.addresses || [], targetAddress);
    
    return {
      ...merged,
      address_match: addressMatch
    };
  }
  
  private static validateAddressMatch(foundAddresses: any[], targetAddress: any): any {
    const targetStr = `${targetAddress.line1} ${targetAddress.city} ${targetAddress.state}`.toLowerCase();
    
    let bestMatch = null;
    let bestScore = 0;
    
    for (const addr of foundAddresses) {
      const addrStr = `${addr.address} ${addr.city} ${addr.state}`.toLowerCase();
      const score = this.calculateAddressSimilarity(targetStr, addrStr);
      
      if (score > bestScore) {
        bestScore = score;
        bestMatch = addr;
      }
    }
    
    // Only return match if similarity is high enough
    return bestScore > 0.7 ? bestMatch : null;
  }
  
  private static calculateAddressSimilarity(addr1: string, addr2: string): number {
    // Simple string similarity calculation
    const words1 = addr1.split(/\s+/);
    const words2 = addr2.split(/\s+/);
    
    let matches = 0;
    for (const word of words1) {
      if (words2.some(w => w.includes(word) || word.includes(w))) {
        matches++;
      }
    }
    
    return matches / Math.max(words1.length, words2.length);
  }
  
  private static enhanceContacts(
    existingContacts: Array<{ type: string; value: string }>,
    reverseResults: any
  ): Contact[] {
    const contacts: Contact[] = [];
    
    for (const contact of existingContacts) {
      const enhanced: Contact = {
        type: contact.type as 'phone' | 'email',
        value: contact.value,
        confidence: 60, // Base confidence for reverse lookup
        source: this.name
      };
      
      // Enhance with reverse lookup info
      if (contact.type === 'phone' && reverseResults.phone_info) {
        enhanced.confidence = reverseResults.phone_info.is_valid ? 80 : 50;
        enhanced.verified = reverseResults.phone_info.is_valid;
      }
      
      contacts.push(enhanced);
    }
    
    return contacts;
  }
  
  private static createFailureResult(startTime: number, failureCode: FailureCode): MethodResult {
    return {
      success: false,
      confidence: 0,
      contacts: [],
      source: this.name,
      failure_code: failureCode,
      processing_time_ms: Date.now() - startTime
    };
  }
}