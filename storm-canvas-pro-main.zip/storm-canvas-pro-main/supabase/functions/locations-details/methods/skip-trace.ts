// SOP-01: Skip-Trace Provider Method for Owner Resolution (SearchBug)

import { ResolutionInput, MethodResult, FailureCode, Contact } from '../types.ts';
import { ResolutionLogger } from '../logging.ts';

export class SkipTraceMethod {
  static name = 'skip_trace';
  static priority = 3;
  
  static async execute(input: ResolutionInput): Promise<MethodResult> {
    const startTime = Date.now();
    
    try {
      console.log(`[skip-trace] Starting SearchBug lookup for ${input.address_hash}`);

      const apiKey = Deno.env.get('SEARCHBUG_API_KEY');

      if (!apiKey) {
        console.warn('[skip-trace] SearchBug API key not configured');
        return this.createFailureResult(startTime, FailureCode.PROVIDER_UNAVAILABLE);
      }

      // Build address string
      const address = input.address;
      const addressStr = [
        address.line1,
        address.city,
        address.state,
        address.postal_code
      ].filter(Boolean).join(', ');

      if (!addressStr) {
        return this.createFailureResult(startTime, FailureCode.ADDRESS_NOT_FOUND);
      }

      // Run SearchBug lookup
      const searchBugResult = await this.searchSearchBug(apiKey, '', addressStr);

      if (!searchBugResult) {
        return this.createFailureResult(startTime, FailureCode.NO_OWNER_DATA);
      }

      // Extract contacts
      const contacts = this.extractContacts(searchBugResult);
      
      // Calculate enhanced confidence
      const processingTime = Date.now() - startTime;
      const confidence = this.calculateEnhancedConfidence(searchBugResult, processingTime);

      ResolutionLogger.logSuccess(
        this.name,
        input.address_hash,
        confidence,
        processingTime,
        searchBugResult.ownerName,
        contacts.length
      );

      return {
        success: true,
        confidence,
        owner: {
          name: searchBugResult.ownerName,
          type: this.classifyOwnerType(searchBugResult.ownerName),
          mailing_address: searchBugResult.mailingAddress,
          is_out_of_state: searchBugResult.isOutOfState
        },
        parcel: {
          apn: searchBugResult.apn,
          county: searchBugResult.county,
          last_sale_date: searchBugResult.lastSaleDate,
          assessed_value: searchBugResult.assessedValue
        },
        contacts,
        source: this.name,
        processing_time_ms: processingTime
      };

    } catch (error) {
      ResolutionLogger.logApiError(
        this.name, 
        'searchbug', 
        error, 
        input.address_hash, 
        Date.now() - startTime
      );
      
      return this.createFailureResult(startTime, FailureCode.API_ERROR);
    }
  }

  private static async searchSearchBug(apiKey: string, _password: string, address: string): Promise<any> {
    console.log('[skip-trace] SearchBug property lookup:', address);

    const baseUrl = 'https://api.searchbug.com';
    
    // Property lookup using API key
    const propertyResponse = await fetch(`${baseUrl}/property`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        address: address
      })
    });

    if (!propertyResponse.ok) {
      const errorText = await propertyResponse.text();
      console.error('[skip-trace] SearchBug property API error:', {
        status: propertyResponse.status,
        statusText: propertyResponse.statusText,
        error: errorText,
        address: address
      });
      
      // Try to parse error response
      try {
        const errorJson = JSON.parse(errorText);
        if (errorJson.error) {
          throw new Error(`SearchBug API: ${errorJson.error}`);
        }
      } catch (parseError) {
        // If not JSON, throw the raw error
      }
      
      throw new Error(`SearchBug API error: ${propertyResponse.status} - ${errorText.substring(0, 200)}`);
    }

    const propertyData = await propertyResponse.json();
    
    if (!propertyData || propertyData.error) {
      console.error('[skip-trace] SearchBug API returned error:', propertyData);
      throw new Error(propertyData?.error || 'Property lookup failed');
    }

    console.log('[skip-trace] SearchBug property result:', {
      hasOwner: !!propertyData.owner_name || !!propertyData.owner || !!propertyData.OwnerName,
      hasApn: !!propertyData.apn || !!propertyData.APN,
      hasAddress: !!propertyData.mailing_address || !!propertyData.MailingAddress
    });

    // Extract owner name
    const ownerName = propertyData.owner_name || propertyData.owner || propertyData.OwnerName || '';
    
    // Contact enrichment if we have owner name
    let contacts: any[] = [];
    if (ownerName) {
      try {
        const peopleResponse = await fetch(`${baseUrl}/people`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            name: ownerName,
            address: address
          })
        });

        if (peopleResponse.ok) {
          const peopleData = await peopleResponse.json();
          console.log('[skip-trace] SearchBug people result:', peopleData);
          
          if (peopleData && peopleData.results && Array.isArray(peopleData.results)) {
            contacts = peopleData.results;
          }
        }
      } catch (error) {
        console.warn('[skip-trace] People lookup failed, using property owner only:', error);
      }
    }

    // Parse mailing address
    const mailingAddress = propertyData.mailing_address || propertyData.MailingAddress || address;
    const isOutOfState = this.isOutOfState(address, mailingAddress);

    return {
      ownerName,
      apn: propertyData.apn || propertyData.APN,
      county: propertyData.county || propertyData.County,
      lastSaleDate: propertyData.last_sale_date || propertyData.LastSaleDate,
      assessedValue: propertyData.assessed_value || propertyData.AssessedValue,
      mailingAddress,
      isOutOfState,
      contacts,
      ownerOccupied: propertyData.owner_occupied || false,
      yearBuilt: propertyData.year_built || propertyData.YearBuilt,
      squareFootage: propertyData.square_footage || propertyData.SquareFootage,
      propertyData
    };
  }

  private static isOutOfState(situsAddress: string, mailingAddress: string): boolean {
    const extractState = (addr: string): string => {
      const match = addr.match(/\b([A-Z]{2})\b/);
      return match ? match[1] : '';
    };

    const situsState = extractState(situsAddress.toUpperCase());
    const mailingState = extractState(mailingAddress.toUpperCase());

    return situsState !== mailingState && situsState !== '' && mailingState !== '';
  }

  private static extractContacts(result: any): Contact[] {
    const contacts: Contact[] = [];
    
    if (!result.contacts || !Array.isArray(result.contacts)) {
      // Fallback to property data
      if (result.propertyData?.phone || result.propertyData?.Phone) {
        contacts.push({
          type: 'phone',
          value: result.propertyData.phone || result.propertyData.Phone,
          confidence: 50,
          source: this.name,
          verified: false
        });
      }
      
      if (result.propertyData?.email || result.propertyData?.Email) {
        contacts.push({
          type: 'email',
          value: result.propertyData.email || result.propertyData.Email,
          confidence: 50,
          source: this.name,
          verified: false
        });
      }
      
      return contacts;
    }

    for (const person of result.contacts) {
      // Add contacts with phones
      if (person.phones && Array.isArray(person.phones)) {
        for (const phone of person.phones) {
          contacts.push({
            type: 'phone',
            value: phone.number || phone,
            confidence: person.confidence || 70,
            source: this.name,
            verified: false
          });
        }
      }
      
      // Add email contact
      if (person.email) {
        contacts.push({
          type: 'email',
          value: person.email,
          confidence: person.confidence || 60,
          source: this.name,
          verified: false
        });
      }
    }

    return contacts;
  }

  private static calculateEnhancedConfidence(result: any, processingTime: number): number {
    let confidence = 0.5; // Base confidence for SearchBug

    // Owner name present
    if (result.ownerName) {
      confidence += 0.15;
    }

    // Contact information
    const hasPhone = result.contacts?.some((c: any) => c.phones?.length > 0);
    const hasEmail = result.contacts?.some((c: any) => c.email);
    
    if (hasPhone) confidence += 0.2;
    if (hasEmail) confidence += 0.1;

    // Property data completeness
    if (result.apn) confidence += 0.05;
    if (result.assessedValue) confidence += 0.05;
    if (result.yearBuilt) confidence += 0.03;

    // Owner occupancy (higher confidence for occupied)
    if (result.ownerOccupied) {
      confidence += 0.1;
    }

    // Out-of-state penalty
    if (result.isOutOfState) {
      confidence -= 0.15;
    } else {
      confidence += 0.05;
    }

    // Performance penalty
    if (processingTime > 5000) {
      confidence -= 0.05;
    }

    return Math.max(0.3, Math.min(0.95, confidence));
  }

  private static classifyOwnerType(ownerName: string): string {
    if (!ownerName) return 'unknown';
    
    const name = ownerName.toLowerCase();
    if (name.includes('llc')) return 'llc';
    if (name.includes('inc') || name.includes('corp')) return 'business';
    if (name.includes('trust')) return 'trust';
    
    return 'individual';
  }

  private static createFailureResult(startTime: number, failureCode: FailureCode): MethodResult {
    return {
      success: false,
      confidence: 0,
      contacts: [],
      source: this.name,
      failure_code: failureCode,
      processing_time_ms: Date.now() - startTime
    };
  }
}
