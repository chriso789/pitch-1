// SOP-01: Method 1 - Direct Parcel Lookup (County Assessor APIs)

import { ResolutionInput, MethodResult, FailureCode, Contact } from '../types.ts';
import { ConfidenceScorer } from '../scoring.ts';
import { ResolutionLogger } from '../logging.ts';

export class DirectParcelMethod {
  static name = 'direct_parcel';
  static priority = 1; // Highest priority
  
  static async execute(input: ResolutionInput): Promise<MethodResult> {
    const startTime = Date.now();
    
    try {
      // Extract county from address for county-specific API selection
      const county = this.extractCounty(input.address);
      
      if (!county) {
        return this.createFailureResult(startTime, FailureCode.GEOCODING_FAILED);
      }
      
      // Route to appropriate county assessor API
      const result = await this.lookupByCounty(county, input.address);
      
      if (!result) {
        return this.createFailureResult(startTime, FailureCode.PARCEL_LOOKUP_FAILED);
      }
      
      const contacts = this.extractContacts(result);
      const confidence = ConfidenceScorer.scoreMethodResult(
        result.owner?.name,
        contacts,
        result.parcel,
        Date.now() - startTime,
        95 // High base confidence for direct parcel lookup
      );
      
      return {
        success: true,
        confidence,
        owner: result.owner,
        parcel: result.parcel,
        contacts,
        source: this.name,
        processing_time_ms: Date.now() - startTime
      };
      
    } catch (error) {
      ResolutionLogger.logApiError(
        this.name, 
        'county_assessor', 
        error, 
        input.address_hash, 
        Date.now() - startTime
      );
      
      return this.createFailureResult(startTime, FailureCode.API_ERROR);
    }
  }
  
  private static async lookupByCounty(county: string, address: any): Promise<any> {
    switch (county.toLowerCase()) {
      case 'broward':
        return this.lookupBrowardCounty(address);
      case 'miami-dade':
        return this.lookupMiamiDadeCounty(address);
      case 'palm beach':
        return this.lookupPalmBeachCounty(address);
      default:
        // Generic property appraiser lookup
        return this.genericPropertyLookup(address);
    }
  }
  
  private static async lookupBrowardCounty(address: any): Promise<any> {
    // Broward County Property Appraiser API
    const apiKey = Deno.env.get('BROWARD_ASSESSOR_API_KEY');
    if (!apiKey) {
      throw new Error('Broward County API key not configured');
    }
    
    const searchAddress = `${address.line1}, ${address.city}, FL ${address.postal_code}`;
    const url = `https://bcpa.net/api/v1/property/search?address=${encodeURIComponent(searchAddress)}&key=${apiKey}`;
    
    const response = await fetch(url, { 
      headers: { 'User-Agent': 'DoorKnocking-App/1.0' }
    });
    
    if (!response.ok) {
      throw new Error(`Broward API error: ${response.status}`);
    }
    
    const data = await response.json();
    
    if (!data.properties || data.properties.length === 0) {
      return null;
    }
    
    const property = data.properties[0];
    
    return {
      owner: {
        name: property.owner_name,
        type: this.classifyOwnerType(property.owner_name),
        mailing_address: property.mailing_address,
        is_out_of_state: this.isOutOfState(property.mailing_address, 'FL')
      },
      parcel: {
        apn: property.parcel_id,
        county: 'Broward',
        last_sale_date: property.sale_date,
        assessed_value: property.assessed_value,
        wkt: property.geometry
      }
    };
  }
  
  private static async lookupMiamiDadeCounty(address: any): Promise<any> {
    // Miami-Dade County Property Appraiser API
    const apiKey = Deno.env.get('MIAMI_DADE_ASSESSOR_API_KEY');
    if (!apiKey) {
      throw new Error('Miami-Dade County API key not configured');
    }
    
    // Implementation for Miami-Dade specific API
    // This would be similar to Broward but with Miami-Dade endpoints
    return null; // Placeholder for now
  }
  
  private static async lookupPalmBeachCounty(address: any): Promise<any> {
    // Palm Beach County Property Appraiser API
    const apiKey = Deno.env.get('PALM_BEACH_ASSESSOR_API_KEY');
    if (!apiKey) {
      throw new Error('Palm Beach County API key not configured');
    }
    
    // Implementation for Palm Beach specific API
    return null; // Placeholder for now
  }
  
  private static async genericPropertyLookup(address: any): Promise<any> {
    // Fallback to generic property data APIs (like DataTree, CoreLogic, etc.)
    const apiKey = Deno.env.get('GENERIC_PROPERTY_API_KEY');
    if (!apiKey) {
      return null;
    }
    
    // Generic property API implementation
    return null; // Placeholder for now
  }
  
  private static extractCounty(address: any): string | null {
    if (address.city) {
      // Map cities to counties for Florida
      const cityToCounty = {
        'fort lauderdale': 'broward',
        'hollywood': 'broward', 
        'pembroke pines': 'broward',
        'coral springs': 'broward',
        'miami': 'miami-dade',
        'hialeah': 'miami-dade',
        'miami beach': 'miami-dade',
        'homestead': 'miami-dade',
        'west palm beach': 'palm beach',
        'boca raton': 'palm beach',
        'boynton beach': 'palm beach',
        'delray beach': 'palm beach'
      };
      
      const city = address.city.toLowerCase() as keyof typeof cityToCounty;
      return cityToCounty[city] || null;
    }
    
    return null;
  }
  
  private static classifyOwnerType(ownerName: string): string {
    if (!ownerName) return 'unknown';
    
    const name = ownerName.toLowerCase();
    if (name.includes('llc')) return 'llc';
    if (name.includes('inc') || name.includes('corp')) return 'business';
    if (name.includes('trust')) return 'trust';
    
    return 'individual';
  }
  
  private static isOutOfState(mailingAddress: string, propertyState: string): boolean {
    if (!mailingAddress || !propertyState) return false;
    
    // Simple state detection - could be enhanced
    return !mailingAddress.toUpperCase().includes(propertyState.toUpperCase());
  }
  
  private static extractContacts(result: any): Contact[] {
    const contacts: Contact[] = [];
    
    // County assessor data typically doesn't include direct contact info
    // but may have business phone numbers for commercial properties
    
    return contacts;
  }
  
  private static createFailureResult(startTime: number, failureCode: FailureCode): MethodResult {
    return {
      success: false,
      confidence: 0,
      contacts: [],
      source: this.name,
      failure_code: failureCode,
      processing_time_ms: Date.now() - startTime
    };
  }
}