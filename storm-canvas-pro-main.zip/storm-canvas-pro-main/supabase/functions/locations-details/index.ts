import { serve } from 'https://deno.land/std/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { OwnerResolutionService } from './owner-resolution.ts';
import { ResolutionInput } from './types.ts';
import { authenticateRequest } from '../_shared/auth.ts';
import { Logger, auditLog } from '../_shared/logger.ts';
import { checkRateLimit, rateLimitResponse } from '../_shared/rateLimit.ts';
import { z } from 'https://deno.land/x/zod@v3.22.4/mod.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const requestSchema = z.object({
  addressHash: z.string().length(64).regex(/^[a-f0-9]{64}$/)
});

/**
 * SOP-01: Pin → Owner Resolution Implementation
 * Replaces mock enrichment with comprehensive 5-method owner resolution ladder
 * Includes caching to prevent duplicate API charges
 */
async function resolveOwnerForPin(address: any, propertyId: string, addressHash: string, existingHomeowner: any): Promise<any> {
  // Check cache first - if data is less than 30 days old, use it
  const CACHE_VALIDITY_DAYS = 30;
  
  if (existingHomeowner?.last_resolved_at) {
    const lastResolvedDate = new Date(existingHomeowner.last_resolved_at);
    const daysSinceResolution = (Date.now() - lastResolvedDate.getTime()) / (1000 * 60 * 60 * 24);
    
    if (daysSinceResolution < CACHE_VALIDITY_DAYS) {
      console.log(`Using cached homeowner data (${Math.floor(daysSinceResolution)} days old) for ${addressHash}`);
      return {
        owner: { 
          name: existingHomeowner.name,
          type: existingHomeowner.type,
          mailing_address: existingHomeowner.mailing_address,
          is_out_of_state: existingHomeowner.is_out_of_state
        },
        parcel: existingHomeowner.parcel || {},
        phones: existingHomeowner.phones || [],
        emails: existingHomeowner.emails || [],
        sources: [existingHomeowner.source || 'cached'],
        confidence_score: existingHomeowner.confidence_score || 0,
        resolution_metadata: {
          cached: true,
          cache_age_days: Math.floor(daysSinceResolution),
          original_timestamp: existingHomeowner.last_resolved_at,
          resolution_method: existingHomeowner.resolution_method || 'unknown'
        }
      };
    }
  }
  
  // Data is stale or doesn't exist - run fresh resolution
  console.log(`Running fresh owner resolution for ${addressHash} (cache expired or missing)`);
  
  const ownerResolutionService = new OwnerResolutionService();
  
  const input: ResolutionInput = {
    address,
    property_id: propertyId,
    address_hash: addressHash,
    existing_data: existingHomeowner
  };
  
  try {
    const result = await ownerResolutionService.resolveOwnerForPin(input);
    
    console.log(`Owner resolution completed for ${addressHash}:`, {
      success: result.confidence_score > 0,
      confidence: result.confidence_score,
      method: result.resolution_method,
      owner_name: result.owner?.name,
      contacts_found: result.contacts.length,
      processing_time: result.processing_metadata.total_processing_time_ms
    });
    
    return {
      owner: result.owner,
      parcel: result.parcel,
      phones: result.contacts
        .filter(c => c.type === 'phone')
        .map(c => c.value),
      emails: result.contacts
        .filter(c => c.type === 'email') 
        .map(c => c.value),
      sources: result.sources,
      confidence_score: result.confidence_score,
      resolution_metadata: {
        ...result.processing_metadata,
        cached: false,
        fresh: true
      }
    };
    
  } catch (error) {
    console.error('Error in owner resolution:', error);
    
    // Fallback to ensure API doesn't break
    return {
      owner: { name: address?.line1 ? `Owner lookup failed for ${address.line1}` : undefined },
      parcel: { apn: undefined, wkt: undefined },
      phones: [],
      emails: [],
      sources: ['fallback'],
      confidence_score: 0,
      resolution_metadata: {
        error: error instanceof Error ? error.message : String(error),
        timestamp: new Date().toISOString(),
        cached: false
      }
    };
  }
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const logger = Logger.create(req, 'locations-details');

  try {
    const { user, error: authError } = await authenticateRequest(req);
    if (!user) {
      logger.warn('Authentication failed');
      return new Response(
        JSON.stringify({ ok: false, error: 'Authentication required' }),
        { status: 401, headers: { ...corsHeaders, 'content-type': 'application/json' } }
      );
    }

    const body = await req.json();
    const { addressHash } = requestSchema.parse(body);

    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    const rateLimit = await checkRateLimit(supabaseAdmin, user.id, 'locations-details', 5, 1);
    if (!rateLimit.allowed) return rateLimitResponse(rateLimit, corsHeaders);

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_ANON_KEY')!,
      { global: { headers: { Authorization: req.headers.get('Authorization')! } } }
    );

    const { data: prop, error } = await supabase
      .from('properties')
      .select('*')
      .eq('address_hash', addressHash)
      .single();

    if (error || !prop) {
      logger.warn('Property not found');
      return new Response(
        JSON.stringify({ ok: false, error: 'not_found' }), 
        { status: 404, headers: { ...corsHeaders, 'content-type': 'application/json' } }
      );
    }

    if (prop.created_by !== user.id) {
      await auditLog(logger, 'UNAUTHORIZED_PROPERTY_ACCESS', user.id, { propertyId: prop.id });
      return new Response(
        JSON.stringify({ ok: false, error: 'Unauthorized' }),
        { status: 403, headers: { ...corsHeaders, 'content-type': 'application/json' } }
      );
    }

    // SOP-01: Run owner resolution with 5-method ladder and caching
    const enr = await resolveOwnerForPin(prop.address, prop.id, addressHash, prop.homeowner);

    const { data: photos } = await supabase
      .from('photos')
      .select('*')
      .eq('property_id', prop.id)
      .order('created_at', { ascending: false })
      .limit(12);

    const payload = {
      addressHash,
      owner: enr.owner,
      parcel: enr.parcel,
      lastVisits: [],
      dispositions: [],
      photos: (photos || []).map((p: any) => ({
        id: p.id,
        key: p.key,
        url: p.key,
        created_at: p.created_at
      })),
      cached: enr.resolution_metadata?.cached || false,
      cacheAgedays: enr.resolution_metadata?.cache_age_days || 0
    };

    // Update homeowner snapshot with SOP-01 results (only if fresh data)
    if (!enr.resolution_metadata?.cached) {
      await supabase
        .from('properties')
        .update({
          homeowner: {
            name: enr.owner?.name ?? null,
            type: enr.owner?.type ?? null,
            mailing_address: enr.owner?.mailing_address ?? null,
            is_out_of_state: enr.owner?.is_out_of_state ?? false,
            phones: enr.phones ?? [],
            emails: enr.emails ?? [],
            source: (enr.sources || [])[0] || 'unknown',
            confidence_score: enr.confidence_score ?? 0,
            last_resolved_at: new Date().toISOString(),
            resolution_method: enr.resolution_metadata?.methods_attempted?.[0] || 'unknown',
            parcel: enr.parcel
          }
        })
        .eq('id', prop.id);
    }

    await auditLog(logger, 'PROPERTY_DETAILS_ACCESSED', user.id, { propertyId: prop.id, cached: enr.resolution_metadata?.cached });
    logger.info('Request completed successfully');

    return new Response(
      JSON.stringify({ ok: true, data: payload }), 
      { headers: { ...corsHeaders, 'content-type': 'application/json' } }
    );
  } catch (e) {
    logger.error('Unexpected error in locations-details', e);
    return new Response(
      JSON.stringify({ ok: false, error: 'Internal server error' }), 
      { status: 500, headers: { ...corsHeaders, 'content-type': 'application/json' } }
    );
  }
});