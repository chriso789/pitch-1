// SOP-01: Structured Logging System

import { LogEntry, MethodResult } from './types.ts';

export class ResolutionLogger {
  
  /**
   * Log a resolution attempt with structured data for analysis
   */
  static log(entry: LogEntry): void {
    // Structure log entry for easy parsing and analysis
    const logData = {
      timestamp: entry.timestamp,
      level: entry.success ? 'INFO' : 'WARN',
      service: 'owner-resolution',
      method: entry.method,
      address_hash: entry.address_hash,
      success: entry.success,
      confidence_score: entry.confidence_score,
      processing_time_ms: entry.processing_time_ms,
      failure_code: entry.failure_code,
      source: entry.source,
      owner_name_length: entry.owner_name?.length || 0,
      contacts_found: entry.contacts_found,
      // Add performance categorization
      performance: this.categorizePerformance(entry.processing_time_ms),
      // Add confidence categorization
      confidence_tier: this.categorizeConfidence(entry.confidence_score)
    };
    
    console.log(JSON.stringify(logData));
  }
  
  /**
   * Log method execution details
   */
  static logMethodExecution(
    method: string,
    addressHash: string,
    result: MethodResult
  ): void {
    this.log({
      timestamp: new Date().toISOString(),
      address_hash: addressHash,
      method: method,
      success: result.success,
      confidence_score: result.confidence,
      processing_time_ms: result.processing_time_ms,
      failure_code: result.failure_code,
      source: result.source,
      owner_name: result.owner?.name,
      contacts_found: result.contacts.length
    });
  }
  
  /**
   * Log overall resolution summary
   */
  static logResolutionSummary(
    addressHash: string,
    methodsAttempted: string[],
    finalConfidence: number,
    totalTimeMs: number,
    success: boolean,
    ownerName?: string,
    contactsCount: number = 0
  ): void {
    const summaryLog = {
      timestamp: new Date().toISOString(),
      level: success ? 'INFO' : 'ERROR',
      service: 'owner-resolution',
      event: 'resolution_complete',
      address_hash: addressHash,
      methods_attempted: methodsAttempted,
      methods_count: methodsAttempted.length,
      final_confidence: finalConfidence,
      total_processing_time_ms: totalTimeMs,
      success: success,
      owner_resolved: !!ownerName,
      owner_name_length: ownerName?.length || 0,
      contacts_found: contactsCount,
      efficiency_score: this.calculateEfficiencyScore(methodsAttempted.length, totalTimeMs, finalConfidence)
    };
    
    console.log(JSON.stringify(summaryLog));
  }
  
  /**
   * Log API errors for monitoring
   */
  static logApiError(
    method: string,
    provider: string,
    error: any,
    addressHash: string,
    processingTimeMs: number = 0
  ): void {
    const errorLog = {
      timestamp: new Date().toISOString(),
      level: 'ERROR',
      service: 'owner-resolution',
      event: 'api_error',
      method: method,
      provider: provider,
      address_hash: addressHash,
      error_message: error?.message || String(error),
      error_type: error?.constructor?.name || 'Unknown',
      processing_time_ms: processingTimeMs,
      // Categorize error for alerting
      error_category: this.categorizeError(error)
    };
    
    console.log(JSON.stringify(errorLog));
  }
  
  /**
   * Performance monitoring helper
   */
  private static categorizePerformance(timeMs: number): string {
    if (timeMs < 1000) return 'fast';
    if (timeMs < 3000) return 'normal';
    if (timeMs < 8000) return 'slow';
    return 'very_slow';
  }
  
  /**
   * Confidence tier helper for analysis
   */
  private static categorizeConfidence(score: number): string {
    if (score >= 90) return 'excellent';
    if (score >= 75) return 'high';
    if (score >= 60) return 'medium';
    if (score >= 40) return 'low';
    return 'very_low';
  }
  
  /**
   * Calculate efficiency score for optimization analysis
   */
  private static calculateEfficiencyScore(
    methodsUsed: number,
    totalTimeMs: number,
    confidence: number
  ): number {
    // Score based on confidence per method and time efficiency
    const confidencePerMethod = confidence / methodsUsed;
    const timeEfficiency = Math.max(0, 100 - (totalTimeMs / 100));
    return Math.round((confidencePerMethod + timeEfficiency) / 2);
  }
  
  /**
   * Categorize errors for alerting and monitoring
   */
  private static categorizeError(error: any): string {
    const message = error?.message?.toLowerCase() || '';
    
    if (message.includes('timeout') || message.includes('timed out')) return 'timeout';
    if (message.includes('rate limit') || message.includes('429')) return 'rate_limit';
    if (message.includes('unauthorized') || message.includes('401')) return 'auth_error';
    if (message.includes('not found') || message.includes('404')) return 'not_found';
    if (message.includes('network') || message.includes('fetch')) return 'network_error';
    if (message.includes('parse') || message.includes('json')) return 'parse_error';
    
    return 'unknown';
  }
  
  /**
   * Generate performance metrics for monitoring dashboard
   */
  static generateMetrics(logs: LogEntry[]): any {
    const successRate = logs.filter(l => l.success).length / logs.length;
    const avgConfidence = logs.reduce((sum, l) => sum + l.confidence_score, 0) / logs.length;
    const avgProcessingTime = logs.reduce((sum, l) => sum + l.processing_time_ms, 0) / logs.length;
    
    const methodStats = logs.reduce((stats, log) => {
      if (!stats[log.method]) {
        stats[log.method] = { attempts: 0, successes: 0, avgConfidence: 0, avgTime: 0 };
      }
      stats[log.method].attempts++;
      if (log.success) stats[log.method].successes++;
      stats[log.method].avgConfidence += log.confidence_score;
      stats[log.method].avgTime += log.processing_time_ms;
      return stats;
    }, {} as any);
    
    // Finalize averages
    Object.keys(methodStats).forEach(method => {
      const stat = methodStats[method];
      stat.successRate = stat.successes / stat.attempts;
      stat.avgConfidence = stat.avgConfidence / stat.attempts;
      stat.avgTime = stat.avgTime / stat.attempts;
    });
    
    return {
      overall: {
        success_rate: successRate,
        avg_confidence: avgConfidence,
        avg_processing_time_ms: avgProcessingTime,
        total_attempts: logs.length
      },
      by_method: methodStats
    };
  }
}