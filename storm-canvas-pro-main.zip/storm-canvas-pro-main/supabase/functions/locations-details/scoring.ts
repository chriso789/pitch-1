// SOP-01: Confidence Scoring System

import { MethodResult, Contact } from './types.ts';

export class ConfidenceScorer {
  
  /**
   * Calculate overall confidence score from method results
   * Uses weighted average based on method reliability and data quality
   */
  static calculateOverallScore(results: MethodResult[]): number {
    if (results.length === 0) return 0;
    
    const successfulResults = results.filter(r => r.success && r.confidence > 0);
    if (successfulResults.length === 0) return 0;
    
    // Weight methods by their inherent reliability
    const methodWeights = {
      'direct_parcel': 1.0,
      'address_standard': 0.9,
      'skip_trace': 0.8,
      'reverse_lookup': 0.7,
      'public_records': 0.6
    };
    
    let totalWeighted = 0;
    let totalWeights = 0;
    
    for (const result of successfulResults) {
      const weight = methodWeights[result.source as keyof typeof methodWeights] || 0.5;
      totalWeighted += result.confidence * weight;
      totalWeights += weight;
    }
    
    return Math.round(totalWeighted / totalWeights);
  }
  
  /**
   * Score individual method result based on data quality factors
   */
  static scoreMethodResult(
    ownerName?: string,
    contacts: Contact[] = [],
    parcelData?: any,
    processingTime: number = 0,
    baseConfidence: number = 50
  ): number {
    let score = baseConfidence;
    
    // Owner name quality
    if (ownerName) {
      score += this.scoreOwnerName(ownerName);
    } else {
      score -= 30; // Major penalty for no owner name
    }
    
    // Contact information bonus
    score += this.scoreContacts(contacts);
    
    // Parcel data bonus
    if (parcelData?.apn) score += 10;
    if (parcelData?.assessed_value) score += 5;
    if (parcelData?.last_sale_date) score += 5;
    
    // Performance penalty for slow responses
    if (processingTime > 5000) score -= 10;
    if (processingTime > 10000) score -= 20;
    
    // Ensure score is within bounds
    return Math.max(0, Math.min(100, score));
  }
  
  /**
   * Score owner name quality
   */
  private static scoreOwnerName(name: string): number {
    let score = 0;
    
    // Basic validation
    if (!name || name.length < 2) return -20;
    
    // Quality indicators
    if (name.includes(',')) score += 10; // "Last, First" format
    if (name.match(/[A-Z][a-z]+ [A-Z][a-z]+/)) score += 15; // Proper case
    if (name.includes('LLC') || name.includes('Inc')) score += 5; // Business entity
    if (name.includes('Trust')) score += 5; // Trust entity
    
    // Quality detractors
    if (name.includes('UNKNOWN')) score -= 25;
    if (name.includes('VACANT')) score -= 25;
    if (name.includes('&') && name.split('&').length > 2) score -= 5; // Too many entities
    if (name.length > 100) score -= 10; // Suspiciously long
    if (name.toUpperCase() === name && name.length > 10) score -= 5; // All caps
    
    // PO Box addresses are lower confidence for owner residence
    if (name.includes('PO BOX') || name.includes('P.O. BOX')) score -= 15;
    
    return score;
  }
  
  /**
   * Score contact information quality
   */
  private static scoreContacts(contacts: Contact[]): number {
    let score = 0;
    
    const phones = contacts.filter(c => c.type === 'phone');
    const emails = contacts.filter(c => c.type === 'email');
    
    // Phone number scoring
    if (phones.length > 0) {
      score += Math.min(phones.length * 8, 20); // Up to 20 points for phones
      
      // Bonus for verified phones
      const verifiedPhones = phones.filter(p => p.verified);
      score += verifiedPhones.length * 5;
    }
    
    // Email scoring
    if (emails.length > 0) {
      score += Math.min(emails.length * 6, 15); // Up to 15 points for emails
      
      // Quality email domains
      const qualityDomains = emails.filter(e => 
        e.value.includes('@gmail.com') || 
        e.value.includes('@yahoo.com') || 
        e.value.includes('@outlook.com') ||
        !e.value.includes('@')
      );
      score += qualityDomains.length * 3;
    }
    
    return score;
  }
  
  /**
   * Determine if confidence meets minimum threshold for different use cases
   */
  static meetsThreshold(confidence: number, useCase: 'display' | 'contact' | 'marketing'): boolean {
    const thresholds = {
      display: 30,    // Show in UI
      contact: 60,    // Safe to contact
      marketing: 80   // High confidence for automated marketing
    };
    
    return confidence >= thresholds[useCase];
  }
}