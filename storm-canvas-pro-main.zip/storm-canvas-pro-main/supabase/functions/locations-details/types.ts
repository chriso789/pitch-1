// SOP-01: Pin → Owner Resolution - Type Definitions

export interface OwnerResolutionResult {
  owner?: {
    name?: string;
    type?: 'individual' | 'business' | 'trust' | 'llc' | 'unknown';
    mailing_address?: string;
    is_out_of_state?: boolean;
  };
  parcel?: {
    apn?: string;
    wkt?: string;
    county?: string;
    last_sale_date?: string;
    assessed_value?: number;
  };
  contacts: Contact[];
  confidence_score: number;
  resolution_method: string;
  sources: string[];
  failure_codes: string[];
  processing_metadata: {
    methods_attempted: string[];
    total_processing_time_ms: number;
    timestamp: string;
  };
}

export interface Contact {
  type: 'phone' | 'email';
  value: string;
  confidence: number;
  source: string;
  verified?: boolean;
}

export interface ResolutionMethod {
  name: string;
  priority: number;
  execute: (input: ResolutionInput) => Promise<MethodResult>;
}

export interface ResolutionInput {
  address: any;
  property_id: string;
  address_hash: string;
  existing_data?: any;
}

export interface MethodResult {
  success: boolean;
  confidence: number;
  owner?: any;
  parcel?: any;
  contacts: Contact[];
  source: string;
  failure_code?: string;
  processing_time_ms: number;
}

export enum FailureCode {
  ADDRESS_NOT_FOUND = 'ADDRESS_NOT_FOUND',
  API_ERROR = 'API_ERROR',
  RATE_LIMITED = 'RATE_LIMITED',
  INVALID_RESPONSE = 'INVALID_RESPONSE',
  TIMEOUT = 'TIMEOUT',
  NO_OWNER_DATA = 'NO_OWNER_DATA',
  INSUFFICIENT_CONFIDENCE = 'INSUFFICIENT_CONFIDENCE',
  GEOCODING_FAILED = 'GEOCODING_FAILED',
  PARCEL_LOOKUP_FAILED = 'PARCEL_LOOKUP_FAILED',
  PROVIDER_UNAVAILABLE = 'PROVIDER_UNAVAILABLE'
}

export interface LogEntry {
  timestamp: string;
  address_hash: string;
  method: string;
  success: boolean;
  confidence_score: number;
  processing_time_ms: number;
  failure_code?: string;
  source: string;
  owner_name?: string;
  contacts_found: number;
}