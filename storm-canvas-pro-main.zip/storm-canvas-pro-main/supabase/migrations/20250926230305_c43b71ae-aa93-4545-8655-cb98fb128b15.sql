-- Check ALL tables in public schema to see what might be missing RLS
SELECT 
    t.table_name,
    t.table_type,
    CASE 
        WHEN pt.rowsecurity IS NULL THEN 'Not a regular table'
        WHEN pt.rowsecurity = true THEN 'RLS ENABLED' 
        ELSE 'RLS DISABLED'
    END as rls_status
FROM information_schema.tables t
LEFT JOIN pg_tables pt ON t.table_name = pt.tablename AND t.table_schema = pt.schemaname
WHERE t.table_schema = 'public'
AND t.table_type = 'BASE TABLE'
ORDER BY t.table_name;

-- Also check if there are any views that might be interfering
SELECT table_name, table_type 
FROM information_schema.tables 
WHERE table_schema = 'public' 
AND table_type = 'VIEW';