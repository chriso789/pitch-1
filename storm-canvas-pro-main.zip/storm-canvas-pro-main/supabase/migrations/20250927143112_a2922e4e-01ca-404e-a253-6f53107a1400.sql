-- Skip-trace system database schema
-- Create leads table for skip-trace pins
CREATE TABLE IF NOT EXISTS leads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  address TEXT NOT NULL,
  city TEXT,
  state TEXT,
  zip TEXT,
  lat DOUBLE PRECISION NOT NULL,
  lng DOUBLE PRECISION NOT NULL,
  status_type_id INTEGER,
  status_title TEXT,
  status_front_color TEXT DEFAULT '#ffffff',
  status_back_color TEXT DEFAULT '#cc0000',
  source TEXT DEFAULT 'manual',
  property_id UUID REFERENCES properties(id) ON DELETE CASCADE,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create contacts table for skip-trace results
CREATE TABLE IF NOT EXISTS contacts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID REFERENCES leads(id) ON DELETE CASCADE,
  property_id UUID REFERENCES properties(id) ON DELETE CASCADE,
  name TEXT,
  phone TEXT,
  email TEXT,
  provider TEXT,
  confidence NUMERIC CHECK (confidence >= 0 AND confidence <= 1),
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create skip_trace_jobs table for tracking enrichment jobs
CREATE TABLE IF NOT EXISTS skip_trace_jobs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lead_id UUID REFERENCES leads(id) ON DELETE CASCADE,
  property_id UUID REFERENCES properties(id) ON DELETE CASCADE,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'running', 'completed', 'failed')),
  provider TEXT,
  input_data JSONB,
  result_data JSONB,
  error_message TEXT,
  started_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  completed_at TIMESTAMP WITH TIME ZONE,
  created_by UUID REFERENCES auth.users(id)
);

-- Create spatial index for leads
CREATE INDEX IF NOT EXISTS idx_leads_location ON leads USING GIST (
  ST_SetSRID(ST_MakePoint(lng, lat), 4326)
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_leads_status ON leads (status_type_id);
CREATE INDEX IF NOT EXISTS idx_leads_created_by ON leads (created_by);
CREATE INDEX IF NOT EXISTS idx_contacts_lead ON contacts (lead_id);
CREATE INDEX IF NOT EXISTS idx_contacts_property ON contacts (property_id);
CREATE INDEX IF NOT EXISTS idx_skip_trace_jobs_status ON skip_trace_jobs (status);

-- Enable Row Level Security
ALTER TABLE leads ENABLE ROW LEVEL SECURITY;
ALTER TABLE contacts ENABLE ROW LEVEL SECURITY;
ALTER TABLE skip_trace_jobs ENABLE ROW LEVEL SECURITY;

-- RLS Policies for leads
CREATE POLICY "Users can view their own leads" ON leads
  FOR SELECT USING (created_by = auth.uid());

CREATE POLICY "Users can create their own leads" ON leads
  FOR INSERT WITH CHECK (auth.uid() = created_by);

CREATE POLICY "Users can update their own leads" ON leads
  FOR UPDATE USING (created_by = auth.uid());

CREATE POLICY "Users can delete their own leads" ON leads
  FOR DELETE USING (created_by = auth.uid());

-- RLS Policies for contacts
CREATE POLICY "Users can view contacts for their leads" ON contacts
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM leads l 
      WHERE l.id = contacts.lead_id 
      AND l.created_by = auth.uid()
    )
    OR
    EXISTS (
      SELECT 1 FROM properties p 
      WHERE p.id = contacts.property_id 
      AND p.created_by = auth.uid()
    )
  );

CREATE POLICY "Users can create contacts for their leads" ON contacts
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM leads l 
      WHERE l.id = contacts.lead_id 
      AND l.created_by = auth.uid()
    )
    OR
    EXISTS (
      SELECT 1 FROM properties p 
      WHERE p.id = contacts.property_id 
      AND p.created_by = auth.uid()
    )
  );

-- RLS Policies for skip_trace_jobs
CREATE POLICY "Users can view their own skip trace jobs" ON skip_trace_jobs
  FOR SELECT USING (created_by = auth.uid());

CREATE POLICY "Users can create their own skip trace jobs" ON skip_trace_jobs
  FOR INSERT WITH CHECK (auth.uid() = created_by);

CREATE POLICY "Users can update their own skip trace jobs" ON skip_trace_jobs
  FOR UPDATE USING (created_by = auth.uid());

-- Create function to get leads in bbox (for GeoJSON API)
CREATE OR REPLACE FUNCTION get_leads_in_bbox(
  min_lng DOUBLE PRECISION,
  min_lat DOUBLE PRECISION,
  max_lng DOUBLE PRECISION,
  max_lat DOUBLE PRECISION,
  status_ids INTEGER[] DEFAULT NULL
)
RETURNS TABLE (
  id UUID,
  address TEXT,
  city TEXT,
  state TEXT,
  zip TEXT,
  lat DOUBLE PRECISION,
  lng DOUBLE PRECISION,
  status_type_id INTEGER,
  status_title TEXT,
  status_front_color TEXT,
  status_back_color TEXT,
  source TEXT,
  created_at TIMESTAMP WITH TIME ZONE
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT 
    l.id,
    l.address,
    l.city,
    l.state,
    l.zip,
    l.lat,
    l.lng,
    l.status_type_id,
    l.status_title,
    l.status_front_color,
    l.status_back_color,
    l.source,
    l.created_at
  FROM leads l
  WHERE l.created_by = auth.uid()
    AND l.lng >= min_lng 
    AND l.lng <= max_lng
    AND l.lat >= min_lat 
    AND l.lat <= max_lat
    AND (status_ids IS NULL OR l.status_type_id = ANY(status_ids))
  ORDER BY l.created_at DESC;
$$;

-- Create trigger for updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_leads_updated_at 
  BEFORE UPDATE ON leads 
  FOR EACH ROW 
  EXECUTE FUNCTION update_updated_at_column();