-- Add foreign key from visits.property_id to properties.id
ALTER TABLE visits
ADD CONSTRAINT fk_visits_property
FOREIGN KEY (property_id) 
REFERENCES properties(id)
ON DELETE CASCADE;

-- Add foreign key from visits.disposition_id to dispositions.id
ALTER TABLE visits
ADD CONSTRAINT fk_visits_disposition
FOREIGN KEY (disposition_id) 
REFERENCES dispositions(id)
ON DELETE SET NULL;