-- Add "Not Contacted" disposition for Spotio-like canvassing structure
INSERT INTO public.dispositions (name, color, description) 
VALUES ('Not Contacted', '#9ca3af', 'Property not yet contacted - default status');