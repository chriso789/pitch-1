-- Create designs table for measurements and area calculations
CREATE TABLE public.designs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id UUID NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  type TEXT NOT NULL DEFAULT 'FAST_ESTIMATES',
  name TEXT,
  geometry JSONB NOT NULL, -- Store GeoJSON polygon
  area_sqft NUMERIC,
  pitch_estimate NUMERIC,
  material_type TEXT,
  estimated_cost NUMERIC,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create photos table for property images
CREATE TABLE public.photos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id UUID REFERENCES public.properties(id) ON DELETE CASCADE,
  design_id UUID REFERENCES public.designs(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  filename TEXT NOT NULL,
  original_filename TEXT,
  file_size INTEGER,
  mime_type TEXT,
  storage_path TEXT NOT NULL,
  caption TEXT,
  latitude NUMERIC,
  longitude NUMERIC,
  exif_data JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Create proposals table for PDF generation
CREATE TABLE public.proposals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id UUID NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
  design_id UUID REFERENCES public.designs(id) ON DELETE SET NULL,
  user_id UUID NOT NULL,
  proposal_type TEXT NOT NULL DEFAULT 'hail',
  customer_name TEXT,
  date_created DATE NOT NULL DEFAULT CURRENT_DATE,
  total_amount NUMERIC,
  status TEXT DEFAULT 'draft',
  pdf_url TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Enable RLS on all tables
ALTER TABLE public.designs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.photos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.proposals ENABLE ROW LEVEL SECURITY;

-- RLS policies for designs
CREATE POLICY "Users can view their own designs" ON public.designs
FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own designs" ON public.designs
FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own designs" ON public.designs
FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own designs" ON public.designs
FOR DELETE USING (auth.uid() = user_id);

-- RLS policies for photos
CREATE POLICY "Users can view their own photos" ON public.photos
FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own photos" ON public.photos
FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own photos" ON public.photos
FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own photos" ON public.photos
FOR DELETE USING (auth.uid() = user_id);

-- RLS policies for proposals
CREATE POLICY "Users can view their own proposals" ON public.proposals
FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own proposals" ON public.proposals
FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own proposals" ON public.proposals
FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own proposals" ON public.proposals
FOR DELETE USING (auth.uid() = user_id);

-- Indexes for performance
CREATE INDEX idx_designs_property_id ON public.designs(property_id);
CREATE INDEX idx_designs_user_id ON public.designs(user_id);
CREATE INDEX idx_photos_property_id ON public.photos(property_id);
CREATE INDEX idx_photos_user_id ON public.photos(user_id);
CREATE INDEX idx_proposals_property_id ON public.proposals(property_id);
CREATE INDEX idx_proposals_user_id ON public.proposals(user_id);

-- Triggers for updated_at
CREATE TRIGGER update_designs_updated_at
BEFORE UPDATE ON public.designs
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_proposals_updated_at
BEFORE UPDATE ON public.proposals
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();