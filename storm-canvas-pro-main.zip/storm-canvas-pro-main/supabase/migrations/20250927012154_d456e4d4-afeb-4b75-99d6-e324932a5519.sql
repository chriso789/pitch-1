-- Fix function search path issues for security compliance
-- Update add_to_outbox function
CREATE OR REPLACE FUNCTION public.add_to_outbox(
  p_event_type TEXT,
  p_payload JSONB
) RETURNS UUID 
LANGUAGE plpgsql 
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  outbox_id UUID;
BEGIN
  INSERT INTO public.outbox (event_type, payload)
  VALUES (p_event_type, p_payload)
  RETURNING id INTO outbox_id;
  
  RETURN outbox_id;
END;
$$;

-- Update handle_property_created function
CREATE OR REPLACE FUNCTION public.handle_property_created()
RETURNS TRIGGER 
LANGUAGE plpgsql 
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Add to outbox for downstream processing
  PERFORM public.add_to_outbox(
    'property.pin_drop.created',
    jsonb_build_object(
      'property_id', NEW.id,
      'address', NEW.address,
      'created_by', NEW.created_by,
      'created_at', NEW.created_at
    )
  );
  
  RETURN NEW;
END;
$$;

-- Update handle_disposition_visit function
CREATE OR REPLACE FUNCTION public.handle_disposition_visit()
RETURNS TRIGGER 
LANGUAGE plpgsql 
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Add to outbox for downstream processing
  PERFORM public.add_to_outbox(
    'disposition.created',
    jsonb_build_object(
      'visit_id', NEW.id,
      'property_id', NEW.property_id,
      'disposition_id', NEW.disposition_id,
      'user_id', NEW.user_id,
      'notes', NEW.notes,
      'created_at', NEW.created_at
    )
  );
  
  RETURN NEW;
END;
$$;