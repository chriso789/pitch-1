-- Integration endpoints table for storing CRM and other integration configurations
CREATE TABLE public.integration_endpoints (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  type TEXT NOT NULL, -- 'pitch_crm', 'slack', 'email', etc.
  base_url TEXT NOT NULL,
  secret_key TEXT, -- encrypted secret reference
  is_enabled BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Rep integrations table for mapping users to external CRM representatives
CREATE TABLE public.rep_integrations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  pitch_rep_id TEXT, -- external CRM rep ID
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, pitch_rep_id)
);

-- Event outbox for reliable webhook delivery with retry logic
CREATE TABLE public.outbox (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  event_type TEXT NOT NULL, -- 'property.pin_drop.created', 'disposition.created', etc.
  payload JSONB NOT NULL,
  retries INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'queued', -- 'queued', 'sent', 'failed', 'dead_letter'
  last_error TEXT,
  scheduled_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  processed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on new tables
ALTER TABLE public.integration_endpoints ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rep_integrations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.outbox ENABLE ROW LEVEL SECURITY;

-- RLS policies for integration_endpoints (admin only)
CREATE POLICY "Only admins can manage integration endpoints" 
ON public.integration_endpoints 
FOR ALL 
USING (check_user_role(auth.uid(), 'admin'));

-- RLS policies for rep_integrations (users can view their own, admins can manage all)
CREATE POLICY "Users can view their own rep integrations" 
ON public.rep_integrations 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own rep integrations" 
ON public.rep_integrations 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage all rep integrations" 
ON public.rep_integrations 
FOR ALL 
USING (check_user_role(auth.uid(), 'admin'));

-- RLS policies for outbox (service role only for processing)
CREATE POLICY "Service role can manage outbox" 
ON public.outbox 
FOR ALL 
USING (auth.role() = 'service_role');

-- Indexes for performance
CREATE INDEX idx_outbox_status_scheduled ON public.outbox(status, scheduled_at) WHERE status = 'queued';
CREATE INDEX idx_outbox_event_type ON public.outbox(event_type);
CREATE INDEX idx_rep_integrations_user_id ON public.rep_integrations(user_id);
CREATE INDEX idx_integration_endpoints_type_enabled ON public.integration_endpoints(type, is_enabled);

-- Add updated_at triggers
CREATE TRIGGER update_integration_endpoints_updated_at
  BEFORE UPDATE ON public.integration_endpoints
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_rep_integrations_updated_at
  BEFORE UPDATE ON public.rep_integrations
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_outbox_updated_at
  BEFORE UPDATE ON public.outbox
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Function to add events to outbox
CREATE OR REPLACE FUNCTION public.add_to_outbox(
  p_event_type TEXT,
  p_payload JSONB
) RETURNS UUID AS $$
DECLARE
  outbox_id UUID;
BEGIN
  INSERT INTO public.outbox (event_type, payload)
  VALUES (p_event_type, p_payload)
  RETURNING id INTO outbox_id;
  
  RETURN outbox_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger function for property pin drop events
CREATE OR REPLACE FUNCTION public.handle_property_created()
RETURNS TRIGGER AS $$
BEGIN
  -- Add to outbox for downstream processing
  PERFORM public.add_to_outbox(
    'property.pin_drop.created',
    jsonb_build_object(
      'property_id', NEW.id,
      'address', NEW.address,
      'created_by', NEW.created_by,
      'created_at', NEW.created_at
    )
  );
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger function for disposition events
CREATE OR REPLACE FUNCTION public.handle_disposition_visit()
RETURNS TRIGGER AS $$
BEGIN
  -- Add to outbox for downstream processing
  PERFORM public.add_to_outbox(
    'disposition.created',
    jsonb_build_object(
      'visit_id', NEW.id,
      'property_id', NEW.property_id,
      'disposition_id', NEW.disposition_id,
      'user_id', NEW.user_id,
      'notes', NEW.notes,
      'created_at', NEW.created_at
    )
  );
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create triggers
CREATE TRIGGER property_created_trigger
  AFTER INSERT ON public.properties
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_property_created();

CREATE TRIGGER visit_created_trigger
  AFTER INSERT ON public.visits
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_disposition_visit();