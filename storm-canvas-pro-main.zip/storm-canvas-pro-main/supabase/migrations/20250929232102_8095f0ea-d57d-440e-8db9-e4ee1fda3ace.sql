-- Drop existing function if it exists
DROP FUNCTION IF EXISTS public.get_nearest_locations(double precision, double precision, double precision);

-- Create enhanced get_nearest_locations function that returns full property data with dispositions
CREATE OR REPLACE FUNCTION public.get_nearest_locations(
  center_lat double precision,
  center_lng double precision,
  radius_km double precision DEFAULT 3.22
)
RETURNS TABLE (
  id uuid,
  address_hash text,
  address jsonb,
  homeowner jsonb,
  consumer_id text,
  flags jsonb,
  lat double precision,
  lng double precision,
  created_at timestamp with time zone,
  disposition_id uuid,
  disposition text,
  disposition_color text
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id,
    p.address_hash,
    p.address,
    p.homeowner,
    p.consumer_id,
    p.flags,
    ST_Y(p.geom::geometry) as lat,
    ST_X(p.geom::geometry) as lng,
    p.created_at,
    v.disposition_id,
    d.name as disposition,
    d.color as disposition_color
  FROM properties p
  LEFT JOIN LATERAL (
    SELECT v.disposition_id, v.visit_date
    FROM visits v
    WHERE v.property_id = p.id
    ORDER BY v.visit_date DESC
    LIMIT 1
  ) v ON true
  LEFT JOIN dispositions d ON d.id = v.disposition_id
  WHERE ST_DWithin(
    p.geom::geography,
    ST_SetSRID(ST_MakePoint(center_lng, center_lat), 4326)::geography,
    radius_km * 1000
  )
  ORDER BY ST_Distance(
    p.geom::geography,
    ST_SetSRID(ST_MakePoint(center_lng, center_lat), 4326)::geography
  );
END;
$$;