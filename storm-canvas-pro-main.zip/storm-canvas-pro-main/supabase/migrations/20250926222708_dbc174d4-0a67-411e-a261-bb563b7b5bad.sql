-- Check which tables don't have RLS enabled
SELECT schemaname, tablename, rowsecurity 
FROM pg_tables 
WHERE schemaname = 'public' 
AND rowsecurity = false;

-- Check for any system tables that might need special handling  
SELECT table_name, table_schema
FROM information_schema.tables 
WHERE table_schema = 'public' 
AND table_name NOT IN ('properties', 'designs', 'photos', 'proposals')
AND table_type = 'BASE TABLE';

-- Enable RLS on any remaining tables (except PostGIS system tables)
DO $$
DECLARE
    rec RECORD;
BEGIN
    FOR rec IN 
        SELECT tablename 
        FROM pg_tables 
        WHERE schemaname = 'public' 
        AND rowsecurity = false
        AND tablename NOT LIKE 'spatial_%'  -- Exclude PostGIS system tables
        AND tablename NOT IN ('geography_columns', 'geometry_columns', 'raster_columns', 'raster_overviews')
    LOOP
        EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', rec.tablename);
        RAISE NOTICE 'Enabled RLS on table: %', rec.tablename;
    END LOOP;
END
$$;