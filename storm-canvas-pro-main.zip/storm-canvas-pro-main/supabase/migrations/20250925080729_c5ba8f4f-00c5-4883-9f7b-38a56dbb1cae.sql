-- Fix security warning: Set search_path for function
CREATE OR REPLACE FUNCTION public.generate_address_hash(addr TEXT, postal TEXT DEFAULT '')
RETURNS TEXT AS $$
BEGIN
  RETURN encode(sha256((COALESCE(addr, '') || COALESCE(postal, ''))::bytea), 'hex');
END;
$$ LANGUAGE plpgsql IMMUTABLE SET search_path = public;