-- Enable real-time for properties table
ALTER TABLE public.properties REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.properties;

-- Enable real-time for dispositions table  
ALTER TABLE public.dispositions REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.dispositions;

-- Enable real-time for visits table
ALTER TABLE public.visits REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.visits;

-- Enable real-time for photos table
ALTER TABLE public.photos REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.photos;

-- Enable real-time for proposals table
ALTER TABLE public.proposals REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.proposals;

-- Enable real-time for designs table
ALTER TABLE public.designs REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.designs;