-- Add place_id column to properties for Google Maps reference
ALTER TABLE properties ADD COLUMN IF NOT EXISTS place_id text;

-- Create index on place_id for faster lookups
CREATE INDEX IF NOT EXISTS idx_properties_place_id ON properties(place_id);

-- Create function to get properties within a bounding box
CREATE OR REPLACE FUNCTION public.get_properties_in_bbox(
  min_lng double precision,
  min_lat double precision,
  max_lng double precision,
  max_lat double precision
)
RETURNS TABLE(
  id uuid,
  address_hash text,
  address jsonb,
  homeowner jsonb,
  consumer_id text,
  flags jsonb,
  lat double precision,
  lng double precision,
  created_at timestamp with time zone,
  disposition_id uuid,
  disposition text,
  disposition_color text,
  place_id text
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id,
    p.address_hash,
    p.address,
    p.homeowner,
    p.consumer_id,
    p.flags,
    ST_Y(p.geom::geometry) as lat,
    ST_X(p.geom::geometry) as lng,
    p.created_at,
    v.disposition_id,
    d.name as disposition,
    d.color as disposition_color,
    p.place_id
  FROM properties p
  LEFT JOIN LATERAL (
    SELECT v.disposition_id, v.visit_date
    FROM visits v
    WHERE v.property_id = p.id
    ORDER BY v.visit_date DESC
    LIMIT 1
  ) v ON true
  LEFT JOIN dispositions d ON d.id = v.disposition_id
  WHERE ST_X(p.geom::geometry) >= min_lng 
    AND ST_X(p.geom::geometry) <= max_lng
    AND ST_Y(p.geom::geometry) >= min_lat 
    AND ST_Y(p.geom::geometry) <= max_lat
  ORDER BY p.created_at DESC;
END;
$$;