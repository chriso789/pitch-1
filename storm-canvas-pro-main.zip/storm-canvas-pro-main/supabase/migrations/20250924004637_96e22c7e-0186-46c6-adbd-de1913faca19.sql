-- Create dispositions lookup table
CREATE TABLE public.dispositions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  color TEXT NOT NULL DEFAULT '#3b82f6',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create properties table
CREATE TABLE public.properties (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  address TEXT NOT NULL,
  latitude DECIMAL(10, 8) NOT NULL,
  longitude DECIMAL(11, 8) NOT NULL,
  place_id TEXT,
  address_hash TEXT GENERATED ALWAYS AS (md5(lower(trim(address)))) STORED,
  
  -- Homeowner information
  homeowner_name TEXT,
  phone TEXT,
  email TEXT,
  credit_score INTEGER,
  age INTEGER,
  gender TEXT,
  
  -- Property details
  property_value INTEGER,
  year_built INTEGER,
  square_footage INTEGER,
  
  -- Disposition tracking
  disposition_id UUID REFERENCES public.dispositions(id),
  disposition_notes TEXT,
  
  -- Enrichment tracking
  enriched_at TIMESTAMP WITH TIME ZONE,
  enrichment_source TEXT,
  last_enrichment_attempt TIMESTAMP WITH TIME ZONE,
  
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create visits table for tracking property visits
CREATE TABLE public.visits (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  property_id UUID NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
  disposition_id UUID REFERENCES public.dispositions(id),
  notes TEXT,
  visit_date TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  duration_minutes INTEGER,
  follow_up_required BOOLEAN DEFAULT false,
  follow_up_date TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create indexes for performance
CREATE INDEX idx_properties_user_id ON public.properties(user_id);
CREATE INDEX idx_properties_disposition_id ON public.properties(disposition_id);
CREATE INDEX idx_properties_address_hash ON public.properties(address_hash);
CREATE INDEX idx_properties_location ON public.properties(latitude, longitude);
CREATE INDEX idx_visits_user_id ON public.visits(user_id);
CREATE INDEX idx_visits_property_id ON public.visits(property_id);
CREATE INDEX idx_visits_date ON public.visits(visit_date);

-- Enable Row Level Security
ALTER TABLE public.dispositions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.properties ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.visits ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for dispositions (shared lookup table)
CREATE POLICY "Dispositions are viewable by everyone" 
ON public.dispositions 
FOR SELECT 
USING (true);

CREATE POLICY "Only admins can manage dispositions" 
ON public.dispositions 
FOR ALL 
USING (auth.jwt() ->> 'role' = 'admin');

-- Create RLS policies for properties
CREATE POLICY "Users can view their own properties" 
ON public.properties 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own properties" 
ON public.properties 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own properties" 
ON public.properties 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own properties" 
ON public.properties 
FOR DELETE 
USING (auth.uid() = user_id);

-- Create RLS policies for visits
CREATE POLICY "Users can view their own visits" 
ON public.visits 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own visits" 
ON public.visits 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own visits" 
ON public.visits 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own visits" 
ON public.visits 
FOR DELETE 
USING (auth.uid() = user_id);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create triggers for automatic timestamp updates
CREATE TRIGGER update_dispositions_updated_at
  BEFORE UPDATE ON public.dispositions
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_properties_updated_at
  BEFORE UPDATE ON public.properties
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_visits_updated_at
  BEFORE UPDATE ON public.visits
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default dispositions
INSERT INTO public.dispositions (name, description, color) VALUES
  ('Not Home', 'Nobody answered the door', '#6b7280'),
  ('Interested', 'Homeowner expressed interest', '#10b981'),
  ('Not Interested', 'Homeowner not interested', '#ef4444'),
  ('Callback', 'Requested a callback later', '#f59e0b'),
  ('Appointment Set', 'Appointment scheduled', '#8b5cf6'),
  ('Proposal Sent', 'Proposal has been sent', '#06b6d4'),
  ('Won', 'Deal closed successfully', '#059669'),
  ('Lost', 'Deal lost to competitor or declined', '#dc2626'),
  ('Do Not Contact', 'Requested no further contact', '#374151');