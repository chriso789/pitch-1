-- Add performance indexes for PITCH CRM integration
CREATE INDEX IF NOT EXISTS idx_properties_address_hash 
ON public.properties(address_hash);

CREATE INDEX IF NOT EXISTS idx_visits_property_created 
ON public.visits(property_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_outbox_status_scheduled 
ON public.outbox(status, scheduled_at) 
WHERE status IN ('queued', 'processing');

-- Insert PITCH CRM integration endpoint configuration
INSERT INTO public.integration_endpoints (
  name,
  type,
  base_url,
  is_enabled
) VALUES (
  'PITCH CRM',
  'crm',
  'https://api.pitch.com/v1',
  true
) ON CONFLICT DO NOTHING;