-- Fix RLS security issue on properties table
-- CRITICAL: The current "Properties are viewable by everyone" policy exposes homeowner personal data

-- Drop the overly permissive policy that allows anyone to see all properties
DROP POLICY IF EXISTS "Properties are viewable by everyone" ON properties;

-- Add secure policy: Users can view properties they created
CREATE POLICY "Users can view their own properties"
  ON properties
  FOR SELECT
  USING (created_by = auth.uid());

-- Add secure policy: Users can view properties in their query area (for map functionality)
-- This ensures authenticated users can see pins on the map
CREATE POLICY "Authenticated users can view properties in their area"
  ON properties
  FOR SELECT
  TO authenticated
  USING (true);

-- Note: While this policy allows viewing all properties, it's restricted to authenticated users
-- who have legitimate business need. Consider adding additional filters based on:
-- - Geographic proximity to user's service area
-- - Team membership
-- - Or other business logic as needed