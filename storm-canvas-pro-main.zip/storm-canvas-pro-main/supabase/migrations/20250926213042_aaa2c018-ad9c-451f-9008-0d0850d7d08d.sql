-- Fix function search path security issues
CREATE OR REPLACE FUNCTION get_nearest_locations(
  lat double precision, 
  lng double precision, 
  radius_km double precision DEFAULT 2.0
)
RETURNS TABLE(
  address_hash text, 
  lat double precision, 
  lng double precision, 
  flags jsonb, 
  consumer_id text
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT 
    p.address_hash,
    ST_Y(ST_Transform(p.geom::geometry,4326)) as lat,
    ST_X(ST_Transform(p.geom::geometry,4326)) as lng,
    p.flags, 
    p.consumer_id
  FROM properties p
  WHERE ST_DWithin(
    p.geom::geography,
    ST_SetSRID(ST_Point(lng, lat),4326)::geography,
    radius_km * 1000
  )
  ORDER BY ST_Distance(
    p.geom::geography,
    ST_SetSRID(ST_Point(lng, lat),4326)::geography
  )
  LIMIT 5000;
$$;

-- Fix helper function search path
CREATE OR REPLACE FUNCTION generate_address_hash(addr jsonb)
RETURNS text
LANGUAGE plpgsql
IMMUTABLE
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN encode(sha256((addr::text)::bytea), 'hex');
END;
$$;

-- Ensure all tables have proper RLS (should already be enabled but double-check)
ALTER TABLE properties ENABLE ROW LEVEL SECURITY;
ALTER TABLE designs ENABLE ROW LEVEL SECURITY;
ALTER TABLE photos ENABLE ROW LEVEL SECURITY;
ALTER TABLE proposals ENABLE ROW LEVEL SECURITY;

-- Check for any other tables that might need RLS
DO $$
DECLARE
    rec RECORD;
BEGIN
    -- Enable RLS for all tables in public schema that don't have it
    FOR rec IN 
        SELECT tablename 
        FROM pg_tables 
        WHERE schemaname = 'public' 
        AND tablename NOT IN ('spatial_ref_sys') -- Exclude PostGIS system table
    LOOP
        EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', rec.tablename);
    END LOOP;
END
$$;