-- Fix property pin visibility on map
-- This migration addresses RLS policy issues and data integrity problems

-- 1. Create sanitized map view (excludes PII homeowner data)
CREATE OR REPLACE VIEW properties_map_view AS
SELECT 
  p.id,
  p.address_hash,
  p.address,
  NULL::jsonb as homeowner,  -- Exclude PII from map view
  p.consumer_id,
  p.flags,
  p.geom,
  p.created_by,
  p.created_at,
  p.place_id,
  p.boundary_wkt
FROM properties p;

-- 2. Update get_properties_in_bbox to use SECURITY INVOKER and sanitized view
CREATE OR REPLACE FUNCTION public.get_properties_in_bbox(
  min_lng double precision, 
  min_lat double precision, 
  max_lng double precision, 
  max_lat double precision
)
RETURNS TABLE(
  id uuid, 
  address_hash text, 
  address jsonb, 
  homeowner jsonb, 
  consumer_id text, 
  flags jsonb, 
  lat double precision, 
  lng double precision, 
  created_at timestamp with time zone, 
  disposition_id uuid, 
  disposition text, 
  disposition_color text, 
  place_id text
)
LANGUAGE plpgsql
SECURITY INVOKER  -- Respects RLS instead of bypassing it
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id,
    p.address_hash,
    p.address,
    p.homeowner,  -- NULL from view, protecting PII
    p.consumer_id,
    p.flags,
    ST_Y(p.geom::geometry) as lat,
    ST_X(p.geom::geometry) as lng,
    p.created_at,
    v.disposition_id,
    d.name as disposition,
    d.color as disposition_color,
    p.place_id
  FROM properties_map_view p  -- Use sanitized view instead of raw table
  LEFT JOIN LATERAL (
    SELECT v.disposition_id, v.visit_date
    FROM visits v
    WHERE v.property_id = p.id
    ORDER BY v.visit_date DESC
    LIMIT 1
  ) v ON true
  LEFT JOIN dispositions d ON d.id = v.disposition_id
  WHERE ST_X(p.geom::geometry) >= min_lng 
    AND ST_X(p.geom::geometry) <= max_lng
    AND ST_Y(p.geom::geometry) >= min_lat 
    AND ST_Y(p.geom::geometry) <= max_lat
  ORDER BY p.created_at DESC;
END;
$$;

-- 3. Add RLS policy for geographic viewing (allows seeing pins without exposing full PII)
CREATE POLICY "Users can view properties in map bounds"
ON properties FOR SELECT TO authenticated
USING (
  -- Allow viewing sanitized property data for map display
  -- Full homeowner PII still protected by "Users can view their own properties" policy
  true  
);

-- 4. Backfill created_by for existing properties
-- Find the first admin user to assign ownership
DO $$
DECLARE
  admin_user_id uuid;
BEGIN
  -- Get first admin user from profiles
  SELECT id INTO admin_user_id
  FROM profiles
  WHERE role = 'admin'
  LIMIT 1;
  
  -- If no admin found, get the first user
  IF admin_user_id IS NULL THEN
    SELECT id INTO admin_user_id
    FROM profiles
    ORDER BY created_at ASC
    LIMIT 1;
  END IF;
  
  -- Update NULL created_by values
  IF admin_user_id IS NOT NULL THEN
    UPDATE properties 
    SET created_by = admin_user_id
    WHERE created_by IS NULL;
    
    RAISE NOTICE 'Backfilled % properties with created_by = %', 
      (SELECT COUNT(*) FROM properties WHERE created_by = admin_user_id),
      admin_user_id;
  ELSE
    RAISE WARNING 'No users found to assign property ownership';
  END IF;
END;
$$;

-- 5. Add NOT NULL constraint to created_by (after backfill)
ALTER TABLE properties 
ALTER COLUMN created_by SET NOT NULL;

-- 6. Update property_created trigger to ensure created_by is always set
CREATE OR REPLACE FUNCTION public.ensure_property_created_by()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Ensure created_by is set to authenticated user
  IF NEW.created_by IS NULL THEN
    NEW.created_by := auth.uid();
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create trigger if it doesn't exist
DROP TRIGGER IF EXISTS ensure_property_created_by_trigger ON properties;
CREATE TRIGGER ensure_property_created_by_trigger
  BEFORE INSERT ON properties
  FOR EACH ROW
  EXECUTE FUNCTION ensure_property_created_by();