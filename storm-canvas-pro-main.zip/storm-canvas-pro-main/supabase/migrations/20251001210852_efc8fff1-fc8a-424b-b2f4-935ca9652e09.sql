-- Add spatial deduplication function
CREATE OR REPLACE FUNCTION check_nearby_property(
  check_lat double precision,
  check_lng double precision,
  min_distance_meters double precision DEFAULT 30
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM properties p
    WHERE ST_DWithin(
      p.geom::geography,
      ST_SetSRID(ST_MakePoint(check_lng, check_lat), 4326)::geography,
      min_distance_meters
    )
  );
END;
$$;

-- Thin out dense clusters - keep only properties at least 30m apart
-- This uses a self-join to identify and remove properties that are too close
WITH ranked_properties AS (
  SELECT 
    p1.id,
    p1.created_at,
    COUNT(p2.id) as nearby_count,
    ROW_NUMBER() OVER (
      PARTITION BY ST_SnapToGrid(p1.geom::geometry, 0.0003) 
      ORDER BY p1.created_at
    ) as row_num
  FROM properties p1
  LEFT JOIN properties p2 ON 
    p1.id != p2.id AND
    ST_DWithin(
      p1.geom::geography,
      p2.geom::geography,
      30
    )
  GROUP BY p1.id, p1.created_at, p1.geom
)
DELETE FROM properties
WHERE id IN (
  SELECT id 
  FROM ranked_properties 
  WHERE row_num > 1 AND nearby_count > 0
);

-- Add index for spatial queries
CREATE INDEX IF NOT EXISTS idx_properties_geom_geography 
ON properties USING GIST ((geom::geography));

COMMENT ON FUNCTION check_nearby_property IS 'Checks if a property already exists within the specified distance (default 30m)';