-- Fix critical RLS issues: Create user_roles table and fix properties policies

-- =====================================================
-- 1. Create User Roles System
-- =====================================================

-- Create enum for roles
DO $$ BEGIN
  CREATE TYPE public.app_role AS ENUM ('admin', 'moderator', 'user');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

-- Create user_roles table
CREATE TABLE IF NOT EXISTS public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL,
  created_at timestamp with time zone DEFAULT now(),
  UNIQUE (user_id, role)
);

-- Enable RLS
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Users can view their own roles
CREATE POLICY "Users can view own roles"
ON user_roles FOR SELECT
TO authenticated
USING (user_id = auth.uid());

-- Admins can view all roles
CREATE POLICY "Admins can view all roles"
ON user_roles FOR SELECT
TO authenticated
USING (public.check_user_role(auth.uid(), 'admin'));

-- Only admins can grant roles
CREATE POLICY "Admins can insert roles"
ON user_roles FOR INSERT
TO authenticated
WITH CHECK (public.check_user_role(auth.uid(), 'admin'));

-- Only admins can revoke roles
CREATE POLICY "Admins can delete roles"
ON user_roles FOR DELETE
TO authenticated
USING (public.check_user_role(auth.uid(), 'admin'));

-- Only admins can modify roles
CREATE POLICY "Admins can update roles"
ON user_roles FOR UPDATE
TO authenticated
USING (public.check_user_role(auth.uid(), 'admin'));

-- Add index for performance
CREATE INDEX IF NOT EXISTS idx_user_roles_user_id ON user_roles(user_id);
CREATE INDEX IF NOT EXISTS idx_user_roles_role ON user_roles(role);

-- =====================================================
-- 2. Fix Overly Permissive Properties Policies
-- =====================================================

-- Drop the two overly permissive SELECT policies that expose all properties
DROP POLICY IF EXISTS "Authenticated users can view properties in their area" ON properties;
DROP POLICY IF EXISTS "Users can view properties in map bounds" ON properties;

-- Keep only the policy that allows users to view their own properties
-- This policy already exists: "Users can view their own properties" USING (created_by = auth.uid())

-- Add comment explaining the security model
COMMENT ON TABLE properties IS 
'Properties table with strict RLS. Users can only view properties they created. 
For map display, use properties_map_view which excludes PII and respects RLS policies.';

COMMENT ON TABLE user_roles IS
'User roles table for RBAC. Users can view their own roles, admins can manage all roles.';