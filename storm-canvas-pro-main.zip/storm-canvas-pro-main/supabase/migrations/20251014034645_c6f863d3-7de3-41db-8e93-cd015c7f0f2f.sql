-- Phase 1: Fix Privilege Escalation Vulnerability (Corrected Order)
-- Drop policies first, then replace function

-- =====================================================
-- 1. Drop all policies that depend on check_user_role
-- =====================================================

DROP POLICY IF EXISTS "Only admins can manage integration endpoints" ON integration_endpoints;
DROP POLICY IF EXISTS "Admins can view all profiles" ON profiles;
DROP POLICY IF EXISTS "Admins can manage all rep integrations" ON rep_integrations;
DROP POLICY IF EXISTS "Admins can view all roles" ON user_roles;
DROP POLICY IF EXISTS "Admins can insert roles" ON user_roles;
DROP POLICY IF EXISTS "Admins can delete roles" ON user_roles;
DROP POLICY IF EXISTS "Admins can update roles" ON user_roles;

-- =====================================================
-- 2. Drop the broken check_user_role function
-- =====================================================

DROP FUNCTION IF EXISTS public.check_user_role(uuid, text);

-- =====================================================
-- 3. Create secure has_role function that queries user_roles table
-- =====================================================

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$$;

-- =====================================================
-- 4. Recreate all policies using secure has_role function
-- =====================================================

-- integration_endpoints policies
CREATE POLICY "Only admins can manage integration endpoints"
ON integration_endpoints FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- profiles policies
CREATE POLICY "Admins can view all profiles"
ON profiles FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- rep_integrations policies
CREATE POLICY "Admins can manage all rep integrations"
ON rep_integrations FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- user_roles policies (with correct function)
CREATE POLICY "Admins can view all roles"
ON user_roles FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can insert roles"
ON user_roles FOR INSERT
TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete roles"
ON user_roles FOR DELETE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update roles"
ON user_roles FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- =====================================================
-- 5. Add security documentation
-- =====================================================

COMMENT ON FUNCTION public.has_role(uuid, app_role) IS
'Security definer function to check user roles. Queries user_roles table to prevent privilege escalation. 
NEVER allow users to update their own roles - this would bypass all authorization checks.';

COMMENT ON TABLE user_roles IS
'User roles table for RBAC. Uses app_role enum to prevent type manipulation.
Only admins can modify roles. Users self-updating roles would allow privilege escalation.';