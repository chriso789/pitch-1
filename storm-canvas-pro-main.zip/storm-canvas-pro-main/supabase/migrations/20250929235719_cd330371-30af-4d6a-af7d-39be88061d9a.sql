-- Phase 1: Update dispositions table schema
ALTER TABLE dispositions 
ADD COLUMN IF NOT EXISTS sync_to_pitch BOOLEAN DEFAULT FALSE,
ADD COLUMN IF NOT EXISTS requires_appointment BOOLEAN DEFAULT FALSE;

-- Phase 1: Update contacts table schema
ALTER TABLE contacts 
ADD COLUMN IF NOT EXISTS first_name TEXT,
ADD COLUMN IF NOT EXISTS last_name TEXT;

-- Phase 1: Update visits table schema
ALTER TABLE visits 
ADD COLUMN IF NOT EXISTS appointment_date TIMESTAMP WITH TIME ZONE;

-- Phase 1: Replace existing dispositions with new set
DELETE FROM dispositions;

INSERT INTO dispositions (name, color, description, sync_to_pitch, requires_appointment) VALUES
('Old Roof Marketing', '#3b82f6', 'Property identified for roof marketing', false, false),
('Storm Damage', '#f97316', 'Storm damage identified on property', false, false),
('New Roof', '#22c55e', 'Property has new roof installed', false, false),
('Signed Contingency', '#a855f7', 'Contingency agreement signed - syncs to PITCH', true, false),
('Signed Contract', '#7c3aed', 'Contract signed - syncs to PITCH', true, false),
('Project Completed', '#10b981', 'Project completed - updated from PITCH', true, false),
('Unqualified', '#6b7280', 'Property does not qualify', false, false),
('Interested', '#86efac', 'Homeowner showed interest', false, false),
('Not Interested', '#ef4444', 'Homeowner declined service', false, false),
('Already Solar', '#f59e0b', 'Property already has solar', false, false),
('Abandoned House', '#475569', 'Property appears abandoned', false, false),
('Go Back', '#eab308', 'Schedule follow-up appointment - syncs to PITCH', true, true);

-- Phase 4: Update disposition visit trigger to only sync when sync_to_pitch is true
CREATE OR REPLACE FUNCTION public.handle_disposition_visit()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  should_sync BOOLEAN;
BEGIN
  -- Check if this disposition should sync to PITCH
  SELECT sync_to_pitch INTO should_sync
  FROM dispositions
  WHERE id = NEW.disposition_id;
  
  -- Only add to outbox if sync_to_pitch is true
  IF should_sync THEN
    PERFORM public.add_to_outbox(
      'disposition.created',
      jsonb_build_object(
        'visit_id', NEW.id,
        'property_id', NEW.property_id,
        'disposition_id', NEW.disposition_id,
        'user_id', NEW.user_id,
        'notes', NEW.notes,
        'appointment_date', NEW.appointment_date,
        'created_at', NEW.created_at
      )
    );
  END IF;
  
  RETURN NEW;
END;
$$;