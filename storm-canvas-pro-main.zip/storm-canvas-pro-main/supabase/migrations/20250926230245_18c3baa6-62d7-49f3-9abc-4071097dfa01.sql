-- Enable RLS on remaining user tables (policies already exist)
ALTER TABLE public.dispositions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.visits ENABLE ROW LEVEL SECURITY;

-- Verify all tables now have RLS enabled
SELECT schemaname, tablename, rowsecurity 
FROM pg_tables 
WHERE schemaname = 'public' 
AND tablename NOT IN ('spatial_ref_sys', 'geography_columns', 'geometry_columns') -- Exclude PostGIS system tables
ORDER BY tablename;