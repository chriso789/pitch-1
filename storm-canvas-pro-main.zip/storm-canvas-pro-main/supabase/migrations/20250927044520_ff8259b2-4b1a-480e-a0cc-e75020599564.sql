-- Add missing RPC functions and enhancements for canvassing system (fixed ordering)

-- Helper function: From WKT Polygon → geometry  
CREATE OR REPLACE FUNCTION public.geom_from_wkt(wkt text)
RETURNS geometry 
LANGUAGE sql 
IMMUTABLE AS $$
  SELECT ST_GeomFromText(wkt, 4326)
$$;

-- Helper function: From bbox → polygon geometry (explicit parameter types)
CREATE OR REPLACE FUNCTION public.geom_from_bbox(
  min_lng double precision, 
  min_lat double precision, 
  max_lng double precision, 
  max_lat double precision
)
RETURNS geometry 
LANGUAGE sql 
IMMUTABLE AS $$
  SELECT ST_SetSRID(ST_MakePolygon(ST_MakeLine(ARRAY[
    ST_MakePoint(min_lng, min_lat),
    ST_MakePoint(min_lng, max_lat),
    ST_MakePoint(max_lng, max_lat),
    ST_MakePoint(max_lng, min_lat),
    ST_MakePoint(min_lng, min_lat)
  ])), 4326)
$$;

-- RPC: Get nearest locations by lat/lng and radius
CREATE OR REPLACE FUNCTION public.get_nearest_locations(
  lat double precision,
  lng double precision,
  radius_km double precision DEFAULT 2.0
)
RETURNS TABLE(
  address_hash text,
  lat double precision,
  lng double precision,
  flags jsonb,
  consumer_id text
) 
LANGUAGE sql 
STABLE AS $$
  SELECT p.address_hash,
         ST_Y(p.geom::geometry) as lat,
         ST_X(p.geom::geometry) as lng,
         p.flags,
         p.consumer_id
  FROM public.properties p
  WHERE ST_DWithin(
    p.geom::geography,
    ST_SetSRID(ST_Point(lng, lat), 4326)::geography,
    radius_km * 1000
  )
  ORDER BY p.geom::geography <-> ST_SetSRID(ST_Point(lng, lat), 4326)::geography
  LIMIT 5000;
$$;

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_properties_geom_gist ON public.properties USING GIST (geom);
CREATE INDEX IF NOT EXISTS idx_properties_address_hash ON public.properties (address_hash);
CREATE INDEX IF NOT EXISTS idx_photos_property_created ON public.photos (property_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_outbox_status_created ON public.outbox (status, created_at);

-- Enhance properties table with homeowner field if not exists
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'properties' AND column_name = 'homeowner'
  ) THEN
    ALTER TABLE public.properties ADD COLUMN homeowner jsonb;
  END IF;
END $$;