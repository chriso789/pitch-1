-- Create spatial index for efficient location queries (if not exists)
CREATE INDEX IF NOT EXISTS idx_properties_location
ON public.properties (latitude, longitude)
WHERE latitude IS NOT NULL AND longitude IS NOT NULL;

-- Add function to generate address hash if it doesn't exist
CREATE OR REPLACE FUNCTION public.generate_address_hash(addr TEXT, postal TEXT DEFAULT '')
RETURNS TEXT AS $$
BEGIN
  RETURN encode(sha256((COALESCE(addr, '') || COALESCE(postal, ''))::bytea), 'hex');
END;
$$ LANGUAGE plpgsql IMMUTABLE;