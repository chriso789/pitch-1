-- Clean up invalid street-level properties
-- Remove properties that are clearly on highways or major roads, not actual buildings

DELETE FROM properties 
WHERE 
  -- Remove properties with no place_id (street-level geocoded)
  place_id IS NULL
  AND (
    -- Remove properties on highways and major roads
    address->>'formatted' ILIKE '%Highway%'
    OR address->>'formatted' ILIKE '%Hwy%'
    OR address->>'formatted' ILIKE '%Pkwy%'
    OR address->>'formatted' ILIKE '%Parkway%'
    OR address->>'formatted' ILIKE '%Blvd%'
    OR address->>'formatted' ILIKE '%Boulevard%'
    OR address->>'formatted' ILIKE '%Freeway%'
    OR address->>'formatted' ILIKE '%Interstate%'
    OR address->>'formatted' ILIKE '%Turnpike%'
    -- Remove properties without proper street numbers
    OR address->>'street_number' IS NULL
    OR address->>'street_number' = ''
  );

-- Add index to help with future queries on place_id
CREATE INDEX IF NOT EXISTS idx_properties_place_id ON properties(place_id) WHERE place_id IS NOT NULL;

-- Add index for formatted address searches
CREATE INDEX IF NOT EXISTS idx_properties_formatted_address ON properties USING gin((address->'formatted') jsonb_path_ops);