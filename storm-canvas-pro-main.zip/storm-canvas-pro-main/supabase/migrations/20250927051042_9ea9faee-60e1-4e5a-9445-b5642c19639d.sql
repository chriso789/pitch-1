-- Create template and estimate management system

-- Create templates table
CREATE TABLE IF NOT EXISTS public.templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  currency CHAR(3) NOT NULL DEFAULT 'USD',
  labor JSONB NOT NULL DEFAULT '{"rate_per_square": 125.0, "complexity": {}}',
  overhead JSONB NOT NULL DEFAULT '{"type": "percent", "percent": 15.0}',
  tenant_id UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create template_items table
CREATE TABLE IF NOT EXISTS public.template_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  template_id UUID REFERENCES public.templates(id) ON DELETE CASCADE,
  item_name TEXT NOT NULL,
  unit TEXT NOT NULL DEFAULT 'square',
  waste_pct NUMERIC(5,2) DEFAULT 10.0,
  unit_cost NUMERIC(10,2) NOT NULL,
  qty_formula TEXT NOT NULL DEFAULT 'squares',
  sort_order INTEGER DEFAULT 0,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create estimates table
CREATE TABLE IF NOT EXISTS public.estimates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id UUID REFERENCES public.properties(id),
  name TEXT,
  status TEXT DEFAULT 'draft',
  tenant_id UUID REFERENCES auth.users(id),
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create estimate_bindings table
CREATE TABLE IF NOT EXISTS public.estimate_bindings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  estimate_id UUID REFERENCES public.estimates(id) ON DELETE CASCADE,
  template_id UUID REFERENCES public.templates(id),
  bound_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(estimate_id)
);

-- Create estimate_measurements table
CREATE TABLE IF NOT EXISTS public.estimate_measurements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  estimate_id UUID REFERENCES public.estimates(id) ON DELETE CASCADE,
  squares NUMERIC(10,2),
  complexity_factor NUMERIC(3,2) DEFAULT 1.0,
  measured_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(estimate_id)
);

-- Create estimate_costs table
CREATE TABLE IF NOT EXISTS public.estimate_costs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  estimate_id UUID REFERENCES public.estimates(id) ON DELETE CASCADE,
  materials NUMERIC(10,2) DEFAULT 0,
  labor NUMERIC(10,2) DEFAULT 0,
  overhead NUMERIC(10,2) DEFAULT 0,
  cost_pre_profit NUMERIC(10,2) DEFAULT 0,
  mode TEXT DEFAULT 'margin' CHECK (mode IN ('margin', 'markup')),
  margin_pct NUMERIC(5,2),
  markup_pct NUMERIC(5,2),
  profit NUMERIC(10,2) DEFAULT 0,
  sale_price NUMERIC(10,2) DEFAULT 0,
  currency CHAR(3) DEFAULT 'USD',
  computed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(estimate_id)
);

-- Create estimate_cost_items table
CREATE TABLE IF NOT EXISTS public.estimate_cost_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  estimate_id UUID REFERENCES public.estimates(id) ON DELETE CASCADE,
  template_item_id UUID REFERENCES public.template_items(id),
  item_name TEXT NOT NULL,
  qty NUMERIC(10,2) NOT NULL,
  unit_cost NUMERIC(10,2) NOT NULL,
  line_total NUMERIC(10,2) NOT NULL,
  computed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS on all tables
ALTER TABLE public.templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.template_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.estimates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.estimate_bindings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.estimate_measurements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.estimate_costs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.estimate_cost_items ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can manage their own templates" ON public.templates
  FOR ALL USING (tenant_id = auth.uid());

CREATE POLICY "Users can manage their template items" ON public.template_items
  FOR ALL USING (EXISTS (
    SELECT 1 FROM public.templates t 
    WHERE t.id = template_items.template_id AND t.tenant_id = auth.uid()
  ));

CREATE POLICY "Users can manage their own estimates" ON public.estimates
  FOR ALL USING (tenant_id = auth.uid());

CREATE POLICY "Users can manage their estimate bindings" ON public.estimate_bindings
  FOR ALL USING (EXISTS (
    SELECT 1 FROM public.estimates e 
    WHERE e.id = estimate_bindings.estimate_id AND e.tenant_id = auth.uid()
  ));

CREATE POLICY "Users can manage their estimate measurements" ON public.estimate_measurements
  FOR ALL USING (EXISTS (
    SELECT 1 FROM public.estimates e 
    WHERE e.id = estimate_measurements.estimate_id AND e.tenant_id = auth.uid()
  ));

CREATE POLICY "Users can manage their estimate costs" ON public.estimate_costs
  FOR ALL USING (EXISTS (
    SELECT 1 FROM public.estimates e 
    WHERE e.id = estimate_costs.estimate_id AND e.tenant_id = auth.uid()
  ));

CREATE POLICY "Users can manage their estimate cost items" ON public.estimate_cost_items
  FOR ALL USING (EXISTS (
    SELECT 1 FROM public.estimates e 
    WHERE e.id = estimate_cost_items.estimate_id AND e.tenant_id = auth.uid()
  ));

-- Create helper function for tenant identification
CREATE OR REPLACE FUNCTION public.get_user_tenant_id()
RETURNS UUID
LANGUAGE SQL
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT auth.uid();
$$;

-- Create RPC functions for the API endpoints

-- List template items for a template
CREATE OR REPLACE FUNCTION public.api_template_items_get(p_template_id uuid)
RETURNS TABLE(
  id uuid, item_name text, unit text, waste_pct numeric, unit_cost numeric,
  qty_formula text, sort_order int, active boolean
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT ti.id, ti.item_name, ti.unit, ti.waste_pct, ti.unit_cost,
         ti.qty_formula, ti.sort_order, ti.active
  FROM public.template_items ti
  JOIN public.templates t ON t.id = ti.template_id
  WHERE ti.template_id = p_template_id
    AND t.tenant_id = public.get_user_tenant_id()
  ORDER BY ti.sort_order, ti.item_name;
$$;

-- List computed items for an estimate
CREATE OR REPLACE FUNCTION public.api_estimate_items_get(p_estimate_id uuid)
RETURNS TABLE(
  template_item_id uuid, item_name text, qty numeric, unit_cost numeric, line_total numeric
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT eci.template_item_id, eci.item_name, eci.qty, eci.unit_cost, eci.line_total
  FROM public.estimate_cost_items eci
  JOIN public.estimates e ON e.id = eci.estimate_id
  WHERE eci.estimate_id = p_estimate_id
    AND e.tenant_id = public.get_user_tenant_id()
  ORDER BY eci.item_name;
$$;

-- Hyperlink Bar response
CREATE OR REPLACE FUNCTION public.api_estimate_hyperlink_bar(p_estimate_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_tenant uuid;
  v_bound boolean := false;
  v_meas  boolean := false;
  v_ready boolean := false;
  v_sq    numeric := 0;
  v_costs  public.estimate_costs%ROWTYPE;
  v_sections jsonb;
  v_currency char(3) := 'USD';
BEGIN
  SELECT tenant_id INTO v_tenant FROM public.estimates WHERE id = p_estimate_id;
  IF v_tenant IS NULL THEN RAISE EXCEPTION 'Estimate not found'; END IF;
  IF v_tenant <> public.get_user_tenant_id() THEN RAISE EXCEPTION 'FORBIDDEN'; END IF;

  v_bound := EXISTS (SELECT 1 FROM public.estimate_bindings WHERE estimate_id=p_estimate_id);
  v_meas  := EXISTS (SELECT 1 FROM public.estimate_measurements WHERE estimate_id=p_estimate_id);
  v_ready := v_bound AND v_meas;

  SELECT COALESCE(squares,0) INTO v_sq
  FROM public.estimate_measurements WHERE estimate_id=p_estimate_id;

  SELECT * INTO v_costs FROM public.estimate_costs WHERE estimate_id=p_estimate_id;
  IF v_costs.currency IS NOT NULL THEN v_currency := v_costs.currency; END IF;

  v_sections := jsonb_build_array(
    jsonb_build_object('key','measurements','label','Measurements',
                       'amount', 0,
                       'pending', NOT v_meas,
                       'extra', jsonb_build_object('squares', v_sq)),
    jsonb_build_object('key','materials','label','Materials',
                       'amount', COALESCE(v_costs.materials,0),
                       'pending', NOT v_ready),
    jsonb_build_object('key','labor','label','Labor',
                       'amount', COALESCE(v_costs.labor,0),
                       'pending', NOT v_ready),
    jsonb_build_object('key','overhead','label','Overhead',
                       'amount', COALESCE(v_costs.overhead,0),
                       'pending', NOT v_ready),
    jsonb_build_object('key','profit','label','Profit',
                       'amount', COALESCE(v_costs.profit,0),
                       'pending', NOT v_ready,
                       'extra', jsonb_build_object('mode', COALESCE(v_costs.mode,'margin'),
                                                   'margin_pct', v_costs.margin_pct,
                                                   'markup_pct', v_costs.markup_pct,
                                                   'slider_disabled', NOT v_ready)),
    jsonb_build_object('key','total','label','Total',
                       'amount', COALESCE(v_costs.sale_price,0),
                       'pending', NOT v_ready)
  );

  RETURN jsonb_build_object(
    'estimate_id', p_estimate_id,
    'currency', v_currency,
    'ready', v_ready,
    'template_bound', v_bound,
    'measurements_present', v_meas,
    'squares', v_sq,
    'materials', COALESCE(v_costs.materials,0),
    'labor', COALESCE(v_costs.labor,0),
    'overhead', COALESCE(v_costs.overhead,0),
    'cost_pre_profit', COALESCE(v_costs.cost_pre_profit,0),
    'mode', COALESCE(v_costs.mode,'margin'),
    'margin_pct', v_costs.margin_pct,
    'markup_pct', v_costs.markup_pct,
    'sale_price', COALESCE(v_costs.sale_price,0),
    'profit', COALESCE(v_costs.profit,0),
    'sections', v_sections
  );
END
$$;

-- Estimate status
CREATE OR REPLACE FUNCTION public.api_estimate_status_get(p_estimate_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_tenant uuid;
  v_bound boolean := false;
  v_meas  boolean := false;
  v_ready boolean := false;
  v_cost  public.estimate_costs%ROWTYPE;
  v_next  text[] := ARRAY[]::text[];
  v_msgs  text[] := ARRAY[]::text[];
  v_mode  text;
  v_margin numeric;
  v_markup numeric;
BEGIN
  SELECT tenant_id INTO v_tenant FROM public.estimates WHERE id = p_estimate_id;
  IF v_tenant IS NULL THEN RAISE EXCEPTION 'Estimate not found'; END IF;
  IF v_tenant <> public.get_user_tenant_id() THEN RAISE EXCEPTION 'FORBIDDEN'; END IF;

  v_bound := EXISTS (SELECT 1 FROM public.estimate_bindings WHERE estimate_id=p_estimate_id);
  v_meas  := EXISTS (SELECT 1 FROM public.estimate_measurements WHERE estimate_id=p_estimate_id);
  v_ready := v_bound AND v_meas;

  SELECT * INTO v_cost FROM public.estimate_costs WHERE estimate_id=p_estimate_id;

  IF NOT v_bound THEN
    v_next := array_append(v_next, 'template');
    v_msgs := array_append(v_msgs, 'Bind a template to enable computations.');
  END IF;
  IF NOT v_meas THEN
    v_next := array_append(v_next, 'measurements');
    v_msgs := array_append(v_msgs, 'Ingest measurements to compute quantities.');
  END IF;

  v_mode   := COALESCE(v_cost.mode, NULL);
  v_margin := v_cost.margin_pct;
  v_markup := v_cost.markup_pct;

  RETURN jsonb_build_object(
    'estimate_id',         p_estimate_id,
    'template_bound',      v_bound,
    'measurements_present', v_meas,
    'ready',               v_ready,
    'slider_disabled',     NOT v_ready,
    'last_computed_at',    COALESCE(v_cost.computed_at, NULL),
    'mode',                v_mode,
    'margin_pct',          v_margin,
    'markup_pct',          v_markup,
    'next_required',       COALESCE(to_jsonb(v_next), '[]'::jsonb),
    'messages',            COALESCE(to_jsonb(v_msgs), '[]'::jsonb)
  );
END
$$;

-- Template full (builder-ready)
CREATE OR REPLACE FUNCTION public.api_template_get_full(p_template_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_tenant uuid := public.get_user_tenant_id();
  t record;
  items jsonb;
BEGIN
  SELECT * INTO t
  FROM public.templates
  WHERE id = p_template_id AND tenant_id = v_tenant;
  IF NOT FOUND THEN RAISE EXCEPTION 'Template not found or forbidden'; END IF;

  SELECT COALESCE(jsonb_agg(
           jsonb_build_object(
             'id', ti.id,
             'item_name', ti.item_name,
             'unit', ti.unit,
             'waste_pct', ti.waste_pct,
             'unit_cost', ti.unit_cost,
             'qty_formula', ti.qty_formula,
             'sort_order', ti.sort_order,
             'active', ti.active
           )
         ORDER BY ti.sort_order, ti.item_name), '[]'::jsonb)
    INTO items
  FROM public.template_items ti
  WHERE ti.template_id = p_template_id;

  RETURN jsonb_build_object(
    'id', t.id,
    'name', t.name,
    'currency', t.currency,
    'labor', t.labor,
    'overhead', t.overhead,
    'items', items
  );
END
$$;

-- Grant permissions
REVOKE ALL ON FUNCTION public.api_template_items_get(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.api_template_items_get(uuid) TO authenticated;

REVOKE ALL ON FUNCTION public.api_estimate_items_get(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.api_estimate_items_get(uuid) TO authenticated;

REVOKE ALL ON FUNCTION public.api_estimate_hyperlink_bar(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.api_estimate_hyperlink_bar(uuid) TO authenticated;

REVOKE ALL ON FUNCTION public.api_estimate_status_get(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.api_estimate_status_get(uuid) TO authenticated;

REVOKE ALL ON FUNCTION public.api_template_get_full(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.api_template_get_full(uuid) TO authenticated;

-- Add indexes for performance
CREATE INDEX IF NOT EXISTS idx_templates_tenant ON public.templates(tenant_id);
CREATE INDEX IF NOT EXISTS idx_template_items_template ON public.template_items(template_id);
CREATE INDEX IF NOT EXISTS idx_estimates_tenant ON public.estimates(tenant_id);
CREATE INDEX IF NOT EXISTS idx_estimates_property ON public.estimates(property_id);
CREATE INDEX IF NOT EXISTS idx_estimate_bindings_estimate ON public.estimate_bindings(estimate_id);
CREATE INDEX IF NOT EXISTS idx_estimate_measurements_estimate ON public.estimate_measurements(estimate_id);
CREATE INDEX IF NOT EXISTS idx_estimate_costs_estimate ON public.estimate_costs(estimate_id);
CREATE INDEX IF NOT EXISTS idx_estimate_cost_items_estimate ON public.estimate_cost_items(estimate_id);

-- Add updated_at triggers
CREATE TRIGGER update_templates_updated_at 
  BEFORE UPDATE ON public.templates 
  FOR EACH ROW 
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_estimates_updated_at 
  BEFORE UPDATE ON public.estimates 
  FOR EACH ROW 
  EXECUTE FUNCTION public.update_updated_at_column();