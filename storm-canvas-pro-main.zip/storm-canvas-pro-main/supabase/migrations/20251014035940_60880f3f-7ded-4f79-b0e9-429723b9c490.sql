-- Migration: Add rate limiting infrastructure
-- Purpose: Track API usage to prevent abuse

-- Create rate_limit_tracking table
CREATE TABLE IF NOT EXISTS public.rate_limit_tracking (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  function_name text NOT NULL,
  request_count integer NOT NULL DEFAULT 1,
  window_start timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  CONSTRAINT unique_user_function_window UNIQUE(user_id, function_name, window_start)
);

-- Create indexes for efficient rate limit lookups
CREATE INDEX IF NOT EXISTS idx_rate_limit_user_function 
ON public.rate_limit_tracking(user_id, function_name, window_start DESC);

CREATE INDEX IF NOT EXISTS idx_rate_limit_window_start 
ON public.rate_limit_tracking(window_start DESC);

-- Enable RLS
ALTER TABLE public.rate_limit_tracking ENABLE ROW LEVEL SECURITY;

-- Only service role can manage rate limiting data
CREATE POLICY "Service role can manage rate limits"
ON public.rate_limit_tracking FOR ALL
TO service_role
USING (true)
WITH CHECK (true);

-- Function to cleanup old rate limit entries (run via cron)
CREATE OR REPLACE FUNCTION public.cleanup_rate_limits()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  DELETE FROM public.rate_limit_tracking 
  WHERE window_start < now() - interval '2 hours';
END;
$$;

-- Add comment for documentation
COMMENT ON TABLE public.rate_limit_tracking IS 
'Tracks API usage for rate limiting. Automatically cleaned up after 2 hours.';

COMMENT ON FUNCTION public.cleanup_rate_limits() IS
'Removes old rate limit tracking entries. Should be run hourly via cron job.';