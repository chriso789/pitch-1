-- Fix security definer view issue for properties_map_view
-- Note: spatial_ref_sys is a PostGIS system table and cannot be modified

-- Drop and recreate properties_map_view with explicit security invoker model
DROP VIEW IF EXISTS properties_map_view CASCADE;

CREATE VIEW properties_map_view 
WITH (security_invoker = true)  -- Explicitly use security invoker model to respect RLS
AS
SELECT 
  p.id,
  p.address_hash,
  p.address,
  NULL::jsonb as homeowner,  -- Exclude PII from map view
  p.consumer_id,
  p.flags,
  p.geom,
  p.created_by,
  p.created_at,
  p.place_id,
  p.boundary_wkt
FROM properties p;

-- Grant explicit SELECT permission on the view to authenticated users
GRANT SELECT ON properties_map_view TO authenticated;

-- Add comment explaining the security model
COMMENT ON VIEW properties_map_view IS 
'Sanitized view of properties for map display. Excludes PII (homeowner data). 
Uses security_invoker=true to respect RLS policies on underlying properties table.
Users can only see properties they have permission to view via properties table RLS policies.';