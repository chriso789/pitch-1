-- Add boundary WKT support to properties table for parcel visualization
ALTER TABLE public.properties 
ADD COLUMN IF NOT EXISTS boundary_wkt TEXT;

-- Add comprehensive property intelligence fields to homeowner JSONB
-- This will store all the enhanced Estated data for advanced owner resolution

-- Add index for boundary queries if PostGIS functions are used
CREATE INDEX IF NOT EXISTS idx_properties_boundary_wkt 
ON public.properties USING btree(boundary_wkt) 
WHERE boundary_wkt IS NOT NULL;

-- Add index for enhanced address hash queries  
CREATE INDEX IF NOT EXISTS idx_properties_address_hash_btree 
ON public.properties USING btree(address_hash);

-- Add comment to document the enhanced homeowner field structure
COMMENT ON COLUMN public.properties.homeowner IS 
'Enhanced JSONB field storing comprehensive property and owner data including: 
owner details, property characteristics, deed history, tax information, 
valuation analysis, confidence factors, and boundary data from Estated API';

-- Add comment for boundary_wkt field
COMMENT ON COLUMN public.properties.boundary_wkt IS 
'Well-Known Text representation of property boundary for parcel visualization and spatial queries';