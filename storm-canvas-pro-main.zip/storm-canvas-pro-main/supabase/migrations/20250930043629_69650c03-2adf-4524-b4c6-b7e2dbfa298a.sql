-- Create measurements table for normalized roof measurement data
CREATE TABLE IF NOT EXISTS public.measurements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id UUID NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
  source TEXT NOT NULL CHECK (source IN ('manual', 'eagleview', 'nearmap', 'hover', 'roofr', 'regrid', 'osm')),
  faces JSONB NOT NULL DEFAULT '[]'::jsonb,
  summary JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Create index for efficient property lookups
CREATE INDEX IF NOT EXISTS idx_measurements_property ON public.measurements(property_id);
CREATE INDEX IF NOT EXISTS idx_measurements_created_by ON public.measurements(created_by);

-- Enable RLS
ALTER TABLE public.measurements ENABLE ROW LEVEL SECURITY;

-- Users can view their own measurements
CREATE POLICY "Users can view their own measurements"
ON public.measurements
FOR SELECT
USING (created_by = auth.uid());

-- Users can create their own measurements
CREATE POLICY "Users can create their own measurements"
ON public.measurements
FOR INSERT
WITH CHECK (created_by = auth.uid());

-- Users can update their own measurements
CREATE POLICY "Users can update their own measurements"
ON public.measurements
FOR UPDATE
USING (created_by = auth.uid());

-- Users can delete their own measurements
CREATE POLICY "Users can delete their own measurements"
ON public.measurements
FOR DELETE
USING (created_by = auth.uid());