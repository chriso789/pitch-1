-- Add sample disposition data to Tampa properties
-- First, let's ensure we have dispositions to work with
DO $$
DECLARE
  interested_id uuid;
  not_home_id uuid;
  not_interested_id uuid;
  callback_id uuid;
  sold_id uuid;
  property_ids uuid[];
  user_id uuid;
BEGIN
  -- Get disposition IDs
  SELECT id INTO interested_id FROM dispositions WHERE name = 'Interested' LIMIT 1;
  SELECT id INTO not_home_id FROM dispositions WHERE name = 'Not Home' LIMIT 1;
  SELECT id INTO not_interested_id FROM dispositions WHERE name = 'Not Interested' LIMIT 1;
  SELECT id INTO callback_id FROM dispositions WHERE name = 'Call Back' LIMIT 1;
  SELECT id INTO sold_id FROM dispositions WHERE name = 'Sold' LIMIT 1;

  -- Get a user ID (use the first user in profiles, or create a system user reference)
  SELECT id INTO user_id FROM profiles LIMIT 1;
  
  -- If we have dispositions and a user, add sample visits to Tampa properties
  IF interested_id IS NOT NULL AND user_id IS NOT NULL THEN
    -- Get Tampa properties (those around lat 27.948, lng -82.45)
    SELECT ARRAY_AGG(id) INTO property_ids 
    FROM properties 
    WHERE ST_Y(geom::geometry) BETWEEN 27.94 AND 27.96
      AND ST_X(geom::geometry) BETWEEN -82.47 AND -82.44
    LIMIT 5;
    
    -- Add sample visits with different dispositions if we have properties
    IF property_ids IS NOT NULL AND array_length(property_ids, 1) > 0 THEN
      -- Property 1: Interested
      IF array_length(property_ids, 1) >= 1 THEN
        INSERT INTO visits (property_id, user_id, disposition_id, visit_date, notes)
        VALUES (property_ids[1], user_id, interested_id, NOW() - INTERVAL '2 hours', 'Homeowner interested in roof inspection')
        ON CONFLICT DO NOTHING;
      END IF;
      
      -- Property 2: Not Home
      IF array_length(property_ids, 1) >= 2 AND not_home_id IS NOT NULL THEN
        INSERT INTO visits (property_id, user_id, disposition_id, visit_date, notes)
        VALUES (property_ids[2], user_id, not_home_id, NOW() - INTERVAL '1 day', 'No answer at door')
        ON CONFLICT DO NOTHING;
      END IF;
      
      -- Property 3: Call Back
      IF array_length(property_ids, 1) >= 3 AND callback_id IS NOT NULL THEN
        INSERT INTO visits (property_id, user_id, disposition_id, visit_date, notes, appointment_date)
        VALUES (property_ids[3], user_id, callback_id, NOW() - INTERVAL '3 hours', 'Requested callback next week', NOW() + INTERVAL '5 days')
        ON CONFLICT DO NOTHING;
      END IF;
      
      -- Property 4: Not Interested
      IF array_length(property_ids, 1) >= 4 AND not_interested_id IS NOT NULL THEN
        INSERT INTO visits (property_id, user_id, disposition_id, visit_date, notes)
        VALUES (property_ids[4], user_id, not_interested_id, NOW() - INTERVAL '5 hours', 'Not interested in services')
        ON CONFLICT DO NOTHING;
      END IF;
      
      -- Property 5: Leave unvisited to show gray bubble
    END IF;
  END IF;
END $$;