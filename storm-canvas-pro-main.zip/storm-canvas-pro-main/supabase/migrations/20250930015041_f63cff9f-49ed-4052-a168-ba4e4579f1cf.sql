-- Create helper function for adding property pins with PostGIS geometry
CREATE OR REPLACE FUNCTION add_property_pin(
  addr jsonb,
  lat float8,
  lng float8,
  homeowner_data jsonb DEFAULT NULL,
  property_flags jsonb DEFAULT NULL,
  consumer_id_val text DEFAULT NULL,
  created_by_val uuid DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_id uuid;
  addr_hash text;
BEGIN
  -- Generate address hash
  addr_hash := encode(sha256((addr::text)::bytea), 'hex');
  
  -- Insert property with PostGIS geometry
  INSERT INTO properties (
    address_hash,
    address,
    geom,
    homeowner,
    flags,
    consumer_id,
    created_by
  ) VALUES (
    addr_hash,
    addr,
    ST_SetSRID(ST_MakePoint(lng, lat), 4326)::geography,
    homeowner_data,
    property_flags,
    consumer_id_val,
    created_by_val
  )
  RETURNING id INTO new_id;
  
  RETURN new_id;
END;
$$;

-- Add sample properties near Tampa, FL for testing
SELECT add_property_pin(
  '{"line1": "123 Beach Blvd", "city": "Tampa", "state": "FL", "postal_code": "33602"}'::jsonb,
  27.9481,
  -82.4587,
  '{"name": "John Smith", "phone": "(813) 555-1234", "email": "john.smith@email.com"}'::jsonb
);

SELECT add_property_pin(
  '{"line1": "456 Bay Street", "city": "Tampa", "state": "FL", "postal_code": "33602"}'::jsonb,
  27.9485,
  -82.4590,
  '{"name": "Sarah Johnson", "phone": "(813) 555-5678", "email": "sarah.j@email.com"}'::jsonb
);

SELECT add_property_pin(
  '{"line1": "789 Harbor Drive", "city": "Tampa", "state": "FL", "postal_code": "33602"}'::jsonb,
  27.9478,
  -82.4584,
  '{"name": "Mike Davis", "phone": "(813) 555-9012", "email": "mike.d@email.com"}'::jsonb
);

SELECT add_property_pin(
  '{"line1": "321 Ocean Ave", "city": "Tampa", "state": "FL", "postal_code": "33602"}'::jsonb,
  27.9490,
  -82.4595,
  '{"name": "Lisa Brown", "phone": "(813) 555-3456", "email": "lisa.b@email.com"}'::jsonb
);

SELECT add_property_pin(
  '{"line1": "654 Sunset Blvd", "city": "Tampa", "state": "FL", "postal_code": "33602"}'::jsonb,
  27.9475,
  -82.4580,
  '{"name": "Robert Wilson", "phone": "(813) 555-7890", "email": "robert.w@email.com"}'::jsonb
);