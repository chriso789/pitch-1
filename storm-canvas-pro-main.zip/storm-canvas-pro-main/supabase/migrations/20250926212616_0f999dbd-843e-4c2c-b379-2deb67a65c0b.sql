-- Enable PostGIS extension if not already enabled
CREATE EXTENSION IF NOT EXISTS postgis;

-- Drop and recreate with new geospatial schema
DROP TABLE IF EXISTS proposals CASCADE;
DROP TABLE IF EXISTS photos CASCADE; 
DROP TABLE IF EXISTS designs CASCADE;
DROP TABLE IF EXISTS properties CASCADE;

-- Create properties table (pins) with geospatial optimization
CREATE TABLE properties (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  address_hash text UNIQUE NOT NULL,
  address jsonb NOT NULL,
  geom geography(Point,4326) NOT NULL,
  flags jsonb,
  consumer_id text,
  created_by uuid,
  created_at timestamptz DEFAULT now()
);

-- Create spatial index for efficient geographic queries
CREATE INDEX properties_geom_idx ON properties USING GIST (geom);
CREATE INDEX properties_address_hash_idx ON properties (address_hash);

-- Create designs table (measurements) with polygon geometry
CREATE TABLE designs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id uuid REFERENCES properties(id) ON DELETE CASCADE,
  type text CHECK (type IN ('FAST_ESTIMATES','CUSTOM')) DEFAULT 'FAST_ESTIMATES',
  geom geometry(Polygon,4326) NOT NULL,
  area_sqft numeric,
  pitch_est numeric,
  created_by uuid,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX designs_property_id_idx ON designs (property_id);
CREATE INDEX designs_geom_idx ON designs USING GIST (geom);

-- Create photos table with storage key reference
CREATE TABLE photos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id uuid REFERENCES properties(id) ON DELETE CASCADE,
  key text NOT NULL, -- storage key path
  exif jsonb,
  lat numeric, 
  lng numeric,
  created_by uuid,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX photos_property_id_idx ON photos (property_id);
CREATE INDEX photos_location_idx ON photos (lat, lng) WHERE lat IS NOT NULL AND lng IS NOT NULL;

-- Create proposals table with URL reference
CREATE TABLE proposals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id uuid REFERENCES properties(id) ON DELETE CASCADE,
  type text DEFAULT 'hail',
  url text, -- S3/signed URL
  created_by uuid,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX proposals_property_id_idx ON proposals (property_id);

-- Create RPC function for nearest locations with proper spatial queries
CREATE OR REPLACE FUNCTION get_nearest_locations(
  lat double precision, 
  lng double precision, 
  radius_km double precision DEFAULT 2.0
)
RETURNS TABLE(
  address_hash text, 
  lat double precision, 
  lng double precision, 
  flags jsonb, 
  consumer_id text
)
LANGUAGE sql
STABLE
AS $$
  SELECT 
    p.address_hash,
    ST_Y(ST_Transform(p.geom::geometry,4326)) as lat,
    ST_X(ST_Transform(p.geom::geometry,4326)) as lng,
    p.flags, 
    p.consumer_id
  FROM properties p
  WHERE ST_DWithin(
    p.geom::geography,
    ST_SetSRID(ST_Point(lng, lat),4326)::geography,
    radius_km * 1000
  )
  ORDER BY ST_Distance(
    p.geom::geography,
    ST_SetSRID(ST_Point(lng, lat),4326)::geography
  )
  LIMIT 5000;
$$;

-- Create helper function to generate address hash
CREATE OR REPLACE FUNCTION generate_address_hash(addr jsonb)
RETURNS text
LANGUAGE plpgsql
IMMUTABLE
AS $$
BEGIN
  RETURN encode(sha256((addr::text)::bytea), 'hex');
END;
$$;

-- Enable Row Level Security on new tables
ALTER TABLE properties ENABLE ROW LEVEL SECURITY;
ALTER TABLE designs ENABLE ROW LEVEL SECURITY;
ALTER TABLE photos ENABLE ROW LEVEL SECURITY;
ALTER TABLE proposals ENABLE ROW LEVEL SECURITY;

-- RLS policies for properties (public read for mapping)
CREATE POLICY "Properties are viewable by everyone" 
ON properties FOR SELECT 
USING (true);

CREATE POLICY "Authenticated users can create properties" 
ON properties FOR INSERT 
TO authenticated 
WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Users can update their own properties" 
ON properties FOR UPDATE 
TO authenticated 
USING (created_by = auth.uid());

-- RLS policies for designs (user-specific)
CREATE POLICY "Users can view their own designs" 
ON designs FOR SELECT 
TO authenticated 
USING (created_by = auth.uid());

CREATE POLICY "Users can create their own designs" 
ON designs FOR INSERT 
TO authenticated 
WITH CHECK (created_by = auth.uid());

CREATE POLICY "Users can update their own designs" 
ON designs FOR UPDATE 
TO authenticated 
USING (created_by = auth.uid());

CREATE POLICY "Users can delete their own designs" 
ON designs FOR DELETE 
TO authenticated 
USING (created_by = auth.uid());

-- RLS policies for photos (user-specific)
CREATE POLICY "Users can view their own photos" 
ON photos FOR SELECT 
TO authenticated 
USING (created_by = auth.uid());

CREATE POLICY "Users can create their own photos" 
ON photos FOR INSERT 
TO authenticated 
WITH CHECK (created_by = auth.uid());

CREATE POLICY "Users can update their own photos" 
ON photos FOR UPDATE 
TO authenticated 
USING (created_by = auth.uid());

CREATE POLICY "Users can delete their own photos" 
ON photos FOR DELETE 
TO authenticated 
USING (created_by = auth.uid());

-- RLS policies for proposals (user-specific)
CREATE POLICY "Users can view their own proposals" 
ON proposals FOR SELECT 
TO authenticated 
USING (created_by = auth.uid());

CREATE POLICY "Users can create their own proposals" 
ON proposals FOR INSERT 
TO authenticated 
WITH CHECK (created_by = auth.uid());

CREATE POLICY "Users can update their own proposals" 
ON proposals FOR UPDATE 
TO authenticated 
USING (created_by = auth.uid());

CREATE POLICY "Users can delete their own proposals" 
ON proposals FOR DELETE 
TO authenticated 
USING (created_by = auth.uid());