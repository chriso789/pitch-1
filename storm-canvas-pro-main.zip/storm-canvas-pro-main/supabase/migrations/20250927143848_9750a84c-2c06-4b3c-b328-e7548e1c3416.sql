-- Fix security warnings without breaking existing functionality

-- First, let's check which tables need RLS enabled (only enable on tables that don't have it)
-- Enable RLS on properties table if not already enabled
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_class c
        JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE c.relname = 'properties'
        AND n.nspname = 'public'
        AND c.relrowsecurity = true
    ) THEN
        ALTER TABLE properties ENABLE ROW LEVEL SECURITY;
    END IF;
END
$$;

-- The skip-trace tables already have RLS enabled from the previous migration
-- The function search path issue can be addressed by creating a wrapper function
-- for the existing update_updated_at_column function that has the correct search path

-- Create a properly scoped version for new triggers
CREATE OR REPLACE FUNCTION public.update_updated_at_column_secure()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql' 
SECURITY DEFINER 
SET search_path = public;