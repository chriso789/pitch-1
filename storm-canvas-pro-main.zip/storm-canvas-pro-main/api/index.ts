// api/index.ts
import express from "express";
import cors from "cors";
import { createClient } from "@supabase/supabase-js";
import { loadConfig } from "./services/config.js";
import { s3PresignPut, storagePublicUrl, supabasePresignPut } from "./services/storage.js";
import { pdfGenerate } from "./services/pdf.js";

const cfg = loadConfig();
const app = express();

app.use(cors());
app.use(express.json({ limit: "2mb" }));

const supabaseAnon = createClient(cfg.supabaseUrl, cfg.supabaseAnon);
const supabaseSvc = createClient(cfg.supabaseUrl, cfg.supabaseService);

// Health check
app.get("/api/health", (req, res) => {
  res.json({ ok: true, timestamp: new Date().toISOString() });
});

// ----- Maps: nearest pins (lat/lng + radius)
app.post("/api/maps/getNearestLocations", async (req, res) => {
  const { lat, lng, radiusKm = 2 } = req.body || {};
  
  if (typeof lat !== "number" || typeof lng !== "number") {
    return res.status(400).json({ ok: false, error: "invalid_coordinates" });
  }
  
  try {
    const { data, error } = await supabaseAnon.rpc("get_nearest_locations", { 
      in_lat: lat, 
      in_lng: lng, 
      in_radius_km: radiusKm 
    });
    
    if (error) throw error;
    
    const features = (data || []).map((r: any) => ({
      type: "Feature",
      geometry: { type: "Point", coordinates: [r.lng, r.lat] },
      properties: { 
        addressHash: r.address_hash, 
        consumerId: r.consumer_id, 
        flags: r.flags || {} 
      }
    }));
    
    res.json({ ok: true, count: features.length, features });
  } catch (error) {
    console.error("Error fetching nearest locations:", error);
    res.status(500).json({ ok: false, error: (error as Error).message });
  }
});

// ----- Optional: bbox (minLng,minLat,maxLng,maxLat)
app.post("/api/maps/getLocationsInBbox", async (req, res) => {
  const { minLng, minLat, maxLng, maxLat } = req.body || {};
  
  try {
    const { data, error } = await supabaseAnon.rpc("get_locations_in_bbox", { 
      min_lng: minLng, 
      min_lat: minLat, 
      max_lng: maxLng, 
      max_lat: maxLat 
    });
    
    if (error) throw error;
    
    const features = (data || []).map((r: any) => ({
      type: "Feature",
      geometry: { type: "Point", coordinates: [r.lng, r.lat] },
      properties: { 
        addressHash: r.address_hash, 
        consumerId: r.consumer_id, 
        flags: r.flags || {} 
      }
    }));
    
    res.json({ ok: true, count: features.length, features });
  } catch (error) {
    console.error("Error fetching locations in bbox:", error);
    res.status(500).json({ ok: false, error: (error as Error).message });
  }
});

// ----- Location details
app.post("/api/locations/details", async (req, res) => {
  const { addressHash } = req.body || {};
  
  if (!addressHash) {
    return res.status(400).json({ ok: false, error: "addressHash_required" });
  }

  try {
    const { data: prop, error } = await supabaseSvc
      .from("properties")
      .select("*")
      .eq("address_hash", addressHash)
      .single();
      
    if (error || !prop) {
      return res.status(404).json({ ok: false, error: "not_found" });
    }

    const { data: photos } = await supabaseAnon
      .from("photos")
      .select("*")
      .eq("property_id", prop.id)
      .order("created_at", { ascending: false })
      .limit(12);

    res.json({
      ok: true,
      data: {
        addressHash,
        owner: prop.homeowner?.name ? { name: prop.homeowner.name } : undefined,
        parcel: { apn: prop.homeowner?.apn, wkt: null },
        lastVisits: [],
        dispositions: [],
        photos: (photos || []).map((p: any) => ({ 
          id: p.id, 
          key: p.key, 
          url: storagePublicUrl(p.key), 
          created_at: p.created_at 
        }))
      }
    });
  } catch (error) {
    console.error("Error fetching location details:", error);
    res.status(500).json({ ok: false, error: (error as Error).message });
  }
});

// ----- Photo presign
app.post("/api/photos/presign", async (req, res) => {
  const { key, contentType = "image/jpeg" } = req.body || {};
  
  if (!key) {
    return res.status(400).json({ ok: false, error: "key_required" });
  }

  try {
    if (cfg.s3) {
      const url = await s3PresignPut(key, contentType);
      return res.json({ ok: true, provider: "s3", url, key });
    } else {
      const data = await supabasePresignPut(key, contentType);
      return res.json({ 
        ok: true, 
        provider: "supabase", 
        bucket: cfg.storageBucket, 
        key,
        signedUrl: data.signedUrl,
        token: data.token
      });
    }
  } catch (error) {
    console.error("Error creating presigned URL:", error);
    res.status(500).json({ ok: false, error: (error as Error).message });
  }
});

// ----- Photo attach (DB record)
app.post("/api/photos/attach", async (req, res) => {
  const { propertyId, key, exif, lat, lng, created_by } = req.body || {};
  
  if (!propertyId || !key) {
    return res.status(400).json({ ok: false, error: "propertyId_key_required" });
  }
  
  try {
    const { error } = await supabaseSvc
      .from("photos")
      .insert({ 
        property_id: propertyId, 
        key, 
        exif, 
        lat, 
        lng, 
        created_by 
      });
      
    if (error) throw error;
    
    res.json({ ok: true });
  } catch (error) {
    console.error("Error attaching photo:", error);
    res.status(500).json({ ok: false, error: (error as Error).message });
  }
});

// ----- Photo feed
app.post("/api/photos/getFeed", async (req, res) => {
  const { propertyId, filter = "all", page = 1, limit = 12 } = req.body || {};
  const from = Math.max(0, (page - 1) * limit);
  const to = from + limit - 1;
  
  try {
    let q = supabaseAnon.from("photos").select("*", { count: "exact" });
    if (propertyId) q = q.eq("property_id", propertyId);
    
    const { data, error, count } = await q
      .order("created_at", { ascending: false })
      .range(from, to);
      
    if (error) throw error;
    
    res.json({ ok: true, total: count ?? 0, data });
  } catch (error) {
    console.error("Error fetching photo feed:", error);
    res.status(500).json({ ok: false, error: (error as Error).message });
  }
});

// ----- Save design (polygon WKT)
app.post("/api/designs/save", async (req, res) => {
  const { property_id, type, geom_wkt, area_sqft, pitch_est, created_by } = req.body || {};
  
  if (!property_id || !type || !geom_wkt) {
    return res.status(400).json({ ok: false, error: "missing_required_fields" });
  }
  
  try {
    // Use raw SQL with geom_from_wkt function
    const { error } = await supabaseSvc.rpc("exec_raw_sql", {
      query: `
        INSERT INTO public.designs (property_id, type, geom, area_sqft, pitch_est, created_by)
        VALUES ('${property_id}', '${type}', public.geom_from_wkt('${geom_wkt}'), ${area_sqft || "null"}, ${pitch_est || "null"}, ${created_by ? `'${created_by}'` : "null"});
      `
    });
    
    if (error) throw error;
    
    res.json({ ok: true });
  } catch (error) {
    console.error("Error saving design:", error);
    res.status(500).json({ ok: false, error: (error as Error).message });
  }
});

// ----- Generate proposal (PDF)
app.post("/api/proposals/generate", async (req, res) => {
  const { propertyId, type = "hail", created_by } = req.body || {};
  
  if (!propertyId) {
    return res.status(400).json({ ok: false, error: "propertyId_required" });
  }
  
  try {
    const url = await pdfGenerate({ propertyId, type });
    
    const { error } = await supabaseSvc
      .from("proposals")
      .insert({ 
        property_id: propertyId, 
        type, 
        url, 
        created_by 
      });
      
    if (error) throw error;
    
    res.json({ ok: true, url });
  } catch (error) {
    console.error("Error generating proposal:", error);
    res.status(500).json({ ok: false, error: (error as Error).message });
  }
});

// ----- Templates & Estimates Management
app.get("/api/templates/:templateId/items", async (req, res) => {
  const { templateId } = req.params;
  try {
    const { data, error } = await supabaseAnon.rpc('api_template_items_get', { 
      p_template_id: templateId 
    });
    if (error) throw error;
    res.json(data || []);
  } catch (error) {
    console.error("Error fetching template items:", error);
    res.status(500).json({ ok: false, error: (error as Error).message });
  }
});

app.get("/api/templates/:templateId", async (req, res) => {
  const { templateId } = req.params;
  try {
    const { data, error } = await supabaseAnon.rpc('api_template_get_full', { 
      p_template_id: templateId 
    });
    if (error) throw error;
    res.json(data);
  } catch (error) {
    console.error("Error fetching template:", error);
    res.status(500).json({ ok: false, error: (error as Error).message });
  }
});

app.get("/api/estimates/:estimateId/items", async (req, res) => {
  const { estimateId } = req.params;
  try {
    const { data, error } = await supabaseAnon.rpc('api_estimate_items_get', { 
      p_estimate_id: estimateId 
    });
    if (error) throw error;
    res.json(data || []);
  } catch (error) {
    console.error("Error fetching estimate items:", error);
    res.status(500).json({ ok: false, error: (error as Error).message });
  }
});

app.get("/api/estimates/:estimateId/hyperlink-bar", async (req, res) => {
  const { estimateId } = req.params;
  try {
    const { data, error } = await supabaseAnon.rpc('api_estimate_hyperlink_bar', { 
      p_estimate_id: estimateId 
    });
    if (error) throw error;
    res.json(data);
  } catch (error) {
    console.error("Error fetching hyperlink bar data:", error);
    res.status(500).json({ ok: false, error: (error as Error).message });
  }
});

app.get("/api/estimates/:estimateId/status", async (req, res) => {
  const { estimateId } = req.params;
  try {
    const { data, error } = await supabaseAnon.rpc('api_estimate_status_get', { 
      p_estimate_id: estimateId 
    });
    if (error) throw error;
    res.json(data);
  } catch (error) {
    console.error("Error fetching estimate status:", error);
    res.status(500).json({ ok: false, error: (error as Error).message });
  }
});

// ----- Create estimates and templates
app.post("/api/estimates", async (req, res) => {
  const { property_id, name, tenant_id, created_by } = req.body || {};
  if (!property_id) {
    return res.status(400).json({ ok: false, error: "property_id_required" });
  }
  
  try {
    const { data, error } = await supabaseSvc
      .from("estimates")
      .insert({ property_id, name, tenant_id, created_by })
      .select()
      .single();
      
    if (error) throw error;
    res.json({ ok: true, data });
  } catch (error) {
    console.error("Error creating estimate:", error);
    res.status(500).json({ ok: false, error: (error as Error).message });
  }
});

app.post("/api/templates", async (req, res) => {
  const { name, currency = 'USD', labor, overhead, tenant_id } = req.body || {};
  if (!name) {
    return res.status(400).json({ ok: false, error: "name_required" });
  }
  
  try {
    const { data, error } = await supabaseSvc
      .from("templates")
      .insert({ name, currency, labor, overhead, tenant_id })
      .select()
      .single();
      
    if (error) throw error;
    res.json({ ok: true, data });
  } catch (error) {
    console.error("Error creating template:", error);
    res.status(500).json({ ok: false, error: (error as Error).message });
  }
});

const port = process.env.PORT || 8787;
app.listen(port, () => {
  console.log(`🚀 Express API listening on :${port}`);
  console.log(`📊 Health check: http://localhost:${port}/api/health`);
});