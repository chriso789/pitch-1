/**
 * Environment variable validation for startup
 * Fails fast with clear error messages if required vars are missing
 */

interface EnvVar {
  name: string;
  required: boolean;
  description: string;
}

const requiredEnvVars: EnvVar[] = [
  {
    name: 'SUPABASE_URL',
    required: true,
    description: 'Supabase project URL (https://xxxxx.supabase.co)'
  },
  {
    name: 'SUPABASE_ANON_KEY',
    required: true,
    description: 'Supabase anonymous/public API key'
  },
  {
    name: 'SUPABASE_SERVICE_ROLE_KEY',
    required: true,
    description: 'Supabase service role key (keep secret!)'
  }
];

const optionalEnvVars: EnvVar[] = [
  {
    name: 'STORAGE_BUCKET',
    required: false,
    description: 'Storage bucket name for file uploads'
  },
  {
    name: 'S3_BUCKET',
    required: false,
    description: 'S3 bucket name (if using S3 instead of Supabase storage)'
  },
  {
    name: 'S3_REGION',
    required: false,
    description: 'S3 region (e.g., us-east-1)'
  },
  {
    name: 'S3_ACCESS_KEY_ID',
    required: false,
    description: 'S3 access key ID'
  },
  {
    name: 'S3_SECRET_ACCESS_KEY',
    required: false,
    description: 'S3 secret access key'
  },
  {
    name: 'MAPBOX_TOKEN',
    required: false,
    description: 'Mapbox API token for mapping features'
  },
  {
    name: 'USPS_USER_ID',
    required: false,
    description: 'USPS API user ID for address validation'
  },
  {
    name: 'MELISSA_API_KEY',
    required: false,
    description: 'Melissa Data API key for address enrichment'
  },
  {
    name: 'PDL_API_KEY',
    required: false,
    description: 'People Data Labs API key for contact enrichment'
  },
  {
    name: 'WHITEPAGES_API_KEY',
    required: false,
    description: 'Whitepages API key for contact lookup'
  },
  {
    name: 'TWILIO_SID',
    required: false,
    description: 'Twilio account SID for SMS features'
  },
  {
    name: 'TWILIO_TOKEN',
    required: false,
    description: 'Twilio auth token'
  },
  {
    name: 'MOCK_ONLY',
    required: false,
    description: 'Set to "true" to use mock providers only'
  },
  {
    name: 'ENABLE_RESTRICTED_PROVIDERS',
    required: false,
    description: 'Set to "true" to enable restricted API providers'
  },
  {
    name: 'PROPOSALS_BASE_URL',
    required: false,
    description: 'Base URL for proposal generation service'
  }
];

/**
 * Validate environment variables at startup
 * Throws error with clear message if required vars are missing
 */
export function validateEnvironment(): void {
  const missing: EnvVar[] = [];
  const warnings: EnvVar[] = [];

  // Check required variables
  for (const envVar of requiredEnvVars) {
    const value = process.env[envVar.name];
    if (!value || value.trim() === '') {
      missing.push(envVar);
    }
  }

  // Check optional variables for warnings
  for (const envVar of optionalEnvVars) {
    const value = process.env[envVar.name];
    if (!value || value.trim() === '') {
      warnings.push(envVar);
    }
  }

  // Fail fast if required vars are missing
  if (missing.length > 0) {
    const errorMessage = [
      '❌ CONFIGURATION ERROR: Missing required environment variables',
      '',
      'The following environment variables are required but not set:',
      '',
      ...missing.map(v => `  • ${v.name}`),
      '    ${v.description}',
      '',
      'Please set these variables in your .env file or environment configuration.',
      'See .env.local.example for reference.',
      '',
      'Security Note: Never commit .env files with real credentials to version control!'
    ].join('\n');

    throw new Error(errorMessage);
  }

  // Log warnings for optional vars (but don't fail)
  if (warnings.length > 0 && process.env.NODE_ENV !== 'test') {
    console.warn('⚠️  Optional environment variables not set:');
    for (const envVar of warnings) {
      console.warn(`  • ${envVar.name} - ${envVar.description}`);
    }
    console.warn('');
  }

  // Success message
  if (process.env.NODE_ENV !== 'test') {
    console.log('✅ Environment configuration validated successfully');
  }
}

/**
 * Get environment variable with validation
 * Throws error if required var is missing
 */
export function getEnvVar(name: string, required: boolean = true): string | undefined {
  const value = process.env[name];
  
  if (required && (!value || value.trim() === '')) {
    throw new Error(
      `Environment variable ${name} is required but not set. ` +
      `Please check your .env file or environment configuration.`
    );
  }
  
  return value;
}
