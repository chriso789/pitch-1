// api/services/storage.ts
import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { createClient } from "@supabase/supabase-js";
import { loadConfig } from "./config.js";

const cfg = loadConfig();

let s3Client: S3Client | null = null;
if (cfg.s3) {
  s3Client = new S3Client({
    region: cfg.s3.region,
    credentials: {
      accessKeyId: cfg.s3.accessKeyId,
      secretAccessKey: cfg.s3.secretAccessKey
    }
  });
}

export async function s3PresignPut(key: string, contentType = "image/jpeg") {
  if (!s3Client || !cfg.s3) throw new Error("S3 not configured");
  const command = new PutObjectCommand({ 
    Bucket: cfg.s3.bucket, 
    Key: key, 
    ContentType: contentType 
  });
  return await getSignedUrl(s3Client, command, { expiresIn: 300 });
}

export function storagePublicUrl(key: string) {
  if (cfg.s3) {
    const base = cfg.proposalsBaseUrl || `https://${cfg.s3.bucket}.s3.${cfg.s3.region}.amazonaws.com/`;
    return `${base}${key}`;
  }
  
  // Supabase Storage public URL
  const sb = createClient(cfg.supabaseUrl, cfg.supabaseAnon);
  const { data } = sb.storage.from(cfg.storageBucket!).getPublicUrl(key);
  return data.publicUrl;
}

export async function supabasePresignPut(key: string, contentType = "image/jpeg") {
  const sb = createClient(cfg.supabaseUrl, cfg.supabaseService);
  const { data, error } = await sb.storage
    .from(cfg.storageBucket!)
    .createSignedUploadUrl(key, {
      expiresIn: 300,
      upsert: true
    });
  
  if (error) throw error;
  return data;
}