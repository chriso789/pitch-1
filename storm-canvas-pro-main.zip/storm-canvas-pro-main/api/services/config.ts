// api/services/config.ts
export type AppConfig = {
  supabaseUrl: string;
  supabaseAnon: string;
  supabaseService: string;
  storageBucket?: string;

  s3?: { 
    region: string; 
    bucket: string; 
    accessKeyId: string; 
    secretAccessKey: string; 
  };
  
  mapboxToken?: string;
  uspsUserId?: string;
  melissaApiKey?: string;
  pdlApiKey?: string;
  whitepagesApiKey?: string;
  twilioSid?: string;
  twilioToken?: string;

  mockOnly: boolean;
  restrictedProviders: boolean;
  proposalsBaseUrl?: string;
};

export function loadConfig(): AppConfig {
  // Validate required environment variables
  const requiredVars = {
    SUPABASE_URL: process.env.SUPABASE_URL,
    SUPABASE_ANON_KEY: process.env.SUPABASE_ANON_KEY,
    SUPABASE_SERVICE_ROLE_KEY: process.env.SUPABASE_SERVICE_ROLE_KEY
  };

  const missing = Object.entries(requiredVars)
    .filter(([_, value]) => !value)
    .map(([key]) => key);

  if (missing.length > 0) {
    throw new Error(
      `❌ Missing required environment variables: ${missing.join(', ')}\n` +
      `Please check your .env file or environment configuration.\n` +
      `See .env.local.example for reference.`
    );
  }

  return {
    supabaseUrl: requiredVars.SUPABASE_URL!,
    supabaseAnon: requiredVars.SUPABASE_ANON_KEY!,
    supabaseService: requiredVars.SUPABASE_SERVICE_ROLE_KEY!,
    storageBucket: process.env.STORAGE_BUCKET || "photos",
    
    s3: process.env.S3_BUCKET
      ? {
          region: process.env.S3_REGION || "us-east-1",
          bucket: process.env.S3_BUCKET!,
          accessKeyId: process.env.S3_ACCESS_KEY_ID || "",
          secretAccessKey: process.env.S3_SECRET_ACCESS_KEY || ""
        }
      : undefined,
      
    mapboxToken: process.env.MAPBOX_TOKEN,
    uspsUserId: process.env.USPS_USER_ID,
    melissaApiKey: process.env.MELISSA_API_KEY,
    pdlApiKey: process.env.PDL_API_KEY,
    whitepagesApiKey: process.env.WHITEPAGES_API_KEY,
    twilioSid: process.env.TWILIO_SID,
    twilioToken: process.env.TWILIO_TOKEN,
    
    mockOnly: process.env.MOCK_ONLY === "true",
    restrictedProviders: process.env.ENABLE_RESTRICTED_PROVIDERS === "true",
    proposalsBaseUrl: process.env.PROPOSALS_BASE_URL
  };
}