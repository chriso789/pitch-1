// api/services/pdf.ts
import { PDFDocument, StandardFonts, rgb } from "pdf-lib";
import { s3PresignPut, supabasePresignPut } from "./storage.js";
import { loadConfig } from "./config.js";

const cfg = loadConfig();

export async function pdfGenerate({ 
  propertyId, 
  type 
}: { 
  propertyId: string; 
  type: string; 
}): Promise<string> {
  // 1) Create a basic PDF (replace with Puppeteer-based rendering later)
  const pdf = await PDFDocument.create();
  const page = pdf.addPage([612, 792]);
  const font = await pdf.embedFont(StandardFonts.Helvetica);
  
  page.drawText(`Property Proposal`, { 
    x: 50, 
    y: 740, 
    size: 24, 
    font, 
    color: rgb(0, 0, 0) 
  });
  
  page.drawText(`Property ID: ${propertyId}`, { 
    x: 50, 
    y: 700, 
    size: 12, 
    font 
  });
  
  page.drawText(`Type: ${type}`, { 
    x: 50, 
    y: 680, 
    size: 12, 
    font 
  });
  
  page.drawText(`Generated: ${new Date().toLocaleDateString()}`, { 
    x: 50, 
    y: 660, 
    size: 10, 
    font,
    color: rgb(0.5, 0.5, 0.5)
  });
  
  const pdfBytes = await pdf.save();

  // 2) Upload to storage
  const key = `proposals/${propertyId}-${type}-${Date.now()}.pdf`;
  
  if (cfg.s3) {
    const putUrl = await s3PresignPut(key, "application/pdf");
    await fetch(putUrl, { 
      method: "PUT", 
      headers: { "content-type": "application/pdf" }, 
      body: pdfBytes 
    });
    return `${cfg.proposalsBaseUrl || `https://${cfg.s3.bucket}.s3.${cfg.s3.region}.amazonaws.com/`}${key}`;
  } else {
    // Use Supabase Storage
    const { signedUrl, token } = await supabasePresignPut(key, "application/pdf");
    await fetch(signedUrl, {
      method: "PUT",
      headers: { 
        "content-type": "application/pdf",
        "authorization": `Bearer ${token}`
      },
      body: pdfBytes
    });
    
    return `${cfg.supabaseUrl}/storage/v1/object/public/${cfg.storageBucket}/${key}`;
  }
}