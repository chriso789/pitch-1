# PII (Personally Identifiable Information) Handling

## What is PII in Canvass-IQ?
- **Homeowner names**
- **Phone numbers**
- **Email addresses**
- **Mailing addresses**
- **Consumer IDs** (from skip-trace providers)

## Data Flow & Protection

### 1. Owner Resolution (locations-details)
- **Cache-first**: Uses cached data (<30 days old) when available
- **Authorization**: Users can only access properties they created
- **Rate limiting**: 5 requests/min to prevent data scraping
- **Audit logging**: All PII access logged (with PII redacted from logs)

### 2. Logging PII Protection
All structured logs automatically redact:
```typescript
const logger = Logger.create(req, 'function-name');
logger.info('Processing', { homeowner: 'John Doe' });
// Output: { homeowner: '[REDACTED]' }
```

### 3. Database Security
- **RLS Policies**: Users see only their own data
- **No public PII**: Map view returns sanitized data (no homeowner info)
- **Encrypted at rest**: Supabase encrypts all database columns

### 4. Data Retention
- **Active properties**: Retained indefinitely while user account active
- **Cached owner data**: Refreshed every 30 days
- **Rate limit tracking**: Auto-deleted after 2 hours
- **Audit logs**: Retained for 90 days

## Compliance Considerations
- **GDPR**: Right to deletion supported (delete user account = cascade delete all data)
- **CCPA**: Users can export their data via Supabase dashboard
- **Data minimization**: Only collect PII necessary for core functionality

## Developer Guidelines
1. Never log PII to console (use Logger with auto-redaction)
2. Never expose PII in error messages
3. Always check ownership before returning PII
4. Use caching to minimize PII API calls
5. Redact PII in all external integrations
