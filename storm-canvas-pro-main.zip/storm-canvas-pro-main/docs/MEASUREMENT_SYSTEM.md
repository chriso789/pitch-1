# 🏗️ Roof Measurement System - Developer Overview

## 📋 Table of Contents
1. [System Architecture](#system-architecture)
2. [Data Flow](#data-flow)
3. [Component Breakdown](#component-breakdown)
4. [Database Schema](#database-schema)
5. [Provider Architecture](#provider-architecture)
6. [Current Implementation Status](#current-implementation-status)
7. [Improvement Opportunities](#improvement-opportunities)
8. [Technical Debt](#technical-debt)
9. [Future Enhancements](#future-enhancements)

---

## 🏛️ System Architecture

### High-Level Overview
```
┌─────────────────────────────────────────────────────────────┐
│                      User Interface                          │
│  ┌──────────────┐  ┌────────────────┐  ┌─────────────────┐  │
│  │ MeasurePanel │  │ RoofMeasurement│  │ MeasurementDrawing│
│  │              │  │ Tools          │  │ Manager         │  │
│  └──────┬───────┘  └────────┬───────┘  └────────┬────────┘  │
└─────────┼──────────────────┼───────────────────┼───────────┘
          │                  │                   │
          ▼                  ▼                   ▼
    ┌────────────────────────────────────────────────┐
    │         React Hook (useMeasurements)           │
    │  ┌──────────┐  ┌──────────┐  ┌─────────────┐  │
    │  │  Fetch   │  │  Save    │  │  Auto       │  │
    │  │  Latest  │  │  Manual  │  │  Measure    │  │
    │  └────┬─────┘  └────┬─────┘  └──────┬──────┘  │
    └───────┼─────────────┼────────────────┼─────────┘
            │             │                │
            ▼             ▼                ▼
    ┌──────────────────────────────────────────────────┐
    │      Supabase Edge Function (/measure)           │
    │  ┌──────────────┐  ┌──────────────┐             │
    │  │ GET /latest  │  │ POST /manual │             │
    │  └──────────────┘  └──────────────┘             │
    │  ┌──────────────────────────────────────┐       │
    │  │ POST /auto (Provider Orchestration)  │       │
    │  │  ┌────────┐  ┌────────┐  ┌────────┐ │       │
    │  │  │Regrid  │  │EagleView│  │Nearmap│ │       │
    │  │  │(active)│  │ (stub)  │  │ (stub) │ │       │
    │  │  └────────┘  └────────┘  └────────┘ │       │
    │  └──────────────────────────────────────┘       │
    └────────────────────┬─────────────────────────────┘
                         │
                         ▼
              ┌──────────────────────┐
              │   Supabase Database  │
              │   ┌──────────────┐   │
              │   │ measurements │   │
              │   └──────────────┘   │
              └──────────────────────┘
```

### Key Technologies
- **Frontend**: React, TypeScript, Google Maps API (Drawing)
- **Backend**: Supabase Edge Functions (Deno)
- **Database**: PostgreSQL (PostGIS for spatial data)
- **State Management**: TanStack Query (React Query)
- **Event Bus**: Custom event system (`@/lib/eventBus`)
- **External APIs**: Regrid Parcel API (active), EagleView/Nearmap/HOVER (planned)

---

## 🔄 Data Flow

### Manual Measurement Flow
```
1. User clicks "Manual" button
   ↓
2. MeasurePanel sets mode='manual'
   ↓
3. RoofMeasurementTools component renders
   ↓
4. User selects draw mode (Face/Line)
   ↓
5. MeasurementDrawingManager activates Google Maps DrawingManager
   ↓
6. User draws polygon/polyline on map
   ↓
7. Google Maps fires 'polygoncomplete' or 'polylinecomplete' event
   ↓
8. DrawingManager calculates area/length + WKT geometry
   ↓
9. Event emitted via bus (EVT_POLY_CREATED / EVT_LINE_CREATED)
   ↓
10. RoofMeasurementTools receives event, applies pitch factor + waste%
   ↓
11. Face/Line added to local state array
   ↓
12. User clicks "Save Measurement"
   ↓
13. useMeasurements.saveManual() calls Supabase function
   ↓
14. Edge function validates + calculates summary
   ↓
15. Measurement inserted into 'measurements' table
   ↓
16. Query invalidation triggers UI refresh
```

### Auto Measurement Flow (Current - Regrid)
```
1. User clicks "Auto" button
   ↓
2. useMeasurements.autoMeasure() sends { propertyId, lat, lng, address }
   ↓
3. Edge function checks REGRID_API_KEY exists
   ↓
4. Calls Regrid Parcels API: GET /parcels/near?lat={lat}&lng={lng}
   ↓
5. Receives GeoJSON polygon (building footprint)
   ↓
6. Converts GeoJSON → WKT format
   ↓
7. Calculates planar area using Shoelace formula
   ↓
8. Converts m² → ft² (x10.7639)
   ↓
9. Creates single RoofFace with default pitch='4/12'
   ↓
10. Saves to 'measurements' table with source='regrid'
   ↓
11. Returns { ok: true, data: measurement }
```

### Auto Measurement Flow (Planned - Multi-Provider)
```
1. User clicks "Auto" button
   ↓
2. Edge function loads provider ranking:
   Priority: EagleView → Nearmap → HOVER → Roofr → Regrid → OSM
   ↓
3. For each provider in order:
   a. Check if API key exists (provider.supports())
   b. Call provider.run({ address, lat, lng })
   c. If successful with valid faces → return result
   d. If fails → log error, try next provider
   ↓
4. If all fail → return error "Use Manual-Measure"
```

---

## 🧩 Component Breakdown

### Frontend Components

#### **1. MeasurePanel.tsx**
- **Purpose**: Main UI panel for measurement feature
- **Location**: `src/components/Canvassing/MeasurePanel.tsx`
- **Responsibilities**:
  - Displays "Auto" and "Manual" measurement buttons
  - Shows latest measurement summary (area, squares, source)
  - Manages mode state (`idle` | `manual`)
  - Delegates to RoofMeasurementTools for drawing

**Props:**
```typescript
interface MeasurePanelProps {
  addressHash: string | null;  // Property ID (SHA-256 hash)
  address?: any;                // Full address object
  lat?: number;                 // Latitude
  lng?: number;                 // Longitude
}
```

**Key Functions:**
- `handleAutoMeasure()` - Triggers auto-measure via provider
- `handleStartManual()` - Switches to manual drawing mode
- `handleMeasurementComplete()` - Saves manual measurement to DB

---

#### **2. RoofMeasurementTools.tsx**
- **Purpose**: Drawing UI and measurement state management
- **Location**: `src/components/Canvassing/RoofMeasurementTools.tsx`
- **Responsibilities**:
  - Mode selector (Face drawing vs Line drawing)
  - Pitch selector (flat, 3/12, 4/12, ..., 12/12)
  - Waste percentage selector (10%, 12%, 15%, 20%)
  - Edge type selector (ridge, hip, valley, eave, etc.)
  - Display list of drawn faces and linear features
  - Calculate totals (squares, linear feet)

**State:**
```typescript
- drawMode: 'face' | 'line'
- currentPitch: string           // e.g., '6/12'
- wastePct: number               // Default 12
- currentEdgeType: EdgeType      // ridge, hip, valley, etc.
- currentLabel: string           // Optional label for lines
- faces: RoofFace[]              // Array of drawn roof faces
- linearFeatures: LinearFeature[] // Array of drawn lines
```

**Event Listeners:**
- `EVT_POLY_CREATED` - When polygon drawn on map
- `EVT_LINE_CREATED` - When polyline drawn on map

**Calculations:**
1. **Roof Area with Pitch**:
   ```typescript
   pitchFactor = sqrt(rise² + run²) / run
   adjustedArea = planArea * pitchFactor * (1 + waste_pct/100)
   ```
   Example: 1000 sqft @ 6/12 pitch + 12% waste
   = 1000 * 1.118 * 1.12 = **1,252 sqft**

2. **Squares**: `totalSquares = totalArea / 100`

---

#### **3. MeasurementDrawingManager.tsx**
- **Purpose**: Google Maps drawing integration
- **Location**: `src/components/Canvassing/MeasurementDrawingManager.tsx`
- **Responsibilities**:
  - Initialize `google.maps.drawing.DrawingManager`
  - Listen for `EVT_MEASURE_MODE` to switch polygon/polyline
  - Handle `polygoncomplete` event → calculate area + WKT
  - Handle `polylinecomplete` event → calculate length + WKT
  - Emit `EVT_POLY_CREATED` / `EVT_LINE_CREATED` events

**Google Maps Drawing Options:**
```typescript
polygonOptions: {
  fillColor: '#3b82f6',      // Blue fill
  fillOpacity: 0.3,
  strokeColor: '#3b82f6',
  strokeWeight: 2,
}

polylineOptions: {
  strokeColor: '#ef4444',    // Red stroke
  strokeWeight: 3,
}
```

**WKT Generation:**
- **Polygon**: `POLYGON((lng lat, lng lat, ..., lng lat))`
- **LineString**: `LINESTRING(lng lat, lng lat, ...)`

---

### React Hook

#### **useMeasurements.ts**
- **Purpose**: Centralized measurement data fetching + mutations
- **Location**: `src/hooks/useMeasurements.ts`

**API:**
```typescript
const { 
  latestMeasurement,  // Latest measurement for property
  isLoading,          // Loading state
  saveManual,         // Mutation: save manual measurement
  autoMeasure,        // Mutation: trigger auto-measure
} = useMeasurements(propertyId);
```

**Queries:**
- `GET /measure/{propertyId}/latest` - Fetch latest measurement

**Mutations:**
- `POST /measure/manual` - Save manual measurement
- `POST /measure/auto` - Trigger auto-measure via providers

**Query Invalidation:**
- On successful save/auto → invalidates `['measurement', propertyId]`

---

### Backend (Supabase Edge Function)

#### **supabase/functions/measure/index.ts**
- **Purpose**: HTTP API for measurements
- **Runtime**: Deno (JavaScript on edge)

**Endpoints:**

1. **GET `/measure/:propertyId/latest`**
   - Returns most recent measurement for property
   - Ordered by `created_at DESC`
   - Returns `null` if no measurements exist

2. **POST `/measure/manual`**
   - **Body**: `{ propertyId, faces, linear_features?, waste_pct? }`
   - Validates `faces` array exists
   - Calculates `total_area_sqft` by summing face areas
   - Calculates `total_squares = total_area / 100`
   - Inserts into `measurements` table with `source='manual'`

3. **POST `/measure/auto`**
   - **Body**: `{ propertyId, address?, lat, lng, waste_pct? }`
   - **Current Implementation**: Only supports Regrid
   - Checks `REGRID_API_KEY` secret exists
   - Calls Regrid Parcels API near lat/lng
   - Extracts building polygon geometry
   - Converts GeoJSON → WKT
   - Calculates area using Shoelace formula
   - Inserts with `source='regrid'`, default `pitch='4/12'`
   - **Planned**: Iterate through provider array (EagleView → Nearmap → HOVER → Roofr → Regrid)

**Area Calculation (Shoelace Formula):**
```typescript
function calculatePolygonArea(coords: [lng, lat][]): number {
  // Convert degrees to meters
  metersPerDegreeLat = 111320
  metersPerDegreeLng = 111320 * cos(lat * π/180)
  
  // Shoelace formula
  area = Σ (x[i]*y[i+1] - x[i+1]*y[i]) / 2
  
  // Convert m² → ft²
  return area * 10.7639
}
```

**⚠️ Known Limitations:**
- Only planar area (doesn't account for roof pitch in auto-measure)
- Single building polygon (doesn't handle multi-building parcels)
- No error retry logic
- No caching of provider results

---

## 🗄️ Database Schema

### Table: `measurements`
```sql
CREATE TABLE measurements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id UUID NOT NULL,           -- FK to properties table
  source TEXT NOT NULL,                -- 'manual' | 'regrid' | 'eagleview' | etc.
  faces JSONB NOT NULL DEFAULT '[]',   -- Array of RoofFace objects
  summary JSONB NOT NULL DEFAULT '{}', -- { total_area_sqft, total_squares, waste_pct, pitch_method }
  created_by UUID,                     -- FK to auth.users
  created_at TIMESTAMPTZ DEFAULT now(),
  
  -- Indexes
  INDEX idx_measurements_property (property_id, created_at DESC)
);
```

**RLS Policies:**
```sql
-- Users can only view/create/update/delete their own measurements
CREATE POLICY "Users can view their own measurements"
  ON measurements FOR SELECT
  USING (created_by = auth.uid());

CREATE POLICY "Users can create their own measurements"
  ON measurements FOR INSERT
  WITH CHECK (created_by = auth.uid());
```

### JSONB Structure

#### **RoofFace** (in `faces` array)
```json
{
  "id": "A",                              // Face identifier (A, B, C, ...)
  "wkt": "POLYGON((-122.4 37.7, ...))",   // Well-Known Text geometry
  "area_sqft": 1252.3,                    // Area including pitch + waste
  "pitch": "6/12",                        // Roof pitch (optional)
  "linear_features": [...]                // Lines on this face (optional)
}
```

#### **LinearFeature** (in `linear_features` array or face)
```json
{
  "id": "L1",                             // Feature identifier
  "wkt": "LINESTRING(-122.4 37.7, ...)",  // WKT line geometry
  "length_ft": 45.2,                      // Length in feet
  "type": "ridge",                        // EdgeType enum
  "label": "North ridge"                  // Optional label
}
```

#### **Summary** (in `summary` object)
```json
{
  "total_area_sqft": 2504.6,              // Sum of all face areas
  "total_squares": 25.046,                // total_area / 100
  "waste_pct": 12,                        // Waste percentage used
  "pitch_method": "manual"                // 'manual' | 'vendor'
}
```

---

## 🔌 Provider Architecture

### Design Pattern: Strategy + Chain of Responsibility

**Provider Interface:**
```typescript
// src/lib/measure/types.ts
interface MeasureProvider {
  name: 'manual' | 'eagleview' | 'nearmap' | 'hover' | 'roofr' | 'regrid' | 'osm';
  
  // Check if provider has necessary credentials and supports address
  supports(address: any): Promise<boolean>;
  
  // Run measurement for property
  run(input: {
    address?: any;
    lat?: number;
    lng?: number;
    propertyId: string;
  }): Promise<MeasureResult>;
}
```

**Provider Ranking** (Priority Order):
1. **EagleView** - Premium 3D measurements + property data
2. **Nearmap** - Aerial imagery + AI roof detection
3. **HOVER** - 3D modeling + measurements
4. **Roofr** - DIY/ordered instant reports
5. **Regrid** - Parcel + building footprints (ACTIVE)
6. **OSM** - OpenStreetMap building footprints (fallback)

### Provider Orchestration Service
**File**: `src/lib/measure/service.ts`

```typescript
export async function autoMeasure(
  input: MeasureInput,
  providers: MeasureProvider[]
): Promise<MeasureResult> {
  const errors: Array<{ provider: string; error: string }> = [];
  
  for (const provider of providers) {
    try {
      const supported = await provider.supports(input.address);
      if (!supported) {
        continue;
      }
      
      const result = await provider.run(input);
      
      // Check if result has valid faces
      if (result.faces && result.faces.length > 0) {
        return result;
      }
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Unknown error';
      errors.push({ provider: provider.name, error: errorMsg });
      console.warn(`Provider ${provider.name} failed:`, errorMsg);
    }
  }
  
  // All providers failed or returned empty results
  throw new Error(
    `No provider available. Tried: ${errors.map(e => e.provider).join(', ')}. ` +
    `Use Manual-Measure instead.`
  );
}
```

---

## ✅ Current Implementation Status

### ✅ Implemented
- ✅ Manual measurement with Google Maps Drawing
- ✅ Polygon (roof face) drawing with area calculation
- ✅ Polyline (linear feature) drawing with length calculation
- ✅ Pitch factor application (flat → 12/12)
- ✅ Waste percentage (10%, 12%, 15%, 20%)
- ✅ Edge type classification (ridge, hip, valley, eave, rake, etc.)
- ✅ WKT geometry storage (PostGIS compatible)
- ✅ Database storage with RLS policies
- ✅ React Query integration with optimistic updates
- ✅ Auto-measure via **Regrid** building footprints
- ✅ Latest measurement display in UI
- ✅ Squares calculation (sqft / 100)

### ⚠️ Partially Implemented
- ⚠️ Provider architecture (stubs created, only Regrid active)
- ⚠️ Auto-measure orchestration (exists but only uses Regrid)
- ⚠️ Linear features on faces (schema exists but not used in auto-measure)

### ❌ Not Implemented
- ❌ **EagleView** provider integration
- ❌ **Nearmap** provider integration
- ❌ **HOVER** provider integration
- ❌ **Roofr** provider integration
- ❌ **OSM** fallback provider
- ❌ Measurement editing/deletion UI
- ❌ Measurement versioning (currently overwrites)
- ❌ Measurement comparison (manual vs auto)
- ❌ 3D visualization of roof (all providers support this)
- ❌ Material takeoff calculations
- ❌ Cost estimation based on measurements
- ❌ Export to PDF/CAD formats
- ❌ Measurement approval workflow
- ❌ Multi-building support on single property
- ❌ Roof complexity scoring
- ❌ Provider result caching
- ❌ Measurement audit log

---

## 🚀 Improvement Opportunities

### **1. Complete Provider Integrations** 🔥 HIGH PRIORITY

#### EagleView Integration
**API**: https://developer.eagleview.com/
**Features**:
- Premium aerial imagery (recent)
- AI-detected roof faces with slopes
- Comprehensive measurements (ridges, hips, valleys, etc.)
- Material recommendations

**Implementation Checklist**:
```typescript
// src/lib/measure/providers/eagleview.ts
export const eagleviewProvider = (apiKey: string): MeasureProvider => ({
  name: 'eagleview',
  
  async supports(address) {
    // Check if API key exists
    // Optionally: Check coverage area via API
    return !!apiKey;
  },
  
  async run({ address, propertyId }) {
    // 1. Create report order
    const orderResponse = await fetch('https://api.eagleview.com/v1/reports', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        address: `${address.line1}, ${address.city}, ${address.state} ${address.postal_code}`,
        product: 'PREMIUM_ROOF_REPORT'
      })
    });
    
    // 2. Poll for completion or use webhook
    // 3. Parse response → RoofFace[] + LinearFeature[]
    // 4. Return MeasureResult
  }
});
```

**Cost**: ~$15-50 per report depending on product tier
**Turnaround**: 24-48 hours (Premium), 1-4 hours (Rush)

---

#### Nearmap Integration
**API**: https://docs.nearmap.com/
**Features**:
- Ultra-high-res aerial imagery (2.5cm resolution)
- AI roof detection API
- 3D mesh + DSM (Digital Surface Model)
- Oblique imagery (4 angles)

**Implementation**:
```typescript
// src/lib/measure/providers/nearmap.ts
export const nearmapProvider = (token: string): MeasureProvider => ({
  name: 'nearmap',
  
  async run({ lat, lng }) {
    // 1. Call AI Features API
    const response = await fetch(
      `https://api.nearmap.com/ai/features/v4/roofs.json?lat=${lat}&lng=${lng}`,
      {
        headers: { 'Authorization': `Bearer ${token}` }
      }
    );
    
    // 2. Parse GeoJSON features
    // 3. Extract roof polygons + attributes
    // 4. Convert to RoofFace[] with pitch estimates
  }
});
```

**Cost**: Subscription-based, typically $500-2000/month for API access
**Turnaround**: Instant (if imagery exists for location)

---

### **2. Enhance Manual Measurement UX** 🎨 MEDIUM PRIORITY

**Current Pain Points**:
- No visual confirmation of drawn shapes
- Can't edit existing measurements
- No undo/redo functionality
- No snap-to-grid or alignment helpers
- No measurement validation warnings

**Proposed Improvements**:

#### A. Visual Overlays on Map
```typescript
// Store drawn polygons on map for visual reference
const [mapOverlays, setMapOverlays] = useState<google.maps.Polygon[]>([]);

// After drawing, keep polygon visible with label
polygon.setOptions({ 
  editable: false,
  clickable: true,
  label: face.id  // 'A', 'B', 'C'
});

// Color-code by pitch
const pitchColors = {
  'flat': '#94a3b8',
  '6/12': '#3b82f6',
  '12/12': '#dc2626',
};
```

#### B. Measurement Editing
```typescript
// Add "Edit" button next to each face in list
<Button onClick={() => enterEditMode(face)}>
  <Edit2 className="h-3 w-3" />
</Button>

// Make polygon editable
polygon.setEditable(true);

// Listen for vertex changes
google.maps.event.addListener(polygon.getPath(), 'set_at', recalculateArea);
google.maps.event.addListener(polygon.getPath(), 'insert_at', recalculateArea);
```

#### C. Measurement Validation
```typescript
// Warn about unrealistic measurements
if (face.area_sqft > 10000) {
  toast.warning('Large roof face detected (>10,000 sqft). Please verify.');
}

// Warn about very steep pitches
if (pitchFactor(face.pitch) > 1.5) {
  toast.warning('Steep pitch (>12/12). Ensure safety considerations.');
}

// Warn about missing linear features for large roofs
if (totalArea > 2000 && linearFeatures.length === 0) {
  toast.info('Consider adding ridge/valley measurements for accuracy.');
}
```

---

### **3. Add Measurement Versioning** 📚 MEDIUM PRIORITY

**Current Problem**: New measurements overwrite old ones (no history)

**Proposed Schema Change**:
```sql
ALTER TABLE measurements
  ADD COLUMN version INT DEFAULT 1,
  ADD COLUMN supersedes UUID REFERENCES measurements(id),
  ADD COLUMN is_active BOOLEAN DEFAULT true;

-- Update query to get latest active measurement
CREATE INDEX idx_measurements_active ON measurements(property_id, is_active, created_at DESC);
```

**UI Changes**:
```typescript
// Show version history in dropdown
<Select value={selectedVersion} onValueChange={setSelectedVersion}>
  {measurements.map(m => (
    <SelectItem value={m.id}>
      v{m.version} - {m.source} - {formatDate(m.created_at)}
    </SelectItem>
  ))}
</Select>

// "Compare" button to diff versions
<Button onClick={() => compareVersions(v1, v2)}>
  Compare v1 vs v2
</Button>
```

---

### **4. Integration with Estimation System** 💰 HIGH PRIORITY

**Current State**: Measurements exist independently from estimates

**Proposed Integration**:

#### Link Measurements to Estimates
```sql
-- Add foreign key to estimates table
ALTER TABLE estimates
  ADD COLUMN measurement_id UUID REFERENCES measurements(id);
```

#### Auto-Calculate Material Quantities
```typescript
// In estimate computation
const measurement = await fetchMeasurement(estimate.measurement_id);

// Calculate shingles needed
const totalSquares = measurement.summary.total_squares;
const shingleBundles = Math.ceil(totalSquares * 3); // 3 bundles per square

// Calculate ridge cap
const ridgeLinear = measurement.linear_features
  .filter(f => f.type === 'ridge')
  .reduce((sum, f) => sum + f.length_ft, 0);
const ridgeCapBundles = Math.ceil(ridgeLinear / 33); // 33 LF per bundle

// Calculate valleys
const valleyLinear = measurement.linear_features
  .filter(f => f.type === 'valley')
  .reduce((sum, f) => sum + f.length_ft, 0);
const valleyRolls = Math.ceil(valleyLinear / 50); // 50 LF per roll
```

#### Template Item Qty Formulas
Enhance `template_items.qty_formula` to support:
```typescript
// Current: Simple 'squares' formula
qty_formula: 'squares'

// Proposed: Advanced formulas
qty_formula: 'squares * 3'                    // Shingle bundles
qty_formula: 'linear_ft(ridge) / 33'          // Ridge cap
qty_formula: 'linear_ft(valley) / 50'         // Valley material
qty_formula: 'linear_ft(rake + eave) / 100'   // Drip edge
qty_formula: 'faces.length * 2'               // Vents (2 per face)
```

**Parser for Formulas**:
```typescript
// src/lib/estimate/formulaParser.ts
export function evaluateFormula(
  formula: string, 
  measurement: MeasureResult
): number {
  const context = {
    squares: measurement.summary.total_squares,
    faces: measurement.faces,
    linear_ft: (type: EdgeType) => {
      return measurement.linear_features
        ?.filter(f => f.type === type)
        .reduce((sum, f) => sum + f.length_ft, 0) || 0;
    }
  };
  
  // Use safe eval or math.js library
  return evaluateExpression(formula, context);
}
```

---

### **5. 3D Visualization** 🎨 LOW PRIORITY (Future Enhancement)

**Technologies**:
- **Three.js** - 3D rendering library
- **Deck.gl** - Geospatial 3D visualization
- **Mapbox GL JS** - 3D terrain + buildings

**Example with Three.js**:
```typescript
// Convert WKT polygon + pitch → 3D roof mesh
function create3DRoof(face: RoofFace): THREE.Mesh {
  // 1. Parse WKT to coordinates
  const coords = parseWKT(face.wkt);
  
  // 2. Create base polygon shape
  const shape = new THREE.Shape(
    coords.map(c => new THREE.Vector2(c[0], c[1]))
  );
  
  // 3. Extrude based on pitch
  const [rise, run] = face.pitch.split('/').map(Number);
  const height = (rise / run) * maxRoofWidth / 2;
  
  const geometry = new THREE.ExtrudeGeometry(shape, {
    depth: height,
    bevelEnabled: false
  });
  
  // 4. Apply material
  const material = new THREE.MeshStandardMaterial({
    color: 0x8b4513,  // Shingle brown
    roughness: 0.8
  });
  
  return new THREE.Mesh(geometry, material);
}
```

---

### **6. Export & Reporting** 📄 MEDIUM PRIORITY

**Export Formats**:
- **PDF Report** - Customer-facing measurement report
- **DXF/DWG** - CAD integration for installers
- **CSV** - Spreadsheet for material ordering
- **GeoJSON** - GIS integration

**Example PDF Generation**:
```typescript
// Using pdf-lib (already in package.json)
import { PDFDocument, rgb } from 'pdf-lib';

async function generateMeasurementPDF(measurement: MeasureResult): Promise<Blob> {
  const pdfDoc = await PDFDocument.create();
  const page = pdfDoc.addPage([612, 792]); // Letter size
  
  // Title
  page.drawText('Roof Measurement Report', {
    x: 50,
    y: 750,
    size: 24,
    color: rgb(0, 0, 0)
  });
  
  // Summary
  page.drawText(`Total Area: ${measurement.summary.total_area_sqft} sqft`, {
    x: 50,
    y: 700,
    size: 14
  });
  
  // Face breakdown
  let y = 650;
  measurement.faces.forEach((face, i) => {
    page.drawText(`Face ${face.id}: ${face.area_sqft} sqft @ ${face.pitch} pitch`, {
      x: 50,
      y: y - (i * 30),
      size: 12
    });
  });
  
  // Embed map screenshot
  // ... (use Google Maps Static API)
  
  const pdfBytes = await pdfDoc.save();
  return new Blob([pdfBytes], { type: 'application/pdf' });
}
```

---

## 🔧 Technical Debt

### **1. Error Handling** ⚠️
**Current State**: Minimal error handling in providers
```typescript
// src/lib/measure/service.ts - Lines 27-31
catch (error) {
  const errorMsg = error instanceof Error ? error.message : 'Unknown error';
  errors.push({ provider: provider.name, error: errorMsg });
  console.warn(`Provider ${provider.name} failed:`, errorMsg);
}
```

**Issues**:
- No retry logic for transient failures
- No exponential backoff
- No circuit breaker pattern
- Generic error messages to user

**Recommended Fix**:
```typescript
import { retryWithBackoff } from '@/lib/retry';

async function runProviderWithRetry(
  provider: MeasureProvider,
  input: MeasureInput
): Promise<MeasureResult> {
  return retryWithBackoff(
    () => provider.run(input),
    {
      maxRetries: 3,
      baseDelay: 1000,
      maxDelay: 10000,
      onRetry: (attempt, error) => {
        console.warn(`Provider ${provider.name} attempt ${attempt} failed:`, error);
      }
    }
  );
}
```

---

### **2. Input Validation** ⚠️
**Current State**: Basic null checks
```typescript
// supabase/functions/measure/index.ts - Lines 40-45
if (!propertyId || !faces || !Array.isArray(faces)) {
  return new Response(
    JSON.stringify({ error: 'Missing required fields: propertyId, faces' }),
    { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  );
}
```

**Missing Validations**:
- Face area > 0
- WKT format validation
- Pitch format validation (e.g., '6/12')
- Reasonable area limits (< 100,000 sqft)
- Coordinate bounds validation

**Recommended Fix**:
```typescript
import { z } from 'zod';

const RoofFaceSchema = z.object({
  id: z.string().regex(/^[A-Z]$/),
  wkt: z.string().regex(/^POLYGON\(\(.+\)\)$/),
  area_sqft: z.number().min(1).max(100000),
  pitch: z.string().regex(/^\d+\/\d+$/).optional(),
});

const ManualMeasureSchema = z.object({
  propertyId: z.string().uuid(),
  faces: z.array(RoofFaceSchema).min(1).max(50),
  linear_features: z.array(LinearFeatureSchema).optional(),
  waste_pct: z.number().min(0).max(50).default(12),
});

// In edge function
const body = ManualMeasureSchema.parse(await req.json());
```

---

### **3. Performance Optimization** ⚠️

**Current Bottlenecks**:
1. **Shoelace area calculation** - O(n) for each polygon vertex
2. **No spatial indexing** - Full table scans on measurements
3. **No caching** - Re-fetching latest measurement on every page load

**Recommended Optimizations**:

#### A. Use PostGIS for Area Calculation
```sql
-- Instead of calculating in JavaScript, use PostGIS
ALTER TABLE measurements
  ADD COLUMN geom GEOMETRY(POLYGON, 4326);

-- Create spatial index
CREATE INDEX idx_measurements_geom ON measurements USING GIST(geom);

-- Calculate area in SQL
SELECT 
  ST_Area(ST_Transform(geom, 3857)) * 10.7639 AS area_sqft
FROM measurements;
```

#### B. Add Caching Layer
```typescript
// Use React Query's staleTime + cacheTime
const { data: latestMeasurement } = useQuery({
  queryKey: ['measurement', propertyId],
  queryFn: fetchLatestMeasurement,
  staleTime: 5 * 60 * 1000,     // 5 minutes
  cacheTime: 10 * 60 * 1000,    // 10 minutes
});

// Or use SWR for background revalidation
import useSWR from 'swr';
const { data } = useSWR(['measurement', propertyId], fetchLatestMeasurement, {
  revalidateOnFocus: false,
  revalidateOnReconnect: true,
  dedupingInterval: 60000,
});
```

---

### **4. Type Safety** ⚠️
**Current State**: `any` types used in multiple places

**Issues Found**:
```typescript
// src/components/Canvassing/MeasurePanel.tsx - Line 12
address?: any;

// src/hooks/useMeasurements.ts - Line 51
address?: any;
```

**Recommended Fix**:
```typescript
// Create proper types
interface PropertyAddress {
  line1: string;
  line2?: string;
  city: string;
  state: string;
  postal_code: string;
  country?: string;
}

// Use in components
interface MeasurePanelProps {
  addressHash: string | null;
  address?: PropertyAddress;
  lat?: number;
  lng?: number;
}
```

---

### **5. Testing Coverage** ❌
**Current State**: No tests for measurement system

**Recommended Test Suite**:

#### Unit Tests
```typescript
// src/lib/measure/util.test.ts
describe('pitchFactor', () => {
  it('should return 1 for flat pitch', () => {
    expect(pitchFactor('flat')).toBe(1);
  });
  
  it('should calculate 6/12 pitch correctly', () => {
    expect(pitchFactor('6/12')).toBeCloseTo(1.118, 3);
  });
  
  it('should return 1 for invalid pitch', () => {
    expect(pitchFactor('invalid')).toBe(1);
  });
});

// src/lib/measure/service.test.ts
describe('autoMeasure', () => {
  it('should try providers in order', async () => {
    const mockProvider1 = { name: 'test1', supports: () => false, run: jest.fn() };
    const mockProvider2 = { name: 'test2', supports: () => true, run: jest.fn() };
    
    await autoMeasure(input, [mockProvider1, mockProvider2]);
    
    expect(mockProvider1.run).not.toHaveBeenCalled();
    expect(mockProvider2.run).toHaveBeenCalled();
  });
});
```

#### Integration Tests
```typescript
// tests/e2e/measurement.spec.ts
test('should create manual measurement', async ({ page }) => {
  await page.goto('/canvassing');
  
  // Select property
  await page.click('[data-testid="property-marker"]');
  
  // Click Manual button
  await page.click('[data-testid="manual-measure-btn"]');
  
  // Draw polygon (simulate map clicks)
  await page.click('[data-testid="google-map"]', { position: { x: 100, y: 100 } });
  await page.click('[data-testid="google-map"]', { position: { x: 200, y: 100 } });
  await page.click('[data-testid="google-map"]', { position: { x: 200, y: 200 } });
  await page.click('[data-testid="google-map"]', { position: { x: 100, y: 200 } });
  await page.click('[data-testid="google-map"]', { position: { x: 100, y: 100 } }); // Close polygon
  
  // Save measurement
  await page.click('[data-testid="save-measurement-btn"]');
  
  // Verify success toast
  await expect(page.locator('text=Measurement saved successfully')).toBeVisible();
});
```

---

## 🚧 Future Enhancements

### **Phase 1: Core Stability** (Q1 2025)
- ✅ Complete provider integrations (EagleView, Nearmap, HOVER)
- ✅ Add comprehensive error handling + retries
- ✅ Implement input validation (Zod schemas)
- ✅ Add measurement versioning
- ✅ Write unit + integration tests

### **Phase 2: UX Improvements** (Q2 2025)
- ✅ Visual overlays on map for drawn shapes
- ✅ Measurement editing functionality
- ✅ Undo/redo support
- ✅ Measurement validation warnings
- ✅ Comparison mode (manual vs auto)

### **Phase 3: Estimation Integration** (Q3 2025)
- ✅ Link measurements to estimates
- ✅ Advanced qty formulas for template items
- ✅ Auto-calculate material quantities from linear features
- ✅ Cost estimation based on measurements
- ✅ Material takeoff reports

### **Phase 4: Advanced Features** (Q4 2025)
- ✅ 3D roof visualization (Three.js or Deck.gl)
- ✅ Multi-building support on properties
- ✅ Roof complexity scoring algorithm
- ✅ Export to PDF/DXF/GeoJSON
- ✅ Mobile measurement app (PWA)
- ✅ AI-powered quality assurance (flag suspicious measurements)

### **Phase 5: Enterprise** (2026)
- ✅ Measurement approval workflow
- ✅ Audit logging for compliance
- ✅ Bulk measurement import/export
- ✅ Custom provider integrations (plugin system)
- ✅ Real-time collaboration (multiple users measuring same property)
- ✅ Integration with drone capture systems

---

## 📚 Developer Resources

### API Documentation
- **EagleView**: https://developer.eagleview.com/docs
- **Nearmap**: https://docs.nearmap.com/display/ND/AI+Feature+API
- **HOVER**: https://developers.hover.to/
- **Regrid**: https://regrid.com/api/parcels

### Libraries Used
- **Google Maps Drawing**: https://developers.google.com/maps/documentation/javascript/drawinglayer
- **PostGIS**: https://postgis.net/documentation/
- **pdf-lib**: https://pdf-lib.js.org/
- **Zod**: https://zod.dev/

### Key Files Quick Reference
```
Frontend:
  src/components/Canvassing/MeasurePanel.tsx         - Main UI
  src/components/Canvassing/RoofMeasurementTools.tsx - Drawing tools
  src/components/Canvassing/MeasurementDrawingManager.tsx - Map integration
  src/hooks/useMeasurements.ts                       - Data fetching
  
Backend:
  supabase/functions/measure/index.ts                - Edge function
  
Types & Utils:
  src/lib/measure/types.ts                           - TypeScript types
  src/lib/measure/util.ts                            - Pitch/area calculations
  src/lib/measure/service.ts                         - Provider orchestration
  
Providers:
  src/lib/measure/providers/regrid.ts                - Active (building footprints)
  src/lib/measure/providers/eagleview.ts             - Stub
  src/lib/measure/providers/nearmap.ts               - Stub
  src/lib/measure/providers/hover.ts                 - Stub
  src/lib/measure/providers/roofr.ts                 - Stub
  src/lib/measure/providers/manual.ts                - Stub
```

---

## 🤝 Contributing Guidelines

### Before Starting Work:
1. Read this document thoroughly
2. Review existing measurement edge cases in database
3. Test with real addresses in different regions
4. Consider mobile/tablet drawing UX

### Code Standards:
- **TypeScript strict mode** - No `any` types
- **Zod validation** - All external inputs
- **Error boundaries** - Wrap UI components
- **Loading states** - Show spinners/skeletons
- **Optimistic updates** - Use React Query mutations
- **Accessibility** - ARIA labels on drawing tools

### Testing Checklist:
- [ ] Unit tests for utilities (pitch calculation, WKT parsing)
- [ ] Integration tests for edge functions
- [ ] E2E tests for manual drawing flow
- [ ] Provider mocks for testing without API keys
- [ ] Test with various roof shapes (L-shape, U-shape, complex)
- [ ] Test edge cases (very small, very large, invalid coordinates)

---

## 🆘 Common Issues & Solutions

### Issue: "Auto-measure not configured"
**Cause**: Missing `REGRID_API_KEY` in Supabase secrets
**Solution**: 
```bash
# Add secret via Supabase CLI
supabase secrets set REGRID_API_KEY=your_key_here

# Or via Supabase Dashboard: Settings → Edge Functions → Secrets
```

### Issue: Google Maps drawing not working
**Cause**: Drawing library not loaded
**Solution**: Ensure `libraries: ['drawing', 'geometry']` in GoogleMapsProvider:
```typescript
<LoadScript
  googleMapsApiKey={apiKey}
  libraries={['drawing', 'geometry']}  // Required!
>
```

### Issue: Area calculation incorrect
**Cause**: Missing pitch factor or waste percentage
**Solution**: Check pitch is applied before saving:
```typescript
const factor = pitchFactor(currentPitch);
const adjustedArea = applyWaste(planArea * factor, wastePct);
```

### Issue: WKT geometry not displaying
**Cause**: Coordinates in wrong order (should be lng,lat not lat,lng)
**Solution**: WKT format is `POLYGON((lng lat, lng lat, ...))`

---

## 📞 Support & Questions

For questions about this system, contact:
- **Architecture**: Review this document + code comments
- **Database**: Check `supabase/migrations/` for schema
- **Provider APIs**: See vendor documentation links above
- **Bugs**: Create GitHub issue with reproduction steps

---

**Last Updated**: 2025-01-14
**Document Version**: 1.0
**Maintained By**: Development Team
