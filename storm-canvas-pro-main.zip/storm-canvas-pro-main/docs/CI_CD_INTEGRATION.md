# CI/CD Integration Guide

## Environment Verification

This project includes automated environment validation for CI/CD pipelines.

### GitHub Actions

Add this step to your workflow:

```yaml
name: Build and Deploy
on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  build:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
    
    - name: Install dependencies
      run: npm install
    
    - name: Verify Environment Configuration
      run: bash scripts/ci-verify-env.sh
      env:
        VITE_SUPABASE_URL: ${{ secrets.VITE_SUPABASE_URL }}
        VITE_SUPABASE_ANON_KEY: ${{ secrets.VITE_SUPABASE_ANON_KEY }}
        VITE_MAPBOX_TOKEN: ${{ secrets.VITE_MAPBOX_TOKEN }}
        VITE_SKIPTRACE_BASE_URL: ${{ secrets.VITE_SKIPTRACE_BASE_URL }}
        VITE_SKIPTRACE_API_KEY: ${{ secrets.VITE_SKIPTRACE_API_KEY }}
        VITE_APP_ENV: production
        VITE_SENTRY_DSN: ${{ secrets.VITE_SENTRY_DSN }}
    
    - name: Build
      run: npm run build
```

### Vercel

Add environment variables in Vercel dashboard and include this build command:

```bash
bash scripts/ci-verify-env.sh && npm run build
```

### Netlify

Add environment variables in Netlify dashboard and set build command:

```bash
bash scripts/ci-verify-env.sh && npm run build
```

### Manual Verification

```bash
# Verify current environment
node scripts/verify-env.js

# Or use the CI script
bash scripts/ci-verify-env.sh
```

## Required Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `VITE_SUPABASE_URL` | Supabase project URL | ✅ |
| `VITE_SUPABASE_ANON_KEY` | Supabase anonymous key | ✅ |
| `VITE_MAPBOX_TOKEN` | Mapbox public token | ✅ |
| `VITE_SKIPTRACE_BASE_URL` | Skiptrace API base URL | ✅ |
| `VITE_SKIPTRACE_API_KEY` | Skiptrace API key | ✅ |
| `VITE_APP_ENV` | App environment (development/staging/production) | ✅ |
| `VITE_SENTRY_DSN` | Sentry error tracking DSN | ❌ |

## Security Notes

- Never commit `.env.local` files
- All secret values are redacted in error messages
- Failed builds prevent deployment with invalid configuration
- Verification runs before any build processes