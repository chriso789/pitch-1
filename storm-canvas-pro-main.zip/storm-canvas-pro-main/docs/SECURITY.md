# Security Architecture

## Overview
Canvass-IQ implements defense-in-depth security with multiple layers protecting sensitive homeowner PII and business data.

## Authentication
- **Method**: Supabase Auth with JWT tokens
- **Required**: All API endpoints require valid JWT (verify_jwt = true)
- **Session Management**: Automatic token refresh, secure httpOnly cookies

## Authorization (RBAC)
- **Roles**: admin, moderator, user (stored in `user_roles` table)
- **Function**: `has_role(_user_id, _role)` - security definer function
- **RLS Policies**: All tables have Row Level Security enabled

## Critical Security Controls

### 1. PII Protection
- **Homeowner data**: Name, phone, email, mailing address
- **Access control**: Users can only view properties they created
- **Logging**: All PII redacted from logs using structured logger
- **Caching**: Owner data cached 30 days to prevent excessive API calls

### 2. Input Validation
- **All inputs validated** using Zod schemas
- **Length limits** enforced on all text fields
- **Type checking** for coordinates, UUIDs, emails
- **Sanitization** prevents injection attacks

### 3. Rate Limiting
- **locations-details**: 5 requests/min per user
- **save-google-maps-key**: Admin only
- **map functions**: 10 requests/min per user
- **skip-trace**: 10 requests/min per user

### 4. Audit Logging
All security-sensitive operations logged:
- Property detail access
- API key changes
- Unauthorized access attempts
- Admin actions

## Edge Function Security Patterns

### Required Security Stack
```typescript
import { authenticateRequest } from '../_shared/auth.ts';
import { Logger, auditLog } from '../_shared/logger.ts';
import { checkRateLimit } from '../_shared/rateLimit.ts';
import { z } from 'zod';

// 1. Authenticate
const { user, error } = await authenticateRequest(req);
if (!user) return unauthorized();

// 2. Validate input
const schema = z.object({...});
const validated = schema.parse(await req.json());

// 3. Check rate limit
const rateLimit = await checkRateLimit(...);
if (!rateLimit.allowed) return rateLimitResponse();

// 4. Authorize (verify ownership/role)
if (resource.created_by !== user.id) return forbidden();

// 5. Audit log
await auditLog(logger, 'ACTION_NAME', user.id, {...});
```

## Security Best Practices
1. Never use SERVICE_ROLE_KEY in client-accessible functions
2. Always use authenticated Supabase clients (respects RLS)
3. Validate all inputs before processing
4. Redact PII from all logs
5. Rate limit all expensive operations
6. Audit log all security-sensitive actions
7. Return generic error messages to prevent information disclosure

## Incident Response
See `docs/SECURITY_RUNBOOK.md` for detailed procedures.
