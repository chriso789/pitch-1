# Authentication Guide

## Overview
Canvass-IQ uses Supabase Auth for secure user authentication with JWT tokens.

## Authentication Methods
1. **Email/Password** - Primary method
2. **Magic Link** - Passwordless email authentication
3. **OAuth (Google)** - Social login

## Implementation

### Client-Side (React)
```typescript
import { useAuth } from '@/components/AuthProvider';

const { user, signIn, signOut, isAdmin } = useAuth();

// Sign in
await signIn(email, password);

// Check admin status
if (isAdmin) {
  // Admin-only features
}
```

### Server-Side (Edge Functions)
```typescript
import { authenticateRequest, requireAdmin } from '../_shared/auth.ts';

// Authenticate user
const { user, error } = await authenticateRequest(req);
if (!user) return unauthorized();

// Require admin role
const { isAdmin, errorResponse } = await requireAdmin(user.id, supabase);
if (!isAdmin) return errorResponse;
```

## Session Management
- **Token Storage**: Secure httpOnly cookies
- **Auto-refresh**: Tokens refreshed automatically before expiration
- **Expiry**: 1 hour (configurable in supabase/config.toml)

## Security Features
- Password hashing with bcrypt
- Email confirmation (configurable)
- Rate limiting on auth endpoints
- Leaked password protection
- Account lockout after failed attempts

## JWT Structure
```json
{
  "sub": "user_id",
  "email": "user@example.com",
  "role": "authenticated",
  "iat": 1234567890,
  "exp": 1234571490
}
```

## Best Practices
1. Always validate JWT on server-side
2. Never trust client-side role claims
3. Use `has_role()` function for role checks
4. Implement proper session timeout
5. Log all authentication failures
