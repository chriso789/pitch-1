// (Copied from v2) Portal UI placeholder
