// (Copied from v2) Project Details UI placeholder
