// (Copied from v2) Estimate Builder UI placeholder
