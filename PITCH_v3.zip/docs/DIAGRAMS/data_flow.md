
```mermaid
flowchart LR
  A[Lead] --> B[LEGAL_REVIEW]
  B --> C[CONTINGENCY_SIGNED]
  C --> D[Project Created]
  D --> E[Original Budget Snapshot]
  E --> F[POs / Labor / Actuals]
  D --> G[Invoice -> Payment]
  G -->|Webhook| H[QuickBooks]
  F --> I[Profit Card]
```
