
```mermaid
graph TB
  FE[Next.js Web] --> API[NestJS API]
  RN[React Native] --> API
  API --> PG[(Postgres + PostGIS)]
  API --> S3[(S3)]
  API --> R[Redis/BullMQ]
  API --> OUT[Outbox Dispatcher]
  OUT --> QB[QuickBooks]
  OUT --> DS[DocuSign]
  OUT --> TW[Twilio]
  OUT --> SUP[Supplier APIs]
```
