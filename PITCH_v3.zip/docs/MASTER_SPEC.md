# PITCH — MASTER SPEC (End-to-End)

## Product mission
Make **profit** and **project status** unmissable. Prevent every common revenue leak: missed calls, moving budgets, bad estimates, slow AP/AR reconciliation, and permissions sloppiness.

## Core pillars
1. **Profit-first Projecting** — Original Budget (locked) vs Actuals (live) vs Commission & Overhead per rep.
2. **Estimate from Parameters** — Supplier pricebooks + templates; reps enter a few numbers; margin guardrails ensure viability.
3. **Never miss a call** — Dialer + IVR with AI fallback to menu; appointment booking via phone.
4. **Clean integrations** — QuickBooks, DocuSign, Suppliers; idempotent, outbox-driven, resilient.
5. **Homeowner portal** — Controlled visibility for photos/docs/balance/messages.

## Architecture
- **Monorepo** (TypeScript): NestJS API (`/backend`), Next.js web (`/frontend`), RN mobile (`/mobile`), workers (`/automation`).
- **DB**: Postgres 15+ + PostGIS + `pgcrypto` + `citext`. Multi-tenant with **Row-Level Security** (RLS).
- **Storage**: S3-compatible for photos/docs.
- **Queue**: Redis + BullMQ; optional Temporal for long-running workflows.
- **Auth**: JWT + refresh; service-to-service via signed HMAC.
- **Infra**: Docker locally; Kubernetes or ECS in prod. Outbox for external sync. All writes audited.

## Data model (summary)
- Tenancy: `tenants`
- Users & RBAC: `users` (role in {MASTER, COMPANY_ADMIN, SALES_MANAGER, SALES_REP, OFFICE})
- Contacts/Leads/Projects:
  - Pipeline: CONTACT → LEAD → **LEGAL_REVIEW** → **CONTINGENCY_SIGNED** → PROJECT → COMPLETED → CLOSED (+ LOST/CANCELED/DUPLICATE)
- Estimating:
  - `pricebook_versions`, `pricebook_items`
  - `estimate_templates` (params + formula lines)
  - `estimates` (+ parameters, line items, snapshot of pricebook version, overhead %, target margin, selling price)
  - Guardrails: `tenant_profit_policies` + trigger
- Finance:
  - Estimates → (Approved) → Original Budget snapshot → Invoices
  - Payments: provider abstraction + `payment_intents`, `payment_transactions`
  - QuickBooks sync via outbox/webhooks
- Costs & Profit:
  - `project_budget_snapshots` (immutable), `project_costs` (actuals), `rep_overhead_rules`, `commission_plans`, `project_commissions`
- Comms:
  - `threads` & `messages` (HOMEOWNER vs INTERNAL), `calls`, `extensions`, IVR flows
- Portal:
  - `tenant_portal_settings`, `portal_access_grants`, `document_shares`
- Automation:
  - `automation_workflows`
- Observability & Control:
  - `audit_log`, `outbox`, `idempotency_keys`

## Non-functional requirements
- **Availability**: 99.95% API; dialer failover to menu within 2s if AI fails.
- **Performance**: p95 < 300ms for project/estimate reads; map tiles < 500ms.
- **Security**: RLS enforced; all PII encrypted at rest; secrets via KMS; signed webhooks & API idempotency.
- **Compliance**: TCPA for dialing; DNC enforcement; data retention: 2 years for call recordings by default.
- **Scalability**: 10k active projects, 1M photos/docs, 100+ concurrent reps.

## Critical invariants (no exceptions)
- Budget snapshot is immutable once created.
- Estimate approval cannot bypass min-profit guardrails.
- Commission numbers never shown to homeowners.
- Outbox processes *exactly once* externally; internal events are idempotent.
- Every mutation is audited.

