# Security, Compliance, and Data Governance

- **RLS** on all tenant data; deny-by-default policies.
- **Encryption**: TLS in transit; S3 SSE; KMS for secrets; at-rest encryption for DB volumes.
- **PII**: access via service roles only; least privilege; audit every read of sensitive fields.
- **Webhooks**: HMAC verification; strict IP allowlist where possible.
- **Idempotency**: all POSTs accept `Idempotency-Key` and return consistent results for 24h window.
- **TCPA**: consent capture stored; honor DNC; time-window dialing by contact’s area code time zone.
- **Retention**: Calls 24 months (configurable). Portal tokens 24 hours. Audit logs 18 months.
- **Backups & DR**: PITR for Postgres; daily S3 backups; quarterly restore drills.
- **Secrets**: never in code; use env + secret manager; rotate quarterly.
