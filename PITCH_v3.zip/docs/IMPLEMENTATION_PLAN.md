# Implementation Plan — Start to Finish (Zero-Kink Build)

This plan is **sequenced** and maps to files in the repo. Each phase has acceptance criteria.

## Phase 0 — Project bootstrap
- Monorepo structure, TypeScript strict mode, linting, formatting, pre-commit hooks.
- Docker compose for Postgres+PostGIS, Redis, MinIO.
- CI pipeline (GitHub Actions) with unit tests + SQL lint.

**Files:**
- `package.json`, `tsconfig.base.json`, `.eslintrc.json`, `.prettierrc`
- `docker-compose.yml`
- `.github/workflows/ci.yml`
- `CONTRIBUTING.md`

**Acceptance:**
- `npm run ci` passes locally and on CI.

---

## Phase 1 — Database foundation + RLS
- Apply `db/schema_full.sql` then `db/indexes.sql` and `db/rls_policies.sql`.
- Seed initial tenant, users, roles with `scripts/seed.sql`.
- Add connection health checks.

**Acceptance:**
- RLS prevents cross-tenant reads/writes in integration tests.
- All tables present with required indexes.

---

## Phase 2 — Pipeline entities (Contacts, Leads, Projects)
- CRUD endpoints + OpenAPI docs.
- Status transitions enforce pipeline order (with LEGAL_REVIEW & CONTINGENCY_SIGNED before PROJECT).

**Acceptance:**
- Attempt to skip stages returns 422 with explanation.
- Audit entries written for every state change.

---

## Phase 3 — Estimating (Pricebook, Templates, Guardrails)
1. **Importer**: parse supplier macro files → `pricebook_versions` + `pricebook_items`.
2. **Template builder**: create `estimate_templates` with parameter definitions & line formulas.
3. **Preview** API `/estimates/preview` — compute base costs, overhead, target price to 30% margin by default.
4. **Min-profit enforcement**: DB trigger blocks `SENT`/`APPROVED` below thresholds.
5. **Commission preview**: compute, store outside the homeowner-facing doc.

**Files:**
- `backend/src/modules/estimating/*`
- `tools/importers/supplier_pricebook_import.ts`
- `db/schema_full.sql` (estimating tables) + trigger
- `frontend/src/pages/EstimateBuilder.tsx`

**Acceptance:**
- Given sample template + pricebook, preview returns deterministic totals.
- Attempt to send estimate with margin below policy → rejected.

---

## Phase 4 — Project conversion + Budgets/Actuals
- On APPROVED estimate → create project + `project_budget_snapshots` (immutable).
- `project_costs` accrue from POs/labor; UI shows Original vs Actuals vs variance.

**Acceptance:**
- Editing snapshot is impossible; adding/removing actuals updates profit card live.

---

## Phase 5 — Commission & Overhead
- Implement per-rep overhead rules & commission plans.
- Profit = Sell − (Overhead%×Sell) − Actuals − Commission.

**Files:**
- `backend/src/modules/commission/engine.ts` + tests.
- `db/schema_full.sql` (commission tables).

**Acceptance:**
- Unit tests cover gross %, net %, tiered margin; negative margins clamp to zero for commission base.

---

## Phase 6 — Integrations (Outbox + Webhooks + Idempotency)
- Implement **outbox** table & dispatcher for QuickBooks, Stripe, DocuSign, Suppliers.
- All external POST/PUT use **Idempotency-Key**; retries safe.
- Webhook verification per provider; duplicate events ignored.

**Files:**
- `db/outbox.sql`, `backend/src/modules/outbox/*`
- `backend/src/middleware/idempotency.ts`
- `backend/src/modules/webhooks/verify.ts`

**Acceptance:**
- Killing the worker mid-flight does not duplicate invoices/payments in QB.
- Replay of webhooks produces no changes (idempotent).

---

## Phase 7 — Payments
- Provider abstraction (Stripe first).
- `/payments/checkout` returns redirect URL.
- Webhook creates internal payment, pushes to QB, attaches receipt PDF to the project.

**Acceptance:**
- Card payment appears as a **QuickBooks Payment** linked to the correct **Invoice**.
- Settlement flips transaction to `CLEARED`.

---

## Phase 8 — Dialer & IVR
- Inbound Twilio → AI or DTMF fallback in < 2s; extensions route to users/queues.
- Outbound power-dialer with list segmentation; TCPA/DNC enforced.

**Acceptance:**
- Calls route; no missed-call gaps; audit & recordings present; DNC is enforced.

---

## Phase 9 — Homeowner Portal
- Master-controlled visibility; tokenized access grants.
- Owner can view approved photos/docs, balance, and pay.

**Acceptance:**
- Changing portal settings immediately reflects on portal; no data leakage across projects/tenants.

---

## Phase 10 — Reporting & Map
- PostGIS-backed map with filters (date completed, roof type, color).
- Report builder with saved views and CSV export.

**Acceptance:**
- p95 < 500ms for map queries on 100k locations; reports export within 10s on 100k rows.

---

## Phase 11 — QA, UAT, Launch
- Test matrix (see `docs/QA_PLAN.md`), performance test targets, security review (see `docs/SECURITY_AND_COMPLIANCE.md`).
- Blue/green or canary rollout; rollback plan documented.

**Acceptance:**
- All critical paths green; error budget respected for 2 weeks.

