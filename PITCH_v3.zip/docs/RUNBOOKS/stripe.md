# Runbook — Stripe
- If webhook delivery fails, Stripe retries; ensure signature secrets are rotated yearly.
- Disputes: mark transaction DISPUTED and notify accounting; do not auto-close invoices.
