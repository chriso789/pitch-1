# Runbook — Twilio
- If AI bot flakes, IVR fallback handles calls. Check Gather timeouts and logs.
- Keep a plain DTMF-only IVR flow ready for failover.
