# Runbook — Suppliers
- Pricebook import monthly; validate SKUs coverage units; generate change report before publish.
