# Runbook — QuickBooks
- Monitor outbox queue length and error rate.
- If invoices/payments drift, run reconciliation job.
- Common errors: token expired → re-auth tenant; duplicate LinkedTxn → purge idempotency key and retry.
