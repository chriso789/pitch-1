# QA Plan and Test Matrix

## Types of tests
- **Unit tests**: math (estimating/commission), permission checks, utilities.
- **Integration tests**: RLS, outbox idempotency, webhook verification, QuickBooks and Stripe sandboxes.
- **E2E tests**: critical flows (lead→estimate→approval→project→invoice→payment→closed).
- **Performance**: k6 or artillery.io scripts for map/report endpoints.
- **Security**: static analysis + dependency checks; secrets scanning.

## Acceptance criteria (critical paths)
1. **Estimate guardrails** prevent sending below min profit (both % and $).
2. **Budget snapshot** immutable; trying to modify returns 403.
3. **Payments** end up applied to the right QuickBooks invoice; retries are safe.
4. **Dialer** routes calls with AI fallback; no dead-ends.
5. **Portal** shows only approved docs/photos; toggles reflect immediately.
6. **Map** displays correct pins with filters; performance targets met.
