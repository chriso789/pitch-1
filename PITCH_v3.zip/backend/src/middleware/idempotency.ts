// Express/Nest middleware to enforce Idempotency-Key on mutating requests.
import type { Request, Response, NextFunction } from 'express';

export async function idempotencyMiddleware(req: Request, res: Response, next: NextFunction) {
  if (['POST','PUT','PATCH','DELETE'].includes(req.method)) {
    const key = req.header('Idempotency-Key');
    if (!key) return res.status(400).json({ error: 'Missing Idempotency-Key' });
    // TODO: persist (tenant_id, key, method, route). If exists, return stored response snapshot.
  }
  next();
}
