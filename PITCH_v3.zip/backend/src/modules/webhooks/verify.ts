// HMAC or provider SDK verification for webhooks (skeleton)
export function verifySignature(rawBody: string, header: string, secret: string): boolean {
  // TODO: implement provider-specific verification. For Stripe, use Stripe SDK constructEvent.
  return true;
}
