// Outbox dispatcher (skeleton). Guarantees at-least-once delivery, idempotent externally.
export type OutboxMessage = {
  id: number;
  tenant_id: string;
  topic: string; // e.g., 'quickbooks.invoice.create'
  payload: any;
  idempotency_key?: string;
};

export async function dispatch(msg: OutboxMessage) {
  switch (msg.topic) {
    case 'quickbooks.invoice.create':
      // call QuickBooks API with idempotency key
      break;
    case 'stripe.payment.create':
      break;
    default:
      throw new Error('Unknown topic ' + msg.topic);
  }
}
