import { buildEstimate } from '../modules/estimating/engine';

const template = {
  id: 'tmp',
  name: 'Shingle',
  default_target_margin_pct: 0.30,
  parameters: { roof_squares: { label:'Squares', type:'number', required:true } },
  lines: [
    { sku:'SHINGLE_BUNDLE', formulaQty:'roof_squares * 3 * (1+waste_pct)' }
  ]
};

const pricebook = {
  SHINGLE_BUNDLE: { id:'x', sku:'SHINGLE_BUNDLE', uom:'BUNDLE', unit_cost: 35, coverage_per_unit: 0.333, waste_pct: 0.1 }
};

test('estimate build computes price to target margin', () => {
  const res = buildEstimate({ roof_squares: 30 }, template as any, pricebook as any, 0.1, 0.3);
  expect(res.subtotal_cost).toBeGreaterThan(0);
  expect(res.selling_price).toBeGreaterThan(res.subtotal_cost);
  const margin = (res.selling_price - res.overhead_amount - res.subtotal_cost)/res.selling_price;
  expect(Math.round(margin*100)).toBe(30);
});
