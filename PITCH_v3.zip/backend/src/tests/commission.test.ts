import { computeCommission } from '../modules/commission/engine';

test('gross percent plan', () => {
  const res = computeCommission({ sellingPrice: 20000, actualCosts: 12000, overheadPct: 0.1 }, { kind: 'GROSS_PERCENT', percent: 0.06 });
  expect(res.overheadAmount).toBeCloseTo(2000);
  expect(res.netBeforeCommission).toBeCloseTo(6000);
  expect(res.commission).toBeCloseTo(1200);
  expect(res.profitAfterCommission).toBeCloseTo(4800);
});

test('net percent plan clamps at zero', () => {
  const res = computeCommission({ sellingPrice: 10000, actualCosts: 9500, overheadPct: 0.1 }, { kind: 'NET_PERCENT', percent: 0.1 });
  expect(res.netBeforeCommission).toBeCloseTo(-500);
  expect(res.commission).toBeCloseTo(0);
});
