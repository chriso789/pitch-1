
-- Useful indexes
CREATE INDEX IF NOT EXISTS idx_leads_tenant_status ON leads (tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_projects_tenant_status ON projects (tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_projects_dates ON projects (date_started, date_completed);
CREATE INDEX IF NOT EXISTS idx_addresses_geom ON addresses USING GIST (geom);
CREATE INDEX IF NOT EXISTS idx_costs_project ON project_costs (project_id, incurred_at);
CREATE INDEX IF NOT EXISTS idx_messages_thread ON messages (thread_id, created_at);
CREATE INDEX IF NOT EXISTS idx_outbox_status ON outbox (status, created_at);
CREATE INDEX IF NOT EXISTS idx_idempotency_key ON idempotency_keys (tenant_id, key);
CREATE INDEX IF NOT EXISTS idx_pricebook_items_version ON pricebook_items (pricebook_version_id, sku);
