
-- Enable RLS & basic tenant policy: user must match tenant_id
ALTER TABLE tenants ENABLE ROW LEVEL SECURITY;
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE contacts ENABLE ROW LEVEL SECURITY;
ALTER TABLE addresses ENABLE ROW LEVEL SECURITY;
ALTER TABLE leads ENABLE ROW LEVEL SECURITY;
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE estimates ENABLE ROW LEVEL SECURITY;
ALTER TABLE estimate_line_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE pricebook_versions ENABLE ROW LEVEL SECURITY;
ALTER TABLE pricebook_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE project_budget_snapshots ENABLE ROW LEVEL SECURITY;
ALTER TABLE project_costs ENABLE ROW LEVEL SECURITY;
ALTER TABLE rep_overhead_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE commission_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_commission_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE project_commissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE threads ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE extensions ENABLE ROW LEVEL SECURITY;
ALTER TABLE calls ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE signatures ENABLE ROW LEVEL SECURITY;
ALTER TABLE automation_workflows ENABLE ROW LEVEL SECURITY;
ALTER TABLE tenant_portal_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE portal_access_grants ENABLE ROW LEVEL SECURITY;
ALTER TABLE document_shares ENABLE ROW LEVEL SECURITY;
ALTER TABLE outbox ENABLE ROW LEVEL SECURITY;
ALTER TABLE idempotency_keys ENABLE ROW LEVEL SECURITY;

-- Example policy: actor_tenant_id is set by API per request
CREATE OR REPLACE FUNCTION current_tenant() RETURNS uuid AS $$
  SELECT NULLIF(current_setting('app.tenant_id', true), '')::uuid;
$$ LANGUAGE SQL STABLE;

-- Simple tenant filter policy (expand with role-based conditions in app)
DO $$ BEGIN
  FOR t IN SELECT tablename FROM pg_tables WHERE schemaname='public' AND tablename IN (
    'users','contacts','addresses','leads','projects','estimates','estimate_line_items','pricebook_versions','pricebook_items',
    'project_budget_snapshots','project_costs','rep_overhead_rules','commission_plans','user_commission_plans','project_commissions',
    'invoices','payments','threads','messages','extensions','calls','documents','signatures','automation_workflows',
    'tenant_portal_settings','portal_access_grants','document_shares','outbox','idempotency_keys'
  ) LOOP
    EXECUTE format('CREATE POLICY %I_tenant_policy ON %I USING (tenant_id = current_tenant())', t, t);
  END LOOP;
END $$;

-- Deny by default
ALTER TABLE users FORCE ROW LEVEL SECURITY;
-- ... do FORCE RLS for all as needed (omitted for brevity)
