
-- Extensions
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS citext;

-- ========== Tenancy & Users
CREATE TABLE IF NOT EXISTS tenants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  email CITEXT NOT NULL,
  full_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('MASTER','COMPANY_ADMIN','SALES_MANAGER','SALES_REP','OFFICE')),
  manager_id UUID NULL REFERENCES users(id),
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(tenant_id, email)
);

-- ========== Contacts & Addresses
CREATE TABLE IF NOT EXISTS contacts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  full_name TEXT,
  email CITEXT,
  phone TEXT,
  organization TEXT,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS addresses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  contact_id UUID REFERENCES contacts(id),
  line1 TEXT, line2 TEXT, city TEXT, state TEXT, postal_code TEXT, country TEXT,
  latitude DOUBLE PRECISION, longitude DOUBLE PRECISION,
  geom geometry(Point, 4326),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ========== Pipeline
DO $$ BEGIN
  CREATE TYPE lead_status AS ENUM ('CONTACT','LEAD','LEGAL_REVIEW','CONTINGENCY_SIGNED','PROJECT','COMPLETED','CLOSED','LOST','CANCELED','DUPLICATE');
EXCEPTION WHEN duplicate_object THEN null; END $$;

CREATE TABLE IF NOT EXISTS leads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  contact_id UUID NOT NULL REFERENCES contacts(id),
  address_id UUID REFERENCES addresses(id),
  source TEXT,
  status lead_status NOT NULL DEFAULT 'CONTACT',
  assigned_rep_id UUID REFERENCES users(id),
  assigned_manager_id UUID REFERENCES users(id),
  roof_type TEXT,
  roof_color TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

DO $$ BEGIN
  CREATE TYPE project_status AS ENUM ('PROJECT','COMPLETED','CLOSED','CANCELED');
EXCEPTION WHEN duplicate_object THEN null; END $$;

CREATE TABLE IF NOT EXISTS projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  lead_id UUID NOT NULL REFERENCES leads(id),
  address_id UUID REFERENCES addresses(id),
  status project_status NOT NULL DEFAULT 'PROJECT',
  selling_price NUMERIC(12,2) NOT NULL DEFAULT 0,
  roof_type TEXT,
  roof_color TEXT,
  date_started DATE,
  date_completed DATE,
  rep_id UUID REFERENCES users(id),
  manager_id UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Estimates & Items
CREATE TABLE IF NOT EXISTS estimates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  lead_id UUID NOT NULL REFERENCES leads(id),
  total NUMERIC(12,2) DEFAULT 0,
  status TEXT NOT NULL CHECK (status IN ('DRAFT','SENT','APPROVED','REJECTED')),
  approved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  -- v2 fields
  pricebook_version_id UUID,
  overhead_pct NUMERIC(5,4),
  target_margin_pct NUMERIC(5,4) DEFAULT 0.30,
  selling_price NUMERIC(12,2),
  subtotal_cost NUMERIC(12,2),
  profit_preview NUMERIC(12,2)
);

CREATE TABLE IF NOT EXISTS estimate_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  estimate_id UUID NOT NULL REFERENCES estimates(id) ON DELETE CASCADE,
  category TEXT NOT NULL,
  description TEXT,
  qty NUMERIC(10,2),
  unit_price NUMERIC(12,2),
  total NUMERIC(12,2) GENERATED ALWAYS AS (qty * unit_price) STORED
);

-- Original Budget & Actuals
CREATE TABLE IF NOT EXISTS project_budget_snapshots (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  source_estimate_id UUID REFERENCES estimates(id),
  materials NUMERIC(12,2) NOT NULL DEFAULT 0,
  labor NUMERIC(12,2) NOT NULL DEFAULT 0,
  permits NUMERIC(12,2) NOT NULL DEFAULT 0,
  dumpsters NUMERIC(12,2) NOT NULL DEFAULT 0,
  other NUMERIC(12,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(project_id)
);

DO $$ BEGIN
  CREATE TYPE cost_type AS ENUM ('MATERIALS','LABOR','PERMIT','DUMPSTER','OTHER');
EXCEPTION WHEN duplicate_object THEN null; END $$;

CREATE TABLE IF NOT EXISTS project_costs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  type cost_type NOT NULL,
  vendor TEXT,
  description TEXT,
  amount NUMERIC(12,2) NOT NULL,
  incurred_at DATE NOT NULL DEFAULT CURRENT_DATE,
  source TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Overhead & Commission
CREATE TABLE IF NOT EXISTS rep_overhead_rules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  rep_id UUID NOT NULL REFERENCES users(id),
  overhead_pct NUMERIC(5,4) NOT NULL CHECK (overhead_pct >= 0 AND overhead_pct <= 1),
  effective_from DATE NOT NULL DEFAULT CURRENT_DATE,
  effective_to DATE
);

DO $$ BEGIN
  CREATE TYPE commission_kind AS ENUM ('GROSS_PERCENT','NET_PERCENT','TIERED_MARGIN');
EXCEPTION WHEN duplicate_object THEN null; END $$;

CREATE TABLE IF NOT EXISTS commission_plans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  kind commission_kind NOT NULL,
  config JSONB NOT NULL,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS user_commission_plans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id),
  plan_id UUID NOT NULL REFERENCES commission_plans(id),
  effective_from DATE NOT NULL DEFAULT CURRENT_DATE,
  effective_to DATE
);

CREATE TABLE IF NOT EXISTS project_commissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  rep_id UUID NOT NULL REFERENCES users(id),
  calculated_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  calculated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  details JSONB
);

-- Invoices/Payments (internal) + Provider payments
CREATE TABLE IF NOT EXISTS invoices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  project_id UUID NOT NULL REFERENCES projects(id),
  qb_id TEXT,
  status TEXT CHECK (status IN ('DRAFT','SENT','PAID','VOID')),
  total NUMERIC(12,2) NOT NULL DEFAULT 0,
  balance NUMERIC(12,2) NOT NULL DEFAULT 0,
  issued_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  invoice_id UUID NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  qb_id TEXT,
  amount NUMERIC(12,2) NOT NULL,
  paid_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  method TEXT
);

DO $$ BEGIN
  CREATE TYPE payment_provider AS ENUM ('STRIPE','INTUIT_PAYMENTS','AUTHORIZE_NET');
EXCEPTION WHEN duplicate_object THEN null; END $$;
DO $$ BEGIN
  CREATE TYPE payment_status AS ENUM ('REQUIRES_ACTION','AUTHORIZED','SUCCEEDED','FAILED','REFUNDED','DISPUTED','CLEARED');
EXCEPTION WHEN duplicate_object THEN null; END $$;

CREATE TABLE IF NOT EXISTS payment_connections (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  provider payment_provider NOT NULL,
  config JSONB NOT NULL,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS payment_intents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  provider payment_provider NOT NULL,
  provider_intent_id TEXT NOT NULL,
  invoice_id UUID NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  amount NUMERIC(12,2) NOT NULL,
  currency TEXT NOT NULL DEFAULT 'USD',
  status payment_status NOT NULL DEFAULT 'REQUIRES_ACTION',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(tenant_id, provider, provider_intent_id)
);

CREATE TABLE IF NOT EXISTS payment_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  payment_intent_id UUID NOT NULL REFERENCES payment_intents(id) ON DELETE CASCADE,
  event TEXT NOT NULL,
  status payment_status NOT NULL,
  amount NUMERIC(12,2) NOT NULL,
  meta JSONB,
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Threads & Calls
DO $$ BEGIN
  CREATE TYPE thread_kind AS ENUM ('HOMEOWNER','INTERNAL');
EXCEPTION WHEN duplicate_object THEN null; END $$;

CREATE TABLE IF NOT EXISTS threads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  lead_id UUID,
  project_id UUID,
  kind thread_kind NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  thread_id UUID NOT NULL REFERENCES threads(id) ON DELETE CASCADE,
  author_user_id UUID REFERENCES users(id),
  direction TEXT CHECK (direction IN ('IN','OUT')),
  channel TEXT CHECK (channel IN ('SMS','EMAIL','NOTE','CALL')),
  body TEXT,
  meta JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS extensions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  number TEXT NOT NULL,
  user_id UUID REFERENCES users(id),
  menu_label TEXT,
  ivr_flow_id UUID,
  UNIQUE(tenant_id, number)
);

CREATE TABLE IF NOT EXISTS calls (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  from_number TEXT, to_number TEXT,
  started_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  ended_at TIMESTAMPTZ,
  recording_url TEXT,
  disposition TEXT,
  project_id UUID, lead_id UUID
);

-- Documents & Signatures
CREATE TABLE IF NOT EXISTS documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  lead_id UUID, project_id UUID,
  name TEXT NOT NULL,
  s3_key TEXT NOT NULL,
  mime_type TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS signatures (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  signer_name TEXT, signer_email TEXT,
  provider TEXT CHECK (provider IN ('DOCUSIGN','NATIVE')),
  status TEXT CHECK (status IN ('PENDING','SIGNED','DECLINED','VOID')),
  completed_at TIMESTAMPTZ
);

-- Automation
CREATE TABLE IF NOT EXISTS automation_workflows (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  definition JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Portal
CREATE TABLE IF NOT EXISTS tenant_portal_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  photos_visible BOOLEAN NOT NULL DEFAULT TRUE,
  documents_visible BOOLEAN NOT NULL DEFAULT TRUE,
  balance_visible BOOLEAN NOT NULL DEFAULT TRUE,
  messages_visible BOOLEAN NOT NULL DEFAULT TRUE,
  modified_by UUID REFERENCES users(id),
  modified_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS portal_access_grants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  contact_id UUID NOT NULL REFERENCES contacts(id),
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  token TEXT NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(tenant_id, contact_id, project_id)
);

CREATE TABLE IF NOT EXISTS document_shares (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  visible_to_homeowner BOOLEAN NOT NULL DEFAULT FALSE,
  decided_by UUID REFERENCES users(id),
  decided_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Estimating (Pricebook)
DO $$ BEGIN
  CREATE TYPE uom AS ENUM ('EACH','SQ','LF','BUNDLE','ROLL','HOUR','DAY','TON','YARD');
EXCEPTION WHEN duplicate_object THEN null; END $$;

CREATE TABLE IF NOT EXISTS pricebook_versions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  supplier TEXT,
  effective_from DATE NOT NULL,
  effective_to DATE,
  meta JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(tenant_id, name, effective_from)
);

CREATE TABLE IF NOT EXISTS pricebook_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  pricebook_version_id UUID NOT NULL REFERENCES pricebook_versions(id) ON DELETE CASCADE,
  sku TEXT NOT NULL,
  name TEXT NOT NULL,
  uom uom NOT NULL,
  unit_cost NUMERIC(12,2) NOT NULL,
  coverage_per_unit NUMERIC(12,4),
  waste_pct NUMERIC(5,4) DEFAULT 0,
  category TEXT,
  meta JSONB,
  UNIQUE (tenant_id, pricebook_version_id, sku)
);

CREATE TABLE IF NOT EXISTS estimate_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  parameters JSONB NOT NULL,
  lines JSONB NOT NULL,
  default_target_margin_pct NUMERIC(5,4) NOT NULL DEFAULT 0.30,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS estimate_parameters (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  estimate_id UUID NOT NULL REFERENCES estimates(id) ON DELETE CASCADE,
  key TEXT NOT NULL,
  value TEXT NOT NULL,
  UNIQUE(estimate_id, key)
);

CREATE TABLE IF NOT EXISTS estimate_line_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  estimate_id UUID NOT NULL REFERENCES estimates(id) ON DELETE CASCADE,
  pricebook_item_id UUID REFERENCES pricebook_items(id),
  sku TEXT,
  description TEXT,
  qty NUMERIC(12,4) NOT NULL,
  uom uom,
  unit_cost NUMERIC(12,2) NOT NULL,
  total_cost NUMERIC(12,2) GENERATED ALWAYS AS (qty * unit_cost) STORED,
  category TEXT
);

-- Profit policy + trigger
CREATE TABLE IF NOT EXISTS tenant_profit_policies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  min_margin_pct NUMERIC(5,4),
  min_profit_amount NUMERIC(12,2),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE OR REPLACE FUNCTION fn_estimate_validate_min_profit() RETURNS TRIGGER AS $$
DECLARE
  tpp RECORD;
  overhead NUMERIC(12,2);
  margin_pct NUMERIC(10,6);
  profit_amt NUMERIC(12,2);
BEGIN
  IF NEW.status IN ('SENT','APPROVED') THEN
    SELECT * INTO tpp FROM tenant_profit_policies WHERE tenant_id = NEW.tenant_id ORDER BY created_at DESC LIMIT 1;
    IF tpp IS NOT NULL THEN
      overhead := COALESCE(NEW.selling_price,0) * COALESCE(NEW.overhead_pct,0);
      profit_amt := COALESCE(NEW.selling_price,0) - overhead - COALESCE(NEW.subtotal_cost,0);
      IF COALESCE(NEW.selling_price,0) > 0 THEN
        margin_pct := profit_amt / NEW.selling_price;
      ELSE
        margin_pct := 0;
      END IF;
      IF tpp.min_margin_pct IS NOT NULL AND margin_pct < tpp.min_margin_pct THEN
        RAISE EXCEPTION 'Estimate violates minimum margin %% (got %%, need >= %%)', margin_pct*100, tpp.min_margin_pct*100;
      END IF;
      IF tpp.min_profit_amount IS NOT NULL AND profit_amt < tpp.min_profit_amount THEN
        RAISE EXCEPTION 'Estimate violates minimum profit $ (got %)', profit_amt;
      END IF;
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_estimate_validate_min_profit ON estimates;
CREATE TRIGGER trg_estimate_validate_min_profit
BEFORE UPDATE OF status ON estimates
FOR EACH ROW
EXECUTE FUNCTION fn_estimate_validate_min_profit();

-- Automation
CREATE TABLE IF NOT EXISTS audit_log (
  id BIGSERIAL PRIMARY KEY,
  tenant_id UUID NOT NULL,
  actor_user_id UUID,
  action TEXT NOT NULL,
  entity TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  meta JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Outbox + Idempotency
CREATE TABLE IF NOT EXISTS outbox (
  id BIGSERIAL PRIMARY KEY,
  tenant_id UUID NOT NULL,
  topic TEXT NOT NULL, -- e.g., quickbooks.invoice.create
  payload JSONB NOT NULL,
  status TEXT NOT NULL DEFAULT 'PENDING', -- PENDING, SENT, FAILED
  attempts INT NOT NULL DEFAULT 0,
  idempotency_key TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  sent_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS idempotency_keys (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  key TEXT NOT NULL,
  method TEXT NOT NULL,
  route TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(tenant_id, key, method, route)
);
