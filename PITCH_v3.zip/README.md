# PITCH — Roofing CRM (v3) — **Full Build Plan + Spec**

**One word. Roofing-native. Profit-obsessed.** PITCH tracks profit and projects from contact to close with uncompromising guardrails.

This v3 package consolidates *everything* (base + estimating + payments + portal) and adds:
- RLS policies, indexes, migrations scaffolding
- Outbox/idempotency for webhooks & external sync
- CI, test scaffolds, runbooks, and acceptance criteria
- A step-by-step implementation plan that maps to these files

Start with `docs/MASTER_SPEC.md` and `docs/IMPLEMENTATION_PLAN.md`.
