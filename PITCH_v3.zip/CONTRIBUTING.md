# Contributing & Coding Standards
- TypeScript strict. No `any` in production code.
- All mutations must create an audit_log entry.
- All external calls must include Idempotency-Key and be wrapped by outbox when possible.
- Write tests before adding new commission/estimating rules.
